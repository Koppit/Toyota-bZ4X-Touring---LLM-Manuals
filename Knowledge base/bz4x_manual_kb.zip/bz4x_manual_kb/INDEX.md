# Toyota bZ4X Touring — Manual Knowledge Base

This knowledge base contains the full text of two manuals, split into one file
per section. To answer a question: find the most relevant section(s) below,
then read only those files.

- `owners/` — Owner's Manual (vehicle operation, safety, charging, driving,
  maintenance, troubleshooting, specifications)
- `navigation/` — Navigation & Multimedia Manual (touchscreen, navigation,
  audio, phone/Bluetooth, Apple CarPlay / Android Auto, voice control)

Tip: `owners/00_alphabetical-index.md` is the manual's own alphabetical index
and maps hundreds of keywords to printed page numbers; each section file notes
its printed page range, so the index can be used as a fallback router.

## Owner's Manual

### Front/back matter
- [Pictorial index](owners/00_pictorial-index.md) — pp. 1–29. Covers: For your information; Reading this manual; How to search; Pictorial index
- [For your information](owners/00_for-your-information.md) — pp. 6–10. Covers: For your information
- [Reading this manual](owners/00_reading-this-manual.md) — pp. 11–12. Covers: Reading this manual; How to search

### Chapter 1: For safety and security
- [1-1. For safe use](owners/1-01_for-safe-use.md) — pp. 30–43. Covers: Before driving; For safe driving; Seat belts; SRS airbags
- [1-2. Child safety](owners/1-02_child-safety.md) — pp. 44–68. Covers: Airbag manual on-off system; Riding with children; Child restraint systems
- [1-3. Emergency assistance](owners/1-03_emergency-assistance.md) — pp. 69–82. Covers: eCall; ERA-GLONASS/EVAK
- [1-4. Theft deterrent system](owners/1-04_theft-deterrent-system.md) — pp. 83–89. Covers: Immobilizer system; Double locking system; Alarm

### Chapter 2: Electric Vehicle system
- [2-1. Electric vehicle system](owners/2-01_electric-vehicle-system.md) — pp. 90–102. Covers: Electric Vehicle system features; Electric Vehicle system precautions; Battery Electric Vehicle driving tips; Driving range
- [2-2. Charging (part 1: Charging equipment, …)](owners/2-02_charging__a_charging-equipment.md) — pp. 103–131. Covers: Charging equipment; Locking and unlocking the AC charging connector; Charging methods; Charging tips; Things to know before charging; How to use AC charging; How to use DC charging; Using the charging schedule function
- [2-2. Charging (part 2: Using Battery Preconditioning, …)](owners/2-02_charging__b_using-battery-preconditioning.md) — pp. 132–151. Covers: Using Battery Preconditioning; Using My Room Mode; When charging cannot be carried out

### Chapter 3: Vehicle status information and indicators
- [3-1. Instrument cluster](owners/3-01_instrument-cluster.md) — pp. 152–167. Covers: Warning lights and indicators; Gauges and meters; Multi-information display; Displayed content; Electricity consumption

### Chapter 4: Before driving
- [4-1. Key information](owners/4-01_key-information.md) — pp. 168–172. Covers: Keys; Digital Key
- [4-2. Opening, closing and locking the doors](owners/4-02_opening-closing-and-locking-the-doors.md) — pp. 173–195. Covers: the doors Side doors; Power back door; Smart entry & start system
- [4-3. Adjusting the seats](owners/4-03_adjusting-the-seats.md) — pp. 196–202. Covers: Front seats; Rear seats; Head restraints
- [4-4. Adjusting the steering wheel and mirrors](owners/4-04_adjusting-the-steering-wheel-and-mirrors.md) — pp. 203–217. Covers: Steering wheel; Inside rear view mirror; Digital Rear-view Mirror; Outside rear view mirrors
- [4-5. Opening, closing the windows](owners/4-05_opening-closing-the-windows.md) — pp. 218–220. Covers: Power windows
- [4-6. Favorite settings](owners/4-06_favorite-settings.md) — pp. 221–226. Covers: Driving position memory; My Settings

### Chapter 5: Driving
- [5-1. Before driving](owners/5-01_before-driving.md) — pp. 227–242. Covers: Driving the vehicle; Cargo and luggage; Trailer towing
- [5-2. Driving procedures](owners/5-02_driving-procedures.md) — pp. 243–259. Covers: Power (ignition) switch; Shift position; Turn signal lever; Parking brake; Brake Hold
- [5-3. Operating the lights and wipers](owners/5-03_operating-the-lights-and-wipers.md) — pp. 260–275. Covers: Headlight switch; AHS (Adaptive High-beam System); AHB (Automatic High Beam); Fog light switch; Windshield wipers and washer; Rear window wiper and washer; Headlight cleaner switch
- [5-4. Using the driving support systems (part 1: Toyota Safety Sense software update, …)](owners/5-04_using-the-driving-support-systems__a_toyota-safety-sense-software-update.md) — pp. 276–303. Covers: Toyota Safety Sense software update; Toyota Safety Sense; Driver monitor; PCS (Pre-Collision System); LTA (Lane Tracing Assist)
- [5-4. Using the driving support systems (part 2: LCA (Lane Change Assist), …)](owners/5-04_using-the-driving-support-systems__b_lca-lane-change-assist.md) — pp. 304–334. Covers: LCA (Lane Change Assist); LDA (Lane Departure Alert); PDA (Proactive driving assist); FCTA (Front Crossing Traffic Alert); RSA (Road Sign Assist); Dynamic radar cruise control
- [5-4. Using the driving support systems (part 3: Cruise control (vehicles with Toyota Safety Sense), …)](owners/5-04_using-the-driving-support-systems__c_cruise-control-vehicles-with-toyota.md) — pp. 335–365. Covers: Cruise control (vehicles with Toyota Safety Sense); Cruise control (vehicles without Toyota Safety Sense); Speed limiter; Emergency Driving Stop System; BSM (Blind Spot Monitor); Rear Vehicle Approaching Indication; Automatic Rear Flashing Hazard Lights; Secondary Collision Brake (Rear Impacts while Stopped); Safe Exit Assist
- [5-4. Using the driving support systems (part 4: Toyota parking assist-sensor, …)](owners/5-04_using-the-driving-support-systems__d_toyota-parking-assist-sensor.md) — pp. 366–393. Covers: Toyota parking assist-sensor; RCTA (Rear crossing traffic alert) function; RCD (Rear camera detection); PKSB (Parking Support Brake); the vehicle/static objects around the vehicle); (moving vehicles rear of the vehicle)
- [5-4. Using the driving support systems (part 5: Parking Support Brake function (pedestrians rear of the vehicle), …)](owners/5-04_using-the-driving-support-systems__e_parking-support-brake-function-pedes.md) — pp. 394–432. Covers: Parking Support Brake function (pedestrians rear of the vehicle); Toyota Teammate Advanced Park
- [5-4. Using the driving support systems (part 6: Multi-terrain Monitor, …)](owners/5-04_using-the-driving-support-systems__f_multi-terrain-monitor.md) — pp. 433–496. Covers: Multi-terrain Monitor
- [5-4. Using the driving support systems (part 7: Snow mode, …)](owners/5-04_using-the-driving-support-systems__g_snow-mode.md) — pp. 497–507. Covers: Snow mode; X-MODE; Driving assist systems
- [5-5. Driving tips](owners/5-05_driving-tips.md) — pp. 508–515. Covers: Winter driving tips; Utility vehicle precautions

### Chapter 6: Interior features
- [6-1. Using the air conditioning system and defogger](owners/6-01_using-the-air-conditioning-system-and-defogger.md) — pp. 516–527. Covers: ALL AUTO (ECO) control; Automatic air conditioning system; Heated steering wheel/seat heaters/seat ventilators/radiant heaters
- [6-2. Using the interior lights](owners/6-02_using-the-interior-lights.md) — pp. 528–530. Covers: Interior lights list
- [6-3. Using the storage features](owners/6-03_using-the-storage-features.md) — pp. 531–539. Covers: List of storage features; Luggage compartment features
- [6-4. Using the other interior features](owners/6-04_using-the-other-interior-features.md) — pp. 540–563. Covers: Electronic sunshade; Other interior features; Power outlets (220 VAC 1500 W); 220V/1500 W) cannot be used properly

### Chapter 7: Maintenance and care
- [7-1. Maintenance and care](owners/7-01_maintenance-and-care.md) — pp. 564–570. Covers: Cleaning and protecting the vehicle exterior; Cleaning and protecting the vehicle interior
- [7-2. Maintenance](owners/7-02_maintenance.md) — pp. 571–577. Covers: (except for Eurasian Economic Union); Eurasian Economic Union); Scheduled maintenance
- [7-3. Do-it-yourself maintenance](owners/7-03_do-it-yourself-maintenance.md) — pp. 578–608. Covers: Do-it-yourself service precautions; Hood; Positioning a floor jack; Motor compartment; Tires; Tire inflation pressure; Wheels; Air conditioning filter; Electronic key battery; Checking and replacing fuses; Light bulbs

### Chapter 8: When trouble arises
- [8-1. Essential information](owners/8-01_essential-information.md) — pp. 609–612. Covers: Emergency flashers; If your vehicle has to be stopped in an emergency; water on the road is rising
- [8-2. Steps to take in an emergency (part 1: If your vehicle needs to be towed, …)](owners/8-02_steps-to-take-in-an-emergency__a_if-your-vehicle-needs-to-be-towed.md) — pp. 613–644. Covers: If your vehicle needs to be towed; If you think something is wrong; If a warning light turns on or a warning buzzer sounds; If a warning message is displayed; If you have a flat tire (vehicles with an emergency tire puncture repair kit)
- [8-2. Steps to take in an emergency (part 2: If you have a flat tire (vehicles with a spare tire), …)](owners/8-02_steps-to-take-in-an-emergency__b_if-you-have-a-flat-tire-vehicles-wit.md) — pp. 645–667. Covers: If you have a flat tire (vehicles with a spare tire); If the EV system will not start; If the charging port lids cannot be opened; If you lose your keys; If the electronic key does not operate properly; If the 12-volt battery is discharged; If your vehicle overheats; If the vehicle becomes stuck

### Chapter 9: Vehicle specifications
- [9-1. Specifications](owners/9-01_specifications.md) — pp. 668–674. Covers: Maintenance data
- [9-2. Customization](owners/9-02_customization.md) — pp. 675–689. Covers: Customizable features
- [9-3. Initialization](owners/9-03_initialization.md) — pp. 690–690. Covers: Items to initialize
- [9-4. Free/open source software](owners/9-04_free-open-source-software.md) — pp. 691–696. Covers: Free/open source software information; What to do if... (Troubleshooting)

### Front/back matter
- [Alphabetical Index](owners/00_alphabetical-index.md) — pp. 697–819. Covers: Alphabetical Index
- [CHARGING STATION INFORMATION](owners/00_charging-station-information.md) — pp. 820–820

## Navigation & Multimedia Manual

### Introduction
- [For your information](navigation/00_for-your-information.md) — pp. 7–8. Covers: Multimedia owner’s manual; Disclaimer about data compensation; Removal of the 12-volt battery
- [Safety instructions](navigation/00_safety-instructions.md) — pp. 9–9
- [Reading this manual](navigation/00_reading-this-manual.md) — pp. 10–11. Covers: Symbols in this manual; Symbols in illustrations
- [Pictorial index](navigation/00_pictorial-index.md) — pp. 12–12. Covers: Instrument panel

### 1 Basic operation
- [1-1. Basic operation of multimedia system](navigation/1-01_basic-operation-of-multimedia-system.md) — pp. 14–27. Covers: Display and control; Multimedia screen overview; Main menu; Status icons; Operating the touch screen; Basic screen function; Entering letters and numbers
- [1-2. Basic operation of navigation system](navigation/1-02_basic-operation-of-navigation-system.md) — pp. 28–33. Covers: Map screen; Displaying the vehicle’s current position; Changing the scale of the map; Changing the orientation of the map; Moving the map
- [1-3. Basic operation of audio system](navigation/1-03_basic-operation-of-audio-system.md) — pp. 34–39. Covers: Audio system ON/OFF and volume adjustment; Changing the audio source; Connecting a device via the USB Type-C port
- [1-4. Voice control system](navigation/1-04_voice-control-system.md) — pp. 40–48. Covers: Operating the system with voice control; Starting voice control; Speaking a voice command; Searching for information using the keyboard

### 2 Settings and registration
- [2-1. Multimedia system initial setup](navigation/2-01_multimedia-system-initial-setup.md) — pp. 50–55. Covers: Registering a user profile
- [2-2. Various settings](navigation/2-02_various-settings.md) — pp. 56–57. Covers: Changing the various settings
- [2-3. Driver settings](navigation/2-03_driver-settings.md) — pp. 58–63. Covers: Changing and registering a user profile; Setting up how to identify a driver
- [2-4. General settings](navigation/2-04_general-settings.md) — pp. 64–66. Covers: Changing general multimedia system settings
- [2-5. Screen settings](navigation/2-05_screen-settings.md) — pp. 67–68. Covers: Changing the screen display settings
- [2-6. Voice control settings](navigation/2-06_voice-control-settings.md) — pp. 69–70. Covers: Changing the voice control settings
- [2-7. Vehicle settings](navigation/2-07_vehicle-settings.md) — pp. 71–77. Covers: Setting dealer information; Changing the security settings; Updating and checking the software information
- [2-8. Navigation Settings](navigation/2-08_navigation-settings.md) — pp. 78–90. Covers: Navigation system settings; Changing the map display settings; Route settings; Guidance settings; Traffic settings; Other settings
- [2-9. Sound and media settings](navigation/2-09_sound-and-media-settings.md) — pp. 91–96. Covers: Changing sound and media settings; Switching the screen mode; Adjusting the image quality; Adjusting the sound of each source
- [2-10. Wi-Fi® Settings](navigation/2-10_wi-fi-settings.md) — pp. 97–98. Covers: Changing Wi-Fi® settings
- [2-11. Bluetooth® Settings](navigation/2-11_bluetooth-settings.md) — pp. 99–102. Covers: Setting Bluetooth® devices

### 3 Connecting a smartphone or communication device
- [3-1. Using the Bluetooth® function](navigation/3-01_using-the-bluetooth-function.md) — pp. 104–117. Covers: Precautions when using Bluetooth® devices; Bluetooth® specifications and compatible profiles; Registering a Bluetooth® device from the multimedia system; Deleting a registered Bluetooth® device; Connecting with a Bluetooth® device; Setting a Bluetooth® device as a primary device; Setting a Bluetooth® device as a secondary device
- [3-2. Connecting to a Wi-Fi® network](navigation/3-02_connecting-to-a-wi-fi-network.md) — pp. 118–122. Covers: Precautions when using Wi-Fi® devices; Connecting to a network using Wi-Fi®
- [3-3. Using Apple CarPlay and Android Auto](navigation/3-03_using-apple-carplay-and-android-auto.md) — pp. 123–142. Covers: Precautions when using Apple CarPlay and Android Auto; Using Apple CarPlay with an unregistered smartphone; Using Apple CarPlay with a registered smartphone; Using Android Auto with an unregistered smartphone; Using Android Auto with a registered smartphone; When Apple CarPlay or Android Auto might be malfunctioning

### 4 Navigation
- [4-1. Navigation system](navigation/4-01_navigation-system.md) — pp. 144–145. Covers: About the use of map information provision services using Wi-Fi®; Connected navigation
- [4-2. Map information](navigation/4-02_map-information.md) — pp. 146–154. Covers: Displaying information for a point; Map options screen; Displaying POI icons; Map display settings; Highway mode
- [4-3. Destination search operation](navigation/4-03_destination-search-operation.md) — pp. 155–162. Covers: Searching for a destination; Destination search screen; Search result list screen; Adding a waypoint; Setting destinations from your smartphone
- [4-4. Destination setting](navigation/4-04_destination-setting.md) — pp. 163–169. Covers: Full route map screen; Viewing a route guidance demo; Changing route options; Changing the route; Setting points to pass through on a route; Editing waypoints
- [4-5. Route guidance](navigation/4-05_route-guidance.md) — pp. 170–174. Covers: Route guidance screen; Lane display screens; Searching for a route again; Typical voice guidance prompts
- [4-6. Map update](navigation/4-06_map-update.md) — pp. 175–176. Covers: Map database version and covered area

### 5 Audio
- [5-1. Radio operation](navigation/5-01_radio-operation.md) — pp. 178–181. Covers: Listening to the radio; Listening to DAB
- [5-2. Internet radio](navigation/5-02_internet-radio.md) — pp. 182–182. Covers: Using Internet radio
- [5-3. USB flash drive operation](navigation/5-03_usb-flash-drive-operation.md) — pp. 183–189. Covers: Playing music files on a USB flash drive; Playing video files on a USB flash drive; Precautions for playback of USB flash drive
- [5-4. iPod/iPhone operation](navigation/5-04_ipod-iphone-operation.md) — pp. 190–192. Covers: Playing iPod/iPhone; Precautions for playback of iPod/iPhone
- [5-5. Apple CarPlay operation](navigation/5-05_apple-carplay-operation.md) — pp. 193–195. Covers: Playing Apple CarPlay; Precautions for playback of Apple CarPlay
- [5-6. Android Auto operation](navigation/5-06_android-auto-operation.md) — pp. 196–198. Covers: Playing Android Auto; Precautions for playback of Android Auto
- [5-7. Bluetooth®audio operation](navigation/5-07_bluetoothaudio-operation.md) — pp. 199–203. Covers: Playing Bluetooth® audio; Precautions for Bluetooth® audio playback
- [5-8. Miracast® operation](navigation/5-08_miracast-operation.md) — pp. 204–208. Covers: Connecting Miracast®-compatible devices; Playing Miracast®; Precautions for playback of Miracast®

### 6 Hands-free calls
- [6-1. Precautions when using hands-free calls](navigation/6-01_precautions-when-using-hands-free-calls.md) — pp. 210–217. Covers: Precautions for hands-free calling; When hands-free calling might be malfunctioning
- [6-2. Operating hands-free calls with the steering switches](navigation/6-02_operating-hands-free-calls-with-the-steering-swi.md) — pp. 218–219. Covers: Operating with the steering switches
- [6-3. How to make calls](navigation/6-03_how-to-make-calls.md) — pp. 220–225. Covers: Making calls from call history; Making calls from the favorites list; Making calls from contacts; Making calls from keypad; Calling Toyota roadside assist service; Calling using a wait or pause signal
- [6-4. How to receive calls](navigation/6-04_how-to-receive-calls.md) — pp. 226–228. Covers: Answering calls; Declining calls
- [6-5. In-call operations](navigation/6-05_in-call-operations.md) — pp. 229–234. Covers: Perform operations from the call screen; Answering a second call; Making a call to another party during an ongoing call; Making conference calls; Ending calls
- [6-6. Changing phones for hands-free calls](navigation/6-06_changing-phones-for-hands-free-calls.md) — pp. 235–235. Covers: Switching phones for hands-free calls
- [6-7. Editing contact data](navigation/6-07_editing-contact-data.md) — pp. 236–242. Covers: Transferring contact data; Adding new contact data to contacts; Registering favorites
- [6-8. How to use the message function](navigation/6-08_how-to-use-the-message-function.md) — pp. 243–248. Covers: Precautions when using the message function; Making calls from the message function

### 7 Connected services
- [7-1. Web browser (Internet)](navigation/7-01_web-browser-internet.md) — pp. 250–256. Covers: About web browser (Internet) function; Displaying the web browser screen; Operating the web browser screen

### 8 Parking assist system
- [8-1. Toyota parking assist monitor](navigation/8-01_toyota-parking-assist-monitor.md) — pp. 258–276. Covers: Toyota parking assist monitor functions; Displaying the guide screen; Changing the guide line display mode; Precautions for the Toyota parking assist monitor
- [8-2. Panoramic view monitor](navigation/8-02_panoramic-view-monitor.md) — pp. 277–324. Covers: Panoramic view monitor functions; Display mode when the shift position is in "P"; Display mode when the shift position is in "D" or "N"; Display mode when the shift position is in "R"; The screen when the outside rear view mirrors are folded; Zooming in on the screen; Displaying transparent underfloor vision; Moving objects alert; Changing the panoramic view monitor settings; Precautions for the panoramic view monitor

### 9 Appendix
- [9-1. Appendix](navigation/9-01_appendix.md) — pp. 326–350. Covers: Information about media and data; Certification

### Index
- [Index](navigation/00_index.md) — pp. 351–355
