# 9-3. Initialization

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 9: Vehicle specifications, pages 690–690

690

9-3. Initialization

Items to initialize

9-3.Initialization

The following items must be initialized for normal system operation
after such cases as the 12-volt battery being reconnected, or maintenance being performed on the vehicle:

List of items to initialize
Item

When to initialize

Reference

Power back door

• After reconnecting or changing the
12-volt battery
• After changing a fuse

P.186

Power window

• When functioning abnormally

P.218

Toyota parking
assist-sensor

• If the 12-volt battery was discharged
or has been removed and installed

P.366

Parking Support
Brake function (static • If the 12-volt battery was discharged
objects around the
or has been removed and installed
vehicle)*

P.389

• When the specified tire inflation
pressure has changed, such as due
to carried load, etc.
Tire pressure warning
• When the tire inflation pressure is
system
changed such as when the tire size
is changed.

P.594

*: If equipped
