# 9-4. Free/open source software

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 9: Vehicle specifications, pages 691–696

9-4. Free/open source software

691

Free/open source software information

9-4.Free/open source software

Water pump
This product (inverter water pump for AWD/4WD vehicles) includes software that is licensed under open-source software.
You can find license information for this free and open-source software at the following URL.
https://www.aisin.com/info/ewp/license001.html

eCall
This product contains Free/Open Source Software (FOSS).
The license information and/or the source code of such FOSS can be found at the
following URL.
http://www.opensourceautomotive.com/dcm/19MC/

Digital Key
This product contains Free/open source software (FOSS).
License information and/or the source code of this FOSS can be obtained at the following URL:
https://www.denso.com/global/en/opensource/dkey/toyota/

Multi-terrain Monitor

9

Vehicle specifications

692

9-4. Free/open source software

693

Index

.

What to do if... (Troubleshooting) .................................694
Alphabetical Index ............697

694

What to do if... (Troubleshooting)

What to do if... (Troubleshooting)
1-1.What to do if... (Troubleshooting)

If you have a problem, check
the following before contacting
any authorized Toyota retailer
or Toyota authorized repairer,
or any reliable repairer.

The doors cannot be locked,
unlocked, opened or closed
You lose your keys

 If you lose your mechanical keys,
new genuine keys can be made
by any authorized Toyota retailer
or Toyota authorized repairer, or
any reliable repairer. (P.655)
 If you lose your electronic keys,
the risk of vehicle theft increases
significantly. Contact any authorized Toyota retailer or Toyota
authorized repairer, or any reliable repairer immediately.
(P.655)
The doors cannot be locked
or unlocked

 Is the electronic key battery
weak or depleted? (P.604)
 Is the power switch in ON?
When locking the doors, turn the
power switch off. (P.246)
 Is the electronic key left inside
the vehicle?
When locking the doors, make sure that

you have the electronic key on your
person.

 The function may not operate
properly due to the condition of
the radio wave. (P.192)
The rear door cannot be
opened

 Is the child-protector lock set?
The rear door cannot be opened from
inside the vehicle when the lock is set.
Open the rear door from outside and
then unlock the child-protector lock.
(P.177)

If you think something is
wrong
The EV system does not
start

 Is the charging cable attached to
the vehicle? (P.112)
 Did you press the power switch
while firmly depressing the brake
pedal? (P.243)
 Is the shift position in P?
(P.248)
 Is the electronic key anywhere
detectable inside the vehicle?
(P.191)
 For right-hand drive vehicles
only: Is the steering wheel
unlocked? (P.244)
 Is the electronic key battery

What to do if... (Troubleshooting)

weak or depleted?
In this case, the EV system can be
started in a temporary way. (P.657)

 Is the 12-volt battery discharged? (P.658)
The steering wheel cannot
be turned after the EV system is stopped (for
right-hand drive vehicle
only)

 It is locked automatically to prevent theft of the vehicle.
(P.244)
The windows do not open or
close by operating the
power window switches

Are the driver and the passengers
wearing the seat belts? (P.621, 621)

 The parking brake indicator is on
Is the parking brake released?
(P.256)

Depending on the situation, other
types of warning buzzer may also
sound. (P.619, 627)
An alarm is activated and the
horn sounds (vehicles with
an alarm)

 Did anyone inside the vehicle
open a door during setting the
alarm?
The sensor detects it and the alarm
sounds. (P.85)

 Is the window lock switch
pressed?

Do one of the following to deactivate or stop the alarms:

The power window except for the one
at the driver’s seat cannot be operated
if the window lock switch is pressed.
(P.220)

 Unlock the doors or open the
back door using the entry function or wireless remote control.

The power switch is turned
off automatically

 The auto power off function will
be operated if the vehicle is left
in ACC or ON (the EV system is
not operating) for a period of
time. (P.246)
A warning buzzer sounds
during driving

 The seat belt reminder light is
flashing

695

 Start the EV system. (The alarm
will be deactivated or stopped
after a few seconds.)
A warning buzzer sounds
when leaving the vehicle

 Is the message displayed on the
multi-information display?
Check the message on the multi-information display. (P.627)
A warning light turns on or a
warning message is displayed

696

What to do if... (Troubleshooting)

 When a warning light turns on or
a warning message is displayed,
refer to P.619, 627.

When a problem has
occurred
If you have a flat tire

 Vehicles with the emergency tire
puncture repair kit
Stop the vehicle in a safe place and
repair the flat tire temporarily with the
emergency tire puncture repair kit.
(P.634)

 Vehicles with a spare tire
Stop the vehicle in a safe place and
replace the flat tire with the spare tire.
(P.645)
The vehicle becomes stuck

 Try the procedure for when the
vehicle becomes stuck in mud,
dirt, or snow. (P.665)
