# 2-1. Electric vehicle system

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 2: Electric Vehicle system, pages 90–102

90

2-1. Electric vehicle system

Electric Vehicle system features

2-1.Electric vehicle system

Battery electric vehicles are considerably different from conventional vehicles.
They use electricity charged in a traction battery, to drive the electric motor. Since battery electric vehicles are driven using electricity, they do not emit any emissions such as CO2 (Carbon Dioxide)
and NOx (Nitrogen Oxides). Battery electric vehicles are environmentally friendly vehicles.

System components

The illustration is an example for explanation and may differ from the actual item.

A ESU: Electricity Supply Unit (built in onboard traction battery
charger/DC-DC converter)
B eAxle (Traction motor/Inverter/Transaxle) (front/rear*)
C Traction battery
Provides electricity to the electric motor.

Charging port
12-volt battery

2-1. Electric vehicle system

91

Provides electricity to various vehicle systems such as the SRS airbags, headlights,
wipers, etc.
*: AWD models only

n When braking (regenerative

braking)

l The accelerator pedal is released

while driving with the shift position in
D.

The electric motor (traction motor)
charges the traction battery.

l The brake pedal is depressed while

The driving range can be extended
by actively using this regenerative
braking to store electricity in the
traction battery.

n Charging the 12-volt battery
The 12-volt battery is charged from the
traction battery when the EV system is
operated or while the traction battery is
being charged.
If the vehicle has not been used for a
long time, the 12-volt battery may
become low due to self-discharge. If this
occurs, follow the correct procedures.
(P.658)

The battery electric vehicle is
driven using electricity, which is
received from an external power
source and stored in the traction
battery. Not only public charging
stations, but also household sockets can be used for charging. Procedures are different from refueling
a conventional vehicle. Therefore,
make sure to read the following
thoroughly.
 Charging equipment (P.103)
 Things to know before charging
(P.112)
 How to charge your vehicle
(P.115, 120)
 When charging cannot be performed normally (P.139)
n Regenerative braking
In the following situations, kinetic energy
is converted to electric energy and
deceleration force can be obtained in
conjunction with the recharging of the
traction battery.

n When not using the vehicle for an
extended period of time

l When the vehicle will not be used for

an extended period of time, charge
the traction battery once a month.
This protects the traction battery from
extreme voltage decline due to self
discharging.

l When the vehicle will not be used for
an extended period of time, the
12-volt battery will be charged from
the traction battery to reduce the risk
of the 12-volt battery discharged. In
this case, the cooling fan may operate, however it is not a malfunction.

l To prevent the 12-volt battery from

being discharged, do not leave the
charging port lid open or the charging
cable connected to the vehicle.
When it is not necessary to have the
charging cable connected, keep it disconnected from the vehicle.

n Charging the traction battery
Be sure to maintain the traction battery
charge level suitable for your driving
needs.
If the traction battery fully discharges,
the vehicle cannot be driven at all. When
the battery becomes low, charge it as

2

Electric Vehicle system

Charging

driving with the shift position in D.

92

2-1. Electric vehicle system

soon as possible.

n If the traction battery becomes low
l If the traction battery becomes low,
the traction battery charge warning
light comes on or flashes and a message will be displayed on the
multi-information display. (P.621)

l If the traction battery is completely

discharged, the EV system cannot be
started and driving will not be possible. When the traction battery
becomes low, charge it as soon as
possible.

n Sounds and vibrations specific to

an electric vehicle
Because there is no engine sound or
vibration, it is easy to mistake the battery electric vehicle for being off when it
is actually still running, as indicated by
the “READY” indicator being illuminated.
For safety, make sure to always shift the
shift position to P and apply the parking
brake when parked.
Before and after the EV system is
started, the following sounds and vibrations may occur. However, these sounds
and/or vibrations are not signs of malfunctions:

l The brake system operation sound
may be heard from the front of the
vehicle when the driver’s door is
opened.

l Motor sounds may be heard from the
motor compartment or luggage compartment.

l Electrical relay sounds may be heard

from the motor compartment when the
EV system starts or stops.

l Relay operating sounds such as a

snap or soft clank will be emitted from
the traction battery in the following situations:
• When the EV system is started or
stopped
• When charging starts or completes
• When the vehicle is driven the first
time after the traction battery has
been charged using DC charging

l Sounds may be heard due to regenerative braking when the brake pedal is
depressed or as the accelerator pedal
is released.

l Cooling fan operating sounds from the
radiator.

l The operation sound of the air conditioning system (air conditioning compressor, blower motor).

n Maintenance, repair, recycling, and

disposal
Contact any authorized Toyota retailer
or Toyota authorized repairer, or any reliable repairer regarding maintenance,
repair, recycling and disposal. Do not
dispose of the vehicle yourself.

Acoustic Vehicle Alerting
System
A sound which changes in accordance with the driving speed, will be
played in order to warn people
nearby of the vehicle’s approach.
This sound may be heard inside the
vehicle. The sound will stop when
the vehicle speed exceeds approximately 25 km/h (15 mph).
n Acoustic Vehicle Alerting System
In the following cases, the Acoustic
Vehicle Alerting System may be difficult
for surrounding people to hear.
l In very noisy areas
l In the wind or the rain
Also, as the Acoustic Vehicle Alerting
System is installed on the front of the
vehicle, it may be more difficult to hear
from the rear of the vehicle compared to
the front.

2-1. Electric vehicle system

93

n When the multi-information dis-

play shows “Acoustic Vehicle
Alerting System Malfunction Visit
your Dealer”
There is a possibility that there is an
abnormality in the Acoustic Vehicle
Alerting System. Please contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
2

Electric Vehicle system

94

2-1. Electric vehicle system

Electric Vehicle system precautions
Be careful of the high voltage components (nominal voltage at 391.0
V), such as the traction battery, electricity supply unit, orange
colored high voltage cables, and electric motor, as well as high temperature components such as the cooling radiator, which are provided on the battery electric vehicle. Read the following
descriptions carefully before using the EV system, and handle the
EV system correctly. Note that warning labels with a
mark are
attached to the high voltage components to remind you of careful
handling required.

System components

The illustration is an example for explanation and may differ from the actual item.

A High voltage cables (orange)
B ESU: Electricity Supply Unit (built in onboard traction battery
charger/DC-DC converter)
C Service plug

AC charging inlet

2-1. Electric vehicle system

95

DC charging inlet
Traction battery
eAxle (Traction motor/Inverter/Transaxle) (front/rear*)
Air conditioning compressor
*

: AWD models only

n Electromagnetic waves
l High-voltage parts and cables on the

l Your vehicle may cause sound inter-

ference in some third party-produced
radio parts.

n Traction battery (Lithium-ion bat-

tery)
The traction battery has a limited service
life.
The traction battery capacity (the ability
to store energy) reduces with time and
use in the same way as other rechargeable batteries. The extent at which
capacity reduces changes drastically
depending on the environment (outside
temperature, etc.) and usage conditions,
such as how the vehicle is driven and
how the traction battery is charged.
This is a natural characteristic of lithium-ion batteries, and is not a malfunction. Also, even though the driving range
decreases when the traction battery
capacity reduces, vehicle performance
does not significantly become worse. In
order to reduce the possibility of the
capacity reducing, follow the directions
listed on P.113, “Capacity reduction of
the traction battery”.

n Starting the EV system in an

extremely cold environment
When the traction battery is extremely
cold (below approximately -30°C
[-22°F]) due to the temperature outside
of the vehicle, it may not be possible to

n Declaration of conformity
This model conforms to hydrogen emissions according to regulation ECE100
(Battery electric vehicle safety).

WARNING
n High-voltage precautions
The vehicle has high voltage DC and
AC systems as well as a 12-volt system.
DC and AC high voltage systems are
very dangerous and can cause
severe burns and electric shock that
may result in death or serious injury.
l Never touch, disassemble, remove,
or replace the high voltage parts,
cables (orange) or their connectors.
l Do not touch the high voltage components. They are extremely hot,
especially after driving.

l The service plug is located under

the console box. The service plug is
used only when the vehicle is being
serviced and is subject to high voltage.

2

Electric Vehicle system

battery electric vehicles incorporate
electro-magnetic shielding, and therefore emit approximately the same
amount of electromagnetic waves as
conventional gasoline-powered vehicles or home electronic appliances.

start the EV system. In this case, try to
start the EV system again after the temperature of the traction battery increases
due to the outside temperature increasing, etc.

96

2-1. Electric vehicle system

WARNING
n Road accident cautions
Observe the following precautions to
reduce the risk of death or serious
injury:
l Stop the vehicle in a safe place to
prevent subsequent accidents.
While depressing the brake pedal,
apply the parking brake and shift
the shift position to P to stop the EV
system. Then, slowly release the
brake pedal.

l Do not touch the high voltage parts,
cables (orange) and connectors.

l If electric wires are exposed inside
or outside your vehicle, an electric
shock may occur. Never touch
exposed electric wires.

l Do not touch the traction battery if

liquid is leaking from or adhered to
it. If electrolyte (Organic Carbonate-based electrolyte) from the
traction battery comes into contact
with the eyes or skin, it could cause
blindness or skin wounds. In the
unlikely event that it comes into
contact with the eyes or skin, wash
it off immediately with a large
amount of water, and seek immediate medical attention.

l If electrolyte is leaking from the

traction battery, do not approach
the vehicle.
Even in the unlikely event that the
traction battery has been damaged,
the internal construction of the battery will prevent a large amount of
electrolyte from leaking out. However, if electrolyte leaks, vapors will
be emitted. These vapors are an
irritant to skin and eyes and could
cause acute poisoning if inhaled.

l Do not bring burning or high-tem-

perature items close to the electrolyte. The electrolyte may ignite and
cause a fire.

l If a fire occurs in the battery electric

vehicle, leave the vehicle as soon
as possible. Never use a fire extinguisher that is not meant for electrical fires. Using even a small
amount of water may be dangerous.

l If your vehicle needs to be towed,

be sure to transport the vehicle with
the front wheels (2WD models) or
four wheels (AWD/4WD models)
raised. If the vehicle is towed with
the wheels which are connected to
the electric motor (traction motor)
contacting the ground, electricity
generated by the operation of the
motor may cause a fire to occur
depending on the nature of the
damage or malfunction. (P.613)

l Carefully inspect the ground under

the vehicle. If leaked liquid (other
than water from the air conditioning) is found on the ground, the
traction battery may have been
damaged. Leave the vehicle as
soon as possible.
In addition, contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer
with regard to the leakage found on
the ground.
Even in the event of a minor accident, the traction battery and surrounding parts may be damaged. In
case of an accident, have the traction battery inspected at any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

n Traction battery
l Your vehicle contains a sealed lithium-ion battery.

2-1. Electric vehicle system

WARNING
l Never resell, hand over or modify

• The traction battery is intended to
be used exclusively with your battery electric vehicle. If the traction
battery is used outside of your vehicle or modified in any way, accidents such as electric shock, heat
generation, smoke generation, an
explosion and electrolyte leakage
may occur. When reselling or handing over your vehicle, the possibility
of an accident is extremely high
because the person receiving the
vehicle may not be aware of the
dangers from these modifications.

l If your vehicle is disposed of with-

out the traction battery having been
removed, there is a danger of serious electric shock if high voltage
parts, cables and their connectors
are touched. In the event that your
vehicle must be disposed of, the
traction battery must be disposed of
by any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer or a qualified service shop. If the traction battery is
not disposed of properly, it may
cause electric shock that can result
in death or serious injury.

l For information about traction bat-

tery collection locations, contact
information, or the recycling process, contact any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.

n Caution while driving
l Pay special attention to the area

around the vehicle. Because there
is no engine noise, pedestrians,
people riding bicycles or other people and vehicles in the area may
not be aware of the vehicle starting
off or approaching them, so take
extra care while driving. Therefore,
take extra care while driving even if
the Acoustic Vehicle Alerting System is active.

l If the vehicle under floor area

receives strong shock or impact
while driving, stop the vehicle in a
safe place and check around the
bottom of the vehicle. If there is
damage to the traction battery or
liquid leakage, it may lead to a vehicle fire, etc. Do not touch the vehicle and immediately contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
Even if no damage can be seen
under the floor, the traction battery
may be damaged. If the vehicle
received an impact under the floor,
have the traction battery inspected
at any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer.

n Modifications
Do not make modifications that lower
the height of the vehicle. The traction
battery in the under floor area may
come into contact with the ground
when the height of vehicle is lowered.
If the traction battery is damaged, a
vehicle fire may occur, possibly resulting in death or serious injury.

2

Electric Vehicle system

the traction battery. To prevent accidents, traction batteries that have
been removed from a disposed
vehicle are collected through any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer. Do not dispose of the battery yourself. Unless the battery is
properly collected, the following
may occur, resulting in death or
serious injury:
• Do not illegally dispose of or dump
the traction battery, and it is hazardous to the environment or someone
may touch a high voltage part,
resulting in an electric shock.

97

98

2-1. Electric vehicle system

Emergency shut off system
When a certain level of impact is
detected by the impact sensors, the
emergency shut off system turns off
the EV system and blocks the high
voltage current. If the emergency
shut off system activates, your vehicle will not restart. To restart the EV
system, contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

Warning message
A message is automatically displayed when a malfunction occurs
in the EV system or an improper
operation is attempted.

If a warning message is shown on
the multi-information display, read
the message and follow the instructions. (P.146, 627)
n If a warning light comes on, a warn-

ing message is displayed, or the
12-volt battery is disconnected
The EV system may not start.
In that case, try to start the system
again. If the “READY” indicator does not
come on, contact any authorized Toyota
retailer or Toyota authorized repairer, or

any reliable repairer.

n When the traction battery is com-

pletely discharged
When the EV system cannot be started
due to the traction battery being completely discharged, restart the system
after AC charging or DC charging. When
charging, it is recommended to charge
the traction battery until the traction battery charge warning light turns off in
order to ensure sufficient driving distance.

2-1. Electric vehicle system

tion battery electricity is consumed.
(P.248)

Unlike the conventional vehicles, the electricity consumption efficiency of battery
electric vehicles will decline if
they continue driving on highways (or freeways) or at high
average speeds, causing the
possible driving distance to
reduce. Therefore, if the
remaining charge of the traction battery is low, avoid relying on the displayed possible
driving distance too much as
well as driving on highways (or
freeways). Driving the vehicle
at moderate speeds, the traction battery’s electricity consumption can be controlled.

Delays

The following driving tips will
contribute to reduction in the
battery consumption and
increase in the driving range.

Shift position operation
Shift the shift position to D when
stopped at a traffic light, or driving
in heavy traffic, etc. Shift the shift
position to P when parking. When
shifting the shift position to N while
driving, there is no positive effect
on electricity consumption. In the N,
the traction battery cannot be
charged. Also, when using the air
conditioning system, etc., the trac-

Repeated acceleration and deceleration due to traffic congestion,
long waits at traffic lights, and driving on steep inclines will lead to
poor electricity consumption. In
order to avoid those situations as
much as possible, check traffic
reports before leaving. If the vehicle
is driven in traffic congestion, gently
release the brake pedal to allow the
vehicle to move forward slightly,
avoid overuse of the accelerator
pedal. Doing so can help minimize
unnecessary electricity consumption.

When braking
Make sure to operate the brakes
gently and a timely manner. A
greater amount of electrical energy
can be regenerated when slowing
down.

Highway (or freeways) driving
Control and maintain the vehicle at
a constant speed. Before stopping
at a toll booth or similar, allow
plenty of time to release the accelerator and gently apply the brakes.
A greater amount of electrical
energy can be regenerated when
slowing down.

2

Electric Vehicle system

Battery Electric Vehicle
driving tips

99

100

2-1. Electric vehicle system

Air conditioning

Luggage

 Use the air conditioning only
when necessary. Doing so can
help reduce excessive electricity
consumption.

Carrying heavy luggage will lead to
poor electricity consumption. Avoid
carrying unnecessary luggage.

In summer: When the ambient temperature is high, use the recirculated air
mode. Doing so will help to reduce the
burden on the air conditioning system
and reduce electricity consumption as
well.
In winter: Excessive or unnecessary
heating should be avoided. Also, electricity consumption can be improved by
avoiding overuse of the heater.

 When the ALL AUTO (ECO)
switch on the air conditioner
operation switch is turned ON,
the air conditioning system prioritizes the use of direct heating
such as seat heaters to warm the
surroundings of the occupants
and reduce electricity consumption by the air conditioner.

Checking tire inflation pressure
Make sure to check the tire inflation
pressure frequently. Improper tire
inflation pressure can cause poor
electricity consumption.
Also, as snow tires can cause large
amounts of friction, their use on dry
roads will lead to poor electricity
consumption. Use tires that are
appropriate for the season.

2-1. Electric vehicle system

Driving range
The driving range displayed on
the multi-information display,
etc., shows the reference distance that driving is possible,
and the actual distance that
can be driven may differ from
that displayed.

A value for which a sufficient level
of driving performance can be provided is estimated based on the
remaining charge of the traction
battery, the state of the traction battery, the outside temperature, etc.,
and is displayed on the multi-information display. (P.156)

Possible driving distance could be
extended if the followings are performed:
 Maintain a safe distance from the
vehicle in front and avoid unnecessary acceleration and deceleration
 Accelerate and decelerate the
vehicle as smoothly as possible
 Drive at moderate speeds as
much as possible and maintain a
constant speed
 Set the air conditioning system to
a moderate temperature and
avoid using the heating and cooling functions excessively.
 Use tires of the specified size
and maintain the specified tire
pressure

When the outside temperature is
low, the traction battery output may
be decreased, causing the possible
driving distance to be shorter. However, this is not a malfunction.
Charge the traction battery earlier
than usual.

 Do not add unnecessary weight
to the vehicle

Tips for extending the driving range

 The charging indicator turns off

Possible driving distance varies significantly depending on how the
vehicle is driven, road conditions,
the weather, the outside temperature, usage conditions of electrical
components and the number of
occupants.

Display when charging is
completed
The followings indicate that charging has been carried out properly.
 “Charging Complete” is displayed on the multi-information
display when a door is opened
while the power switch is off.
(P.111)
Regardless of the type of power
source or whether the charging
schedule function is used, charging is completed if the above can

2

Electric Vehicle system

Displayed value

101

102

2-1. Electric vehicle system

be confirmed.
Charging-related messages:
P.146
