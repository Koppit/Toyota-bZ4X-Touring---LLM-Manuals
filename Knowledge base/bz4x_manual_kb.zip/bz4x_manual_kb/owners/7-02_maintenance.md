# 7-2. Maintenance

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 7: Maintenance and care, pages 571–577

7-2. Maintenance

Maintenance requirements (except for Eurasian Economic Union)

571

7-2.Maintenance

To ensure safe and economical
driving, day-to-day care and
regular maintenance are
essential. Toyota recommends
the maintenance below.
n Where to go for maintenance ser-

WARNING
n If your vehicle is not properly

maintained
Improper maintenance could result in
serious damage to the vehicle and
possible death or serious injury.

Scheduled maintenance
Scheduled maintenance should be
performed at specified intervals
according to the maintenance
schedule.
For full details of your maintenance
schedule, read the “Toyota Service
Booklet” or “Toyota Warranty Booklet”.

Do-it-yourself maintenance
What about do-it-yourself maintenance?
Many of the maintenance items are
easy to do yourself if you have a little
mechanical ability and a few basic
automotive tools.
Note, however, that some maintenance
tasks require special tools and skills.
These are best performed by qualified
technicians. Even if you’re an experienced do-it-yourself mechanic, we recommend that repairs and maintenance
be conducted by any authorized Toyota
retailer or Toyota authorized repairer, or
any reliable repairer. Any authorized
Toyota retailer or repairer will keep a
record of maintenance, which could be
useful should you ever require Warranty Service. Should you choose to
select a qualified and equipped professional other than an authorized Toyota
repairer to service or maintain your
vehicle, we recommend that you

7

Maintenance and care

vice?
In order to maintain your vehicle in the
best possible condition, Toyota recommends that maintenance service operations as well as other inspections and
repairs be carried out by authorized
Toyota retailers or Toyota authorized
repairers, or any reliable repairers. For
repairs and services covered by your
warranty, please visit an authorized
Toyota retailer or repairer, who will use
genuine Toyota parts in repairing any
difficulties you may encounter. There
can also be advantages in utilizing
authorized Toyota retailers or repairers
for non-warranty repairs and services,
as members of the Toyota network will
be able to expertly assist you with any
difficulties you may encounter.
Your Toyota retailer or Toyota authorized
repairer, or any reliable repairer will perform all of the scheduled maintenance
on your vehicle reliably and economically due to their experience with Toyota
vehicles.

n Handling of the 12-volt battery
12-volt battery posts, terminals and
related accessories contain lead and
lead compounds which are known to
cause brain damage. Wash your
hands after handling. (P.585)

572

7-2. Maintenance

request that a record of maintenance
be kept.

n Does your vehicle need repairs?
Be on the alert for changes in performance and sounds, and visual tip-offs
that indicate service is needed. Some
important clues are:

l Appreciable loss of power
l Strange noises
l A fluid leak under the vehicle (How-

ever, water dripping from the air conditioning system after use is normal.)

l Flat-looking tires, excessive tire

squeal when cornering, uneven tire
wear

l Vehicle pulls to one side when driven
straight on a level road

l Strange noises related to suspension
movement

l Loss of brake effectiveness, spongy

feeling brake pedal, pedal almost
touches the floor, vehicle pulls to one
side when braking
If you notice any of these clues, take
your vehicle to any authorized Toyota
retailer or Toyota authorized repairer, or
any reliable repairer as soon as possible. Your vehicle may need adjustment
or repair.

Maintenance requirements (For Eurasian
Economic Union)
To ensure safe and economical
driving, day-to-day care and
regular maintenance are
essential. Toyota recommends
the maintenance below.
WARNING
n If your vehicle is not properly

maintained
Improper maintenance could result in
serious damage to the vehicle and
possible death or serious injury.

n Handling of the 12-volt battery
12-volt battery posts, terminals and
related accessories contain lead and
lead compounds which are known to
cause brain damage. Wash your
hands after handling. (P.585)

Scheduled maintenance
 Scheduled maintenance should
be performed at specified intervals according to the maintenance schedule.
The interval for scheduled maintenance
is determined by the odometer reading
or the time interval, whichever comes
first, shown in the schedule.
Maintenance beyond the last period
should be performed at the same intervals.

 Where to go for maintenance
service?
It makes good sense to take your vehicle to your local Toyota dealer for maintenance service as well as other

7-2. Maintenance
inspections and repairs.
Toyota technicians are well-trained specialists receiving the latest service information through technical bulletins,
service tips and in-dealership training
programs. They learn to work on Toyota
before they work on your vehicle, rather
than while they are working on it.
Doesn’t that seem like the best way?
Your Toyota dealer has invested a lot of
money in special Toyota tools and service equipment. It helps them to do the
job better and at less cost.
Your Toyota dealer’s service department will perform all of the scheduled
maintenance on your vehicle reliably
and economically.
Rubber hoses (for cooling, heater system and brake system) should be
inspected by a qualified technician
according to the Toyota maintenance
schedule.
Rubber hoses are particularly important
maintenance items. Have any deteriorated or damaged hoses replaced
immediately. Note that rubber hoses
will deteriorate with age, resulting in
swelling, chafing or cracking.

What about do-it-yourself maintenance?
Many maintenance items are easy to
do yourself if you have a little mechanical ability and a few basic automotive
tools.
Note, however, that some maintenance
tasks require special tools and skills.
These are best performed by qualified
technicians. Even if you are an experienced do-it-yourself mechanic, we rec-

ommend that repairs and maintenance
be conducted by your Toyota dealer
who will keep a record of maintenance
on your vehicle. This record could be
helpful should you ever require Warranty Service.

n Does your vehicle need repairs?
Be on the alert for changes in performance and sounds, and visual tip-offs
that indicate service is needed. Some
important clues are:

l Appreciable loss of power
l Strange noises
l A fluid leak under the vehicle (How-

ever, water dripping from the air conditioning system after use is normal.)

l Flat-looking tires, excessive tire

squeal when cornering, uneven tire
wear

l Vehicle pulls to one side when driven
straight on a level road

l Strange noises related to suspension
movement

l Loss of brake effectiveness, spongy

feeling brake pedal, pedal almost
touches the floor, vehicle pulls to one
side when braking
If you notice any of these clues, take
your vehicle to your Toyota dealer as
soon as possible. Your vehicle may
need adjustment or repair.

7

Maintenance and care

Do-it-yourself maintenance

573

574

7-2. Maintenance

Scheduled maintenance (For Eurasian EconomicUnion)
Perform maintenance by the schedule as follows:

Maintenance schedule requirements
Your vehicle needs to be serviced according to the normal maintenance schedule.
(See “Maintenance schedule”.)

If you mainly operate your vehicle under one or more of the special operating conditions below, some of the maintenance schedule items need to be
serviced more frequently in order to keep your vehicle in good condition.
(See “Additional maintenance schedule”.)
B. Driving Conditions
A. Road Conditions
1. Operating on rough or muddy roads,
or roads with melted snow or waterlogged roads.

1. Heavily loaded vehicle. (Example :
Towing a trailer, using a camper, using a
car top carrier, etc.)
2. Extensive idling and/or low speed driving for a long distance such as police,
professional/private use like taxi or
door-to-door delivery use.

2. Operating on dusty roads. (Roads in
areas where their pavement rate is low,
or a cloud of dust often arises and the air
3. Continuous high speed driving (80%
is dry.)
or more of maximum vehicle speed) for
over 2 hours.

Maintenance schedule
Maintenance operations:
I = Inspect, correct or replace as necessary
R = Replace, change or lubricate

575

7-2. Maintenance
SERVICE INTERVAL:

ODOMETER READING

(Odometer reading x1000 km
or months, whichever comes first.) x1000 miles

10 20 30 40 50 60 70 80
6

MONTHS

12 18 24 30 36 42 48

COOLANT AND 12-VOLT BATTERY
1 Heater coolant <<See note 1.>>
2 12-volt battery
3

I
I

I

I

Traction battery coolant <<See
note 1.>>

I

I

I

I

I

I

—

I

12

I

—

CHASSIS AND BODY
4

Brake pedal and parking brake
<<See note 2.>>

I

I

I

I

I

I

I

I

6

5 Brake pads and discs

I

I

I

I

I

I

I

I

12

6 Brake fluid

I

I

I

R

I

I

I

R

7 Brake pipes and hoses
8

Steering wheel, linkage and
steering gear box

9 Drive shaft boots
10

Suspension ball joints and dust
covers

I

I

I

12

I

I

I

I

12

I

I

I

I

24

I

I

I

I

12

I

24

I

12

I

14

Lights, horns, wipers and washers

15 Air conditioning filter

I

I

I

I

I

I

I

I

I

I

I

6

I

I

I

I

I

I

I

I

6

R

—

I

24

R

16 Corrosion inspection

R
I

R

NOTE:
1. First replace at 200000 km (120000 miles), then replace every 80000 km
(50000 miles).
2. Parking brake inspection is not necessary.

7

Maintenance and care

13 Tires and inflation pressure

R: 24

I

11 e-Transaxle fluid
12 Front and rear suspension

I: 6

576

7-2. Maintenance

Additional maintenance schedule
Refer to the following table for normal maintenance schedule items requiring more frequent service specific to the type of severe conditions. (For outline, see “Maintenance schedule requirements”.)
A-1: Operating on rough or muddy roads, or roads with melted snow or waterlogged
roads.
 Inspection* of brake pads and discs

Every 5000 km (3000 miles) or 6 months

 Inspection* of brake pipes and hoses

Every 10000 km (6000 miles) or 6
months

 Inspection* of steering wheel, linkage
and steering gear box

Every 5000 km (3000 miles) or 3 months

 Inspection* of drive shaft boots

Every 10000 km (6000 miles) or 12
months

 Inspection* of suspension ball joints
and dust covers

Every 10000 km (6000 miles) or 6
months

 Inspection* of front and rear suspension

Every 10000 km (6000 miles) or 6
months

 Tightening of bolts and nuts on chassis Every 10000 km (6000 miles) or 6
and body <<See note>>
months
A-2: Operating on dusty roads. (Roads in areas where their pavement rate is low, or
a cloud of dust often arises and the air is dry.)
 Replacement of air conditioner filter

Every 15000 km (9000 miles)

 Inspection* of brake pads and discs

Every 5000 km (3000 miles) or 6 months

B-1: Heavily loaded vehicle. (Example : Towing a trailer, using a camper, using a car
top carrier, etc.)
 Inspection* of brake pads and discs
 Inspection* or replacement of
e-Transaxle fluid

Every 5000 km (3000 miles) or 6 months
I: Every 40000 km (24000 miles) or 24
months
R: Every 80000 km (48000 miles) or 48
months

7-2. Maintenance

577

B-1: Heavily loaded vehicle. (Example : Towing a trailer, using a camper, using a car
top carrier, etc.)
 Inspection* of front and rear suspension

Every 10000 km (6000 miles) or 6
months

 Tightening of bolts and nuts on chassis Every 10000 km (6000 miles) or 6
and body <<See note>>
months
B-2: Extensive idling and/or low speed driving for a long distance such as police,
professional/private use like taxi or door-to-door delivery use.
 Inspection* of brake pads and discs

Every 5000 km (3000 miles) or 6 months

B-3: Continuous high speed driving (80% or more of maximum vehicle speed) for
over 2 hours.
 Inspection* or replacement of
e-Transaxle fluid

I: Every 40000 km (24000 miles) or 24
months
R: Every 80000 km (48000 miles) or 48
months

NOTE:
For seat mounting bolts, front and rear suspension member retaining bolts.
*: Perform correction or replacement as necessary.

7

Maintenance and care
