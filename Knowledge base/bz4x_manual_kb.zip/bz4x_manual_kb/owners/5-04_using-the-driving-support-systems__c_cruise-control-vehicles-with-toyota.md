# 5-4. Using the driving support systems (part 3: Cruise control (vehicles with Toyota Safety Sense), …)

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 335–365
> Topics in this part: Cruise control (vehicles with Toyota Safety Sense); Cruise control (vehicles without Toyota Safety Sense); Speed limiter; Emergency Driving Stop System; BSM (Blind Spot Monitor); Rear Vehicle Approaching Indication; Automatic Rear Flashing Hazard Lights; Secondary Collision Brake (Rear Impacts while Stopped); Safe Exit Assist

5-4. Using the driving support systems

Cruise control (vehicles
with Toyota Safety
Sense)

l When it is necessary to disable the

The vehicle can be driven at a
set speed even if the accelerator pedal is not depressed.

n Meter display

335

system: P.279

System Components

Use the cruise control only on
highways and expressways.
WARNING
n For safe use
l Driving safely is solely the responsibility of the driver. Therefore, do not
overly rely on this system. The
driver is solely responsible for paying attention to the vehicle’s
surroundings and driving safely.

l Set the speed appropriately accord-

A Set vehicle speed
B Cruise control indicator
n Switches

n Situations in which cruise con-

trol should not be used
Do not use the cruise control in the
following situations. As the system
will not be able to provide appropriate
control, using it may lead to an accident resulting in death or serious
injury.

A Driving assist switch

l On winding roads

B Driving assist mode select
switch

l On slippery roads, such as those

C Cancel switch

l On roads with sharp bends

covered with rain, ice or snow

l On steep downhills, or where there

are sudden changes between sharp
up and down gradients
Vehicle speed may exceed the set
speed when driving down a steep hill.

5

Driving

ing to the speed limit, traffic flow,
road conditions, weather conditions, etc. The driver is responsible
for confirming the set speed.

“-” switch
“+” switch/“RES” switch

336

5-4. Using the driving support systems

Using the cruise control
Setting the vehicle speed

using the switches
To change the set vehicle speed,
press the “+” switch or “-” switch
until the desired speed is displayed.

1 Press the driving assist mode
select switch to select Cruise
Control Mode.
The cruise control indicator will illuminate.

1 Increase set vehicle speed
2 Decrease set vehicle speed
The set vehicle speed will increase
or decrease as follows:
2 Using the accelerator pedal,
accelerate to the desired vehicle
speed (approximately 30 km/h
[20 mph] or more), and press
the driving assist switch to set
the set vehicle speed.
The vehicle speed at the moment the
switch is released will be the set vehicle
speed.

Fine adjustment: By 1 km/h (0.6 mph)
or 1 mph (1.6 km/h) each time the
switch is pressed
Large adjustment: Increases continuously while the switch is pressed and
held

 Increasing the set vehicle speed
using the accelerator pedal
1 Depress the accelerator pedal
to accelerate the vehicle to the
desired vehicle speed.
2 Press the “+” switch.

Adjusting the set vehicle
speed
 Adjusting the set vehicle speed

5-4. Using the driving support systems

Canceling/resuming control

337

n Automatic cancellation of the

cruise control
In the following situations, the cruise
control will be canceled automatically:

l When the vehicle speed drops

approximately 16 km/h (10 mph) or
more below the set vehicle speed

l When the vehicle speed drops below
approximately 30 km/h (20 mph)

l When the brake control or output

1 Press the cancel switch or driving assist switch to cancel control.

restriction control of a driving support
system operates
(For example: PCS, drive-start control)

l When the parking brake has been
operated

Control will also be canceled if the
brake pedal is depressed.

l When the driver’s seat belt is unfas-

2 Press the “RES” switch to
resume control.

l Situations in which some or all of the

tened

functions of the system cannot operate: P.285

5

Display and system operation state

Indicator

Multi-information display

Situation

Blank
White

Cruise control being OFF

Driving

The operating state of cruise control is indicated.

338

5-4. Using the driving support systems

Indicator

Green

Green

Multi-information display

Situation

Set vehicle
speed: Green

Constant
speed cruising

Set vehicle
Set vehicle
speed: Green
speed being
in reverse disexceeded
play

5-4. Using the driving support systems

Cruise control (vehicles
without Toyota Safety
Sense)

l When it is necessary to disable the

The vehicle can be driven at a
set speed even if the accelerator pedal is not depressed.

n Meter display

339

system: P.279

System Components

Use the cruise control only on
highways and expressways.
WARNING
n For safe use
l Driving safely is solely the responsibility of the driver. Therefore, do not
overly rely on this system. The
driver is solely responsible for paying attention to the vehicle’s
surroundings and driving safely.

l Set the speed appropriately accord-

A Set vehicle speed
B Cruise control indicator
n Switches

n Situations in which cruise con-

trol should not be used
Do not use the cruise control in the
following situations. As the system
will not be able to provide appropriate
control, using it may lead to an accident resulting in death or serious
injury.

A Cruise Control main switch

l On roads with sharp bends

B Cancel switch

l On winding roads

C “-” switch/“SET” switch

l On slippery roads, such as those
covered with rain, ice or snow

l On steep downhills, or where there

are sudden changes between sharp
up and down gradients
Vehicle speed may exceed the set
speed when driving down a steep hill.

5

Driving

ing to the speed limit, traffic flow,
road conditions, weather conditions, etc. The driver is responsible
for confirming the set speed.

“+” switch/“RES” switch

340

5-4. Using the driving support systems

Using the cruise control
Setting the vehicle speed

using the switches
To change the set vehicle speed,
press the “+” switch or “-” switch
until the desired speed is displayed.

1 Press the cruise control main
switch to activate the cruise control.
The cruise control indicator will illuminate.

1 Increase set vehicle speed
2 Decrease set vehicle speed
The set vehicle speed will increase
or decrease as follows:
2 Using the accelerator pedal,
accelerate to the desired vehicle
speed (approximately 30 km/h
[20 mph] or more), and press
the “SET” switch to set the set
vehicle speed.
The vehicle speed at the moment the
switch is released will be the set vehicle
speed.

Fine adjustment: By 1 km/h (0.6 mph)
or 1 mph (1.6 km/h) each time the
switch is pressed
Large adjustment: Increases continuously while the switch is pressed and
held

 Increasing the set vehicle speed
using the accelerator pedal
1 Depress the accelerator pedal
to accelerate the vehicle to the
desired vehicle speed.
2 Press the “+” switch.

Adjusting the set vehicle
speed
 Adjusting the set vehicle speed

5-4. Using the driving support systems

Canceling/resuming control

341

n Automatic cancellation of the

cruise control
In the following situations, the cruise
control will be canceled automatically:

l When the vehicle speed drops

approximately 16 km/h (10 mph) or
more below the set vehicle speed

l When the vehicle speed drops below
approximately 30 km/h (20 mph)

l When the brake control or output

1 Press the cancel switch or
cruise control main switch to
cancel control.
Control will also be canceled if the
brake pedal is depressed.

2 Press the “RES” switch to
resume control.

restriction control of a driving support
system operates
(For example: PCS, drive-start control)

l When the parking brake has been
operated

l Situations in which some or all of the
functions of the system cannot operate: P.285

5

Display and system operation state

Indicator

Multi-information display

Situation

Blank
White

Cruise control being OFF

Driving

The operating state of cruise control is indicated.

342

5-4. Using the driving support systems

Indicator

Green

Green

Multi-information display

Situation

Set vehicle
speed: Green

Constant
speed cruising

Set vehicle
Set vehicle
speed: Green
speed being
in reverse disexceeded
play

5-4. Using the driving support systems

Speed limiter*
*

343

n Switches

: If equipped

A desired maximum speed can
be set using the speed limiter
switch. The speed limiter prevents the vehicle speed from
exceeding the set speed.
WARNING
n Situations in which speed limiter

A Driving assist switch

l Situations in which the sensors may

B Driving assist mode select
switch

l When it is necessary to disable the

C Cancel switch

should not be used

not operate properly: P.283
system: P.285

System Components
n Meter display

“-” switch
“+” switch/“RES” switch

Using the speed limiter

1 Press the driving assist mode
select switch to select the speed
limiter.
The speed limiter indicator will illuminate in white.

A Set vehicle speed
B Speed limiter indicator

2 Accelerate or decelerate to the
desired vehicle speed, and

Driving

Setting the maximum vehicle
speed

5

344

5-4. Using the driving support systems

press the driving assist switch to
set the maximum vehicle speed.

1 Increase set vehicle speed
2 Decrease set vehicle speed

The speed limiter indicator will change
from illuminated in white to green.
The set vehicle speed will be displayed
on the multi-information display in
green.
If the vehicle speed is set while driving
at below approximately 30 km/h (20
mph), the set vehicle speed will be set
to approximately 30 km/h (20 mph).
Press the cancel switch or driving
assist switch to cancel control.

Short press adjustment: Press the
switch
Long press adjustment: Press and hold
the switch until the desired set vehicle
speed is reached.
The set vehicle speed will increase or
decrease as follows:
Short press adjustment: By 1 km/h (0.6
mph) or 1 mph (1.6 km/h) each time the
switch is pressed
Long press adjustment: Increases or
decreases in 5 km/h (3.1 mph) or 5
mph (8 km/h) increments continuously
while the switch is pressed and held
The set vehicle speed adjustment
increment can be changed through a
customize setting.

The system does not start when the
shift position is in R.
The system does not start when the
driving assist switch is pressed continuously.

Canceling/resuming control

Adjusting the set vehicle
speed
To change the set vehicle speed,
press the “+” switch or “-” switch
until the desired speed is displayed.

1 Press the cancel switch or driving assist switch to cancel control.
2 Press the “RES” switch to
resume control.
When control is canceled, the speed
limiter indicator will change from illuminated in green to white.

5-4. Using the driving support systems

n Exceeding the set speed
In the following situations, if the vehicle
speed exceeds the set vehicle speed,
the displayed set vehicle speed will be
highlighted:

345

Press and hold the “+” switch.

n When the set vehicle speed is

higher than the detected
speed limit

l When the accelerator pedal is deeply
depressed

l When driving down a slope
n Automatic cancellation of the
speed limiter

l Situations in which some or all of the
functions of the system cannot operate: P.285

n Changes in brake operation sound

and pedal response
P.285

Press and hold the “-” switch.

n The speed limiter with road sign

Speed limiter with Road
Sign Assist

n When the set vehicle speed is

lower than the detected speed
limit

l When the detected speed limit is the
same as the set speed

l When the detected speed limit is outside of the speed range which the
speed limiter system can operate

5

Driving

When RSA function is enabled and
the speed limiter is operating, if a
speed limit sign is detected, the
detected speed limit will be displayed with an up/down arrow. The
set vehicle speed can be
increased/reduced to the detected
speed limit by pressing and holding
the “+” switch or “-” switch.

assist may not operate properly
when
As the speed limiter with road sign
assist may not operate properly in situations where the RSA may not operate or
cannot detect signs correctly (P.320),
when using this function, make sure to
confirm the actual speed limit.
In the following situations, the set speed
may not change to the detected speed
limit by pressing and holding the “+”
switch or “-” switch:

346

5-4. Using the driving support systems

Emergency Driving Stop
System*
*: If equipped

The emergency driving stop
system is a system which
automatically decelerates and
stops the vehicle within its
lane if the driver becomes unable to continue driving the
vehicle, such as if they have
suffered a medical emergency,
etc.
During LTA (Lane Tracing
Assist) control, if the system
does not detect driving operations, such as if the driver is
not holding the steering wheel,
and determines the driver is
not responsive, the vehicle will
be decelerated and stopped
within its current lane to help
avoid a collision or reduce the
impact of a collision.
WARNING
n For safe use
l Driving safely is solely the responsibility of the driver. Pay careful attention to the surrounding conditions in
order to ensure safe driving. The
emergency driving stop system is
designed to provide support in an
emergency where it is difficult for
the driver to continue driving, such
as if they have had a medical emergency. It is not designed to support
driving while drowsy or in poor
physical health, or inattentive driving.

l Although the emergency driving

stop system is designed to
decelerate the vehicle within its
lane to help avoid or help reduce
the impact of a collision if the system determines that it is difficult for
the driver to continue driving, its
effectiveness may change according to various conditions. Therefore,
it may not always be able to
achieve the same level of performance. Also, if the operating conditions are not met, this function will
not operate.

l After the emergency driving stop

system operates, if driving
becomes possible again, immediately begin driving again or, if necessary, park the vehicle on the
shoulder of the road and set a
warning reflector and flare to warn
other drivers of your stopped vehicle.

l After this system operates, passengers should attend to the driver as
necessary and take appropriate
hazard prevention measures, such
as moving to a place where safety
can be ensured, such as the shoulder of the road or behind a guardrail.

l This system detects the condition of
the driver through the operation of
the steering wheel. This system
may operate if the driver is aware
but intentionally and continuously
does not operate the vehicle. Also,
the system may not operate if it
cannot determine that the driver is
not responsive, such as if they are
leaning on the steering wheel.

l Situations in which the driver monitor may not operate properly (vehicles with a driver monitor): P.285

Summary of the system
Operation of this system is sepa-

5-4. Using the driving support systems

rated into 4 control states. Through
control state “Warning phase 1” and
“Warning phase 2”, the system
determines if the driver is aware
and responsive while outputting a
warning and controlling the vehicle
speed. If the system determines the
driver is not responsive, it will operate in control state “Deceleration
stop phase” and “Stop hold phase”
and decelerate and stop the vehicle. It will then operate continuously
in “Stop hold phase”.
n Operating conditions
This system operates when all of the following conditions are met:

l When the LTA is on
l When the vehicle speed is approximately 50 km/h (30 mph) or more

In the following situations, system operation will be canceled:

l When LTA control has been canceled
(the LTA switch has been pressed,
etc.)

n LTA control when operation is

canceled
When emergency driving stop system
operation is canceled, LTA control may
also be canceled.

Warning phase 1
If driving operations are not
detected after the hands off steering wheel warning operates, a
buzzer will sound intermittently and
a message will be displayed to
warn the driver, and the system will
judge if the driver is responsive or
not. If driving operations, such as
holding the steering wheel, are not
performed within a certain amount
of time, the system will enter warning phase 2.
Vehicles with a driver monitor camera: Depending on the type of
detection of the driver’s unresponsiveness, the system may skip
warning phase 1 and start the control of warning phase 2.

l When the dynamic radar cruise control has been canceled

l When driver operations are detected

(the steering wheel is held, the brake
pedal, accelerator pedal, parking
brake, hazard light switch, or turn signal lever is operated)

l When the driving assist switch is

pressed while in the stop and hold
phase

l When the power switch has been
turned from ON to off

l Situations in which some or all of the
functions of the system cannot operate: P.285

Warning phase 2
After entering warning phase 2, a
buzzer will sound in short intervals
and a message will be displayed to
warn the driver, and the vehicle will
slowly decelerate. If driving operations, such as holding the steering
wheel, are not performed within a
certain amount of time, the system
will determine that the driver is not
responsive and enter the deceleration stop phase.

5

Driving

n Operation cancelation conditions

347

348

5-4. Using the driving support systems

When the vehicle is decelerating, the
brake lights may illuminate, depending
on the road conditions, etc.
After the vehicle has decelerated a certain amount, the emergency flashers
(hazard lights) will flash.

Deceleration stop phase
After the driver is judged as being
not responsive, a buzzer will sound
continuously and a message will be
displayed to warn the driver, and
the vehicle will slowly decelerate
and stop. While the vehicle is
decelerating, the emergency flashers (hazard lights) will flash to warn
other drivers of the emergency.

Stop hold phase
After the vehicle is stopped, the
parking brake will be applied automatically. After entering the stop
and hold phase, the buzzer will
continue sounding continuously, the
emergency flashers (hazard lights)
will flash to warn other drivers of
the emergency, and the doors will
unlock.
n Restricted functions after the oper-

ation is canceled
After shifting to the deceleration stop
phase, the following functions will not be
available until the EV system is
re-started even though the emergency
driving stop system is canceled:

l LTA (if equipped)
l LCA (if equipped)

BSM (Blind Spot Monitor)*
*: If equipped

The Blind Spot Monitor is a
system that uses rear side
radar sensors installed on the
inner side of the rear bumper
on the left and right side to
assist the driver in confirming
safety when changing lanes.
WARNING
n Cautions regarding the use of
the system

l The driver is solely responsible for
safe driving. Always drive safely,
taking care to observe your
surroundings.

l The Blind Spot Monitor is a supple-

mentary function which alerts the
driver that a vehicle is in a blind
spot of the outside rear view mirrors
or is approaching rapidly from
behind into a blind spot. Do not
overly rely on the Blind Spot Monitor. As the function cannot judge if it
is safe to change lanes, over reliance could lead to an accident
resulting in death or serious injury.
As the system may not function correctly under certain conditions, the
driver’s own visual confirmation of
safety is necessary.

5-4. Using the driving support systems

System components

349

(P.675)

n Certification
P.710

WARNING
n To ensure the system can oper-

A Multimedia display

ate properly
Blind Spot Monitor sensors are
installed behind the left and right
sides of the rear bumper respectively.
Observe the following to ensure the
Blind Spot Monitor can operate correctly.

Turning the Blind Spot Monitor on/off.

l Keep the sensors and the sur-

B Outside rear view mirror indicators

C Driving assist information indicator
Illuminates when the Blind Spot Monitor
is turned off. At this time, a message
will be displayed on the multi-information display.

n Outside rear view mirror indicator

visibility
In strong sunlight, the outside rear view
mirror indicator may be difficult to see.

n Buzzer
If the volume setting of the audio system
is high or the surrounding area is loud, it
may be difficult to hear the buzzer.
n Customization
Some functions can be customized.

l Do not attach accessories, stickers

(including transparent stickers), aluminum tape, etc. to a sensor or its
surrounding area on the rear
bumper.

5

Driving

When a vehicle is detected in a blind
spot of the outside rear view mirrors or
approaching rapidly from behind into a
blind spot, the outside rear view mirror
indicator (P.153) on the detected side
will illuminate. If the turn signal lever is
operated toward the detected side, the
outside rear view mirror indicator will
flash and a buzzer will sound.

rounding areas on the rear bumper
clean at all times.
If a sensor or its surrounding area on
the rear bumper is dirty or covered
with snow, the Blind Spot Monitor may
not operate and a warning message
will be displayed. In this situation,
clear off the dirt or snow and drive the
vehicle with the operation conditions
of the BSM function (P.352) satisfied for approximately 10 minutes. If
the warning message does not disappear, have the vehicle inspected by
any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.

350

5-4. Using the driving support systems

WARNING
l Do not paint the surrounding area
of a sensor on the rear bumper.

l Do not subject a sensor or its sur-

rounding area on the rear bumper
to a strong impact.
If a sensor is moved even slightly
off position, the system may malfunction and vehicles may not be
detected correctly.
In the following situations, have
your vehicle inspected by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
• A sensor or its surrounding area is
subject to a strong impact.
• If the surrounding area of a sensor
is scratched or dented, or part of
them has become disconnected.

l Do not disassemble the sensor.
l Do not modify the sensor or sur-

rounding area on the rear bumper.

l If a sensor or the rear bumper

needs to be removed/installed or
replaced, contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

l The sensors are likely to be

affected by paint on the rear
bumper. If the rear bumper is not
repaired correctly, the Blind Spot
Monitor may not operate with a
warning message displayed. If any
paint repair is needed, contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliabler
epairer.

Turning the Blind Spot Monitor on/off
The Blind Spot Monitor can be enabled/disabled through a customize
setting. (P.675)
When the Blind Spot Monitor is off,
the driving assist information indicator (P.153) will illuminate and a
message will be displayed on the
multi-information display.
Each time the power switch is
turned to ON, the Blind Spot Monitor is enabled.

Blind Spot Monitor operation
n Objects that can be detected while driving

The Blind Spot Monitor uses rear side radar sensors to detect the following
vehicles traveling in adjacent lanes and advises the driver of the presence

5-4. Using the driving support systems

351

of such vehicles via the indicators on the outside rear view mirrors.

A Vehicles that are traveling in areas that are not visible using the outside
rear view mirrors (the blind spots)
B Vehicles that are approaching rapidly from behind in areas that are not
visible using the outside rear view mirrors (the blind spots)
n Detection range while driving

The areas that vehicles can be detected in are outlined below.
5

Driving

The range of each detection area is:

A Approximately 0.5 m (1.6 ft.) to 3.5 m (11.5 ft.) from either side of the

vehicle*1
B Approximately 1 m (3.3 ft.) forward of the rear bumper*2
C Approximately 3 m (9.8 ft.) from the rear bumper

Approximately 3 m (9.8 ft.) to 70 m (230 ft.) from the rear bumper*3
*1: The area between the side of the vehicle and 0.5 m (1.6 ft.) from the side of the

vehicle cannot be detected.
*2: While the vehicle is to being overtaken, up to approximately 3 m (9.8 ft.) forward

of the rear bumper will be detected.
*3: The greater the difference in speed between your vehicle and the detected vehi-

cle is, the farther away the vehicle will be detected, causing the outside rear view

352

5-4. Using the driving support systems
mirror indicator to illuminate or flash.

n The Blind Spot Monitor linked function

The LDA (Lane Departure Alert) has a function that uses information of
detected vehicles driving in an adjacent lane. For details about the function
and its operating conditions, P.307.
n The Blind Spot Monitor is opera-

tional when
The Blind Spot Monitor is operational
when all of the following conditions are
met:

l The power switch is in ON.
l The Blind Spot Monitor is on.
l The shift position is in a position other
than R.

l The vehicle speed is approximately 10
km/h (7 mph) or more.

n The Blind Spot Monitor will detect a

vehicle when
The Blind Spot Monitor will detect a
vehicle present in the detection area in
the following situations:

l A vehicle in an adjacent lane overtakes your vehicle.

l You overtake a vehicle in an adjacent
lane slowly.

l Another vehicle enters the detection
area when it changes lanes.

n Situations in which the Blind Spot

Monitor cannot detect vehicles
The Blind Spot Monitor cannot detect
the following vehicles and other objects:

l Small motorcycles, bicycles, pedestrians, etc.*

l Vehicles traveling in the opposite
direction

l Guardrails, walls, signs, parked vehicles and similar stationary objects*

l Following vehicles that are in the
same lane*

l Vehicles traveling 2 lanes away from
your vehicle*

l Vehicles which are being overtaken
rapidly by your vehicle*
: Depending on the conditions, detection of a vehicle and/or object may
occur.

*

n Conditions in which a buzzer may

not sound
In situations such as the following, while
the turn signal lever is being operated,
the indicator will flash but a buzzer may
not sound.

l When a second vehicle is detected
while the turn signal lever is being
held

l When overtaking a vehicle in the adjacent lane at a much higher speed than
it*
*
: Depending on the situations, a buzzer
may sound.

n Conditions under which the system
may not function correctly

l The Blind Spot Monitor may not detect

vehicles correctly in the following situations:
• When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area
• When mud, snow, ice, a sticker, etc. is
covering the sensor or surrounding
area on the rear bumper
• When driving on a wet road surface,
such as in a puddle, while in inclement
weather, such as heavy rain, snow,
fog, etc.
• When multiple vehicles are approaching with only a small gap between
each vehicle
• When the distance between your vehicle and a following vehicle is short
• When there is a significant difference

5-4. Using the driving support systems

l Instances of the Blind Spot Monitor

unnecessarily detecting a vehicle
and/or object may increase in the following situations:
• When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area
• When the distance between your vehicle and a guardrail, wall, etc. that
enters the detection area is short
• When driving up and down consecutive steep inclines, such as hills, dips
in the road, etc.
• When vehicle lanes are narrow, or
when driving on the edge of a lane,
and a vehicle traveling in a lane other
than the adjacent lanes enters the
detection area
• When driving on roads with sharp
bends, consecutive curves, or uneven
surfaces

• When the tires are slipping or spinning
• When the distance between your vehicle and a following vehicle is short
• When an accessory (such as a bicycle
carrier) is installed to the rear of the
vehicle
• When towing with the vehicle

5

Driving

in speed between your vehicle and
the vehicle that enters the detection
area
• When the difference in speed
between your vehicle and another
vehicle is changing
• When a vehicle enters a detection
area traveling at about the same
speed as your vehicle
• As your vehicle starts from a stop, a
vehicle remains in the detection area
• When driving up and down consecutive steep inclines, such as hills, dips
in the road, etc.
• When driving on roads with sharp
bends, consecutive curves, or uneven
surfaces
• When vehicle lanes are wide, or when
driving on the edge of a lane, and the
vehicle in an adjacent lane is far away
from your vehicle
• When an accessory (such as a bicycle
carrier) is installed to the rear of the
vehicle
• When there is a significant difference
in height between your vehicle and
the vehicle that enters the detection
area
• Immediately after the Blind Spot Monitor is turned on
• When towing with the vehicle

353

354

5-4. Using the driving support systems

Rear Vehicle Approaching Indication*

System components

*: If equipped

The rear vehicle approaching
indication is a system that
uses radar sensors installed
on the inner side of the rear
bumper. By notifying the driver
of a vehicle approaching
behind your vehicle, the system assists the driver in judging whether or not an evasive
action should be taken.
WARNING
n Cautions regarding the use of

A A Multi-information display
Notifies through message and buzzer
when your vehicle may obstruct the
passing of the vehicle behind you.

B Multimedia display
Turning the Rear Vehicle Approaching
Indication on/off.

the system
The driver is solely responsible for
safe driving. Always drive safely, taking care to observe your
surroundings.
The rear vehicle approaching indication is a supplementary system that
informs the driver of the existence of
a vehicle approaching behind your
vehicle.
As this system may not function to its
fullest extent in certain situations, the
driver’s own visual confirmation of
safety is necessary.
Over reliance on this function may
lead to an accident resulting death or
serious injury.

If the volume setting of the audio system
is high or the surrounding area is loud, it
may be difficult to hear the buzzer.

n To ensure the system can oper-

n Customization

ate properly
P.349

Turning the Rear Vehicle
Approaching Indication
on/off
The Rear Vehicle Approaching Indication can be enabled/disabled
through a customize setting.
(P.675)
n Buzzer

Some functions can be customized.
(P.675)

Rear Vehicle Approaching
Indication operation
On detecting a vehicle approaching
behind your vehicle using the rear

5-4. Using the driving support systems

side radar sensors, the rear vehicle
approaching indication notifies the
driver of the existence of the vehicle through a message on the
multi-information display or
head-up display, and a buzzer.

355

n The Rear Vehicle Approaching Indi-

cation will detect a vehicle when
The rear vehicle approaching indication
detects vehicles within the detection
range when a following vehicle driving in
the same lane is approaching.

n Situations in which the Rear Vehi-

cle Approaching Indication cannot
detect vehicles
The Rear Vehicle Approaching Indication cannot detect the following vehicles
and other objects:

l Small motorcycles, bicycles, pedestrians, etc.*

l Guardrails, walls, signs, parked vehicles and similar stationary objects*

l Vehicles traveling in the opposite
direction

l A vehicle in an adjacent lane*
*: Depending on the conditions, detec-

tion of a vehicle and/or object may
occur.

5

n Situations in which the Rear Vehi-

Driving

cle Approaching Indication may not
operate properly

l In the following situations, the system

n Operating conditions of Rear Vehi-

cle Approaching Indication
When the following conditions are met,
the Rear Vehicle Approaching Indication
will operate:

l The power switch is in ON.
l The Rear Vehicle Approaching Indication is on.

l The shift position is in a position other
than R.

l The vehicle speed is approximately
100 km/h (63 mph) or more.

l The turn signal lever is not being operated.

l The brake pedal is not depressed.
l Approximately 5 or more minutes

have elapsed since the system was
operated.

may not detect a following vehicle
properly:
• When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area
• When mud, snow, ice, a sticker, etc. is
covering the sensor or surrounding
area on the rear bumper
• When driving on a wet road surface,
such as in a puddle, while in inclement
weather, such as heavy rain, snow,
fog, etc.
• When driving up and down consecutive steep inclines, such as hills, dips
in the road, etc.
• When towing with the vehicle
• When the following vehicle is not
approaching from straight behind your
vehicle
• When the following vehicle is
approaching from an angle

356

5-4. Using the driving support systems

• If a vehicle suddenly cuts behind your
vehicle
• When your vehicle cuts in front of
another vehicle
• When the following vehicle is surrounded by other vehicles
• When there is a static object, such as
a guardrail or wall, around a following
vehicle
• When a following vehicle, which
approached your vehicle then moved
away, is approaching again
• When a following vehicle is moving
away from your vehicle
• When a following vehicle is overtaking
your vehicle
• When driving on roads with sharp
bends, consecutive curves, or uneven
surfaces
• When the height of a following vehicle
is too much different from that of your
vehicle

l Especially in situations such as the

following, the system may operate
even if it is unlikely for a following
vehicle to approach your vehicle:
• When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area
• When towing with the vehicle
• When your vehicle is surrounded by
other vehicles
• When making a left/right turn and a
following vehicle passes immediately
behind your vehicle
• When a following vehicle closely
approaches your vehicle before overtaking
• When a vehicle driving in an adjacent
lane is within the detection range,
such as when your vehicle is driving
on a narrow lane road or driving on
the edge of a lane
• When there are more than one vehicle
around a following vehicle
• When passing through a location with
a structure above the road (traffic
sign, billboard, etc.)
• When there is a static object, such as
a guardrail or wall, around a following
vehicle
• When there is an adjacent vehicle

while on a curve
• When your vehicle cuts in front of
another vehicle

5-4. Using the driving support systems

Automatic Rear Flashing Hazard Lights
The Automatic Rear Flashing
Hazard Lights is a system that
uses the rear side radar sensors located on the inside of
the rear bumper. When the system determines that the possibility of a rear-end collision is
high, it flashes the emergency
flashers rapidly to warn the
driver of the following vehicle.

357

mines that the possibility of a
rear-end collision is high, the emergency flashers will flash rapidly to
warn the driver of the following
vehicle. Simultaneously, a message
will be displayed on the multi-information display to notify the driver of
the approach of the following vehicle.

WARNING
n Cautions regarding the use of

n To ensure the system can oper-

ate properly
P.349

5

Driving

the system
The driver is solely responsible for
safe driving. Always drive safely, taking care to observe your
surroundings. The Automatic Rear
Flashing Hazard Lights is an auxiliary
system that flashes the emergency
flashers rapidly to warn the driver of
the following vehicle when it determines that the possibility of a rear-end
collision is high. As this system may
not function to its fullest extent in certain situations, the driver’s own visual
confirmation of safety is necessary.
Over reliance on this function may
lead to an accident resulting death or
serious injury.

n Operating conditions of Automatic

Rear Flashing Hazard Lights
When the following conditions are met,
the Automatic Rear Flashing Hazard
Lights will operate:

l The power switch is in ON.
l The shift position is in a position other
than R.

Automatic Rear Flashing
Hazard Lights operation

l The turn signal lever is not being oper-

The rear side radar sensors detect
following vehicles driving in the
same lane. If the system deter-

cle and the following vehicle is
between approximately 30 and 100
km/h (19 and 62 mph)

ated.

l The relative speed between your vehi-

l Your vehicle is being driven at approx-

358

5-4. Using the driving support systems

imately 10 km/h (7 mph) or less or at
any speed with the brake pedal
depressed.

n The Automatic Rear Flashing Haz-

ard Lights will detect a vehicle
when
The Automatic Rear Flashing Hazard
Lights detects the following vehicle driving in the same lane within the detection
range, when it determines that the possibility of a rear-end collision with it is
high.

n Situations in which the Automatic

Rear Flashing Hazard Lights cannot detect vehicles
The Automatic Rear Flashing Hazard
Lights cannot detect the following vehicles and other objects:

l Small motorcycles, bicycles, pedestrians, etc.*

l Guardrails, walls, signs, parked vehicles and similar stationary objects*

l Vehicles traveling in the opposite
direction

l A vehicle in an adjacent lane*
*

: Depending on the conditions, detection of a vehicle and/or object may
occur.

n Situations in which the Automatic
Rear Flashing Hazard Lights may
not operate properly

l In the following situations, the system

may not detect a following vehicle
properly:
• When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area
• When mud, snow, ice, a sticker, etc. is
covering the sensor or surrounding
area on the rear bumper
• When the vehicle is stopped or driving
on a wet road surface, such as in a
puddle, while in inclement weather,
such as heavy rain, snow, fog, etc.
• When driving up and down consecutive steep inclines, such as hills, dips
in the road, etc.

• When towing with the vehicle
• When the following vehicle is not
approaching from straight behind your
vehicle
• When the following vehicle is
approaching from an angle
• If a vehicle suddenly cuts behind your
vehicle
• When the following vehicle is surrounded by other vehicles
• When there is a static object, such as
a guardrail or wall, around a following
vehicle
• When a bicycle carrier or other accessory is installed to the rear of your
vehicle
• When the height of a following vehicle
is too much different from that of your
vehicle

l In the following situations, the system

may operate even though there is no
possibility of a collision
• When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area
• When towing with the vehicle
• When your vehicle is surrounded by
other vehicles
• When your vehicle is stopped to make
a turn at an intersection, etc. and a
vehicle passes your vehicle from
straight behind
• When your vehicle is stopped on the
roadside, etc. and a vehicle passes
close to the side of your vehicle
• When a following vehicle closely
approaches your vehicle before overtaking
• When a following vehicle suddenly
approaches to close to your vehicle
• When there is a static object, such as
a guardrail or wall, around a following
vehicle

5-4. Using the driving support systems

359

Secondary Collision
Brake (Rear Impacts
while Stopped)

Secondary Collision Brake
(Rear Impacts while
Stopped) operation

The Secondary Collision Brake
(Rear Impacts while Stopped)
is a system that uses the rear
side radar sensors located on
the inside of the rear bumper.
When the system determines
that the possibility of a
rear-end collision while the
vehicle is stopped is very high,
the brakes are controlled automatically to help reduce the
possibility of further damage
due to a secondary collision.

With the Secondary Collision Brake
(Rear Impacts while Stopped), the
rear side radar sensors detect a following vehicle driving in the same
lane while the vehicle is stopped. If
the system determines that the
possibility of a rear-end collision is
very high, the brakes and brake
lights will be automatically controlled to reduce the vehicle speed
after the rear-end collision and help
reduce the possibility of further
damage due to a secondary collision.
5

WARNING

Driving

n Cautions regarding the use of

the system
The driver is solely responsible for
safe driving. Always drive safely, taking care to observe your
surroundings. The Secondary Collision Brake (Rear Impacts while
Stopped) is an auxiliary system that
controls the brakes automatically
when it determines that the possibility
of a rear-end collision with the following vehicle driving in the same lane is
very high while the vehicle is stopped.
As the Secondary Collision Brake
(Rear Impacts while Stopped) may
not function to its fullest extent in certain situations, the driver’s own visual
confirmation of safety is necessary.
Over reliance on this function may
lead to an accident resulting death or
serious injury.

n To ensure the system can oper-

ate properly
P.349

n Operating conditions of Secondary

Collision Brake (Rear Impacts while
Stopped)
When the following conditions are met,

360

5-4. Using the driving support systems

the Secondary Collision Brake (Rear
Impacts while Stopped) will operate:

l The power switch is in ON.
l The shift position is in a position other
than R.*

l The turn signal lever is not being operated.

l Approximately 7 or more minutes

have elapsed since the system was
operated.

l The relative speed between your vehicle and the following vehicle is
between approximately 30 and 100
km/h (19 and 62 mph)

l The vehicle speed is approximately 0
km/h (0 mph).

*: When the N shift position is selected,

the system is not operational when
none of the brake pedal, parking
brake, and brake hold system are
operated.

n The Secondary Collision Brake

(Rear Impacts while Stopped) will
detect a vehicle when
The Secondary Collision Brake (Rear
Impacts while Stopped) detects the following vehicle driving in the same lane
within the detection range, when it
determines that the possibility of a
rear-end collision with it is very high.

n Situations in which the Secondary

Collision Brake (Rear Impacts while
Stopped) cannot detect vehicles
The Secondary Collision Brake (Rear
Impacts while Stopped) cannot detect
the following vehicles and other objects:

l Small motorcycles, bicycles, pedestrians, etc.*

l Guardrails, walls, signs, parked vehicles and similar stationary objects*

l Vehicles traveling in the opposite
direction

l A vehicle in an adjacent lane*
*

: Depending on the conditions, detec-

tion of a vehicle and/or object may
occur.

n Situations in which the Secondary

Collision Brake (Rear Impacts while
Stopped) may not operate properly

l In the following situations, the system

may not detect a following vehicle
properly:
• When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area
• When mud, snow, ice, a sticker, etc. is
covering the sensor or surrounding
area on the rear bumper
• When the vehicle is stopped on a wet
road surface, such as in a puddle,
while in inclement weather, such as
heavy rain, snow, fog, etc.
• When driving up and down consecutive steep inclines, such as hills, dips
in the road, etc.
• When towing with the vehicle
• When a following vehicle approaches
immediately after your vehicle is
stopped
• When the following vehicle is not
approaching from straight behind your
vehicle
• When the following vehicle is
approaching from an angle
• If a vehicle suddenly cuts behind your
vehicle
• When the following vehicle is surrounded by other vehicles
• When there is a static object, such as
a guardrail or wall, around a following
vehicle
• When the height of a following vehicle
is too much different from that of your
vehicle
• When an accessory (such as a bicycle
carrier) is installed to the rear of the
vehicle

l Especially in situations such as the

following, the system may operate
even though there is no possibility of a
collision:
• When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area
• When towing with the vehicle

5-4. Using the driving support systems

Safe Exit Assist*
*

: If equipped

The safe exit assist (with door
opening control) is a system
that uses rear side radar sensors installed on the inner side
of the rear bumper to help
occupants judge if an
approaching vehicle or bicycle
may collide with a door when
exiting or cancel opening of a
door, to help reduce the possibility of a collision.
WARNING
n Cautions regarding the use of
the system

l The driver is solely responsible for

5

l The safe exit assist is a supplemen-

Driving

• When your vehicle is stopped to make
a turn at an intersection, etc. and a
vehicle passes your vehicle from
straight behind
• When the vehicle is stopped at a roadside, etc. and another vehicle passes
right next to your vehicle
• When a following vehicle closely
approaches your vehicle before overtaking
• When a following vehicle suddenly
approaches close to your vehicle
• When your vehicle is surrounded by
other vehicles
• When there is a static object, such as
a guardrail or wall, around a following
vehicle
• When a following vehicle approaches
immediately before stopping or immediately after starting off
• When braked on a slippery road, etc.,
locking your tires, and a following
vehicle approaches
• When the vehicle is washed in a car
wash machine

361

safe driving. Always drive safely,
taking care to observe your
surroundings.

tary system that, when the vehicle
is stopped, informs occupants of
the existence of approaching vehicles and bicycles. As this system
alone cannot be used to judge
safety, over-reliance on this system
may lead to an accident resulting in
death or serious injury.
In certain situations, this system may
not function to its fullest extent.
Therefore it is necessary for the occupants to visually check for safety
directly and using the mirrors.

362

5-4. Using the driving support systems

System components

Driving assist information indicator
Illuminates when the safe exit assist is
turned off. At this time, a message will
be displayed on the multi-information
display.

Speakers
When the outside rear view mirror indicator blinks, the driver is informed
through voice guidance that the system
has operated. After the notification
through voice guidance is made, no
more voice guidance notifications will
be made again until the door is fully
closed.

Door Illumination

A Multimedia display
Turning the safe exit assist on/off.

B Outside rear view mirror indicators
When a vehicle or bicycle which may
collide with a door (other than the back
door) when opened is detected, the
outside rear view mirror indicator
(P.153) on the detected side will illuminate. If the door on the detected side
is open, or opening of the door is
canceled, the outside rear view mirror
indicator will blink.

C Multi-information display
If collision with a door is likely and the
door is opened or opening of the door is
canceled, the door will be displayed on
the multi-information display. Also, if a
door is opened when an outside rear
view mirror indicator is illuminated, a
buzzer will sound as a warning.

When a vehicle or bicycle which may
collide with a door (other than the back
door) when opened is detected, the
door Illumination (red) on the detected
side will illuminate. If the door on the
detected side is opened, the door Illumination (red) will blink.

n Outside rear view mirror indicator

visibility
In strong sunlight, the outside rear view
mirror indicator may be difficult to see.

n Buzzer
If the volume setting of the audio system
is high or the surrounding area is loud, it
may be difficult to hear the buzzer.
n Voice notifications
In the following situations, voice notifications will not be output:
l When it is estimated that no occupants are on board*

l After opening a door and entering the
vehicle, until the EV system is started

l When 3 minutes or more have

elapsed since the EV system was
stopped

5-4. Using the driving support systems

l When the language setting of the multimedia display has been set to a language that does not support voice
notifications

l When all of the doors have been
locked from outside the vehicle

l When a door remains open for 1 minute or more after the EV system is
stopped

l When the ACC mode (P.675) has

been enabled through a customize
setting on the multimedia display and
the EV system has been stopped

l When the parking assist volume set-

ting on the multimedia display has
been set to off
*: For each seating position, judgment is
made based on the opening and closing of a door, before driving for ingress
and after driving for egress.

n Customization
Some functions can be customized.
(P.685)

363

WARNING
n To ensure the system can oper-

ate properly
P.349

Turning the safe exit assist
system ON/OFF
The safe exit assist system can be
enabled/disabled through a customize setting. (P.675)
When the safe exit assist is off, the
driving assist information indicator
will illuminate and a message will
be displayed on the multi-information display.
Each time the power switch is
turned to ON, the safe exit assist is
enabled.*
and then to ON immediately after
that, the safe exit assist may not be
enabled.

Safe exit assist operation
n Objects that can be detected by the safe exit assist

When the safe exit assist detects the following vehicles or bicycles behind
your vehicle using a rear side radar sensor, the occupants of the vehicle are
informed through an outside rear view mirror indicator, door Illumination
(red), buzzer, multi-information display, and voice notification.

Driving

*: When the power switch is turned off

5

364

5-4. Using the driving support systems

A Vehicle or bicycle which has a high possibility of colliding with a door
(other than the back door) when opened
n The safe exit assist detection areas

The areas that vehicles can be detected in are outlined below.

A Approximately 45 m (145 ft.) rearward from the front door*
*: The faster a vehicle or bicycle is approaching, the distance at which an outside

rear view mirror indicator and door Illumination (red) will illuminate or blink will
become further.

n The safe exit assist is operational

when
The safe exit assist is operational when
all of the following conditions are met:

l When the power switch is ON, less

than 3 minutes have elapsed since
the EV system was off, or less than 3
minutes have elapsed since a door
was opened and someone has
entered the vehicle (the time which
operation is possible may be
extended if a door is opened and
closed)

l Safe exit assist is on
l The vehicle is stopped.

l The shift position is in a position other
than R.

n The safe exit assist will detect a

vehicle when
The safe exit assist will detect a vehicle
present in the detection area in the following situations:

l When the vehicle is stopped and a

vehicle or bicycle, which is traveling
parallel to the vehicle, is approaching
within the area that a door opens
(other than the back door)

n Conditions under which the system
will not detect a vehicle

l Safe exit assist does not detect the

5-4. Using the driving support systems
following objects, vehicles, and bicycles:
• Vehicles or bicycles which are
approaching slowly*
• Vehicles or bicycles which are determined to have a low possibility of colliding with a door (other than the back
door) when opened*
• Vehicles or bicycles which are
approaching from directly behind*
• Vehicles or bicycles which are
approaching from the front*
• Guardrails, walls, signs, parked vehicles, and other stationary objects*
• Pedestrians, animals, etc.*
*
: Depending on the conditions, detection of a vehicle and/or object may
occur.

l In situations such as the following,

n Conditions under which the system
may not function correctly

l The safe exit assist may not detect

vehicles correctly in the following situations:
• When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area
• When mud, snow, ice, a sticker, etc. is
covering the sensor or surrounding
area on the rear bumper
• When the vehicle is stopped on a wet
road surface, such as in a puddle,
while in inclement weather, such as
heavy rain, snow, fog, etc.
• When a vehicle or bicycle approaches
from behind a nearby parked vehicle
• When an approaching vehicle or bicycle suddenly changes direction
• Immediately after a vehicle or bicycle
starts moving
• When the back door is open

• When a bicycle carrier, ramp, or other
accessory is installed to the back of
the vehicle
• When a parked vehicle, wall, sign,
person or other stationary object is
behind the vehicle
• When the vehicle is stopped at an
angle to the road
• When a vehicle is traveling near an
approaching vehicle or bicycle
• When an approaching vehicle or bicycle is traveling along a stationary
object, such a wall or sign
• When a vehicle or bicycle is
approaching at high speed
• When towing with the vehicle
• When stopped on a steep slope
• When stopped on a curve or at the
exit of a curve

l Instances of the safe exit assist

unnecessarily detecting a vehicle
and/or object may increase in the following situations:
• When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area
• When a vehicle or bicycle approaches
your vehicle from directly behind in an
offset position
• When the vehicle is stopped at an
angle to the road
• When a vehicle or bicycle approaches
from behind a parked vehicle at an
angle
• When a parked vehicle, wall, sign,
person or other stationary object is
behind the vehicle
• When an approaching vehicle or bicycle suddenly changes direction
• When an approaching vehicle or bicycle is traveling along a stationary
object, such a wall or sign
• When the back door is open
• When a bicycle carrier, ramp, or other
accessory is installed to the back of
the vehicle
• When a vehicle or bicycle is
approaching at high speed
• When towing with the vehicle
• When stopped on a steep slope
• When stopped on a curve or at the
exit of a curve

5

Driving

safe exit assist will not operate:
• When 3 minutes or more have
elapsed since the EV system off (the
time which operation is possible may
be extended if a door is opened and
closed)
• When your vehicle is not completely
stopped

365
