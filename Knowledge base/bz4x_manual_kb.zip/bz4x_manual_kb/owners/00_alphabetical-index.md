# Alphabetical Index

> Source: Toyota bZ4X Touring — Owner's Manual, Front/back matter, pages 697–819

Alphabetical Index

697

Alphabetical Index
A
A/C
Air conditioning filter................... 602
Automatic air conditioning system
................................................. 518
My Room Mode.......................... 136
ABS (Anti-lock Brake System) .... 502
Warning light .............................. 620
AC charging .................................. 115
AC charging cable
If the charging connector cannot be
unlocked .................................. 107
ACA (Active Cornering Assist).... 502
Acoustic Vehicle Alerting System. 92
Active Cornering Assist (ACA).... 502
Adaptive High-beam System ....... 264
AHS (Adaptive High-beam System)
..................................................... 264
Air conditioning filter ................... 602
Air conditioning system
Air conditioning filter................... 602
Automatic air conditioning system
................................................. 518
Airbag manual on-off system ........ 44
Airbags
Airbag manual on-off system ....... 44
Airbag operating conditions ... 38, 39
Airbag precautions for your child . 40
Correct driving posture................. 31
Curtain shield airbag precautions 40
General airbag precautions.......... 40
Modification and disposal of airbags
................................................... 43
Side airbag precautions ............... 40
Side and curtain shield airbags precautions ..................................... 40
SRS airbags................................. 37
SRS warning light ...................... 620
Alarm ............................................... 85
Warning buzzer .......................... 619
ALL AUTO (ECO) control ............. 516
Antennas (smart entry & start system).............................................. 191

Anti-lock Brake System (ABS).....502
Warning light ..............................620
Approach warning ........................330
Armrest ..........................................552
Assist grips ...................................552
Audio system-linked display .......162
Automatic air conditioning system
.....................................................518
Automatic headlight leveling system
.....................................................262
Automatic light control system ...262
Automatic Rear Flashing Hazard
Lights...........................................357
Average electricity consumption 161
AWD/4WD operation status .........162

B
Back door ......................................178
Back-up lights
Replacing light bulbs ..................608
Battery (12-volt battery)
Battery checking.........................585
If the 12-volt battery is discharged
.................................................658
Preparing and checking before winter.............................................508
Replacing ...................................661
Warning light ..............................619
Battery (traction battery)
Charging............................. 115, 120
Location........................................90
Traction battery cooler................109
Traction battery heater ...............109
Warning messages.....................146
Battery Electric Vehicle driving tips
.......................................................99
Blind Spot Monitor (BSM) ............348
Bottle holders................................533
Brake
Brake hold ..................................257
Fluid ...........................................672
Parking brake .............................254
Regenerative braking ...................91
Warning light ..............................619

698

Alphabetical Index

Brake assist .................................. 502
Brake hold
Warning lights ............................ 625
Brake Override System ................ 230
Break-in tips.................................. 230
Brightness control
Instrument panel light control..... 158
BSM (Blind Spot Monitor) ............ 348
Buzzer
Driver monitor ............................ 286

C
Camera
Digital Rear-view Mirror ............. 209
Driver monitor ............................ 286
Toyota Teammate Advanced Park
................................................. 404
Card holders ................................. 533
Card key ........................................ 168
Care
Exterior....................................... 564
Interior........................................ 567
Seat belts ................................... 567
Wheels and wheel ornaments.... 564
Cargo capacity.............................. 235
Cargo hooks ................................. 534
Chains ........................................... 509
Charging
AC charging ............................... 115
Charging components................ 103
Charging methods...................... 108
Charging procedure ........... 115, 120
Charging schedule function ....... 125
Charging time may increase ...... 114
Charging tips.............................. 110
DC charging ............................... 120
Display ....... 111, 127, 136, 137, 146
Information related to charging display .......... 111, 127, 136, 137, 146
Locking and unlocking the AC charging connector ........................... 106
My Room Mode.......................... 136
Opening and closing the charging
port lids .................................... 104

Safety functions.......................... 112
Things to know before charging . 112
Warning messages.....................146
When AC charging cannot be performed......................................139
When charging schedule function
cannot be performed................144
When DC charging cannot be performed......................................141
Charging equipment.....................103
Charging methods ........................108
AC charging ............................... 115
DC charging ...............................120
Charging ports
Charging port lid.........................103
Locking and unlocking the AC charging connector ...........................106
Opening and closing ..................104
Charging schedule function ........125
Setting ........................................127
Charging tips................................. 110
Charging-linked functions
My Room Mode..........................108
Traction battery cooler................109
Traction battery heater ...............109
Traction battery warming control 109
Child restraint system
Points to remember......................47
Riding with children ......................45
Child safety
12-volt battery precautions.........662
Airbag precautions .......................40
Child restraint system...................46
Electronic sunshade...................541
Heated steering wheel and seat
heater precautions ...................525
How your child should wear the seat
belt .............................................34
Installing child restraints...............46
Power back door precautions.....178
Power window lock switch..........220
Power window precautions ........219
Rear door child-protectors..........177
Seat belt precautions ...................46
Child-protectors............................177

Alphabetical Index

Cleaning
Digital Rear-view Mirror ............. 209
Exterior....................................... 564
Interior........................................ 567
Seat belts ................................... 567
Wheels and wheel ornaments.... 564
Clock.............................................. 156
Coat hooks .................................... 552
Console box .................................. 532
Coolant
Capacity ............................. 670, 671
Checking ............................ 583, 585
Preparing and checking before winter ............................................ 508
Cooling system
EV system overheating .............. 663
Cruise control
Dynamic radar cruise control ..... 324
Warning lights ............................ 623
Cup holders .................................. 532
Current electricity consumption . 161
Curtain shield airbags.................... 37
Customizable features ................. 675

D
Daytime running light system ..... 262
Daytime running lights
Light switch ................................ 260
Replacing light bulbs.................. 608
DC charging .................................. 120
Deck board .................................... 534
Deck under tray ............................ 535
Defogger
Outside rear view mirrors........... 521
Rear window .............................. 521
Windshield ......................... 520, 521
Digital Rear-view Mirror
Function ..................................... 205
Dimension ..................................... 668
Display
Charging .... 111, 127, 136, 137, 146
Dynamic radar cruise control ..... 327
Multi-information display ............ 159
RCTA.......................................... 376

699

Speed limiter ..............................343
Toyota parking assist-sensor......366
Warning message ......................627
Do-it-yourself maintenance .571, 573
Door courtesy lights.....................528
Door lock
Power back door ........................178
Side doors ..................................173
Smart entry & start system.........191
Wireless remote control .............169
Doors
Automatic door locking and unlocking system................................177
Door glasses ..............................218
Door lock warning buzzer...........174
Outside rear view mirrors ...........214
Rear door child-protectors..........177
Side doors ..................................173
Double locking system...................84
Driver’s seat position memory
Driving position memory.............221
Memory recall function ...............223
Power easy access system........221
Drive-start control.........................234
Driving
Battery Electric Vehicle driving tips
...................................................99
Break-in tips ...............................230
Correct driving posture.................31
Procedures.................................229
Winter drive tips .........................508
Driving information display .........161
Driving position memory .............221
Memory recall function ...............223
Power easy access system........221
Driving range.................................156
Driving support system information
display .........................................161
Dynamic radar cruise control ......324
Warning lights.............................623
Warning message ......................330

E
eCall .................................................69

700

Alphabetical Index

ECB (Electronically Controlled Brake
System) ....................................... 502
Eco heat/cool ................................ 520
Eco mode ...................................... 251
EDR (Event data recorder)............... 8
Electric motor (traction motor)
Location ....................................... 90
Electric Power Steering (EPS)..... 502
Warning light .............................. 621
Electric Vehicle system features... 90
Electric Vehicle system precautions
....................................................... 94
Electricity consumption....... 161, 164
Average electricity consumption 161
Current electricity consumption.. 161
Electronic key ....................... 168, 171
Battery-saving function .............. 192
If the electronic key does not operate
properly.................................... 656
Replacing the battery ................. 604
Electronic sunshade .................... 540
Operation ................................... 540
Electronically Controlled Brake System (ECB).................................... 502
Emergency brake signal .............. 502
Emergency Driving Stop System 346
Emergency flashers ..................... 610
Emergency tire puncture repair kit
..................................................... 634
Emergency, in case of
If a warning buzzer sounds ........ 619
If a warning light turns on........... 619
If a warning message is displayed
................................................. 627
If the 12-volt battery is discharged
................................................. 658
If the electronic key does not operate
properly.................................... 656
If the EV system will not start..... 653
If the vehicle is submerged or water
on the road is rising ................. 611
If you have a flat tire........... 634, 645
If you lose your keys .................. 655
If you think something is wrong.. 617
If your vehicle becomes stuck.... 665

If your vehicle has to be stopped in
an emergency ..........................610
If your vehicle needs to be towed
.................................................613
If your vehicle overheats ............663
Engine
Hood...........................................580
Identification number..................669
EPS (Electric Power Steering) .....502
Warning light ..............................621
ERA-GLONASS/EVAK ....................79
EV system
Acoustic Vehicle Alerting System .92
Battery Electric Vehicle driving tips
...................................................99
Brake Override System ..............230
Drive-start control.......................234
Driving range..............................101
Electric Vehicle system precautions
...................................................94
Emergency shut off system..........98
Features .......................................90
How to use AC charging............. 115
How to use DC charging ............120
If the EV system will not start .....653
If your vehicle has to be stopped in
an emergency ..........................610
Overheating................................663
Power meter...............................156
Power switch ..............................243
Regenerative braking ...................91
Starting the EV system...............243
Event data recorder (EDR) ...............8
Extended Headlight Lighting system
.....................................................263

F
FCTA (Front Crossing Traffic Alert)
.....................................................317
Flat tire
Tire pressure warning system ....590
Vehicles with a spare tire ...........645
Vehicles without a spare tire ......634
Floor mats .......................................30

Alphabetical Index

Fluid
Brake.......................................... 672
Transmission.............................. 672
Washer....................................... 588
Fog lights
Replacing light bulbs.................. 608
Switch ........................................ 271
Footwell lights .............................. 528
Front Crossing Traffic Alert (FCTA)
..................................................... 317
Front position light
Light switch ................................ 260
Replacing light bulbs.................. 608
Front seats
Adjustment ................................. 196
Cleaning..................................... 567
Correct driving posture................. 31
Driving position memory ............ 221
Head restraints........................... 200
Memory recall function............... 223
Power easy access system........ 221
Seat heaters............................... 525
Seat position memory ................ 221
Seat ventilators .......................... 525
Front turn signal lights
Replacing light bulbs.................. 608
Turn signal lever ........................ 253
Fuses ............................................. 606

G
Gauges .......................................... 156
Grip Control .................................. 500
Grocery bag hooks....................... 534

H
Hands Free Power Back Door ..... 182
Head restraints ............................. 200
Headlights ..................................... 260
Adaptive High-beam System ..... 264
Extended Headlight Lighting system
................................................. 263
Light switch ................................ 260
Replacing light bulbs.................. 608

701

Heated steering wheel
ALL AUTO (ECO) control ...........516
Heater coolant
Capacity .....................................671
Checking ....................................583
Heaters
Front automatic air conditioning system ...........................................518
Heated steering wheel ...............525
Outside rear view mirrors ...........521
Seat heaters...............................525
Traction battery heater ...............109
Hill-start assist control.................502
Hood
Open ..........................................580
Hooks
Cargo hooks...............................534
Coat hooks .................................552
Grocery bag hooks.....................534
Retaining hooks (floor mat) ..........30
Horn ...............................................203

I
Identification
Engine ........................................669
Vehicle........................................668
If the charging port lids cannot be
opened.........................................655
If your vehicle overheats..............663
Ignition switch (Power switch) ....243
Auto power off function ..............246
Changing power switch modes ..246
If your vehicle has to be stopped in
an emergency ..........................610
Starting the EV system...............243
Illuminated entry system..............528
Immobilizer system ........................83
Indicators
Charging indicator ......................105
Initialization
Electronic sunshade...................540
Items to initialize.........................690
Power windows ..........................218
Inside rear view mirror .........204, 205

702

Alphabetical Index

Installing a CRS to a front passenger
seat ................................................ 48
Intercooler coolant
Capacity ..................................... 670
Interior lights ................................ 528

J
Jack
Positioning a floor jack ............... 581
Vehicle-equipped jack ................ 646
Jack handle ................................... 646
Jam protection function
Power back door ........................ 183
Power windows .......................... 218

K
Keyless entry
Smart entry & start system......... 191
Wireless remote control ............. 169
Keys
Battery-saving function .............. 192
Electronic key............................. 168
If the electronic key does not operate
properly.................................... 656
If you lose your keys .................. 655
Key number plate....................... 168
Keyless entry ..................... 169, 191
Mechanical key .......................... 168
Power switch.............................. 243
Replacing the battery ................. 604
Warning buzzer .......................... 191
Wireless remote control ............. 169
Knee airbags ................................... 37

L
Lane change Assist (LCA) ........... 304
Lane Departure Alert (LDA) ......... 307
Warning lights ............................ 623
Lane Tracing Assist (LTA)
Operation ................................... 299
Warning lights ............................ 622
LCA (Lane change Assist) ........... 304

LDA (Lane Departure Alert)..........307
Warning lights.............................623
Lever
Auxiliary catch lever ...................580
Hood lock release lever..............580
Turn signal lever.........................253
Wiper lever .................................271
License plate lights
Light switch ................................260
Replacing light bulbs ..................608
Light bulbs
Replacing ...................................608
Lights
Automatic High Beam system ....268
Extended Headlight Lighting system
.................................................263
Fog light switch ..........................271
Front personal lights...................529
Headlight switch .........................260
Interior lights.......................528, 529
Interior lights list .........................528
Rear personal lights ...................529
Replacing light bulbs ..................608
Turn signal lever.........................253
Vanity lights ................................541
Locking and unlocking the AC
charging connector....................106
LTA (Lane Tracing Assist)
Operation ...................................299
Warning lights.............................622
Luggage cover ..............................536

M
Maintenance
Do-it-yourself maintenance ........578
Maintenance data.......................668
Maintenance requirements.571, 572
Scheduled maintenance.............574
Manual headlight leveling dial.....263
Max heat ........................................520
Menu icons ....................................160
Meter
Clock ..........................................156
Indicators....................................153

Alphabetical Index

Instrument panel light control..... 158
Meter control switches ............... 160
Meters ........................................ 156
Multi-information display ............ 159
Warning lights ............................ 619
Warning message ...................... 627
Mirrors
Digital Rear-view Mirror ............. 205
Inside rear view mirror ............... 204
Outside rear view mirror defoggers
................................................. 521
Outside rear view mirrors........... 214
Vanity mirrors ............................. 541
Motor
Compartment ............................. 583
Multi-information display
Audio system-linked display....... 162
Charging .... 111, 127, 136, 137, 146
Driving information display......... 161
Driving support system information
display ..................................... 161
Dynamic radar cruise control ..... 327
Electricity consumption .............. 161
Menu icons................................. 160
Meter control switches ............... 160
Navigation system-linked display161
Speed limiter .............................. 343
Suggestion function ................... 163
Tire pressure .............................. 590
Warning message ...................... 627
Multi-terrain Monitor..................... 433
How to switch the display........... 437
If you notice any symptoms ....... 493
Screen display ........................... 434
My Room Mode ............................. 136
Starting My Room Mode ............ 136
Warning messages .................... 137
My Settings ................................... 224

N
Navigation system-linked display161

703

O
Odometer.......................................158
Odometer and trip meter display
Display items..............................158
Open tray .......................................533
Opener
Hood...........................................580
Outer foot lights
Location......................................528
Outside door handle lights ..........528
Outside rear view mirrors
Adjustment .................................214
BSM (Blind Sport Monitor) .........348
Folding ...............................215, 216
Linked mirror function when reversing ............................................216
Mirror position memory ..............221
Outside rear view mirror defoggers
.................................................521
RCTA function ............................375
Safe Exit Assist ..........................361
Outside temperature.....................156

P
Paddle shift switch .......................252
Parking assist sensors (Toyota parking assist-sensor).......................366
Parking brake
Operation ...................................254
Parking brake engaged warning
buzzer ......................................256
Warning light ..............................625
Warning message ......................256
Parking Support Brake function
(moving vehicles rear of the vehicle) ...............................................393
Parking Support Brake function
(pedestrians rear of the vehicle)394
Parking Support Brake function
(static objects around the vehicle)
.....................................................389

704

Alphabetical Index

Parking Support Brake function
(static objects front and rear of the
vehicle)........................................ 389
PCS (Pre-Collision System)
Function ..................................... 288
Warning light .............................. 622
PDA
Warning lights ............................ 623
PDA (Proactive driving assist) .... 312
Personal lights.............................. 528
PKSB (Parking Support Brake) ... 384
Power back door .......................... 178
Hands Free Power Back Door ... 182
Smart entry & start system......... 179
Power control unit coolant
Checking .................................... 585
Preparing and checking before winter ............................................ 508
Power easy access system ......... 221
Power meter .................................. 156
Power outlets ................................ 542
Power outlets (1500 W) ................ 553
Power steering (Electric power
steering system)......................... 502
Warning light .............................. 621
Power switch ................................ 243
Auto power off function .............. 246
Changing power switch modes .. 246
If your vehicle has to be stopped in
an emergency .......................... 610
Starting the EV system .............. 243
Power windows
Door lock linked window operation
................................................. 219
Jam protection function.............. 218
Operation ................................... 218
Window lock switch.................... 220
Pre-Collision System (PCS)
Function ..................................... 288
Warning light .............................. 622

R
Radar cruise control (dynamic radar
cruise control) ............................ 324

Radiator .........................................584
RCD (Rear Camera Detection) .....380
RCTA
Function .....................................375
RCTA function ...............................376
Rear Crossing Traffic Alert (RCTA)
.....................................................375
Rear fog light
Replacing light bulbs ..................608
Rear fog lights
Switch.........................................271
Rear seats......................................197
Adjustment .................................197
Folding down the rear seatbacks197
Head restraints...........................200
Seat heaters...............................525
Rear turn signal lights
Replacing light bulbs ..................608
Turn signal lever.........................253
Rear Vehicle Approaching Indication
.....................................................354
Rear view mirror
Digital Rear-view Mirror..............205
Inside rear view mirror................204
Outside rear view mirrors ...........214
Rear window defogger .................521
Rear window wiper .......................274
Regenerative braking .....................91
Replacing
Electronic key battery.................604
Fuses .........................................606
Light bulbs..................................608
Tires ...........................................645
Road Sign Assist (RSA) ...............320
RSA (Road Sign Assist) ...............320

S
Safe Exit Assist.............................361
Seat belt reminder light................621
Seat belts
Child restraint system installation.46
Cleaning and maintaining the seat
belt ...........................................567
Emergency Locking Retractor......35

Alphabetical Index

How to wear your seat belt .... 32, 34
How your child should wear the seat
belt ............................................. 34
Pregnant women, proper seat belt
use ............................................. 33
Reminder light and buzzer ......... 621
Seat belt pretensioners ................ 35
SRS warning light ...................... 620
Seat heaters
ALL AUTO (ECO) control ........... 516
Seat position memory .................. 221
Seat ventilators............................. 525
Seats
Adjustment ......................... 196, 197
Adjustment precautions ..... 196, 199
Child seats/child restraint system
installation.................................. 46
Cleaning..................................... 567
Driving position memory ............ 221
Folding down the rear seatbacks197
Head restraints........................... 200
Power easy access system........ 221
Properly sitting in the seat............ 31
Seat heaters............................... 525
Seat position memory ................ 221
Seat ventilators .......................... 525
Secondary Collision Brake (Rear
Impacts while Stopped) ............. 359
Secondary Collision Brake (Secondary collision reduction at the time
of a frontal collision) .................. 503
Sensor
Automatic headlight system ....... 262
Automatic High Beam system.... 268
Digital Rearview Mirror............... 208
Inside rear view mirror ............... 204
LDA (Lane Departure Alert with
steering control) ....................... 307
LTA (Lane Tracing Assist) .......... 299
Radar sensor ..................... 349, 363
Rain-sensing windshield wipers. 272
RCTA.......................................... 376
Toyota parking assist-sensor ..... 366
Service plug .................................... 94
Shift lever light ............................. 528

705

Shift position.................................247
Paddle shift switch .....................252
Side airbags ....................................37
Side doors .....................................173
Side mirrors
Adjustment .................................214
BSM (Blind Sport Monitor) .........348
Folding ...............................215, 216
Linked mirror function when reversing ............................................216
Mirror position memory ..............221
RCTA function ............................375
Side turn signal lights
Replacing light bulbs ..................608
Turn signal lever.........................253
Side windows ................................218
Smart entry & start system
Antenna location ........................191
Entry functions ...................173, 179
Starting the EV system...............243
Snow mode....................................497
Snow tires......................................508
SOC (State of Charge) gauge ......156
Software update............................276
“SOS” button ..................................79
Spare tire .......................................645
Storage location .........................646
Specifications ...............................668
Speed limiter .................................343
Speedometer .................................156
Steering lock
Column lock release...................244
Steering lock system warning message .........................................244
Steering wheel
Adjustment .................................203
Heated steering wheel ...............525
Meter control switches ...............160
Power easy access system........221
Steering wheel position memory 221
Stop lights
Emergency brake signal.............502
Replacing light bulbs ..................608
Storage features ...........................531

706

Alphabetical Index

Stuck
If the vehicle becomes stuck...... 665
Suggestion function..................... 163
Sun visors ..................................... 541
Sunshade ...................................... 540
Switches
Automatic High Beam system.... 268
Brake Hold switch ...................... 257
Camera switch ........................... 437
Digital Rear-view Mirror control
switches ................................... 205
Door lock switches ..................... 176
Driving position memory switches
................................................. 221
Dynamic radar cruise control switch
................................................. 327
Eco mode................................... 251
Electronic sunshade switch........ 540
Emergency flashers switch ........ 610
Fog light switch .......................... 271
Grip Control................................ 500
Heated steering wheel switch .... 525
Ignition switch (Power switch).... 243
Inside lock buttons ..................... 176
Light switches ............................ 260
Meter control switches ............... 160
Outside rear view mirror switches
................................................. 214
Paddle shift switch ..................... 252
Parking brake switch.................. 254
Power switch.............................. 243
Power window switches ............. 218
RCTA switch............................... 376
Seat heater switches.................. 525
Seat ventilator switches ............. 525
Snow mode switch ..................... 497
“SOS” button ................................ 69
Tilt and telescopic steering control
switch....................................... 203
Vehicle-to-vehicle distance switch
................................................. 327
VIEW switch............................... 437
VSC OFF switch ........................ 503
Window lock switch.................... 220

Windshield wiper and washer switch
.................................................271
X-MODE switch..........................498
Switching the meter display ........158

T
Tail lights
Light switch ................................260
Replacing light bulbs ..................608
Theft deterrent system
Alarm............................................85
Double locking system .................84
Immobilizer system ......................83
Things you should know
If you notice any symptoms........493
Tire inflation pressure
Maintenance data.......................673
Tire inflation pressure display function ...........................................590
Warning light ..............................622
Tire pressure display....................590
Tire pressure warning system
Function .....................................590
Installing tire pressure warning
valves and transmitters ............592
Registering ID codes..................596
Registering the position of each
wheel........................................593
Selecting wheel set ....................598
Setting the tire pressure .............594
Warning light ..............................622
Tires
Chains ........................................509
Checking ....................................589
Emergency tire puncture repair kit
.................................................634
If you have a flat tire...........634, 645
Inflation pressure........................599
Replacing ...................................645
Rotating tires ..............................590
Size ............................................673
Snow tires ..................................508
Spare tire....................................645

Alphabetical Index

Tire inflation pressure display function ........................................... 590
Tire pressure warning system .... 590
Warning light .............................. 622
Tools .............................................. 646
Top tether anchorages ................... 63
Towing
Emergency towing ..................... 613
Towing eyelet ............................. 615
Trailer towing ............................. 237
Toyota parking assist-sensor
Function ..................................... 366
Warning lights ............................ 624
Toyota Safety Sense
AHB (Automatic High Beam) ..... 268
AHS (Adaptive High-beam System)
................................................. 264
Driver monitor ............................ 286
Dynamic radar cruise control ..... 324
Emergency Driving Stop System346
FCTA (Front Crossing Traffic Alert)
................................................. 317
LCA (Lane change Assist).......... 304
LDA (Lane Departure Alert)........ 307
LTA (Lane Tracing Assist) .......... 299
PCS (Pre-Collision System)....... 288
PDA (Proactive driving assist).... 312
RSA (Road Sign Assist) ............. 320
Software update......................... 276
Speed limiter .............................. 343
Toyota Teammate Advanced Park396
Memory function ........................ 418
Parallel exiting function .............. 416
Parallel parking function............. 413
Perpendicular exiting (forward/reverse) function ............. 411
Perpendicular parking (forward/reverse) function ............. 408
Remote control function ............. 422
Traction battery
Charging ............................ 115, 120
Location ....................................... 90
Specification............................... 670
Traction battery cooler ............... 109
Traction battery heater ............... 109

707

Warning messages.....................146
Traction Control (TRC) .................502
Trailer Sway Control .....................502
Trailer towing ................................237
TRC (Traction Control) .................502
Trip meters ....................................158
Turn signal lights
Replacing light bulbs ..................608
Turn signal lever.........................253

U
USB charging ports ......................542

V
Vanity lights...................................541
Vanity mirrors................................541
Vehicle data recording .................7, 8
Vehicle identification number......668
Vehicle Stability Control (VSC)....502
Vehicle Stability Control+ (VSC+)502
Ventilators (seat ventilators)........525
VSC (Vehicle Stability Control)....502
VSC+ (Vehicle Stability Control+)502

W
Warning buzzers
ABS ............................................620
Airbags .......................................620
Approach warning ......................330
Brake system .............................619
Cruise control .............................623
Door lock ....................................174
Dynamic radar cruise control .....623
Electric power steering...............621
EV system malfunction...............620
Inappropriate pedal operation ....620
LDA (Lane Departure Alert)........623
LTA (Lane Tracing Assist)...299, 622
Open window .............................219
PCS (Pre-Collision System) .......622
PDA............................................623
Pre-collision warning ..................289

708

Alphabetical Index

Seat belt..................................... 621
Tire pressure .............................. 622
Toyota parking assist-sensor ... 372,
624
Warning lights............................... 619
ABS............................................ 620
Brake hold operated indicator .... 625
Brake system ............................. 619
Charging system ........................ 619
Cruise control indicator .............. 623
Driving assist information indicator
................................................. 624
Dynamic radar cruise control indicator ............................................ 623
Electric power steering............... 621
EV system malfunction indicator
lamp ......................................... 620
Inappropriate pedal operation warning light .................................... 620
LDA indicator.............................. 623
LTA indicator .............................. 622
Parking brake indicator .............. 625
PDA indicator ............................. 623
Pre-collision system ................... 622
Seat belt reminder light .............. 621
Slip indicator .............................. 625
SRS............................................ 620
Tire pressure .............................. 622
Toyota parking assist-sensor OFF
indicator ................................... 624
Traction battery charge warning light
................................................. 621
Warning messages....................... 627
Washer
Low washer fluid warning message
................................................. 588
Preparing and checking before winter ............................................ 508
Switch ........................................ 271
Washing and waxing .................... 564
Weight
Cargo capacity ........................... 235
Weight........................................ 668
Wheels ........................................... 600
Size ............................................ 673

Window lock switch......................220
Windows
Power windows ..........................218
Rear window defogger ...............521
Washer .......................................271
Windshield wipers
Rain-sensing windshield wipers .271
Winter driving tips ........................508
Wireless charger...........................544
Wireless remote control
Battery-Saving Function.............192
Locking/Unlocking ......................169
Replacing the battery .................604

X
X-MODE .................................497, 498
Grip control.................................497

For information regarding the
equipment listed below, refer
to the “Multimedia owner’s
manual”.
· Voice control system
· Navigation system
· Audio/visual system
· Toyota parking assist monitor
· Panoramic view monitor

Alphabetical Index

709

710
Certifications
 eCall

711

 Smart entry & start system and immobilizer system

712

713

714

715

716

717

718

719

720

721

722

723

724

725

726

727
 Smart entry & start system

728

729

730

731

732

733

734

735

736

737

738

739

740

741

742

743

744

745

746

747

748

749

750

751

752

753

754

755

756

757

758

759

760

761

762

 Digital key

763

764

765

766

767

768

769

770

771

772
 Toyota Safety Sense

773

774

775

776

777

778

779

780
 BSM (Blind Spot Monitor)

781

782

783

784

785

786

787

788

789

790

791

792

793

794

795

796

797

798

799
 Tire pressure warning system

800

801

802

803

804

805

806

807

808

809
 Wireless charger

810

811

812

813

814

815

816

817

818
 Jack

 Air conditioning system

Type: R-1234yf (HFO-1234yf)
Capacity: 0.700 kg (1.54 lb.)

819
GWP (Global Warming Potential): 0.501
CO2 equivalent: 0.000351 t (0.774 lb.)
