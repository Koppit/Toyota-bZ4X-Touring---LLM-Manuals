# 8-1. Essential information

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 8: When trouble arises, pages 609–612

609

When trouble arises

8-1. Essential information
.

Emergency flashers ..........610

8
If the vehicle becomes stuck
........................................665

If your vehicle has to be
stopped in an emergency
.......................................610
If the vehicle is submerged or
water on the road is rising
.......................................611
8-2. Steps to take in an emergency
If your vehicle needs to be
towed ..............................613
If you think something is wrong
.......................................617
If a warning light turns on or a
warning buzzer sounds...619
If a warning message is displayed .............................627
If you have a flat tire (vehicles
with an emergency tire puncture repair kit) .................634
If you have a flat tire (vehicles
with a spare tire) .............645

If you lose your keys .........655
If the charging port lids cannot
be opened ......................655
If the electronic key does not
operate properly .............656
If the 12-volt battery is discharged ..........................658
If your vehicle overheats...663

When trouble arises

If the EV system will not start
.......................................653

8

610

8-1. Essential information

Emergency flashers

8-1.Essential information

The emergency flashers are
used to warn other drivers
when the vehicle has to be
stopped on the road due to a
breakdown, etc.

Operating instructions
Press the switch.
All the turn signal lights will flash. To
turn them off, press the switch once
again.

If your vehicle has to be
stopped in an emergency
Only in an emergency, such as
if it becomes impossible to
stop the vehicle in the normal
way, stop the vehicle using the
following procedure:

Stopping the vehicle
1 Steadily step on the brake pedal
with both feet and firmly depress
it.
Do not pump the brake pedal repeatedly as this will increase the effort
required to slow the vehicle.

2 Shift the shift position to N.
 If the shift position is shifted to N

3 After slowing down, stop the
vehicle in a safe place by the
road.
n Emergency flashers
l If the emergency flashers are used for
a long time while the EV system is not
operating (while the “READY” indicator is not illuminated), the 12-volt battery may discharge.

l If any of the SRS airbags deploy

(inflate) or in the event of a strong rear
impact, the emergency flashers will
turn on automatically.
The emergency flashers will turn off
automatically after operating for
approximately 20 minutes. To manually turn the emergency flashers off,
press the switch twice. (The emergency flashers may not turn on automatically depending on the force of
the impact and conditions of the collision.)

4 Stop the EV system.
 If the shift position cannot be

shifted to N
3 Keep depressing the brake
pedal with both feet to reduce
vehicle speed as much as possible.
4 To stop the EV system, press
and hold the power switch for 2
consecutive seconds or more,

8-1. Essential information

or press it briefly 3 times or
more in succession.

5 Stop the vehicle in a safe place
by the road.
n If emergency stopped
The functions of the air conditioning, etc.
may be partially limited in order to
reduce the power consumption of the
12-volt battery.

WARNING
n If the EV system has to be turned

If the vehicle is submerged or water on the
road is rising
This vehicle is not designed to
be able to drive on roads that
are deeply flooded with water.
Do not drive on roads where
the roads may be submerged
or the water may be rising. It is
dangerous to remain in the
vehicle, if it is anticipated that
the vehicle will be flooded or
set adrift. Remain calm and follow the following.
 If the door can be opened, open
the door and exit the vehicle.
 If the door cannot be opened,
open the window using the
power window switch and ensure
an escape route.
 If the window can be opened,
exit the vehicle through the window.
 If the door and window cannot be
opened due to the rising water,
remain calm, wait until the water
level inside the vehicle rises to
the point that the water pressure
inside of the vehicle equals the
water pressure outside of the
vehicle and then open the door
after waiting for the rising water
to enter the vehicle, and exit the
vehicle.
When the outside water level exceeds
half the height of the door, the door
cannot be opened from the inside due

8

When trouble arises

off while driving
Turning the EV system off while driving will not cause a loss of steering or
braking control. However, power
assist for the steering wheel may be
lost making it difficult to steer
smoothly before stopping the vehicle
depending on the remaining charge in
the 12-volt battery or usage conditions. Decelerate as much as possible
before turning off the EV system.

611

612

8-1. Essential information

to water pressure.

n Water level exceeds the floor
When the water level exceeds the floor
and time has passed, the electrical
equipment will get damaged, the power
windows will not operate, the motor
stops, and the vehicle may not be able
to get moving.

n Using an emergency escape hammer*1
Laminated glass*2 is used in the windshield and the windows on this vehicle.
Laminated glass cannot be shattered
with an emergency hammer*1.
*1: Contact any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer, or
aftermarket accessory manufacturer
for further information about an emergency hammer.
*2: If equipped

n How to distinguish laminated glass
When looking from the cross-sectional
view point, laminated glass is two
sheets of glass pasted together.

A Laminated glass
B Tempered glass

WARNING
n Caution while driving
Do not drive on roads where the
roads may be submerged or the water
may be rising. Otherwise the vehicle
may be damaged and cannot move,
as well as become flooded and set
adrift, which may lead to death.
