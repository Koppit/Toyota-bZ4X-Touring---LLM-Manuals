# 1-1. For safe use

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 1: For safety and security, pages 30–43

30

1-1. For safe use

Before driving

1-1.For safe use

Observe the following before
starting off in the vehicle to
ensure safety of driving.

Installing floor mats
Use only floor mats designed specifically for vehicles of the same
model and model year as your vehicle. Fix them securely in place onto
the carpet.
1 Insert the retaining hooks (clips)
into the floor mat eyelets.

may differ from that shown in the illustration.

WARNING
Observe the following precautions.
Failure to do so may cause the
driver’s floor mat to slip, possibly
interfering with the pedals while driving. An unexpectedly high speed may
result or it may become difficult to
stop the vehicle. This could lead to an
accident, resulting in death or serious
injury.

n When installing the driver’s floor
mat
l Do not use floor mats designed for
other models or different model
year vehicles, even if they are
Toyota Genuine floor mats.

l Only use floor mats designed for
the driver’s seat.

l Always install the floor mat securely
using the retaining hooks (clips)
provided.

l Do not use two or more floor mats
on top of each other.

l Do not place the floor mat bot-

2 Turn the upper knob of each
retaining hook (clip) to secure
the floor mats in place.

Always align the

marks A .

The shape of the retaining hooks (clips)

tom-side up or upside-down.

n Before driving
l Check that the floor mat is securely

fixed in the correct place with all the
provided retaining hooks (clips). Be
especially careful to perform this
check after cleaning the floor.

1-1. For safe use

WARNING

31

For safe driving

l With the EV system stopped and

the shift position in P, fully depress
each pedal to the floor to make sure
it does not interfere with the floor
mat.

For safe driving, adjust the
seat and mirror to an appropriate position before driving.

Correct driving posture

1

For safety and security

A Adjust the angle of the seatback
so that you are sitting straight up
and so that you do not have to
lean forward to steer. (P.196)
B Adjust the seat so that you can
depress the pedals fully and so
that your arms bend slightly at
the elbow when gripping the
steering wheel. (P.196)
C Lock the head restraint in place
with the center of the head
restraint closest to the top of
your ears. (P.200)

Wear the seat belt correctly.
(P.33)

32

1-1. For safe use

WARNING
n For safe driving
Observe the following precautions.
Failure to do so may result in death or
serious injury.
l Do not adjust the position of the
driver’s seat while driving.
Doing so could cause the driver to
lose control of the vehicle.
l Do not place a cushion between the

driver or passenger and the
seatback.
A cushion may prevent correct posture from being achieved, and
reduce the effectiveness of the seat
belt and head restraint.

l Do not place anything under the

front seats.
Objects placed under the front
seats may become jammed in the
seat tracks and stop the seat from
locking in place. This may lead to
an accident and the adjustment
mechanism may also be damaged.

l Always observe the legal speed

limit when driving on public roads.

l When driving over long distances,

take regular breaks before you start
to feel tired.
Also, if you feel tired or sleepy while
driving, do not force yourself to continue driving and take a break
immediately.

Correct use of the seat belts
Make sure that all occupants are
wearing their seat belts before driving the vehicle. (P.33)
Use a child restraint system appropriate for the child until the child
becomes large enough to properly
wear the vehicle’s seat belt.
(P.46)

Adjusting the mirrors
Make sure that you can see the
rear of the vehicle clearly, by
adjusting the inside rear view mirror
(if equipped), Digital Rear-view Mirror (if equipped) and outside rear
view mirrors properly. (P.204,
205, 214)

1-1. For safe use

Seat belts

33

n Pregnant women

Make sure that all occupants
are wearing their seat belts
before driving the vehicle.
WARNING

1

n Wearing a seat belt
l Ensure that all passengers wear a
seat belt.

l Always wear a seat belt properly.
l Each seat belt should be used by

one person only. Do not use a seat
belt for more than one person at
once, including children.

l Toyota recommends that children

be seated in the rear seat and
always use a seat belt and/or an
appropriate child restraint system.

l To achieve a proper seating posi-

tion, do not recline the seat more
than necessary. The seat belt is
most effective when the occupants
are sitting up straight and well back
in the seats.

l Do not wear the shoulder belt under
your arm.

l Always wear your seat belt low and
snug across your hips.

Obtain medical advice and wear the
seat belt in the proper way. (P.34)
Women who are pregnant should
position the lap belt as low as possible over the hips in the same manner
as other occupants, extending the
shoulder belt completely over the
shoulder and avoiding belt contact
with the rounding of the abdominal
area.
If the seat belt is not worn properly,
not only the pregnant woman, but
also the fetus could suffer death or
serious injury as a result of sudden
braking or a collision.

n People suffering illness
Obtain medical advice and wear the
seat belt in the proper way. (P.34)

n When children are in the vehicle

P.65

n Seat belt damage and wear
l Do not damage the seat belts by

allowing the belt, plate, or buckle to
be jammed in the door.

For safety and security

Observe the following precautions to
reduce the risk of injury in the event of
sudden braking, sudden swerving or
an accident.
Failure to do so may cause death or
serious injury.

34

1-1. For safe use

WARNING
l Inspect the seat belt system periodically. Check for cuts, fraying, and
loose parts. Do not use a damaged
seat belt until it is replaced. Damaged seat belts cannot protect an
occupant from death or serious
injury.

l Ensure that the belt and plate are

locked and the belt is not twisted.
If the seat belt does not function
correctly, immediately contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

l Replace the seat assembly, includ-

ing the belts, if your vehicle has
been involved in a serious accident,
even if there is no obvious damage.

l Do not attempt to install, remove,

 Position the lap belt as low as
possible over the hips.
 Adjust the position of the
seatback. Sit up straight and well
back in the seat.
 Do not twist the seat belt.
n Child seat belt usage
The seat belts of your vehicle were principally designed for persons of adult
size.
l Use a child restraint system appropriate for the child, until the child
becomes large enough to properly
wear the vehicle’s seat belt. (P.65)

l When the child becomes large

enough to properly wear the vehicle’s
seat belt, follow the instructions
regarding seat belt usage. (P.33)

modify, disassemble or dispose of
the seat belts. Have any necessary
repairs carried out by any authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer. Inappropriate handling
may lead to incorrect operation.

n Seat belt regulations
If seat belt regulations exist in the country where you reside, please contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer for seat belt replacement or
installation.

Correct use of the seat belts

Fastening and releasing the
seat belt

 Extend the shoulder belt so that
it comes fully over the shoulder,
but does not come into contact
with the neck or slide off the
shoulder.

1 To fasten the seat belt, push the
plate into the buckle until a click
sound is heard.
2 To release the seat belt, press

1-1. For safe use

the release button A .
n Emergency locking retractor (ELR)
The retractor will lock the belt during a
sudden stop or on impact. It may also
lock if you lean forward too quickly.
When the seat belt locks, pull the belt
strongly and then release the belt, then
a slow and easy pulling will allow the
belt to extend.

WARNING
n Adjustable shoulder anchor
Always make sure the shoulder belt is
positioned across the center of your
shoulder. The belt should be kept
away from your neck, but not falling
off your shoulder. Failure to do so
could reduce the amount of protection
in an accident and cause death or
serious injuries in the event of a sudden stop, sudden swerve or accident.

Seat belt pretensioners
When the vehicle is subjected to a
severe frontal or side impact, the
pretensioners retract the seat belts
of the front seats and rear outer
seats to securely restrain the occupants.
The pretensioners will not operate in
minor frontal or side impacts, rear
impacts, or vehicle rollovers.

1 Push the seat belt shoulder
anchor down while pressing the
release button A .
2 Push the seat belt shoulder
anchor up while pressing the
release button A .
Move the height adjuster up and down
as needed until you hear a click.

n Replacing the belt after the

pretensioner has been activated
If the vehicle is involved in multiple collisions, the pretensioner will activate for
the first collision, but will not activate for
the second or subsequent collisions.

n PCS-linked control (vehicles with

Toyota safety sense)
If the PCS (Pre-Collision System) determines that the possibility of a collision
with a vehicle is high, the seat belt
pretensioners will be prepared to operate.

1

For safety and security

Adjusting the seat belt
shoulder anchor height
(front seats)

35

36

1-1. For safe use

WARNING
n Seat belt pretensioners
If a pretensioner has operated, the
SRS warning light will illuminate. In
this situation, the seat belt cannot be
used and must be replaced at any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
Failure to do so may result in death or
serious injury.

1-1. For safe use

37

SRS airbags
The SRS airbags deploy when the vehicle is subjected to certain
types of severe impact that may cause significant injury to the occupants. The airbags work together with the seat belts to help reduce
the risk of death or serious injury.
1

A SRS front airbags (SRS driver airbag/SRS front passenger airbag)
Help reduce impact to the head and chest of the driver and front passenger

B SRS knee airbag (driver seat only)
Help reduce impact to the driver

C SRS side airbags
Help reduce impact to the chest of the occupants of the front seats

SRS curtain shield airbags
Help reduce impact to the heads of the occupants of the front and rear outer seats

SRS front center airbags
Help reduce impact to the head and neck of the occupants of the front seats

The main SRS airbag system components are shown above. The SRS

For safety and security

SRS airbag system

38

1-1. For safe use

airbag system is controlled by the airbag sensor assembly. As the airbags
deploy, a chemical reaction in the inflators quickly fills the airbags with
non-toxic gas to help restrain the motion of the occupants.
n If the SRS airbags deploy (inflate)
l Slight abrasions, burns, bruising, etc.,
may be sustained from SRS airbags,
due to the extremely high speed of
deployment (inflation) by hot gases.

l A loud noise and white powder will be
emitted.

l Parts of the airbag module (steering

wheel hub, airbag cover and inflator)
as well as the parts around the
airbags may be hot for several minutes. The airbag itself may also be
hot.

l The windshield may crack.
l The EV system will be stopped.
(P.98)

l All of the doors will be unlocked.
(P.174)

l The brakes and stop lights will be controlled automatically. (P.503)

l The interior lights will turn on automatically. (P.529)

l The emergency flashers will turn on
automatically. (P.610)

n Emergency call (if equipped)
l For eCall subscribers, if any of the fol-

lowing situations occur, the system is
designed to send an emergency call
to the response center.
• When an SRS airbag has been
deployed
• When a seat belt pretensioner has
operated
• When the vehicle received an impact
exceeding a certain level

l Vehicles with ERA-GLONASS/EVAK:
If any of the following situations occur,
the system is designed to send an
emergency call* to the
ERA-GLONASS/EVAK control center.
• When an SRS airbag has been
deployed

• When a seat belt pretensioner has
operated
• When the vehicle received an impact
exceeding a certain level
Emergency services may be dispatched
even if there is no response to calls from
the agent.
*: In some cases, the call cannot be
made. (P.81)

n The SRS airbags deploy in a frontal
impact when

l The following SRS airbags will deploy

in the event of an impact that exceeds
a threshold level (level of force corresponding to an approximately 20 - 30
km/h [12 - 18 mph] frontal collision
with a fixed wall that does not move or
deform):
• SRS front airbags
• SRS knee airbags

l The threshold level at which the SRS

airbags will deploy will be higher than
normal in the in the following situations:
• When the vehicle collides with an
object, such as a parked vehicle or
sign pole, which moves or deforms on
impact
• If the vehicle is involved in an
underride collision, such as a collision
in which the front of the vehicle
“underrides”, or goes under, the bed
of a truck

l Depending on the type of collision,

only the following may deploy:
• Seat belt pretensioners

l In the event of an especially severe

frontal collision, the left and right SRS
curtain shield airbags may also
deploy.

n The SRS airbags deploy in a side
impact when

l The following SRS airbags will deploy

in the event of an impact that exceeds

1-1. For safe use
the set threshold level (level of force
corresponding to the impact force produced by an approximately 1500 kg
[3300 lb.] vehicle colliding with the
passenger compartment at a perpendicular angle at an approximate speed
of 20 - 30 km/h [12 - 18 mph]):
• SRS side airbags
• SRS curtain shield airbags
• SRS front center airbags

l In the event of a side collision, regard-

n The SRS airbags deploy in an
underside impact when

l The following airbags may deploy if

deploy if the vehicle is collided with at
a certain angle or in a side collision
where an area of the vehicle other
than the passenger compartment is
collided with:
• SRS side airbags
• SRS curtain shield airbags
• SRS front center airbags

the underside of the vehicle collides
with a hard object:
• SRS front airbags
• SRS knee airbags
• SRS side airbags
• SRS curtain shield airbags

l The following SRS airbags will not

normally deploy in front or rear collisions, vehicle rollovers, or low speed
side collisions:
• SRS side airbags
• SRS front center airbags

n The SRS airbags will not deploy
when

l The following SRS airbags will not

normally deploy in side or rear collisions, vehicle rollovers, or low speed
frontal collisions. However, if such a
collision causes sufficient sudden
deceleration, the SRS airbags may
deploy.
• SRS front airbags
• SRS knee airbags

l The following SRS airbags will not

normally deploy in rear collisions,
vehicle rollovers, or low speed front or
side collisions:
• SRS curtain shield airbags

1

For safety and security

less of the impacted side, both the left
and right SRS curtain shield airbags
will deploy.

l The following SRS airbags may not

39

40

1-1. For safe use

n When to contact any authorized

Toyota retailer or Toyota authorized
repairer, or any reliable repairer
In the following situations, the vehicle
will require inspection and/or repair.
Contact any authorized Toyota retailer
or Toyota authorized repairer, or any reliable repairer as soon as possible.

l When the pad section of the steering

wheel, the dashboard near the front
passenger SRS airbag or the lower
side of the instrument panel is
scratched, cracked, or otherwise damaged.

l When the surface of a seat with an

l When any of the SRS airbags have

SRS side airbag or SRS front center
airbag is scratched, cracked, or otherwise damaged.

l When the front of the vehicle is dam-

l When the part of a front pillar, rear pil-

been deployed

aged or deformed, or was involved in
a collision that was not severe enough
to cause any of the following SRS
airbags to deploy:
• SRS front airbags
• SRS knee airbags

lar or roof side rail garnish (padding)
which covers a SRS curtain shield
airbag is scratched, cracked, or otherwise damaged.

WARNING
n SRS airbag precautions
Observe the following precautions.
Failure to do so may result in death or
serious injury.
l The driver and all passengers must

l When a door or its surrounding area is

damaged, deformed or has had a hole
made in it, or was involved in a collision that was not severe enough to
cause any of the following SRS
airbags to deploy:
• SRS side airbags
• SRS curtain shield airbags
• SRS front center airbags

wear their seat belts correctly.
The SRS airbags are supplemental
devices to be used with the seat
belts.

1-1. For safe use

WARNING
l The SRS driver airbag deploys with

l The SRS front passenger airbag

deploys with considerable force,
and can cause death or serious
injury, especially if the front passenger is very close to the airbag. The
front passenger seat should be
positioned as far possible from the
airbag with the seatback adjusted
so that the passenger is sat upright.
infants and children can be killed or
seriously injured by a deploying
airbag. An infant or child who is too
small to use a seat belt should be
properly secured using a child
restraint system.Toyota strongly
recommends that all infants and
children be placed in the rear seats
of the vehicle and properly
restrained. The rear seats are safer
for infants and children than the
front passenger seat. (P.46)

• Move your seat to the rear as far as
possible while still being able to
reach the pedals comfortably.

l Do not sit on the edge of the seat or

• Slightly recline the seatback.
Although vehicle designs vary,
many drivers can achieve the 250
mm (10 in.) distance, even with the
driver seat all the way forward, simply by reclining the seatback somewhat. If reclining the seatback
makes it hard to see the road, raise
yourself by using a firm, non-slippery cushion, or raise the seat if
your vehicle has that feature.

l Do not allow a child to stand in front

• If your steering wheel is adjustable,
tilt it downward. This points the
airbag toward your chest instead of
your head and neck. The seat
should be adjusted as recommended above, while still being
able to control the vehicle with the
pedals and steering wheel, and
maintaining your view of the instrument panel controls.

1

l Improperly seated and/or restrained

lean against the dashboard.

of the SRS front passenger airbag
or sit on the lap of a front passenger.

l Front seat occupants should never
hold items on their lap.

For safety and security

considerable force, and can cause
death or serious injury, especially if
the driver is very close to the
airbag.
Since the risk zone for the driver’s
airbag is the first 50-75 mm (2-3 in.) of
inflation, placing yourself 250 mm (10
in.) from your driver airbag provides
you with a clear margin of safety. This
distance is measured from the center
of the steering wheel to your breastbone. If your current driving position
places you less than 250 mm (10 in.)
away from the driver airbag,, you can
change your driving position in several ways:

41

42

1-1. For safe use

WARNING
l Do not lean against the door, roof

side rail, or front, side, or rear pillar.

l Do not attach anything to areas

such as the doors, windshield, side
windows, front or rear pillars, roof
side rails and assist grips. (With the
exception of the speed limit label
P.638)

l Do not allow anyone to kneel on a

seat toward the door or put their
head or hands outside the vehicle.

l Do not hang coat hangers or other

hard objects on the coat hooks.
These items could become projectiles if the SRS curtain shield
airbags deploy, possibly leading to
death or serious injury.

l If a vinyl cover is attached to the

area where the SRS knee airbag
deploys, be sure to remove it.

l Do not attach anything to or lean

anything against areas such as the
dashboard, steering wheel pad and
lower portion of the instrument
panel.

l Do not use seat accessories which

cover the parts from which the SRS
airbags deploy, as they may interfere with inflation of the SRS
airbags. Such accessories may prevent the SRS airbags from deploying correctly, may disable the
system or cause the SRS airbags to
inflate unintentionally, possibly
resulting in death or serious injury.

l Do not strike or apply significant

force to the SRS airbag system
components, front doors or their
surrounding area.
Doing so may cause the SRS
airbags to malfunction.

l Do not touch any components of

the SRS airbags immediately after
the SRS airbags have deployed
(inflated) as they may be hot.

1-1. For safe use

WARNING
l If breathing becomes difficult after

the SRS airbags have deployed,
open a door or window to allow
fresh air in, or leave the vehicle if it
is safe to do so. Wash off any residue as soon as possible to prevent
skin irritation.

l If a part where an SRS airbag is

n Modification and disposal of SRS

airbag system components
Do not dispose of your vehicle or perform any of the following modifications without consulting your any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer. The SRS airbags may malfunction or deploy unintentionally,
possibly leading to death or serious
injury.
l Removal, installation, disassembly
or repair of the SRS airbags

l Repair, removal or modification of

the following parts or their surrounding
• Steering wheel
• Instrument panel
• Dashboard
• Seats
• Seat upholstery
• Front pillars
• Side pillars
• Rear pillars
• Roof side rails
• Front door panels
• Front door trim

• Front door speakers

l Modifications to the front door panels (such as making holes in them)

l Repair or modification of the follow-

ing parts or their surrounding
• Front fender
• Front bumper

1

• Sides of the vehicle interior

l Installation of the following parts or

accessories
• Bull bars or kangaroo bars
• Snow plows
• Winches

l Modifications to the vehicle’s suspension

l Installation of electronic devices

such as mobile two-way radios
(RF-transmitter) and CD players

For safety and security

stored is damaged or cracked, have
it replaced by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

43
