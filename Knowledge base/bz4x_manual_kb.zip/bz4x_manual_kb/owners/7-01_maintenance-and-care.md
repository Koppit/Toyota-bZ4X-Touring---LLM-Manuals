# 7-1. Maintenance and care

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 7: Maintenance and care, pages 564–570

564

7-1. Maintenance and care

Cleaning and protecting
the vehicle exterior

7-1.Maintenance and care

Perform cleaning in a manner
appropriate to each component and its material.

Cleaning instructions
 Working from top to bottom, liberally apply water to the vehicle
body, wheel wells and underside
of the vehicle to remove any dirt
and dust.

increased risk of damage to vehicle.

l When using an automatic car

washes,etc. the shift position needs to
be held in N, refer to P.251.

n High pressure car washes
As water may enter the cabin, do not
bring the nozzle tip near the gaps
around the doors or perimeter of the
windows, or spray these areas continuously.

n Note for a smart entry & start system

l If the door handle becomes wet while

 For hard-to-remove marks, use
car wash soap and rinse thoroughly with water.

the electronic key is within the effective range, the door may lock and
unlock repeatedly. In that case, follow
the following correction procedures to
wash the vehicle:
• Place the key in a position 2 m (6 ft.)
or more separate from the vehicle
while the vehicle is being washed.
(Take care to ensure that the key is
not stolen.)
• Set the electronic key to battery-saving mode to disable the smart entry &
start system. ( P.191)

 Wipe away any water.

l If the electronic key is inside the vehi-

 Wash the vehicle body using a
sponge or soft cloth, such as a
chamois.

 Wax the vehicle when the waterproof coating deteriorates.
If water does not bead on a clean surface, apply wax when the vehicle body
is cool.

n Automatic car washes
l Before washing the vehicle:

• Fold the mirrors
• Turn off the power back door
Start washing from the front of the vehicle. Extend the mirrors before driving.

l Brushes used in automatic car

washes may scratch the vehicle surface, parts (wheel, etc.) and harm
your vehicle’s paint.

l Rear spoiler (if equipped) may not be
washable in some automatic car
washes. There may also be an

cle and a door handle becomes wet
during a car wash, a buzzer may
sound outside the vehicle and “Key
Detected in Vehicle” may be shown on
the multi-information display. To turn
off the alarm, lock all the doors.

n Wheels and wheel ornaments
l Remove any dirt immediately by using
a neutral detergent.

l Wash detergent off with water immediately after use.

l To protect the paint from damage,

make sure to observe the following
precautions.
• Do not use acidic, alkaline or abrasive
detergent
• Do not use hard brushes
• Do not use detergent on the wheels
when they are hot, such as after driving or parking in hot weather

7-1. Maintenance and care

n Wheels and wheel ornaments (vehi-

cles with matte painted wheels)
A different set of care is necessary for
matte painted wheels and wheel ornaments. Contact any authorized Toyota
retailer or Toyota authorized repairer, or
any reliable repairer for details.

l Remove any dirt with water immedi-

ately.
If the wheels are excessively dirty, use
diluted neutral detergent.

l When using detergent, make sure to
wash it off with water immediately.
Then use a soft cloth to wipe off the
water.

l Use a sponge or soft cloth to remove
the dirt by hand.

l To prevent the matte paint from being

n Brake pads and calipers

l Use a soft cloth dampened with an

approximately 5% solution of neutral
detergent and water to clean the dirt
off.

l Wipe the surface with a dry, soft cloth
to remove any remaining moisture.

l To remove oily deposits, use alcohol
wet wipes or a similar product.

WARNING
n When washing the vehicle
Do not apply water to the inside of the
motor compartment. Doing so may
cause the electrical components, etc.
to catch fire.
n When cleaning the windshield
Set the wiper switch to off.
If the switch is in “AUTO”, the wipers
may operate unexpectedly in the following situations, and may result in
hands being caught or other serious
injuries and cause damage to the
wiper blades.

7

A Off
B AUTO

Rust may form if the vehicle is parked
with wet brake pads or disc rotors, causing them to stick. Before parking the
vehicle after it is washed, drive slowly
and apply the brakes several times to
dry the parts.

l When the upper part of the wind-

n Bumpers

l If something bumps against the

Do not scrub with abrasive cleaners.

n Plated portions
If dirt cannot be removed, clean the
parts as follows:

shield where the raindrop sensor is
located is touched by hand

l When a wet rag or similar is held
close to the raindrop sensor
windshield

l If you directly touch the raindrop

sensor body or if something bumps
into the raindrop sensor

Maintenance and care

damaged or glossy, make sure to
observe the following precautions:
• Do not apply any coatings or wax.
• Do not use acidic, alkaline or abrasive
detergents.
• When using tire cleaners or tire wax,
do not allow them to be applied to the
wheels.
• Do not scrub or polish the wheels
using a brush or dry cloth, etc.
• When using an automatic car wash,
do not select the wheel brush function.
• Do not use a high pressure washer or
steam cleaner.
• Do not use detergent on the wheels
when they are hot, such as after driving or parking in hot weather.

565

566

7-1. Maintenance and care

WARNING
n Precaution regarding the front

and rear bumpers
If the paint of the front or rear bumper
is chipped or scratched, the following
systems may not function correctly. If
this occurs, consult any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

l Toyota Safety Sense
l BSM (Blind Spot Monitor) (if
equipped)

l Automatic Rear Flashing Hazard
Lights

l Safe Exit Assist (if equipped)
l RCTA (Rear crossing traffic alert) (if
equipped)

l PKSB (Parking Support Brake) (if
equipped)

l Secondary Collision Brake (Rear
Impacts while Stopped)

l Toyota parking assist-sensor

NOTICE
n To prevent paint deterioration

and corrosion on the body and
components (aluminum wheels,
etc.)
l Wash the vehicle immediately in the
following cases:
• After driving near the sea coast
• After driving on salted roads
• If coal tar or tree sap is present on
the paint surface
• If dead insects, insect droppings or
bird droppings are present on the
paint surface

• After driving in an area contaminated with soot, oily smoke, mine
dust, iron powder or chemical substances
• If the vehicle becomes heavily
soiled with dust or mud
• If liquids such as benzene and gasoline are spilled on the paint surface

l If the paint is chipped or scratched,
have it repaired immediately.

l To prevent the wheels from corroding, remove any dirt and store in a
place with low humidity when storing the wheels.

n Cleaning the exterior lights
l Wash carefully. Do not use organic
substances or scrub with a hard
brush.
This may damage the surfaces of
the lights.

l Do not apply wax to the surfaces of
the lights.
Wax may cause damage to the
lenses.

n When using an automatic car

wash
Set the wiper switch to the off position.
If the wiper switch is in “AUTO”, the
wipers may operate and the wiper
blades may be damaged.

n When using a high pressure car
wash

l When washing the vehicle, do not

spray the camera or its surrounding
area directly with a high pressure
washer. Shock applied from high
pressure water may cause the
device to not operate normally.

l Do not spray water directly on the

radar which is equipped behind the
emblem. Otherwise it may cause
the device to be damaged.

7-1. Maintenance and care

NOTICE
l Do not bring the nozzle tip close to

boots (rubber or resin manufactured cover), connectors or the following parts. The parts may be
damaged if they come into contact
with high-pressure water.
• Traction related parts
• Steering parts
• Suspension parts
• Brake parts

l Keep the cleaning nozzle at least

30 cm (11.9 in.) away from the vehicle body. Otherwise resin section,
such as moldings and bumpers,
may be deformed and damaged.
Also, do not continuously hold the
nozzle in the same place.

l Do not spray the lower part of the

windshield continuously.
If water enters the air conditioning
system intake located near the
lower part of the windshield, the air
conditioning system may not operate correctly.

567

Cleaning and protecting
the vehicle interior
Perform cleaning in a manner
appropriate to each component and its material.

Protecting the vehicle interior
 Remove dirt and dust using a
vacuum cleaner. Wipe dirty surfaces with a cloth dampened with
lukewarm water.
 If dirt cannot be removed, wipe it
off with a soft cloth dampened
with neutral detergent diluted to
approximately 1%.
Wring out any excess water from
the cloth and thoroughly wipe off
remaining traces of detergent
and water.

l Do not wash the underside of the

l Do not use the washer on the area

around the charging port lid. Water
could get into the charging inlet and
could damage the vehicle.

n Cleaning aluminum parts
When cleaning the hood, do not push
hard or put weight on it. The aluminum part may be dented.

n Shampooing the carpets
There are several commercial foaming-type cleaners available. Use a
sponge or brush to apply the foam. Rub
in overlapping circles. Do not use water.
Wipe dirty surfaces and let them dry.
Excellent results are obtained by keeping the carpet as dry as possible.
n Handling the seat belts
Clean with mild soap and lukewarm
water using a cloth or sponge. Also
check the belts periodically for excessive wear, fraying or cuts.
n Front side windows with IR protec-

tive coating
The front side windows have IR protective coating. To prevent any damage to
the IR protective coating, observe the
following:

7

Maintenance and care

vehicle using a high pressure car
washer. If water enters the traction
battery, the EV system may malfunction.

568

7-1. Maintenance and care

l If the windows are dirty, gently wipe

them with a cloth soaked in water or
lukewarm water as soon as possible.

l If the windows are very dirty, do not
open and close them repeatedly.

WARNING
n Water in the vehicle
l Do not splash or spill liquid in the

vehicle.
Doing so may cause electrical components, etc. to malfunction or
catch fire.

l Do not get any of the SRS compo-

nents or wiring in the vehicle interior
wet.
(P.37)
An electrical malfunction may
cause the airbags to deploy or not
function properly, resulting in death
or serious injury.

l Do not let the wireless charger

(P.544) get wet. Failure to do so
may cause the charger to become
hot and cause burns or could cause
electric shock resulting in death or
serious injury.

n Cleaning the interior (especially

instrument panel)
Do not use polish wax or polish
cleaner. The instrument panel may
reflect off the windshield, obstructing
the driver’s view and leading to an
accident, resulting in death or serious
injury.

NOTICE
n Cleaning detergents
l Do not use the following types of

detergent, as they may discolor the
vehicle interior or cause streaks or
damage to painted surfaces:
• Non-seat portions: Organic substances such as benzene or gasoline, alkaline or acidic solutions,
dye, and bleach

• Seats: Alkaline or acidic solutions,
such as thinner, benzene, and alcohol

l Do not use polish wax or polish

cleaner. The instrument panel’s or
other interior part’s painted surface
may be damaged.

n Water on the floor
Do not wash the vehicle floor with
water.
Vehicle systems such as the audio
system may be damaged if water
comes into contact with electrical
components such as the audio system above or under the floor of the
vehicle. Water may also cause the
body to rust.
n When cleaning the inside of the

windshield
Do not allow glass cleaner to contact
the lens. Also, do not touch the lens.
(P.278)

n Cleaning the inside of the rear
window

l Do not use a glass cleaner toclean

the rear window, as thismay cause
damage to the rearwindow defogger heater wires.Use a cloth dampened withlukewarm water to gently
wipethe window clean. Wipe the
windowin strokes running parallelto
the heater wires.

l Be careful not to scratch or damage
the heater wires or antenna.

n Cleaning the front side windows
Do not use any compound orabrasive
product (e.g., glasscleaner, detergent,
wax) to cleanthe windows. It may
damage the coating.

Cleaning the areas withsatin-finish metal accents
 Remove dirt using a waterdampened soft cloth or synthetic

7-1. Maintenance and care

chamois.
 Wipe the surface with a drysoft
cloth to remove anyremaining
moisture.
n Cleaning the areas withsatin-finish

metal accents
The metal areas use a layer of realmetal
for the surface. It is necessaryto clean
them regularly. If dirty areasare left
uncleaned for long periodsof time, they
may be difficult to clean.

Cleaning the leather areas

569

NOTICE
n Preventing damage to leather

surfaces
Observe the following precautions to
avoid damage to and deterioration of
leather surfaces:
l Remove any dust or dirt from
leather surfaces immediately.

l Do not expose the vehicle to direct

sunlight for extended periods of
time. Park the vehicle in the shade,
especially during summer.

l Do not place items made of vinyl,

 Wipe off any excess dirt and dust
with a soft cloth dampened with
diluted detergent.

Cleaning the synthetic
leather areas

Use a diluted water solution of approximately 5% neutral wool detergent.

 Remove dirt and dust using a
vacuum cleaner.

 Wring out any excess water from
the cloth and thoroughly wipe off
all remaining traces of detergent.

 Wipe it off with a soft cloth dampened with neutral detergent
diluted to approximately 1%.

 Wipe the surface with a dry, soft
cloth to remove any remaining
moisture. Allow the leather to dry
in a shaded and ventilated area.

 Wring out any excess water from
the cloth and thoroughly wipe off
remaining traces of detergent
and water.

n Caring for leather areas
Toyota recommends cleaning theinterior of the vehicle at least twice ayear to
maintain the quality of thevehicle’s interior.

Cleaning fabric portions
 To remove dust from the fabric,use a vacuum cleaner oradhesive tape.
However, please remove the dustnear
the passenger airbag ornamentby
hand.

 Use a cloth dampened with
water to gently wipe the fabric

7

Maintenance and care

 Remove dirt and dust using a
vacuum cleaner.

plastic, or containing wax on the
upholstery, as they may stick to the
leather surface if the vehicle interior
heats up significantly.

570

7-1. Maintenance and care

clean.
Do not use detergents to clean the fabric.

 Vehicles with radiant heaters: Do
not hard scrub on the fabricportion of the radiant heaters(
P.526).

Cleaning the instrumentpanel surface
 Remove dirt and dust using
avacuum cleaner.
 Wipe it off with a soft cloth dampened with neutral detergent
diluted to approximately 1%.
 Wring out any excess water from
the cloth and thoroughly wipe off
remaining traces of detergent
and water.
