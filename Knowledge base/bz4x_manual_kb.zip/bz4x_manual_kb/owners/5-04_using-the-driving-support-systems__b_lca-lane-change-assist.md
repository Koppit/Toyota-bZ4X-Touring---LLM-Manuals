# 5-4. Using the driving support systems (part 2: LCA (Lane Change Assist), …)

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 304–334
> Topics in this part: LCA (Lane Change Assist); LDA (Lane Departure Alert); PDA (Proactive driving assist); FCTA (Front Crossing Traffic Alert); RSA (Road Sign Assist); Dynamic radar cruise control

304

5-4. Using the driving support systems

LCA (Lane Change
Assist)*
*: If equipped

LCA functions
This function is linked to the LTA
and provides assistance in performing lane changes through steering
wheel operations.
Use this function only on highways and
expressways.
The steering assist operation can be
overridden by the steering wheel operation of the driver.
The lane change assist function is not
designed to operate when changing
lanes at a junction.

WARNING
n Before using the LCA system
l Do not overly rely on the LCA sys-

tem.
The LCA system is not a system
which provides automated assistance in driving and it is not a system
which reduces the need for checking
an adjacent lane for other vehicles,
approaching vehicles, etc. when
changing lanes. The driver is solely
responsible for paying attention to
their surroundings and operating the
steering wheel as necessary to
ensure safety.
Also, do not use the LCA to change
lanes into which a lane change should
not be performed (oncoming lanes,
road shoulders, etc.).

l Failure to perform appropriate driving operations and pay careful
attention may lead to an accident.

n Operating conditions of function
This function is operable when all of the
following conditions are met:
l The LTA is operating.
l The lane change assist function is
enabled by a customize setting.

l The vehicle speed is between approximately 80 and 140 km/h (50 and 85
mph).

l The system recognizes the current
road as a highway or expressway.

l The system detects a broken white

line on the side which the lane change
is to be performed.

l A vehicle is not detected in the lane

toward which the turn signal is operated.

l The navigation system map data is
correct.

l The steering wheel is not being turned

5-4. Using the driving support systems

305

with a large force.

l The hands off steering wheel warning
(P.301) is not operating.

l The system has detected a moving

object behind the vehicle at least once
since the EV system was started.

n Cancelation of functions
In the following situations, operation of
the LCA may be canceled with the display and buzzer:

l When the operating conditions
(P.304) are no longer met

l When the system can no longer
detect lane lines

l When the turn signal lever is operated
to the second position (P.305)

l When the turn signal lever is operated
in the opposite direction of the lane
change

l When the system detects operation of
the steering wheel, brake pedal or
accelerator pedal by the driver.

l The hands off steering wheel warning

n Hands off steering wheel warning

operation
When the system determines the driver
is not holding the steering wheel, a message urging the driver to grip the steering wheel and the icon shown in the
illustration will be displayed on the
multi-information display to warn the
driver. If the system detects that the
steering wheel is held, the warning will
be canceled. When using the system,
make sure to grip the steering wheel
firmly, regardless of whether the warning
is operating or not.

steering wheel warning may not
operate properly

l Depending on the condition of the

vehicle, handle control condition and
road surface, the warning function
may not operate.

l In the following situations, the system

may not be able to detect when the
driver’s hands are off the steering
wheel.
• When a steering wheel cover is
installed
• When the driver is wearing gloves
• When foreign matter is attached to the
steering wheel
• When the driver is gripping the wood
trim, seam of the leather, spokes, or
other part of the steering wheel that
does not have sensors

l In the following situations, the hands

off steering wheel warning may not
operate and the LCA function may
continue operating even though the
driver’s hands are off the steering
wheel:
• When something other than a hand is
contacting the steering wheel
• When a wide object or arms are held
across the steering wheel

Operating the LCA
If the turn signal lever is held in the
lane change position (1) until a
buzzer sounds, the lane change
direction will be displayed and the
function will operate.
To change lanes by holding the turn sig-

5

Driving

(P.305) is operating.
If the system detects that a vehicle is
quickly approaching in the lane toward
which the turn signal is operated a
buzzer will sound and a message will be
displayed to alert the driver. At the same
time the steering wheel may be slightly
operated to help keep the vehicle away
from the approaching vehicle.

n Situations in which the hands off

306

5-4. Using the driving support systems

nal lever in the first position without
using the LCA, turn the customize setting of the LCA off.

1 First position: LCA is operational
2 Second position: LCA is not
operational
WARNING
n Situations in which the LCA
should not be used

l When driving on a one lane road
l When there is no broken white line
between the current lane and the
lane to be changed to

Enabling/disabling the system
LCA can be enabled/disabled
through a customize setting.
(P.682)

Displays and system operation
The operating state of the LCA system is indicated.
LCA display

Steering icon

Condition

LCA on standby
Gray arrow and green line

Green

LCA is operating
Blue arrow and white line

Green

Gray

Gray line

Gray

Approaching vehicle detected while LCA
is operating

Lane line no longer detected while LCA
is operating

5-4. Using the driving support systems

307

LDA (Lane Departure
Alert)*
*: If equipped

Basic functions
The LDA system warns the driver if
the vehicle may deviate from the
current lane or course*, and also
can slightly operate the steering
wheel to help avoid deviation from
the lane or course*.
The front camera is used to detect
lane lines or a course*.
*: Boundary between the asphalt and

grass, soil, etc., or structures, such
as a curb, guardrail, etc.

n Lane departure alert function

lane or course*, a warning is displayed on a display, and either a
warning buzzer will sound or the
steering wheel will vibrate to alert
the driver.
Check the area around your vehicle
and carefully operate the steering
wheel to move the vehicle back to the
center of the lane or course*.
Vehicles with BSM: If the system determines that the vehicle may collide with
a vehicle in an adjacent lane, the lane
departure alert will operate even if the
turn signals are operating.
*: Boundary between the asphalt and

grass, soil, etc., or structures, such
as a curb, guardrail, etc.

function
If the system determines that the
vehicle is likely to depart from its
lane or course*, it provides assistance through steering wheel operations to help avoid deviation from
the lane or course*.
If the system determines that the steering wheel has not been operated for a
certain amount of time or the steering
wheel is not being firmly gripped, a
warning message may be displayed
and a warning buzzer may sound to
alert the driver.
Vehicles with BSM: If the system determines that the vehicle may collide with
a vehicle in an adjacent lane, the lane
departure prevention function will operate even if the turn signals are operating.
*: Boundary between the asphalt and

grass, soil, etc., or structures, such

5

Driving

When the system determines that
the vehicle might depart from its

n Lane departure prevention

308

5-4. Using the driving support systems

as a curb, guardrail, etc.

n Break suggestion function

If the vehicle is swaying, a message will be displayed and a buzzer
will sound to urge the driver to take
a break.

WARNING
n Before using the LDA system
l Do not overly rely on the LDA sys-

tem. The LDA system is not a system which provides automated
assistance in driving. However, as it
is not a system which reduces the
amount of attention necessary for
safe driving. The driver is solely
responsible for paying attention to
their surroundings and operating
the steering wheel as necessary to
ensure safety. Also, the driver is
responsible for taking adequate
breaks when fatigued, such as
when driving for a long time.

l Failure to perform appropriate driving operations and pay careful
attention may lead to an accident.

n Operating conditions of each function

l Lane departure alert/prevention function

This function is operable when all of the
following conditions are met:

5-4. Using the driving support systems

n Temporary cancellation of func-

tions
When the operating conditions are no
longer met, a function may be temporarily canceled. However, when the operation conditions are met again, operation
of the function will automatically be
restored. (P.308)

n Operation of the lane departure

alert function/lane departure prevention function

l Depending on the vehicle speed, road
conditions, lane departure angle, etc.,
operation of the lane departure prevention function may not be felt or the
function may not operate.

l Depending on the conditions, the

warning buzzer may operate even if
vibration is selected through a customize setting.

l If a course* is not clear or straight, the
lane departure alert function or lane
departure prevention function may not
operate.

l The lane departure alert function or

lane departure prevention function
may not operate if the system judges
that the vehicle is intentionally being
steered to avoid a pedestrian or
parked vehicle.

l Vehicles with BSM: It may not be possible for the system to judge if there is
danger of a collision with a vehicle in
an adjacent lane.

l Vehicles with a driver monitor camera:

Depending on the driver condition, the
lane departure alert function or lane
departure prevention function
changes the timing of operation.

l The steering assist operation of the

lane departure prevention function
can be overridden by the steering
wheel operation of the driver.
*: Boundary between the asphalt and
grass, soil, etc., or structures, such as
a curb, guardrail, etc.

n Hands off steering wheel warning

operation
In the following situations, a message
urging the driver to operate the steering
wheel and an icon will be displayed and
a buzzer will sound to warn the driver.
When using the system, make sure to
grip the steering wheel firmly, regardless
of whether the warning is operating or
not.

5

Driving

• The vehicle speed is approximately 50
km/h (30 mph) or more.
Operation may be possible when the
vehicle speed is approximately 40 km/h
(25 mph) or more if vehicles, motorcycles, bicycles, or pedestrians are
detected near the lane.
• The system recognizes a lane or
course*. (When recognized on only
one side, the system will operate only
for the recognized side.)
• The lane width is approximately 3 m
(9.8 ft.) or more.
• The turn signal lever is not being operated.
(Vehicles with BSM: Except when a
vehicle is detected in the direction that
the turn signal lever is operated.)
• The vehicle is not being driven around
a sharp curve.
• The vehicle is not accelerating or
decelerating more than a certain
amount.
• The steering wheel is not being turned
sufficiently to perform a lane change.
• The VSC or TRC system is not turned
off.
*: Boundary between the asphalt and
grass, soil, etc., or structures, such as
a curb, guardrail, etc.

309

310

5-4. Using the driving support systems

l When the system determines that the

driver is not securely holding the
steering wheel, or the steering wheel
is not being operated when the steering assist operation of the lane departure prevention function is operating
The length of time that the warning
buzzer operates will become longer as
the frequency of the steering assist
operating increases. Even if the system
judges that the steering wheel has been
operated, the warning buzzer will sound
for a certain amount of time.

n Break suggestion function
This function is operable when all of the
following conditions are met:
l The vehicle speed is approximately 65
km/h (40 mph) or more.

l The lane width is approximately 3 m

(9.8 ft.) or more.
Depending on the condition of the vehicle and road surface, the break suggestion function may not operate.

changed on the customize settings. (P.675)
 Vehicles with a driver monitor
camera: When the system determines that the driver is tired, the
lane departure warning function
will operate at the “Earlier” timing, regardless of the customized
setting. Also, this setting will be
kept until the power switch is
turned off.
WARNING
n Situations in which the system

may not operate properly
In the following situations, the system
may not operate properly and the
vehicle may depart from its lane. Do
not overly rely on these functions. The
driver is solely responsible for paying
attention to their surroundings and
operating the steering wheel as necessary to ensure safety.

l When the boundary between the

asphalt and grass, soil, etc., or
structures, such as a curb, guardrail, etc. is not clear or straight

l When the vehicle is struck by a

crosswind or the turbulence of other
nearby vehicles

Press the
meter control switch to
turn off the message.
Unless
or
is pressed, the message of the break suggestion function
will remain displayed.

Changing LDA settings
 The LDA system can be enabled/disabled through a customize setting. (P.675)
 The settings of the LDA can be

l Situations in which the lane may not
be detected: P.285

l Situations in which the sensors may
not operate properly: P.283

l Situations in which some or all of

the functions of the system cannot
operate: P.285

l When it is necessary to disable the
system: P.279

5-4. Using the driving support systems

311

Displays and system operation
The operating state of the lane departure alert function and steering assist
operation of the lane departure prevention function are indicated.
Indicator

Lane display Steering icon

Yellow

Not illuminated

Situation

Not illuminated

System disabled

Not illuminated

Lane lines are not detected by the system

Not illuminated

Lane lines are detected by the system

Not illuminated

Lane departure alert function is operating for the side which the lane display is
flashing

Illuminated
Not illuminated

Not illuminated

Gray

White

Yellow

Flashing

Flashing

Green

Green

Yellow

Yellow

Flashing

Flashing

Green

Lane departure prevention function is
operating for the side which the lane display is illuminated

Green

Lane departure alert function/lane
departure prevention function is operating for the side which the lane display is
flashing

5

Driving

Yellow

312

5-4. Using the driving support systems

PDA (Proactive driving
assist)*
*: If equipped

When a detectable object
(P.313) is detected, the proactive driving assist operates
the brakes and steering wheel
to help prevent the vehicle
from approaching too close to
the object.
WARNING
n For safe use
Driving safely is solely the responsibility of the driver.

l The proactive driving assist is

designed to provide some assistance for regular braking and steering operations, as well as helping to
prevent the vehicle from approaching too close to a detectable object.
However, the scope of this assistance is limited.
The driver should perform brake and
steering operations as necessary.
Read the following items carefully. Do
not overly rely on the proactive driving
assist and always drive carefully.
(P.314)

l The proactive driving assist is not a

system which reduces the amount
of attention necessary for safe driving. Even if the system is operating
correctly, the surrounding conditions as recognized by the driver
and detected by the system may
differ. It is necessary for the driver
to pay attention, assess risks, and
ensure safety. Over-reliance on this
system to drive the vehicle safely
may lead to an accident resulting in
death or serious injury.

l Proactive driving assist is not a system which allows for inattentive
driving and is not a system which
assists in poor visibility conditions.
The driver is solely responsible for
paying attention to their
surroundings and driving safely.

n When turning proactive driving
assist off

l Situations in which the sensors may
not operate properly: P.283

l When it is necessary to disable the
system: P.279

5-4. Using the driving support systems

313

System operating conditions and detectable objects
According to the driving conditions, the operation and detectable objects of
the proactive driving assist will change as follows.
Function

Obstacle Anticipation Assist
(OAA)

Operation

Detectable objects

A detectable object
is detected crossing the road

Assistance with some
brake operations is
provided in order to
reduce the possibility
of a collision.

 Pedestrians
 Bicyclists

A detectable object
is detected on the
side of the road

Assistance with some
brake and steering
wheel operations are
provided according to
the surrounding conditions to help prevent
the vehicle from
 Pedestrians
approaching too close  Bicyclists
to a detected object.
 Parked vehicles
Assistance with steering wheel operations is
provided within a range
that the vehicle will not
deviate from its current lane.

A preceding vehicle The vehicle is gently
or an adjacent vehi- decelerated so that the  Preceding vehicle cutting in front of vehicle-to-vehicle discles
the vehicle is
tance will not be exces-  Motorcycles
detected
sively short.
The vehicle is gently
decelerated if the vehiA curve is detected
cle speed is deterNone
ahead of the vehicle
mined to be too high
for the curve ahead.

n Vehicle speeds at which the system
can operate

l Detectable object crossing the road

assistance
Approximately 30 to 60 km/h (20 to 35

mph)

l Detectable object on the side of the

road assistance
Approximately 30 to 60 km/h (20 to 35
mph)

5

Driving

Deceleration
Assist (DA)

Conditions

314

5-4. Using the driving support systems

l Preceding vehicle deceleration assis-

tance
Approximately 20 km/h (15 mph) or
more

l Curve deceleration assistance
Approximately 20 km/h (15 mph) or
more
n System operation will be canceled
when

l In the following situations, system

operation will be canceled:
• When the dynamic radar cruise control or cruise control is operating
• When the PCS is off
• Situations in which some or all of the
functions of the system cannot operate: P.285
• When the P, R or N shift position is
selected
• The driver’s seat belt is unfastened

l In the following situations, the brake

operation assist will be canceled:
• Approximately 15 km/h (9 mph) or
less
• When a certain vehicle speed has
been reached, as judged by the system, according to the surrounding
conditions

l In the following situations, system

operation may be canceled:
• When the brake control or output
restriction control of a driving support
system operates
(For example: PCS, drive-start control)
• When the system determines that a
detected object has moved away from
the vehicle
• When lane lines can no longer be
detected
• When the brake pedal has been
depressed
• When the accelerator pedal has been
depressed
• When the steering wheel has been
operated with more than a certain
amount of force
• When the turn signal lever is operated
to the left/right turn position

WARNING
n Situations in which the system
may not operate properly

l Situations in which the lane may not
be detected: P.285

l When a detectable object stops

immediately before entering the
path of the vehicle

l When passing extremely close to a
detectable object behind a guardrail, fence, etc.

l When changing lanes while overtaking a detectable object

l When passing a detectable object
that is changing lanes or turning
left/right

l When there are objects (guardrails,

power poles, trees, walls, fences,
poles, traffic cones, mailboxes, etc.)
in the surrounding area

l When there are patterns or a painting ahead of the vehicle that may
be mistaken for a detectable object

l When passing through a place with

a low structure above the road (tunnel with a low ceiling, traffic sign,
signboard, etc.)

l When driving on snowy, icy, or rutted roads

l When a detectable object is
approaching your vehicle

l When your vehicle or a detectable
object is wandering

l When the movement of a detectable object changes (change in
direction, sudden acceleration or
deceleration, etc.)

l When suddenly approaching a
detectable object

l When a preceding vehicle or motorcycle is not directly in front of your
vehicle

5-4. Using the driving support systems

WARNING
l When there is a structure above a
detectable object

l When part of a detectable object is

hidden by another object (large luggage, umbrella, guardrail, etc.)

315

l When a pedestrian or bicyclist is
moving at high speed

l When a pedestrian is pushing a

stroller, wheelchair, bicycle or other
vehicle

l When a detectable object blends in

l When multiple detectable objects

with the surrounding area, such as
when it is dim (at dawn or dusk) or
dark (at night, in a tunnel, etc.)

l When a bright light, such as the sun

l When the lane width is 4 m (13.1 ft.)

are overlapping

or headlights of another vehicle, is
reflecting off of the detectable
object

l When the detectable object is white
and looks extremely bright

l When the color or brightness of the

detectable object causes it to blend
in with its surroundings

l When a detectable object cuts in

front of or emerges from beside a
vehicle

or more

l When the lane width is 2.5 m (8.2
ft.) or less

l When the vehicle has not been

driven for a certain amount of time
after the EV system was started

l While turning left or right or a few
seconds after turning left or right

l While changing lanes or a few seconds after changing lanes

l When entering a curve, driving

which is perpendicular or at an
angle to the vehicle, or is facing the
vehicle

around a curve and a few seconds
after driving around a curve

l If a parked vehicle is perpendicular

Changing proactive driving
assist settings

or at an angle to the vehicle

l When a bicycle is a child sized bicycle, is carrying a large load, is carrying an extra passenger, or has an
unusual shape (bicycles equipped
with a child seat, tandem bicycles,
etc.)

l When a pedestrian or bicyclist is

shorter than approximately 1 m (3.2
ft.) or taller than approximately 2 m
(6.5 ft.)

l When the silhouette of a pedestrian

or bicyclist is unclear (such as when
they are wearing a raincoat, long
skirt, etc.)

l When a pedestrian or bicyclist is
bending forward or squatting

 The proactive driving assist can
be enabled/disabled through a
customize setting. (P.683)
 The following settings of the proactive driving assist can be
changed through customize settings. (P.683)

Driving

l When approaching a vehicle ahead

5

316

5-4. Using the driving support systems

System operation display
Depending on the situation, the following indicators or icons will be displayed.
Some icons cannot be displayed unless the display is changed to the driving safety support function information screen.
Icon

Meaning
 White: Monitoring for detectable objects
 Green: Detectable object crossing the road or detectable object
on the side of the road assistance operating
A pedestrian has been detected as crossing the road or on the
side of the road and brake or steering assistance is operating

A vehicle has been detected on the side of the road and brake or
steering operation assistance is being performed

Steering operation assistance is being performed to prevent the
vehicle from approaching too close to a detectable object on the
side of the road
Preceding vehicle deceleration assistance is being performed

Warning to maintain appropriate vehicle-to-vehicle distance

Curve deceleration assistance is being performed

n Hands off steering wheel warning

operation
In the following situations, a message
urging the driver to grip the steering
wheel and the icon shown in the illustration will be displayed on the display to
warn the driver. If the system detects
that the steering wheel is held, the warning will be canceled. When using the

system, make sure to grip the steering
wheel firmly, regardless of whether the
warning is operating or not.

5-4. Using the driving support systems

317

FCTA (Front Crossing
Traffic Alert)*
*: If equipped

l When assistance to a detectable

object crossing the road or assistance
to a detectable object on the side of
the road is performed and the system
determines the driver is not holding
the steering wheel
If no operations are detected for a certain amount of time, a buzzer will sound,
the warning will operate. This warning
may also operate if the driver only operates steering wheel a small amount continuously.

n Warning operation after preceding

FCTA system control
 When the system detects a vehicle approaching from the left or
right in front of your vehicle when
approaching an intersection, a
notification will be displayed.
 When the system determines
that your vehicle may be about to
enter an intersection even
though a vehicle is approaching
from the left or right in front of
your vehicle, a buzzer will sound
and a message will be displayed
to urge you to depress the brake
pedal.
• Multi-information display

5

Driving

vehicle deceleration assistance has
ended
After preceding vehicle deceleration
assistance has ended, if the driver does
not operate the brake pedal or accelerator pedal and the vehicle approaches
the preceding vehicle, the display will
flash and a buzzer will sound to urge the
driver to decelerate. If the system determines that the driver is operating the
brake pedal or accelerator pedal, the
warning will be canceled.

When approaching an intersection, etc., at a low speed,
vehicles approaching from the
left and right of the front of the
vehicle can be detected and
the driver informed of these
vehicles.

318

5-4. Using the driving support systems

WARNING
n For safe use
Driving safely is solely the responsibility of the driver. Pay careful attention to the surrounding conditions in
order to ensure safe driving.
The FCTA system is a supplementary
system that informs the driver of vehicles approaching from the left and
right of the front of the vehicle.
Over-reliance on this system may
lead to an accident resulting in death
or serious injury.
The details of the warning display
may differ from the actual traffic conditions.
Although the warning display will stop
being displayed after a certain
amount of time, this does not necessarily indicate that there are no longer
any vehicles or pedestrians around
your vehicle.

though no vehicles are approaching:

l When approaching objects on the

roadside, such as guardrails, traffic
signs, utility poles, street lights, trees,
tall grass, walls, etc.

l When passing an object on the side of
the road, such as a parked vehicle

l When a vehicle or pedestrian is

approaching from the left or right in
front of your vehicle in the distance

l When a vehicle or pedestrian is moving within a parking spot, etc., next to
the lane your vehicle is in

l When a pedestrian or bicyclist is
approaching on a sidewalk

l When a vehicle or pedestrian is moving away from your vehicle

l When an approaching vehicle is
decelerating or stops

l When an approaching vehicle makes

a left/right turn immediately in front of
your vehicle

l When a pedestrian is approaching
n FCTA system operating conditions

your vehicle

The system will operate when all of the
following conditions are met:

l When an oncoming vehicle makes a

l A shift position other than P or R is

l When your vehicle enters an intersec-

selected

l The vehicle speed is approximately 15
km/h (10 mph) or less

l A vehicle is approaching from the left
or right in front of your vehicle at a
speed between approximately 10 to
60 km/h (7 to 37 mph)

right/left turn

tion before a vehicle approaching from
the left or right in front of your vehicle

l When stopped at traffic light and a

vehicle approaches from the left or
right in front of your vehicle

l When making a left/right turn in front
of an approaching vehicle

l There are no vehicles in front of your
vehicle

l The accelerator pedal is not being
strongly depressed

l The brake pedal is not being strongly
depressed

n Situations in which the system may

operate even though no vehicles
are approaching
In certain situations, such as the following, the system may operate even

l When an oncoming vehicle
approaches and passes

l When being overtaken by another

5-4. Using the driving support systems
vehicle

l When driving next to another vehicle
or a pedestrian

319

FCTA can be changed through
customize settings. (P.682)

l When a vehicle or pedestrian

approaches the side of your vehicle

n Situations in which the system may

not operate properly
In situations such as the following, a
vehicle may not be detected by a front
side radar sensor and the system may
not operate properly:

l If an approaching vehicle moves suddenly (sudden steering, acceleration,
deceleration, etc.)

5

l If a vehicle is approaching from the

l When a vehicle is approaching from

the left or right in front of your vehicle
in the distance

l When there is an object between your
vehicle and an approaching vehicle

l When several vehicles are approaching with little space between them

l Situations in which the sensors may
not operate properly: P.283

l Situations in which some or all of the
functions of the system cannot operate: P.285

Changing FCTA settings
 The FCTA can be enabled/disabled through a customize setting.
(P.682)
 The following settings of the

Driving

left or right of the front of your vehicle
diagonally

320

*

5-4. Using the driving support systems

RSA (Road Sign Assist)*

n Situations in which the RSA

: If equipped

l When it is necessary to disable the

The RSA system detects specific road signs using the front
camera and/or multimedia system (when speed limit information is available) and warns the
driver via displays and buzzers.
In order to maintain performance of the speed limit display function, it is necessary to
update map data* on a regular
basis.
*: For details about updates, refer to

the separate “Multimedia owner’s
manual”.

WARNING
n For safe use
l Regardless of the availability of

RSA display/buzzer, including conditional speed limit alert, it is the
driver who is solely responsible for
driving safely and abiding by the
regulations. Therefore, do not
overly rely on this system. The
driver is solely responsible for paying attention to the vehicle’s
surroundings and driving safely.

l Do not rely solely upon the RSA.

The RSA assists the driver by providing road sign information, but it is
not a replacement for the driver’s
own vision and awareness. Driving
safely is solely the responsibility of
the driver. Pay careful attention to
the surrounding conditions in order
to ensure safe driving.

should not be used
system: P.279

n Situations in which the system
may not operate properly

l Situations in which the sensors may
not operate properly: P.283

Display Function
 When the front camera detects a
sign or information of a sign is
available from the multimedia
system, the sign will be displayed on the display.
 Multiple signs can be displayed.
Depending on the specifications of the
vehicle, the number of displayed signs
may be limited.

n Operating conditions of sign dis-

play
Signs will be displayed when the following conditions are met:

l The system has detected a sign
In the following situations, a displayed
sign may stop being displayed:

l When a new sign has not been
detected for a certain distance

l When the system determines that the
road being driven on has changed,
such as after a left or right turn

n Situations in which the display

function may not operate properly
In the following situations, the RSA system may not operate properly and may
not detect signs or may display the
incorrect sign. However, this does not
indicate a malfunction.

l When a sign is dirty, faded, tilted or
bent

l When the contrast of an electronic

5-4. Using the driving support systems
sign is low

l When all or part of a sign is hidden by
a tree, utility pole, etc.

l When a sign is detected by the front
camera for a short amount of time

l When the driving state (turning,

changing lanes, etc.) is judged incorrectly

l When a sign is immediately after a
freeway junction or in an adjacent
lane just before merging

l When stickers are attached to the rear
of a preceding vehicle

l When a sign similar to a system compatible sign is detected as a system
compatible sign

l When a speed limit sign for a frontage
road is within detection range of the
front camera

l When driving around a roundabout
l When a sign intended for trucks, etc.
is detected

l When a sign has a supplemental sign

l When there is a sign within a traffic

restricted area, such as a roadworks
area

l When the vehicle is driven in a country with a different direction of traffic

l When the multimedia system map
data is out of date

l When the multimedia system cannot

be used
In this case, the speed limit signs displayed on the multi-information display
and multimedia system display may differ.

Notification function
In the following situations, the RSA
system will output a warning to
notify the driver.

 If the vehicle speed exceeds the
speed warning threshold of the
speed limit sign displayed on the
display, the sign display will be
emphasized and a buzzer will
sound.
Also when the limit speed to be displayed is changed due to the change of
driving zones, etc., the sign display will
be emphasized and a buzzer will
sound* to alert the driver.*
*: The availability of emphasized dis-

play and buzzer depends on the
country where the vehicle is available.

 When the RSA system detects a
no-entry sign and determines
that the vehicle has entered the
no-entry area based on the map
information of the multimedia
system, the no-entry sign displayed on the multi-information
display will flash and a buzzer
will sound.
n Operating conditions of the notification functions

l Excess speed notification function
This function will operate when the following condition is met:
• A speed limit road sign is recognized
by the system.

l No entry notification function
This function will operate when all of the
following conditions are met:
• More than one no entry road signs are
recognized by the system simultaneously.
• The vehicle is passing between no
entry road signs recognized by the
system.
• The vehicle is equipped with an

5

Driving

(end point, day of week, time of day,
etc.)

321

322

5-4. Using the driving support systems

on-board multimedia system.

Types of road signs supported
 The following types of road signs
can be displayed.
However, non-standard or recently
introduced traffic signs may not be displayed.

Urban area beginning

Urban area ending

Residential area beginning

 Speed limit road signs*

Speed limit begins/Maximum speed zone begins

Residential area ending
*1: Displayed when a sign is detected

Speed limit ends/Maximum speed zone ends
*: No speed limit information

is dis-

played when neither speed limit road
sign nor speed limit related information is available.
 Speed limit related information*1, 2

but speed limit information for the
road is not available from the multimedia system.
*2: No speed limit information

is dis-

played when neither speed limit road
sign nor speed limit related information is available.
 No overtaking road signs

No overtaking begins
Motorway

No overtaking ends
Motorway exit
 Other road signs

Expressway
No-entry

Expressway exit
End of prohibition

5-4. Using the driving support systems

323

turned to ON in certain countries.
Stop

Warning

 Speed limit with supplemental mark*1

Ice
Supplemental mark
exists*2
Exit ramp on right

Exit ramp on left
5
Time
: Displayed simultaneously with a
speed limit sign.

*2: Content not recognized.

 Depending on the specifications
of the vehicle, signs may be displayed overlapping.
Duplicate display example

Changing RSA settings
The following settings of the RSA
can be changed through customize
settings. (P.684)
The system and some functions are
enabled each time the power switch is

Driving

*1

324

5-4. Using the driving support systems

Dynamic radar cruise
control*
*: If equipped

This dynamic radar cruise control detects the presence of
vehicles ahead, determines the
current vehicle-to-vehicle distance, and operates to maintain a suitable distance from
the vehicle ahead. The desired
vehicle-to-vehicle distance can
be set by operating the vehicle-to-vehicle distance switch.
Use the dynamic radar cruise
control only on highways and
expressways.
WARNING
n For safe use
l Driving safely is solely the responsi-

bility of the driver. Do not overly rely
on this system, and pay careful
attention to the surrounding conditions in order to ensure safe driving.

l The dynamic radar cruise control

provides driving assistance to
reduce the driver’s burden. However, there are limitations to the
assistance provided.
Read the following items carefully. Do
not overly rely on this system and
always drive carefully.
Conditions under which the system
may not operate correctly: P.330

l Set the speed appropriately according to the speed limit, traffic flow,
road conditions, weather conditions, etc. The driver is responsible
for confirming the set speed.

l Even if the system is operating correctly, the condition of a preceding
vehicle as recognized by the driver
and detected by the system may
differ. Therefore, it is necessary for
the driver to pay attention, assess
risks, and ensure safety. Over-reliance on this system to drive the
vehicle safely may lead to an accident resulting in death or serious
injury.

n Precautions for the driving assist

systems
Observe the following precautions, as
there are limitations to the assistance
provided by the system. Over-reliance
on this system may lead to an accident resulting in death or serious
injury.

l Details of support provided for the

driver’s vision
The dynamic radar cruise control is
only intended to help the driver in
determining the distance between the
driver’s own vehicle and a designated
preceding vehicle. It is not a system
which allows for careless or inattentive driving, and is not a system which
assists in poor visibility conditions.
The driver must pay attention to their
surroundings, even when the vehicle
stops.

l Details of support provided for the

driver’s judgement
The dynamic radar cruise control
determines whether the distance
between the driver’s own vehicle and
a designated preceding vehicle is
within a set range. It is not capable of
making any other type of judgement.
Therefore, it is absolutely necessary
for the driver to remain vigilant and to
determine whether or not there is a
possibility of danger.

5-4. Using the driving support systems

325

WARNING
l Details of support provided for the

driver’s operation
The dynamic radar cruise control
does not include functions which will
prevent or avoid collisions with vehicles ahead of your vehicle. Therefore,
if there is ever any possibility of danger, the driver must take immediate
and direct control of the vehicle and
act appropriately in order to ensure
safety.

n Situations in which the dynamic

radar cruise control should not
be used
Do not use the dynamic radar cruise
control in the following situations. As
the system will not be able to provide
appropriate control, using it may lead
to an accident resulting in death or
serious injury.

l Roads where there are pedestrians,

5

l When driving on a highway or

Driving

cyclists, etc.

expressway entrance or exit

l When the approach warning
sounds frequently

l Situations in which the sensors may
not operate properly: P.283

l When it is necessary to disable the
system: P.279

326

5-4. Using the driving support systems

Basic functions

A Constant speed cruising:
When there are no vehicles ahead
The vehicle drives at the speed set by the driver.
If the set vehicle speed is exceeded while driving down a hill, the set vehicle speed
display will blink and a buzzer will sound.

B Deceleration and follow-up cruising:
When a preceding vehicle driving slower than the set vehicle speed is
detected
When a vehicle is detected driving ahead of your vehicle, the vehicle automatically
decelerates and if a greater reduction in vehicle speed is necessary, the brakes are
applied (the stop lights will come on at this time). The vehicle is controlled to maintain the vehicle-to-vehicle distance set by the driver, in accordance with changes in
the speed of the preceding vehicle. If vehicle deceleration is not sufficient and the
vehicle approaches the vehicle ahead, the approach warning will sound.

C Acceleration:
When there are no longer any preceding vehicles driving slower than the
set vehicle speed
The vehicle accelerates until the set vehicle speed is reached and then resumes
constant speed cruising.

Starting off:
If a preceding vehicle stops, the vehicle will also stop (controlled stop). After the
preceding vehicle starts off, pressing the “RES” switch or depressing the accelerator
pedal will resume follow-up cruising (start off operation). If a start off operation is not
performed, the controlled stop will continue.

5-4. Using the driving support systems

327

Vehicles with a driver monitor and LCA: While driving on a highway or expressway,
if a preceding vehicle stops, your vehicle will stop accordingly. On some highways
and expressways, if the system determines that the preceding vehicle starts off
within approximately 3 minutes of stopping, a buzzer will sound and a message will
be displayed on the multi-information display to notify the driver, and your vehicle
will start off accordingly following the preceding vehicle. (Extended resume time)

System components
n Meter display

“-” switch
“+” switch/“RES” switch

Using the dynamic radar
cruise control
Setting the vehicle speed
1 Press the driving assist mode
select switch to select Adaptive
Cruise Mode.
A Multi-information display
C Indicators
n Switches

A Driving assist switch
B Driving assist mode select
switch
C Cancel switch

Vehicle-to-vehicle distance
switch

5

Driving

B Set vehicle speed

The dynamic radar cruise control indicator will illuminate.

2 Using the accelerator pedal,
accelerate or decelerate to the
desired vehicle speed (approximately 30 km/h [20 mph] or
more), and press the driving
assist switch to set the set vehicle speed.
The set vehicle speed will be displayed
on the multi-information display.
The vehicle speed at the moment the
switch is released will be the set vehicle

328

5-4. Using the driving support systems

speed.

Long press adjustment: Increases or
decreases in 5 km/h (3.1 mph) or 5
mph (8 km/h) increments continuously
while the switch is pressed and held
The set vehicle speed adjustment
increment can be changed through a
customize setting.

 Increasing the set vehicle speed
using the accelerator pedal
Adjusting the set vehicle
speed
 Adjusting the set vehicle speed
using the switches
To change the set vehicle speed,
press the “+” switch or “-” switch
until the desired speed is displayed.

1 Increase set vehicle speed
2 Decrease set vehicle speed
Short press adjustment: Press the
switch
Long press adjustment: Press and hold
the switch until the desired set vehicle
speed is reached.

The set vehicle speed will increase
or decrease as follows:
Short press adjustment: By 1 km/h (0.6
mph) or 1 mph (1.6 km/h) each time the
switch is pressed

1 Depress the accelerator pedal
to accelerate the vehicle to the
desired vehicle speed.
2 Press the “+” switch.
Canceling/resuming control

1 Press the cancel switch or driving assist switch to cancel control.
Control will also be canceled if the
brake pedal is depressed.
(If the vehicle has been stopped by system control, depressing the brake pedal
will not cancel control.)

2 Press the “RES” switch to
resume control.
Changing the vehicle-to-vehicle distance
Each time the switch is pressed,
the vehicle-to-vehicle distance set-

5-4. Using the driving support systems

ting will change as follows:
If a preceding vehicle is detected, the
preceding vehicle mark A will be displayed.

329

at below approximately 30 km/h (20
mph), the set vehicle speed will be
approximately 30 km/h (20 mph).
• If the vehicle speed is set while driving
at a speed that exceeds the system’s
upper limit, the set vehicle speed will
be the system’s upper limit.

n Accelerating after setting the vehi-

Illustration
Number

Vehicle-to-vehicle distance

Approximate
Distance (Vehicle Speed: 100
km/h [60 mph])

Short

2

Medium

Approximately
30 m (100 ft.)

3

Long

Approximately
45 m (145 ft.)

4

Extra long

Approximately
60 m (200 ft.)

The actual vehicle-to-vehicle distance
varies in accordance with the vehicle
speed. Also, when the vehicle is
stopped by system control, it will be
stopped at a certain distance from the
preceding vehicle, depending on the
situation, regardless of the setting.

n When the vehicle is stopped by

system control during follow-up
cruising

l When the “RES” switch is pressed

while the vehicle is stopped by system
control, if the preceding vehicle starts
off within approximately 3 seconds,
follow-up cruising will resume.

l If the preceding vehicle starts off

within approximately 3 seconds of the
vehicle being stopped by system control, follow-up cruising will resume.

n Automatic cancelation of vehi-

cle-to-vehicle distance control
mode
In the following situations, vehicle-to-vehicle distance control mode will
be canceled automatically:

l When the brake control or output

restriction control of a driving support
system operates
(For example: Pre-Collision System,
drive-start control)

l When the parking brake has been
n Operating conditions
l The D shift position is selected.
l The desired set speed can be set

when the vehicle speed is approximately 30 km/h (20 mph) or more.
• If the vehicle speed is set while driving

operated

l When the driver’s seat belt is unfastened while driving

l When the Pre-Collision System is disabled

l When the vehicle is stopped by sys-

5

Driving

1

Approximately
25 m (85 ft.)

cle speed
As with normal driving, acceleration can
be performed by depressing the accelerator pedal. After accelerating, the vehicle will return to the set vehicle speed.
However, while in vehicle-to-vehicle distance control mode, the vehicle speed
may decrease to below the set vehicle
speed in order to maintain the distance
from the preceding vehicle.

330

5-4. Using the driving support systems

tem control on a steep incline

l When any of the following are

detected while the vehicle is stopped
by system control:
• The driver’s seat belt is unfastened
• The driver’s door is opened
• Approximately 3 minutes have
elapsed since the vehicle was
stopped
The parking brake may be actived automatically.

l Situations in which some or all of the
functions of the system cannot operate: P.285

n Dynamic radar cruise control sys-

tem warning messages and buzzers
For safe use: P.278

n Preceding vehicles that the sensor

may not detect correctly
In the following situations, depending on
the conditions, if the system cannot provide sufficient deceleration or acceleration is necessary, operate the brake
pedal or accelerator pedal.
As the sensor may not be able to correctly detect these types of vehicles, the
approach warning (P.330) may not
operate.

l When a vehicle cuts in front of your

vehicle or changes lanes away from
your vehicle extremely slowly or
quickly

l When changing lanes
l When a preceding vehicle is driving at
a low speed

l When a vehicle is stopped in the
same lane as the vehicle

l When a motorcycle is traveling in the
same lane as the vehicle

n Conditions under which the system

may not operate correctly
In the following situations, operate the
brake pedal (or accelerator pedal,
depending on the situation) as necessary.
As the sensor may not be able to cor-

rectly detect a vehicle, the system may
not operate properly.

l When a preceding vehicle brakes suddenly

l When changing lanes at low speeds,
such as in a traffic jam

n Conditions for extended resume

time (vehicles with a driver monitor
and LCA)
Extended resume time is activated when
all of the following conditions are satisfied:

l The vehicle is driving on a vehi-

cle-only road, such as an expressway.

l There is a preceding vehicle and the
system is able to detect it.

l No vehicle interruptions occur.
l The preceding vehicle has not been
replaced.

l Clearance sonar and FCTA are not
detecting the object in front of you.

l The driver monitor judges that the
driver is looking forward.

l The steering wheel has not been
operated.

l The brake pedal has not been operated.

Approach warning
In situations where the vehicle
approaches a preceding vehicle
and the system cannot provide sufficient deceleration, such as if a
vehicle cuts in front of the vehicle, a
warning display will flash and a
buzzer will sound to alert the driver.
Depress the brake pedal to ensure
appropriate vehicle-to-vehicle distance.
n Warnings may not occur when

In the following situations, the

5-4. Using the driving support systems

warning may not operate even
though the vehicle-to-vehicle distance is short.
 When the preceding vehicle is
traveling at the same speed or
faster than your vehicle
 When the preceding vehicle is
traveling at an extremely low
speed
 Immediately after the vehicle
speed has been set
 When the accelerator pedal is
depressed

Curve speed reduction function

331

n Situations in which the curve speed

reduction function may not operate
In situations such as the following, the
curve speed reduction function may not
operate:

l When the vehicle is being driven
around a gentle curve

l When the accelerator pedal is being
depressed

l When the vehicle is being driven
around an extremely short curve

Overtaking prevention function
If a detected vehicle in the passing
lane is traveling slower than your
vehicle, overtaking will be suppressed.
The overtaking prevention function will
not operate if the passing lane is congested or vehicles are traveling at low
speeds.

Depending on the situation, the vehicle
speed will then return to the set vehicle
speed.

This function is not available for vehicles without a DCM.

In situations where vehicle-to-vehicle
distance control needs to operate, such
as when a preceding vehicle cuts in
front of your vehicle, the curve speed
reduction function will be canceled.

Driver Monitor support function (if equipped)
While a warning of the driver monitor is being displayed, the vehicle
acceleration will be restrained.
When the warning of the driver
monitor disappears, the restrained
acceleration control will end.

Support for lane change
If your vehicle is being driven at
approximately 80 km/h (50 mph) or

5

Driving

When a curve is detected, the vehicle speed will begin being reduced.
When the curve ends, the vehicle
speed reduction will end.

332

5-4. Using the driving support systems

more and a lane change to the
passing lane is performed, when
the turn signal lever is operated and
the lane is changed, the vehicle will
accelerate up to the set speed to
assist in overtaking.
For vehicles with a DCM: The system’s
recognition of which lane is the passing
lane is determined by location information and the driving condition of surrounding vehicles. The support for lane
change function and overtaking prevention function may not operate if it is difficult to obtain location information or
there are few surrounding vehicles.
For vehicles without a DCM: The system’s recognition of which lane is the
passing lane may be based solely on
the location of the steering wheel in the
vehicle (left-hand drive/right-hand
drive). If the vehicle is driven in a location where the passing lane is on the
opposite side of that where the vehicle
was originally sold, the vehicle may
accelerate when the turn signal lever is
operated away from the passing lane.
(e.g. The vehicle was manufactured for
a right-hand traffic location, but is being
driven in a left-hand traffic location. The
vehicle may accelerate when the turn
signal lever is operated to the right.)

If your vehicle is being driven at
approximately 80 km/h (50 mph) or
more and the lane is changed to
that with a vehicle traveling slower
than your vehicle, when the turn
signal lever is operated the vehicle
will gradually decelerate to assist in
changing lanes.

Dynamic Radar Cruise Control with Road Sign Assist (if
equipped)
When RSA function is enabled and
the dynamic radar cruise control
system is operating, if a speed limit
sign is detected, the detected
speed limit will be displayed with an
up/down arrow. The set speed can
be increased/reduced to the
detected speed limit by pressing
and holding the “+” switch or “-”
switch.
When the set speed is lower
than the detected speed limit

Press and hold the “+” switch.

When the set speed is higher
than the detected speed limit

5-4. Using the driving support systems
Press and hold the “-” switch.

333

available

l When the detected speed limit is the
n The dynamic radar cruise control

with road sign assist may not operate properly when
As the dynamic radar cruise control with
road sign assist may not operate properly in situations where the RSA may not
operate or cannot detect signs correctly
(P.320), when using this function,
make sure to confirm the actual speed
limit.
In the following situations, the set speed
may not change to the detected speed
limit by pressing and holding the “+”
switch or “-” switch:

l When speed limit information is not

same as the set speed

l When the detected speed limit is outside of the speed range which the
dynamic radar cruise control system
can operate

Changing Dynamic radar
cruise control settings
 The settings of Dynamic radar
cruise control can be changed
through customize settings.
(P.682)

Display and system operation state
The operating state of Dynamic radar cruise control is indicated.
Indicator

Green

Situation
VehiDynamic
cle-to-vehicle radar cruise
distance set- control being
ting: Gray
OFF
Vehicle-to-vehicle
distance setting: Blue
Set vehicle
speed: Green
Vehicle-to-vehicle
distance setting: Blue

Green

Set vehicle
speed: Green
Preceding
vehicle: White

Constant
speed cruising

Follow-up
cruising

5

Driving

White

Multi-information display

334

5-4. Using the driving support systems

Indicator

Multi-information display

Situation
Vehicle-to-vehicle
distance setting: Orange
flashing

Green

Set vehicle
speed: Green

Approach
warning

Preceding
vehicle:
Orange flashing
Vehicle-to-vehicle
distance setting: Gray
Green

Set vehicle
speed: White

Accelerating
with the accelerator pedal

Preceding
vehicle: Gray

Green

Set vehicle
Set vehicle
speed: Green
speed being
in reverse disexceeded
play
Vehicle-to-vehicle
distance setting: Gray

Green

Set vehicle
speed: White
Preceding
vehicle: Gray

Vehicle in
controlled
stop
