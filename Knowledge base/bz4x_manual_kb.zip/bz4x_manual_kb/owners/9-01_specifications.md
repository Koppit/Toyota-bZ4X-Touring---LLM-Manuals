# 9-1. Specifications

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 9: Vehicle specifications, pages 668–674

668

9-1. Specifications

Maintenance data

9-1.Specifications

Dimensions and weights
Overall length

4830 mm (190.2 in.)

Overall width

1860 mm (73.2 in.)

Overall height*1

1675 mm (65.9 in.)

Wheelbase

2850 mm (112.2 in.)

Tread

Front

1600 mm (63.0 in.)

Rear

1610 mm (63.4 in.)
2465 kg (5434 lb.)*2

Gross vehicle mass

2560 kg (5644 lb.)*3
Front

Maximum permissible axle
capacity

1355 kg (2987 lb.)
1355 kg (2987 lb.)*2

Rear

1400 kg (3086 lb.)*3
75 kg (165 lb.)*2

Drawbar load

150 kg (331 lb.)*3
Without brake

Towing capacity

With brake

750 kg (1653 lb.)
750 kg (1653 lb.)*2
1500 kg (3307 lb.)*3

*1: Unladen vehicle
*2

: 2WD models

*3

: AWD/4WD models

Vehicle identification
n Vehicle identification number

The vehicle identification number
(VIN) is the legal identifier for your
vehicle.
This is the primary identification
number for your Toyota. It is used in
registering the ownership of your
vehicle.

This number is stamped on the top
left of the instrument panel.

9-1. Specifications

669

n Motor model type and motor

number
The motor model type and the
motor number are stamped on the
motor as shown.
 Front electric motor (traction

motor)
This number is also stamped under
the right-hand front seat.

 Rear electric motor (traction

motor) (AWD/4WD models)
This number is also on the manufacturer’s label.

9

Model

2XM

Type

Permanent magnet synchronous motor

Maximum output

167 kW

Maximum torque

268.6 N•m (27.4 kgf•m, 198.1 ft•lbf)

Vehicle specifications

Front electric motor (traction motor)

670

9-1. Specifications

Rear electric motor (traction motor) (AWD/4WD models)
Model

2XM

Type

Permanent magnet synchronous motor

Maximum output

167 kW

Maximum torque

268.6 N•m (27.4 kgf•m, 198.1 ft•lbf)

Traction battery
Type

Lithium-ion battery

Cell voltage

3.76 V/cell

Cell rated capacity

191 Ah

Quantity

104 cells

Voltage

391.0 V

Cooling system
 11 kW type AC charger

2WD models

6.8 L (7.2 qt., 6.0 Imp. qt.)
 22 kW type AC charger
7.3 L (7.7 qt., 6.4 Imp. qt.)

Capacity*

 11 kW type AC charger

AWD models

8.3 L (8.8 qt., 7.3 Imp. qt.)
 22 kW type AC charger
8.8 L (9.3 qt., 7.7 Imp. qt.)

Coolant type

Use either of the following:
 “Toyota Genuine Traction Battery Coolant”
 Similar high-quality ethylene glycol-based non-silicate, non-amine, non-nitrite, and non-borate coolant
with long-life hybrid organic acid technology
Do not use plain water alone.

*: The coolant capacity is a reference quantity.

If replacement is necessary, contact any authorized Toyota retailer or Toyota
authorized repairer, or any reliable repairer.

9-1. Specifications

671

NOTICE
n Cooling system coolant
In order to ensure maximum performance of the traction battery cooling system
and limit risks of battery short circuit and other damage to your vehicle, Toyota recommends using “Toyota Genuine Traction Battery Coolant” or similar high-quality
ethylene glycol-based, low electric conductivity coolant, non-amine and
non-borate coolant with azole additives.
Toyota cannot guarantee that the use of a product other than “Toyota Genuine
Traction Battery Coolant” will prevent risks of battery short circuit or other damage.
Never use water as it will cause damage.
Do not reuse coolant that has been removed from the radiator.

Heater system
Capacity*

Coolant type

4.1 L (4.3 qt., 3.6 Imp. qt.)
Use either of the following:
 “Toyota Super Long Life Coolant”
 Similar high-quality ethylene glycol-based non-silicate, non-amine, non-nitrite, and non-borate coolant
with long-life hybrid organic acid technology
Do not use plain water alone.

*: The coolant capacity is a reference quantity.

If replacement is necessary, contact any authorized Toyota retailer or Toyota
authorized repairer, or any reliable repairer.

Specific gravity reading at 20°C
(68°F):
Charging rates:
Slow charge

1.250 or higher
If the specific gravity is lower than the standard
value, charge the 12-volt battery.
5 A max.

Vehicle specifications

Electrical system (12-volt battery)

9

672

9-1. Specifications

Front eAxle
Fluid capacity*

3.0 L (3.2 qt., 2.6 Imp.qt.)

Fluid type

e-Transaxle Fluid TE

*

: The fluid capacity is a reference quantity.
If replacement is necessary, contact any authorized Toyota retailer or Toyota
authorized repairer, or any reliable repairer.

NOTICE
n Front eAxle fluid type
Using transaxle fluid other than the above type may cause abnormal noise or
vibration, or ultimately damage the front eAxle of your vehicle.

Rear eAxle (AWD/4WD models)
Fluid capacity*

3.0 L (3.2 qt., 2.6 Imp.qt.)

Fluid type

e-Transaxle Fluid TE

*: The fluid capacity is a reference quantity.

If replacement is necessary, contact any authorized Toyota retailer or Toyota
authorized repairer, or any reliable repairer.

NOTICE
n Rear eAxle fluid type
Using transaxle fluid other than the above type may cause abnormal noise or
vibration, or ultimately damage the rear eAxle of your vehicle.

Brakes
 Left-hand drive vehicles

Pedal clearance*1

57.5 mm (2.26 in.) Min.
 Right-hand drive vehicles
62 mm (2.44 in.) Min.

Pedal free play

1  6 mm (0.04  0.24 in.)

9-1. Specifications

Parking brake indicator*2

Fluid type

673

When pushing the parking brake switch for 1 to
4 seconds: turns off
When pulling the parking brake switch for 1 to 4
seconds: comes on
FMVSS No. 116 DOT 3 or SAE J1703
FMVSS No. 116 DOT 4 or SAE J1704

*1: Minimum pedal clearance when depressed with a force of 300 N (30.6 kgf, 67.5

lbf) while the EV system is operating.
*2: Make sure to confirm that the brake warning light (yellow) does not illuminate. (If

the brake warning light illuminates, refer to P.619.)

Steering
Free play

Less than 30 mm (1.2 in.)

Tires and wheels
 18-inch tires

Tire size

235/60R18 103H
 Front

Tire inflation pressure
(Recommended cold tire
inflation pressure)

260 kPa (2.6 kgf/cm2 or bar, 38 psi)
 Rear

Wheel size

18  7 1/2 J

Wheel bolt torque

103 N•m (10.5 kgf•m, 76 ft•lbf)

260 kPa (2.6 kgf/cm2 or bar, 38 psi)

 20-inch tires

Tire size

235/50R20 104V XL

9

 Front

260 kPa (2.6 kgf/cm2 or bar, 38 psi)
 Rear

Wheel size

20  7 1/2 J

Wheel bolt torque

103 N•m (10.5 kgf•m, 76 ft•lbf)

260 kPa (2.6 kgf/cm2 or bar, 38 psi)

Vehicle specifications

Tire inflation pressure
(Recommended cold tire
inflation pressure)

674

9-1. Specifications

 Compact spare tire (if equipped)

Tire size

T165/90D18 107M

Spare tire inflation pressure
(Recommended cold tire
420 kPa (4.2 kgf/cm2 or bar, 60 psi)
inflation pressure)
Wheel size

18  4T

Wheel bolt torque

103 N•m (10.5 kgf•m, 76 ft•lbf)

n When towing a trailer (vehicles with towing package)
Add 20.0 kPa (0.2 kgf/cm2 or bar, 3 psi) to the recommended tire inflation pressure,
and drive at speeds below 100 km/h (62 mph).

n When installing a compact spare tire (vehicles with a compact spare tire)
Do not tow if your vehicle has a compact spare tire installed.
