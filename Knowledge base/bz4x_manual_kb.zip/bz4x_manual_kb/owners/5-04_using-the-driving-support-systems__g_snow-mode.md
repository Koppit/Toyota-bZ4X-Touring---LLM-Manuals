# 5-4. Using the driving support systems (part 7: Snow mode, …)

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 497–507
> Topics in this part: Snow mode; X-MODE; Driving assist systems

5-4. Using the driving support systems

Snow mode (2WD models)

497

X-MODE*
*

: If equipped

Snow mode can be selected to
suit the conditions when driving on slippery road surfaces,
such as on snow.

This mode has improved road
handling ability off roads.

System operation

During “X-MODE”, the
downhill assist control will
control the brakes to maintain
a constant vehicle speed when
driving on steep descents.

Press the snow mode switch
When the switch is pressed, snow
mode turns on and the snow mode indicator illuminates on the multi-information display. When the switch is pressed
again, the snow mode indicator turns
off.

Select between the 2 types of
mode, SNOW/DIRT and
D.SNOW/MUD.

WARNING
n Be sure to observe the following

n Snow Mode Automatic Cancellation
Snow mode is automatically canceled
by turning off the power switch.

before using “X-MODE”
If not observed, there is the danger
that it may lead to an unexpected
accident.
l Drive the vehicle after checking that
the SNOW/DIRT indicator/D.SNOW/MUD indicator turns
on.

l “X-MODE” is not a device that

enhances the limited performance
of the vehicle. Carefully check the
road surface conditions and the
driving route in advance, and then
drive with caution.

5

Driving

Grip Control supports the
driver’s operation by maintaining a low vehicle speed on
steep inclines and slippery
roads without having to step
on the accelerator pedal or
brake pedal.

498

5-4. Using the driving support systems

WARNING
n Conditions in which it may not

function correctly
When driving on the following road
surfaces, it may not be possible to
maintain a constant speed of the vehicle, which may lead to an unexpected
accident.

km/h (13 mph).
When the drive mode is switched,
the buzzer sounds.

l Extremely steep inclines
l Rough road surfaces
l Slippery road surfaces such as

snowy roads and frozen road surfaces

System Components
1 Normal mode
Has a good balance of electrical consumption performance, quietness, and
driving performance, and is suitable for
driving in urban areas.

2 SNOW/DIRT mode
When the tires are likely to slip or slip
on slippery roads such as snowy roads,
gravel roads, etc., the tire spinning is
reduced, making it easier to drive.

A “X-MODE” switch
B Grip Control switch (P.500)
C Indicators

Selecting the Drive Mode
Press the “X-MODE” switch repeatedly until the system switches to
the desired driving mode while the
vehicle is stopped or traveling at a
speeds less than approximately 20

At this time, the SNOW/DIRT mode
indicator lights up in green on the
meter.

3 D.SNOW/MUD mode
In special cases such as the tires being
buried in deep snow or mud, the TRC
(Traction Control) function is temporarily canceled, and the tires are idled as
needed to make it easier to start.
At this time, the D.SNOW/MUD mode
indicator lights up in green on the
meter. In addition, the VSC OFF indicator and PCS warning light will be turned
on in the meter.

5-4. Using the driving support systems

n When “X-MODE” is not available
In the following cases, the system does
not operate.

l When the EV system is not started
l When SNOW/DIRT mode or

D.SNOW/MUD mode is not selected

l When Advanced Park is being used (if
equipped)

l When the EV system is malfunctioning

n About Dynamic Radar Cruise Con-

trol or Cruise Control (if equipped)
Dynamic radar cruise control and cruise
control cannot be used during
“X-MODE”. If dynamic radar cruise control or cruise control are being used, it
will be automatically canceled.

n During “X-MODE”
l In “X-MODE”, VSC does not switch

l During “X-MODE”, operating the Eco
mode switch will not change the
mode.

l The SNOW/DIRT and D.SNOW/MUD
modes control the vehicle so that it
can maximize the drive force and
improve the drive force on rough
roads. As a result, electricity consumption may diminish when compared to driving in normal mode.

n “X-MODE” Automatic Release
l “X-MODE” is automatically canceled
when the power switch is turned off.

l When the vehicle speed exceeds

about 40 km/h (25 mph), the
“X-MODE” is canceled, the “X-MODE”
indicator on the meter lights up in
white, and switches to the normal
mode.

l When the vehicle speed is approxi-

mately 35 km/h (22 mph) or less,
X-MODE indicator lights up in green
and switches to “X-MODE” again.

n Cautions regarding the use of the

system
For safety, the following operations are
not accepted when “X-MODE” is ON.

l Eco mode switch operations

When selecting “X-MODE”,
Downhill Assist Control
When the “X-MODE” switch is
pressed and SNOW/DIRT mode or
D.SNOW/MUD mode is selected,
the Downhill Assist Control automatically enters the standby state
and operates under the following
conditions.
 When the vehicle speed is
approximately 30 km/h (18 mph)
or less
 Neither the accelerator pedal or
brake pedal are not operated
n When changing the target

vehicle speed
When changing the target vehicle
speed, adjust it with the accelerator
pedal or the brake pedal. When the
foot is removed from the pedal, the
system will operate at the vehicle
speed at that time.
n Downhill Assist Control during
“X-MODE”

l In SNOW/DIRT mode or

D.SNOW/MUD mode, the downhill
assist control can be set to standby
state. The operation indicator
changes depending on the operating
status of the downhill assist control.

l When the system is not operating, the
indicator turns on white.

5

Driving

ON/OFF even if the VSC OFF switch
is operated. It is fixed as ON in
SNOW/DIRT mode and OFF in
D.SNOW/MUD mode.

499

500

5-4. Using the driving support systems

n When Downhill Assist Control is

not available when selecting
“X-MODE”
In the following cases, the system does
not operate.

l When SNOW/DIRT mode or

D.SNOW/MUD mode is not selected

l When the shift position is in P
l When the Grip Control is operating
l When the brake system or EV system
is malfunctioning

When using Grip Control
With SNOW/DIRT mode or
D.SNOW/MUD mode selected,
press down on the Grip Control
switch.
At this time, the downhill assist control system indicator turns off and
the Grip Control indicator turns on.
When the vehicle is stopped, press
the brake pedal firmly and operate
the switch. The vehicle may start
moving unintentionally on an
incline.
n Set the speed of the Grip Con-

trol
Press the Grip Control switch up or
down to set the desired speed
(approximately 2 to 10 km/h [2 to 6
mph]). The set speed is shown on
the multi-information display.

A Increase Speed
B Decrease Speed
C Indicator Lights
n Grip Control Operations

During system operations, the Grip
Control indicator turns on green. If
the Grip Control indicator is white,
release the brake pedal to activate
the system.
While the system is operating, the
accelerator pedal and brake pedal
can be used to temporarily accelerate or decelerate. If operating the
accelerator pedal or brake pedal is
stopped, the speed will return to the
set speed.
n When Grip Control is released

 Press the “X-MODE” Switch
When the Grip Control is released, the
Grip Control operation light turns off,
and after a while, the downhill assist
control system indicator light turns on.
Drive carefully when releasing Grip
Control while driving.

5-4. Using the driving support systems

n Grip Control Operations Conditions
l When in “X-MODE”
l When the shift position is in D
l When the parking brake has been
released

501

switch.
When using the brake hold system
again, turn ON the brake hold system
after releasing the Grip Control.

NOTICE

l When the driver side door is closed
l When the vehicle is stopped by step-

n Long term usage
If used continuously for a long periods
of time, the temperature of the brakes
may rise the system may temporarily
stop.

n Automatic Releasing the Grip Con-

n Operation noises and vibrations
l Operating noise may be heard from

ping on the brake or the vehicle speed
is approximately 2 to 10 km/h (2 to 6
mph)

trol
In case of any of the following, the Grip
Control is released.

l When the vehicle is stopped by stepping on the brake pedal

l When the vehicle speed exceeds
more than 20 km/h (13 mph)

l When the shift position in a position
other than D

pression by the driving support device
are activated (example: Pre-Collision
System, Parking Support Brake [if
equipped])

l When the system determines it cannot
continue in the current environment

l When the power switch is turned off
n When Grip Control is not available
In the following conditions, Grip Control
is not available.
l When the brake system or EV system
is malfunctioning

l After the EV system is started and

until the vehicle has been running for
a while

n Brake hold system
The brake hold system turns OFF when
the Grip Control is being used. Press the
brake pedal firmly and operate the

l When the brake pedal is

depressed, it may become harder
than usual or it may feel different
from normal, but this is not a malfunction.

n When the operation indicator

does not turn on in the meter
even after operating the switch
The system may not be working properly. Have the vehicle inspected by
any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer immediately.

5

Driving

l When the parking brake is operated
l When the driver side door is opened
l ABS/VSC is activated.
l When brake control and output sup-

motor room, however this is not a
malfunction.

502

5-4. Using the driving support systems

Driving assist systems

n VSC+ (Vehicle Stability Con-

To keep driving safety and performance, the following systems operate automatically in
response to various driving situations. Be aware, however,
that these systems are supplementary and should not be
relied upon too heavily when
operating the vehicle.

Provides cooperative control of the
ABS, TRC, VSC and EPS.
Helps to maintain directional stability when swerving on slippery road
surfaces by controlling steering performance.

Summary of the driving
assist systems
n ECB (Electronically Con-

trolled Brake System)
The electronically controlled system generates braking force corresponding to the brake operation
n ABS (Anti-lock Brake System)

Helps to prevent wheel lock when
the brakes are applied suddenly, or
if the brakes are applied while driving on a slippery road surface
n Brake assist

Generates an increased level of
braking force after the brake pedal
is depressed when the system
detects a panic stop situation
n VSC (Vehicle Stability Control)

Helps the driver to control skidding
when swerving suddenly or turning
on slippery road surfaces.

trol+)

n Trailer Sway Control

Helps the driver to control trailer
sway by selectively applying brake
pressure for individual wheels and
reducing driving torque when trailer
sway is detected.
n TRC (Traction Control)

Helps to maintain drive power and
prevent the drive wheels from spinning when starting the vehicle or
accelerating on slippery roads
n Active Cornering Assist (ACA)

Helps to prevent the vehicle from
drifting to the outer side by performing inner wheel brake control when
attempting to accelerate while turning
n Hill-start assist control

Helps to reduce the backward
movement of the vehicle when
starting on an uphill
n EPS (Electric Power Steering)

Employs an electric motor to
reduce the amount of effort needed
to turn the steering wheel
n Emergency brake signal

When the brakes are applied suddenly, the emergency flashers auto-

5-4. Using the driving support systems

matically flash to alert the vehicle
behind.
n The Secondary Collision

Press

503

again to turn the system

back on.

Brake (Secondary collision
reduction at the time of a frontal collision)
When the SRS airbag sensor
detects a collision and the system
operates, the brakes and brake
lights are automatically controlled
to reduce the vehicle speed and
help reduce the possibility of further
damage due to a secondary collision.
n When the TRC/VSC/ABS/Trailer

Sway Control systems are operating
The slip indicator light will flash while the
TRC/VSC/ABS/Trailer Sway Control
systems are operating.

n Turning off both TRC, VSC and

Trailer Sway Control systems
To turn the TRC, VSC and Trailer Sway
Control systems off, press and hold
for more than 3 seconds while the vehicle is stopped.
The VSC OFF indicator light will come
on and the “Traction Control Turned
OFF” will be shown on the multi-information display.*
again to turn the system

back on.
*: On vehicles with PCS (Pre-Collision-

n Disabling the TRC system
If the vehicle gets stuck in mud, dirt
orsnow, the TRC system may reducepower from the EV system to the
wheels. Pressing
to turn the systemoff may make it easier for you to rock
thevehicle in order to free it.
To turn the TRC system off, quickly
press and release

.

The “Traction Control Turned OFF” will
be shown on the multi-information display.

System), PCS will also be disabled
(only pre-collision warning is available). The PCS warning light will come
on and a message will be displayed
on the multi-information display.
(P.289)

n When the message is displayed on
the multi-information display showing that TRC has been disabled
even if

has not been pressed

TRC is temporary deactivated. If the
information continues to show, contactany authorized Toyota retailer or
Toyota authorized repairer, or any reliablerepairer.

n Operating conditions of hill-start

assist control
When all of the following conditions are

Driving

Press

5

504

5-4. Using the driving support systems

met, the hill-start assist control will operate:

l The shift position is in a position other
than P or N (when starting off forward/backward on an upward incline)

l Operating sound heard from the motor
compartment when the brake pedal is
operated.

l Motor sound of the brake system

heard from the front part of the vehicle
when the driver’s door is opened.

l The vehicle is stopped
l The accelerator pedal is not

l Operating sound heard from the motor

l The parking brake is not engaged
l Power switch is turned to ON

n Active Cornering Assist operation

depressed

n Automatic system cancelation of

hill-start assist control
The hill-start assist control will turn off in
any of the following situations:

l Shift the shift position to P or N
l The accelerator pedal is depressed
l The brake pedal is depressed and the
parking brake is engaged

l A maximum of 2 seconds have

elapsed after the brake pedal is
released

l Power switch is turned to off
n Sounds and vibrations caused by

the ABS, brake assist, VSC, Trailer
Sway Control, TRC and hill-start
assist control systems

l A sound may be heard from the motor

compartment when the brake pedal is
depressed repeatedly, when the EV
system is started or just after the vehicle begins to move. This sound does
not indicate that a malfunction has
occurred in any of these systems.

l Any of the following conditions may

occur when the above systems are
operating. None of these indicates
that a malfunction has occurred.
• Vibrations may be felt through the
vehicle body and steering.
• A motor sound may be heard also
after the vehicle comes to a stop.

n ECB operating sound
ECB operating sound may be heard in
the following cases, but it does not indicate that a malfunction has occurred.

compartment when one or two minutes passed after the stop of the EV
system.

sounds and vibrations
When the Active Cornering Assist is
operated, operation sounds and vibrations may be generated from the brake
system, but this is not a malfunction.

n Reduced effectiveness of the EPS

system
The effectiveness of the EPS system is
reduced to prevent the system from
overheating when there is frequent
steering input over an extended period
of time. The steering wheel may feel
heavy as a result. Should this occur,
refrain from excessive steering input or
stop the vehicle and turn the EV system
off. The EPS system should return to
normal within 10 minutes.

n Automatic reactivation of TRC,

Trailer Sway Control and VSC systems
After turning the TRC, Trailer Sway Control and VSC systems off, the systems
will be automatically re-enabled in the
following situations:

l When the power switch is turned off
l If only the TRC system is turned off,

the TRC will turn on when vehicle
speed increases
If both the TRC and VSC systems are
turned off, automatic re-enabling will
not occur when vehicle speed
increases.

n Operating conditions of Active Cor-

nering Assist
The system operates when the following
occurs.

5-4. Using the driving support systems

l TRC/VSC can operate
l The driver is attempting to accelerate
while turning

505

ing operation

l The accelerator pedal is depressed a
large amount

l The system detects that the vehicle is
drifting to the outer side

l The brake pedal is released
n Operating conditions of emergency

WARNING
n The ABS does not operate effectively when

brake signal
When the following conditions are met,
the emergency brake signal will operates:

l The limits of tire gripping perfor-

l The emergency flashers are off.
l Actual vehicle speed is over 55 km/h

l The vehicle hydroplanes while driv-

l The system judges from the vehicle

n Stopping distance when the ABS

(35 mph).

deceleration that it is a sudden braking operation.

mance have been exceeded (such
as excessively worn tires on a snow
covered road).
ing at high speed on wet or slick
roads.

l The emergency flashers are turned

l When driving on dirt, gravel or

l The system judges from the vehicle

l When driving with tire chains

n Automatic system cancelation of

on.

deceleration that is not a sudden braking operation.

n Secondary Collision Brake (Sec-

ondary collision reduction at the
time of a frontal collision) operating
conditions
The system operates when the SRS
airbag sensor detects a collision while
the vehicle is in motion. However, the
system does not operate when the components are damaged.

n Secondary Collision Brake (Sec-

ondary collision reduction at the
time of a frontal collision) automatic cancellation
The system is automatically canceled in
any of the following situations.

l The vehicle speed drops to approximately 0 km/h (0 mph).

l A certain amount of time elapses dur-

snow-covered roads

l When driving over bumps in the
road

l When driving over roads with potholes or uneven surfaces

n TRC/VSC may not operate effec-

tively when
Directional control and power may not
be achievable while driving on slippery road surfaces, even if the
TRC/VSC system is operating. Drive
the vehicle carefully in conditions
where stability and power may be
lost.

5

Driving

emergency brake signal
The emergency brake signal will be
canceled in any of the following situations:

is operating may exceed that of
normal conditions
The ABS is not designed to shorten
the vehicle’s stopping distance.
Always maintain a safe distance from
the vehicle in front of you, especially
in the following situations:

506

5-4. Using the driving support systems

WARNING
n Active Cornering Assist does not
operate effectively when

l Do not overly rely on Active Cornering Assist. Active Cornering Assist
may not operate effectively when
accelerating down slopes or driving
on slippery road surfaces.

l When Active Cornering Assist fre-

quently operates, Active Cornering
Assist may temporarily stop operating to ensure proper operation of
the brakes, TRC and VSC.

n Hill-start assist control does not

operate effectively when
l Do not overly rely on hill-start assist
control. Hill-start assist control may
not operate effectively on steep
inclines and roads covered with ice.

l Unlike the parking brake, hill-start

assist control is not intended to hold
the vehicle stationary for an
extended period of time. Do not
attempt to use hill-start assist control to hold the vehicle on an incline,
as doing so may lead to an accident.

n When the TRC/ABS/VSC/Trailer

Sway Control is activated
The slip indicator light flashes. Always
drive carefully. Reckless driving may
cause an accident. Exercise particular
care when the indicator light flashes.

n When the TRC/VSC/Trailer Sway
Control systems are turned off

l Be especially careful and drive at a

speed appropriate to the road conditions. As these are the systems to
help ensure vehicle stability and
driving force, do not turn the
TRC/VSC/Trailer Sway Control systems off unless necessary.

l Trailer Sway Control is part of the

VSC system and will not operate if
VSC is turned off or experiences a
malfunction.

n Replacing tires
Make sure that all tires are of the
specified size, brand, tread pattern
and total load capacity. In addition,
make sure that the tires are inflated to
the recommended tire inflation pressure level.
The ABS, TRC, Trailer Sway Control
and VSC systems will not function
correctly if different tires are installed
on the vehicle.
Contact any authorized Toyota retailer
or Toyota authorized repairer, or any
reliable repairer for further information
when replacing tires or wheels.
n Handling of tires and the suspen-

sion
Using tires with any kind of problem
or modifying the suspension will affect
the driving assist systems, and may
cause a system to malfunction.

n Trailer Sway Control precaution
The Trailer Sway Control system is
not able to reduce trailer sway in all
situations. Depending on many factors such as the conditions of the
vehicle, trailer, road surface and driving environment, the Trailer Sway
Control system may not be effective.
Refer to your trailer owner’s manual
for information on how to tow your
trailer properly.

n If trailer sway occurs
Observe the following precautions.
Failing to do so may cause death or
serious injury.
l Firmly grip the steering wheel.
Steer straight ahead. Do not try to
control trailer sway by turning the
steering wheel.

l Begin releasing the accelerator

pedal immediately but very gradually to reduce speed.
Do not increase speed. Do not
apply vehicle brakes.

5-4. Using the driving support systems

507

WARNING
If you make no extreme correction
with the steering or brakes, your vehicle and trailer should stabilize.
(P.237)

n Secondary Collision Brake (Sec-

ondary collision reduction at the
time of a frontal collision)
Do not rely solely upon the Secondary
Collision Brake (Secondary collision
reduction at the time of a frontal collision). This system is designed to help
reduce the possibility of further damage due to a secondary collision,
however, that effect changes according to various conditions. Overly relying on the system may result in death
or serious injury.

5

Driving
