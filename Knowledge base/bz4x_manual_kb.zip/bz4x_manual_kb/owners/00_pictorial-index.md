# Pictorial index

> Source: Toyota bZ4X Touring — Owner's Manual, Front/back matter, pages 1–29

Pictorial index

Search by illustration

For safety
and security

Make sure to read through them

Electric Vehicle
system

Reading charging-related information

Vehicle status
information and
indicators

Reading driving-related information

Before driving

Opening and closing the doors and windows, adjustment
before driving

(Main topics: Child seat, theft deterrent system)

(Main topics: Electric Vehicle system, charging methods)

(Main topics: Meters, multi-information display)

1

2

3

4

(Main topics: Keys, doors, seats, power windows)

Driving

Operations and advice which are necessary for driving
(Main topics: Starting Electric Vehicle system, driving support
systems)

Interior features

Usage of the interior features

Maintenance
and care

Caring for your vehicle and maintenance procedures

When trouble
arises

What to do in case of malfunction and emergency

Vehicle
specifications

Vehicle specifications, customizable features

Index
bZ4X TOURING
PZ49X-9AD75-EN
L/O 30/01/2026

bZ4X-Touring_OM_EE

(Main topics: Air conditioner, storage features)

(Main topics: Interior and exterior, light bulbs)

(Main topics: 12-volt battery discharge, flat tire)

(Main topics: Fluids, tire inflation pressure)

Search by symptom
Search alphabetically

5

6

7

8

9

Pictorial index

Pictorial index
nExterior

A Side doors ......................................................................................P.173
Locking/unlocking ............................................................................P.173
Opening/closing the side windows...................................................P.218
Locking/unlocking by using the mechanical key ..............................P.656
Warning messages ..........................................................................P.627

B Back door .......................................................................................P.178
Locking/unlocking ............................................................................P.179
Opening/closing the back door ........................................................P.179
Power back door ..............................................................................P.179
Warning messages ..........................................................................P.627

C Outside rear view mirrors .............................................................P.214
Adjusting the mirror angle ................................................................P.214
Folding the mirrors ...........................................................................P.214
Driving position memory*1 ................................................................P.221
Defogging the mirrors ......................................................................P.521
Windshield wipers .........................................................................P.271

13

14

Pictorial index

Precautions against winter season ..................................................P.508
To prevent freezing (windshield wiper de-icer)*1 ..............................P.521
Precautions against car wash (rain-sensing windshield wipers)......P.565
Charging port lids ..........................................................................P.103
Charging methods............................................................................P.108
Tires ................................................................................................P.589
Tire size/inflation pressure ...............................................................P.673
Winter tires/tire chain .......................................................................P.508
Checking/rotation/tire pressure warning system ..............................P.589
Coping with flat tires.................................................................P.634, 645
Hood................................................................................................P.580
Opening ...........................................................................................P.580
Coping with overheat .......................................................................P.663
Warning messages ..........................................................................P.627
Light bulbs of the exterior lights for driving
(Replacing method: P.608)
Headlights/front position lights/daytime running lights ............P.260
Turn signal lights ...........................................................................P.253
Tail lights ........................................................................................P.260
Turn signal lights ...........................................................................P.253
Stop lights
Emergency brake signal ..................................................................P.502
Tail lights ........................................................................................P.260
Back-up light*2
Shifting the shift position to R ..........................................................P.247
License plate lights........................................................................P.260
Rear fog light*2 ...............................................................................P.271
Side turn signal lights ...................................................................P.253
*1: If equipped
*2: It may be located on the opposite side depending on the target region.

Pictorial index

nInstrument panel (left-hand drive vehicles)

A Power switch ..................................................................................P.243
Starting the EV system/changing the modes ...........................P.243, 246
Emergency stop of the EV system...................................................P.610
When the EV system will not start ...................................................P.653
Warning messages ..........................................................................P.627

B Rotary shifter..................................................................................P.247
Changing the shift position...............................................................P.248
Precautions against towing ..............................................................P.613

C Meters .............................................................................................P.156
Reading the meters/adjusting the instrument panel lights .......P.156, 158
Warning lights/indicator lights ..........................................................P.152
When the warning lights come on....................................................P.619
Multi-information display ..............................................................P.159
Display .............................................................................................P.159
When the warning messages are displayed ....................................P.627
Turn signal lever ............................................................................P.253

15

16

Pictorial index

Headlight switch ............................................................................P.260
Headlights/front position lights/tail lights/license plate lights/daytime running
lights.................................................................................................P.260
Rear fog light....................................................................................P.271
Windshield wiper and washer switch ..................................P.271, 274
Usage.......................................................................................P.271, 274
Adding washer fluid..........................................................................P.588
Headlight cleaners ...........................................................................P.275
Warning messages ..........................................................................P.627
Emergency flasher switch.............................................................P.610
Hood lock release lever.................................................................P.580
Tilt and telescopic steering lock release lever............................P.203
Adjustment .......................................................................................P.203
Air conditioning system ................................................................P.518
Usage...............................................................................................P.518
Rear window defogger .....................................................................P.521
Multimedia system*
*

: Refer to “Multimedia owner’s manual”.

Pictorial index

nSwitches (left-hand drive vehicles)

A Instrument panel light control switches ......................................P.158
B “ODO TRIP” switch........................................................................P.158
C Camera switch*1, 2 ..........................................................................P.437
Brake hold switch ..........................................................................P.257
Parking brake switch .....................................................................P.254
Applying/releasing............................................................................P.254
Precautions against winter season ..................................................P.509
Warning buzzer/message ........................................................P.619, 627
“ECO MODE” switch......................................................................P.251
VSC (Vehicle Stability Control) off switch ...................................P.503
Grip Control switch*1 .....................................................................P.500
“X-MODE” switch*1 ........................................................................P.498
“SNOW” mode switch*1 .................................................................P.497
Advanced Park (parking assist system) main switch*1 ..............P.406
Power back door switch................................................................P.178
Headlight cleaner switch ..............................................................P.275

17

18

Pictorial index

Adaptive High-beam System switch*1..........................................P.264
Automatic High Beam switch*1 .....................................................P.268
Manual headlight leveling dial*1 ...................................................P.263
*1

: If equipped

*2: Refer to “Multimedia owner’s manual”.

A Position memory switches*...........................................................P.221
B Outside rear view mirror switches ...............................................P.214
C Door lock switches ........................................................................P.176
Power window switches................................................................P.218
Window lock switch.......................................................................P.220
*: If equipped

Pictorial index

G

B

C

D G

A

C
E
E
G

F
B

C

G

A
E
E

F

A Meter control switches ..................................................................P.160
B TEL switch*1 ...................................................................................P.160
C Cruise control switch
Dynamic radar cruise control*2.........................................................P.324
Cruise control...........................................................................P.335, 339
Speed limiter*2 .................................................................................P.343
LTA (Lane Tracing Assist) switch .................................................P.299
Audio remote control switches*1
Talk switch*1
Paddle shift switches ....................................................................P.252
*1: Refer to “Multimedia owner’s manual”.
*2: If equipped

19

20

Pictorial index

nInterior (left-hand drive vehicles)

A SRS airbags......................................................................................P.37
B Floor mats.........................................................................................P.30
C Front seats......................................................................................P.196
Rear seats.......................................................................................P.197
Head restraints...............................................................................P.200
Seat belts ..........................................................................................P.33
Inside lock buttons ........................................................................P.176
Assist grips ....................................................................................P.552
Coat hooks .....................................................................................P.552
Cup holders ....................................................................................P.532
Console box ...................................................................................P.532
Rear seat heater switches* ............................................................P.526
*: If equipped

Pictorial index

nCeiling (left-hand drive vehicles)

A Inside rear view mirror*1 ................................................................P.204
Digital Rear-view Mirror*1 ..............................................................P.205

B Sun visors*2 ....................................................................................P.541
C Vanity mirrors.................................................................................P.541
Electronic sunshade switches*1 ...................................................P.540
Interior light*3 .................................................................................P.529
Personal lights ...............................................................................P.529
“SOS” button*1 ...........................................................................P.69, 79
Intrusion sensor and tilt sensor cancel switch*1 ..........................P.86
*1: If equipped
*2: NEVER use a rearward facing child restraint on a seat protected by an ACTIVE

AIRBAG in front of it, DEATH or SERIOUS INJURY to the CHILD can occur.
(P.48)

*3: The illustration shows the front, but they are also equipped in the rear.

21

22

Pictorial index

nInstrument panel (right-hand drive vehicles)

A Power switch ..................................................................................P.243
Starting the EV system/changing the modes ...........................P.243, 246
Emergency stop of the EV system...................................................P.610
When the EV system will not start ...................................................P.653
Warning messages ..........................................................................P.627

B Rotary shifter..................................................................................P.247
Changing the shift position...............................................................P.248
Precautions against towing ..............................................................P.613

C Meters .............................................................................................P.156
Reading the meters/adjusting the instrument panel lights .......P.156, 158
Warning lights/indicator lights ..........................................................P.152
When the warning lights come on....................................................P.619
Multi-information display ..............................................................P.159
Display .............................................................................................P.159
When the warning messages are displayed ....................................P.627
Turn signal lever ............................................................................P.253

Pictorial index

Headlight switch ............................................................................P.260
Headlights/front position lights/tail lights/license plate lights/daytime running
lights.................................................................................................P.260
Rear fog light....................................................................................P.271
Windshield wiper and washer switch ..................................P.271, 274
Usage.......................................................................................P.271, 274
Adding washer fluid..........................................................................P.588
Headlight cleaners ...........................................................................P.275
Warning messages ..........................................................................P.627
Emergency flasher switch.............................................................P.610
Hood lock release lever.................................................................P.580
Tilt and telescopic steering lock release lever............................P.203
Adjustment .......................................................................................P.203
Air conditioning system ................................................................P.518
Usage...............................................................................................P.518
Rear window defogger .....................................................................P.521
Multimedia system*
*

: Refer to “Multimedia owner’s manual”.

23

24

Pictorial index

nSwitches (right-hand drive vehicles)

A “ECO MODE” switch......................................................................P.251
B VSC (Vehicle Stability Control) off switch ...................................P.503
C Grip Control switch*1 .....................................................................P.500
“X-MODE” switch*1 ........................................................................P.498
“SNOW” mode switch*1 .................................................................P.497
Camera switch*2 .............................................................................P.437
Brake hold switch ..........................................................................P.257
Parking brake switch .....................................................................P.254
Applying/releasing............................................................................P.254
Precautions against winter season ..................................................P.509
Warning buzzer/message ........................................................P.619, 627
Instrument panel light control switches ......................................P.158
“ODO TRIP” switch........................................................................P.158
Adaptive High-beam System switch ............................................P.264
Automatic High Beam switch .......................................................P.268
Headlight cleaner switch ..............................................................P.275

Pictorial index

Power back door switch................................................................P.178
Advanced Park (parking assist system) main switch*1 ..............P.406
*1: If equipped
*2: Refer to “Multimedia owner’s manual”.

A Position memory switches*...........................................................P.221
B Outside rear view mirror switches ...............................................P.214
C Door lock switches ........................................................................P.176
Power window switches................................................................P.218
Window lock switch.......................................................................P.220
*

: If equipped

25

26

Pictorial index

A Meter control switches ..................................................................P.160
B TEL switch* .....................................................................................P.160
C Cruise control switch
Dynamic radar cruise control ...........................................................P.324
Cruise control...................................................................................P.335
Speed limiter ....................................................................................P.343
LTA (Lane Tracing Assist) switch .................................................P.299
Audio remote control switches*
Talk switch*
Paddle shift switches ....................................................................P.252
*: Refer to “Multimedia owner’s manual”.

Pictorial index

nInterior (right-hand drive vehicles)

A SRS airbags......................................................................................P.37
B Floor mats.........................................................................................P.30
C Front seats......................................................................................P.196
Rear seats.......................................................................................P.197
Head restraints...............................................................................P.200
Seat belts ..........................................................................................P.33
Inside lock buttons ........................................................................P.176
Assist grips ....................................................................................P.552
Coat hooks .....................................................................................P.552
Cup holders ....................................................................................P.532
Console box ...................................................................................P.532
Rear seat heater switches* ............................................................P.526
*: If equipped

27

28

Pictorial index

nCeiling (right-hand drive vehicles)

A Inside rear view mirror*1 ................................................................P.204
Digital Rear-view Mirror*1 ..............................................................P.205

B Sun visors*2 ....................................................................................P.541
C Vanity mirrors.................................................................................P.541
Electronic sunshade switches*1 ...................................................P.540
Interior light*3 .................................................................................P.529
Personal lights ...............................................................................P.529
“SOS” button....................................................................................P.69
Intrusion sensor and tilt sensor cancel switch.............................P.86
*1: If equipped
*2: NEVER use a rearward facing child restraint on a seat protected by an ACTIVE

AIRBAG in front of it, DEATH or SERIOUS INJURY to the CHILD can occur.
(P.48)

*3: The illustration shows the front, but they are also equipped in the rear.

29

For safety and security

1

1-1. For safe use
.

Before driving ..................... 30
For safe driving ................... 31
SRS airbags ....................... 37
1-2. Child safety
Airbag manual on-off system
......................................... 44
Riding with children ............ 45
Child restraint systems ....... 46
1-3. Emergency assistance
eCall ................................... 69
ERA-GLONASS/EVAK ....... 79
1-4. Theft deterrent system
Immobilizer system ............. 83
Double locking system........ 84
Alarm .................................. 85

For safety and security

Seat belts............................ 33

1
