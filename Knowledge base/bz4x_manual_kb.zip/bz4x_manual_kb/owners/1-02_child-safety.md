# 1-2. Child safety

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 1: For safety and security, pages 44–68

44

1-2. Child safety

Airbag manual on-off
system*

1-2.Child safety

*: If equipped

This system deactivates the
following SRS airbags:
 SRS front passenger airbag
Only deactivate the airbags
when using a child restraint
system on the front passenger
seat.

B Airbag manual on-off switch

Deactivating the airbags for
the front passenger
Insert the mechanical key into the
cylinder and turn to the “OFF” position.
The “OFF” indicator light turns on (only
when the power switch is in ON).

System components

n “PASSENGER AIR BAG” indicator

information
If any of the following problems occur, it
is possible that there is a malfunction in
the system. Have the vehicle inspected
by any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.

l The “OFF” indicator does not illuminate when the airbag manual on-off
switch is set to “OFF”.

l The indicator light does not change

when the airbag manual on-off switch
is switched to “ON” or “OFF”.

A “PASSENGER AIR BAG” indicator
“PASSENGER AIR BAG” and “ON”
indicator light turns on when the airbag
system is on, and about after 60 seconds they go off. (only when the power
switch is in ON).

1-2. Child safety

WARNING

45

Riding with children

n When installing a child restraint

n When a child restraint system is

not installed on the front passenger seat
Ensure that the airbag manual on-off
system is set to “ON”.
If it is left off, the airbag may not
deploy in the event of an accident,
which may result in serious injury or
even death.

Observe the following precautions when children are in the
vehicle.
Use a child restraint system
appropriate for the child, until
the child becomes large
enough to properly wear the
vehicle’s seat belt.
 It is recommended that children sit in the rear seats to
avoid accidental contact with
the steering wheel, wiper
switch, etc.
 Use the rear door child-protector lock or the window lock
switch to avoid children opening the door while driving or
operating the power window
accidentally. (P.177, 220)
 Do not let small children operate equipment which may
catch or pinch body parts,
such as the power window,
hood, back door, seats etc.

1

For safety and security

system
For safety reasons, always install a
child restraint system in a rear seat. In
the event that the rear seat cannot be
used, the front seat can be used as
long as the airbag manual on-off system is set to “OFF”.
If the airbag manual on-off system is
left on, the strong impact of the airbag
deployment (inflation) may cause
serious injury or even death.

46

1-2. Child safety

WARNING
n When children are in the vehicle
Never leave children unattended in
the vehicle, and never allow children
to have or use the key.
Children may be able to start the vehicle or shift the vehicle into neutral.
There is also a danger that children
may injure themselves by playing with
the windows or other features of the
vehicle. In addition, heat build-up or
extremely cold temperatures inside
the vehicle can be fatal to children.

Child restraint systems
Before installing a child
restraint system in the vehicle,
there are precautions that need
to be observed, different types
of child restraint systems, as
well as installation methods,
etc., written in this manual.
 Use a child restraint system
when riding with a small child
that cannot properly use a seat
belt. For the child’s safety,
install the child restraint system to a rear seat. Be sure to
follow the installation method
that is in the operation manual
enclosed with the restraint system.
 The use of a Toyota genuine
child restraint system is recommended, as it is safer to
use in this vehicle. Toyota genuine child restraint systems
are made specifically for
Toyota vehicles. They can be
purchased at a Toyota dealer.

Table of contents
Points to remember: P.47
When using a child restraint system: P.48
Child restraint system compatibility
for each seating position: P.51
Child restraint system installation
method

1-2. Child safety

• Fixed with a seat belt: P.64
• Fixed with an ISOFIX lower
anchorage: P.66
• Using a top tether anchorage:
P.67

Points to remember

 Use a child restraint system until
the child becomes large enough
to properly wear the vehicle’s
seat belt.
 Choose a child restraint system
appropriate to the age and size
of the child.
 Note that not all child restraint
systems can fit in all vehicles.
Before using or purchasing a
child restraint system, check the
compatibility of the child restraint
system with seat positions.
(P.51)
WARNING
n When a child is riding
Observe the following precautions.
Failure to do so may result in death or
serious injury.

l For effective protection in automo-

bile accidents and sudden stops, a
child must be properly restrained,
using a seat belt or child restraint
system which is correctly installed.
For installation details, refer to the
operation manual enclosed with the
child restraint system. General
installation instruction is provided in
this manual.

l Toyota strongly urges the use of a

proper child restraint system that
conforms to the weight and size of
the child, installed on the rear seat.
According to accident statistics, the
child is safer when properly
restrained in the rear seat than in
the front seat.

l Holding a child in your or someone
else’s arms is not a substitute for a
child restraint system. In an accident, the child can be crushed
against the windshield or between
the holder and the interior of the
vehicle.

n Handling the child restraint sys-

tem
If the child restraint system is not
properly fixed in place, the child or
other passengers may be seriously
injured or even killed in the event of
sudden braking, sudden swerving, or
an accident.

l If the vehicle were to receive a

strong impact from an accident,
etc., it is possible that the child
restraint system has damage that is
not readily visible. In such cases,
do not reuse the restraint system.

1

For safety and security

 Prioritize and observe the warnings, as well as the laws and regulations for child restraint
systems.

47

48

1-2. Child safety

WARNING
l Depending on the child restraint

system, installation may be difficult
or impossible. In those cases,
check whether the child restraint
system is suitable for installment in
the vehicle. (P.51) Be sure to
install and observe the usage rules
after carefully reading the child
restraint system fixing method in
this manual, as well as the operation manual enclosed with the child
restraint system.

l Keep the child restraint system

 Move the front seat fully rearward.
 Adjust the seat height to the
uppermost position.
 If the head restraint interferes
with your child restraint system,
and the head restraint can be
removed, remove the head
restraint.
Otherwise, put the head restraint in the
upper most position.

properly secured on the seat even if
it is not in use. Do not store the
child restraint system unsecured in
the passenger compartment.

l If it is necessary to detach the child

restraint system, remove it from the
vehicle or store it securely in the
luggage compartment.

When using a child restraint
system
n When installing a child

restraint system to a front passenger seat
For the safety of a child, install a
child restraint system to a rear seat.
When installing a child restraint
system to a front passenger seat is
unavoidable, adjust the seat as follows and install the child restraint
system:
 Adjust the seatback angle to the
most upright position.
When installing a forward-facing child
seat, if there is a gap between the child
seat and the seatback, adjust the
seatback angle until good contact is
achieved.

WARNING
n When using a child restraint sys-

tem
Observe the following precautions.
Failure to do so may result in death or
serious injury.

1-2. Child safety

49

WARNING
l Never use a rear-facing child

restraint system on the front passenger seat when the airbag manual on-off switch is on. (P.44)
The force of the rapid inflation of
the front passenger airbag can
cause death or serious injury to
children in the event of an accident.

ger side sun visor, indicating it is
forbidden to attach a rear-facing
child restraint system to the front
passenger seat.
Details of the label(s) are shown in
the illustration below.

For safety and security

l There is a label(s) on the passen-

1

50

1-2. Child safety

WARNING

WARNING
l Only put a forward-facing child

restraint system on the front seat
when unavoidable. When installing
a forward-facing child restraint on
the front passenger seat, move the
seat as far back as possible. Failing
to do so may result in death or serious injury if the airbags deploy
(inflate).

l Do not allow the child to lean

his/her head or any part of his/her
body against the door or the area of
the seat, front or rear pillars, or roof
side rails from which the SRS side
airbags or SRS curtain shield
airbags deploy even if the child is
seated in the child restraint system.
It is dangerous if the SRS side
airbags and curtain shield airbags
inflate, and the impact could cause
death or serious injury to the child.

l When a junior seat is installed,

always ensure that the shoulder
belt is positioned across the center
of the child’s shoulder. The belt
should be kept away from the
child’s neck, but not so that it could
fall off the child’s shoulder.

1-2. Child safety

WARNING
l Use child restraint system suitable

to the age and size of the child and
install it to the rear seat.

l If the driver’s seat interferes with

systems. (P.57)
Check the selected child restraint
system together with the following
[Before confirming the compatibility
of each seating position with child
restraint systems].
n Before confirming the compat-

ibility of each seating position
with child restraint systems
1 Checking the child restraint system standards.
Use a child restraint system that
conforms to UN(ECE) R44*1 or

Child restraint system compatibility for each seating
position (except for Reunion
and Mayotte)

UN(ECE) R129*1, 2.
The following approval mark is
displayed on child restraint systems which are conformed.
Check for an approval mark
attached to the child restraint
system.

n Child restraint system compat-

ibility for each seating position
Compatibility of each seating position with child restraint systems
(P.52) displays the type of child
restraint systems that can be used
and possible seating positions for
installation using symbols. Also, the
recommended child restraint system that is suitable for your child
can be selected.
Otherwise, check [Recommended
child restraint systems information]
for recommended child restraint

Example of the displayed regulation
number

A UN(ECE) R44 approval mark*3
The weight range of the child
who is applicable for an

1

For safety and security

the child restraint system and prevents it from being attached correctly, attach the child restraint
system to the right-hand rear seat
(left-hand drive vehicles) or the
left-hand rear seat (right-hand drive
vehicles).

51

52

1-2. Child safety

UN(ECE) R44 approval mark is
indicated.
B UN(ECE) R129 approval mark
The height range of the child
who is applicable as well as
available weights for an
UN(ECE) R129 approval mark
is indicated.

*3

2 Checking the category of the
child restraint system.
Check the approval mark of the
child restraint system for which
of the following categories the
child restraint system is suitable.
Also, if there are any uncertainties, check the user’s guide
included with the child restraint
system or contact the retailer of
the child restraint system.
• “universal”
• “semi-universal”
• “restricted”
• “vehicle specific”

*1: UN(ECE) R44 and UN(ECE) R129

are U.N. regulations for child
restraint systems.
*2: The child restraint systems men-

tioned in the table may not be available outside of the EU area.
*3: The displayed mark may differ

depending on the product.

n Compatibility of each seating

position with child restraint
systems
 Left-hand drive vehicles

1-2. Child safety
 Right-hand drive vehicles

53

Suitable for i-Size and ISOFIX
child restraint system.
Includes a top tether anchorage
point.
*1: Move the front seat fully rearward. If

the passenger seat height can be
adjusted, move it to the upper most
position.
most upright position. When installing a forward-facing child seat, if
there is a gap between the child seat
and the seatback, adjust the
seatback angle until good contact is
achieved.

Deactivation of front passenger
airbag.
Activation of front passenger
airbag.
Never use a rearward-facing
child restraint system on the
front passenger seat when the
airbag manual on-off switch is
on.
Suitable for “universal” category
child restraint system fixed with
the seat belt.
Suitable for forward-facing “universal” category child restraint
system fixed with the seat belt.
Suitable for recommended child
restraint systems given on recommended child restraint systems information (P.57).

*3: If the head restraint interferes with

your child restraint system, and the
head restraint can be removed,
remove the head restraint.
Otherwise, put the head restraint in
the upper most position.
*4: Applicable for KIDFIX PRO and

KIDFIX i-Size only.

When securing some types of child
restraint systems in rear seat, it
may not be possible to properly use
the seat belts in positions next to
the child restraint without interfering
with it or affecting seat belt effectiveness. Be sure your seat belt fits
snugly across your shoulder and

For safety and security

*2: Adjust the seatback angle to the

1

54

1-2. Child safety

guide, move the seat cushion
forward.

low on your hips. If it does not, or if
it interferes with the child restraint,
move to a different position. Failure
to do so may result in death or serious injury.
 When installing a child restraint
in the rear seats, adjust the front
seat so that it does not interfere
with the child or child restraint
system.
 When installing a child seat with
support base, if the child seat
interferes with the seatback
when latching it into the support
base, adjust the seatback rearward until there is no interference.

 When installing a junior seat, if
the child in your child restraint
system is in a very upright position, adjust the seatback angle to
the most comfortable position.
And if the seat belt shoulder
anchor is ahead of the child seat
belt guide, move the seat cushion forward.

 If the seat belt shoulder anchor is
ahead of the child seat belt

n Detail information for child restraint systems installation
Seating position

Seat position number

Seating position suitable for universal
belted (Yes/No)*
i-Size seating position (Yes/No)

Airbag manual on-off
switch
ON

OFF

Yes
Forward-facing only

Yes

Yes

Yes

Yes

No

No

Yes

No

Yes

55

1-2. Child safety
Seating position

Seat position number

Airbag manual on-off
switch
ON

OFF

Seating position suitable for lateral fixture
(L1/L2/No)

No

No

No

No

No

Suitable rearward
facing fixture
(R1/R2X/R2/R3/No)

No

No

R1, R2X,
R2, R3

No

R1, R2X,
R2, R3

Suitable forward facing fixture
(F2X/F2/F3/No)

No

No

F2X, F2,
F3

No

F2X, F2,
F3

B2, B3

B2, B3

Belt fixation only

Belt fixation only

B2, B3

No

B2, B3

*: All universal categories (group 0, 0+, I, II and III).

Toyota suggests the users to use

and

seating positions.

ISOFIX child restraint systems are divided into different “fixture”. The child
restraint system can be used in the seating positions for “fixture” mentioned
in the table above. For kind of “fixture” relation, confirm the following table.
If your child restraint system has no kind of “fixture” (or if you cannot find
information in the table below), please refer to the child restraint system
“vehicle list” for compatibility information or ask the retailer of your child
seat.

For safety and security

Suitable junior seat
fixture (B2/B3/No)

1

56

1-2. Child safety
Mass
groups

0

0+

I

Child weight

up to 10 kg
(22 lb.)

up to 13 kg
(28 lb.)

9 to 18 kg (20
to 39 lb.)

II

15 to 25 kg
(34 to 55 lb.)

III

22 to 36 kg
(48 to 79 lb.)

Size
class

Fixture

Description

E

R1

Rearward-facing infant seat

F

L1

Left lateral-facing infant seat (Carrycot)

G

L2

Right lateral-facing infant seat (Carrycot)

C

R3

Full-size, rearward-facing child
restraint systems

D

R2

Reduced-size, rearward-facing child
restraint systems

—

R2X

Reduced-size, rearward-facing child
restraint systems

E

R1

Rearward-facing infant seat

A

F3

Full-height, forward-facing child
restraint systems

B

F2

Reduced-height, forward-facing child
restraint systems

B1

F2X

Reduced-height, forward-facing child
restraint systems

C

R3

Full-size, rearward-facing child
restraint systems

D

R2

Reduced-size, rearward-facing child
restraint systems

—

B2, B3

Junior seat

1-2. Child safety

57

n Recommended child restraint systems information
Recommended child
restraint system

Size range

Direction of
travel

Fixation
Lower
anchorages

Seat belt

40 to 105 cm (16
to 41 in.)*3
[Up to 17.5 kg
(Up to 38 lb.)]

Rearward-facing

TOYOTA KIDFIX
i-SIZE*1, 2

KIDFIX PRO*1, 2

Yes

Not applicable

100 to 150 cm
(39 to 59 in.) Forward-fac[15 to 36 kg (34 ing use only
to 79 lb.)]

Yes

Yes

100 to 150 cm
(39 to 59 in.) Forward-fac[15 to 36 kg (34 ing use only
to 79 lb.)]

Yes

Yes

*1: Be sure to attach the seat belt through the SecureGuard.
*2: TOYOTA recommends to use with lower anchorages.
*3: Be sure to use the newborn inlay accessory for stature 40 to 60 cm.

The child restraint systems mentioned in the table may not be available outside the EU countries and United Kingdom.
 When using the child restraint
system with SecureGuard, be
sure to guide the lap belt into
SecureGuard A as shown in the
illustration.

For safety and security

MAXI COSI PEARL
360 & FAMILYFIX > 15 month & 76
360 BASE
to 105 cm (30 to
Forward-fac41 in.)
ing
[Up to 17.5 kg
(Up to 38 lb.)]

1

58

1-2. Child safety

Child restraint system compatibility for each seating
position (for Reunion and
Mayotte)

attached to the child restraint
system.

n Child restraint system compat-

ibility for each seating position
Compatibility of each seating position with child restraint systems
(P.59) displays the type of child
restraint systems that can be used
and possible seating positions for
installation using symbols.
Check the selected child restraint
system together with the following
[Before confirming the compatibility
of each seating position with child
restraint systems].
n Before confirming the compat-

ibility of each seating position
with child restraint systems
1 Checking the child restraint system standards.
Use a child restraint system that
conforms to UN(ECE) R44*1 or
UN(ECE) R129*1, 2.
The following approval mark is
displayed on child restraint systems which are conformed.
Check for an approval mark

Example of the displayed regulation
number

A UN(ECE) R44 approval mark*3
The weight range of the child
who is applicable for an
UN(ECE) R44 approval mark is
indicated.
B UN(ECE) R129 approval mark*3
The height range of the child
who is applicable as well as
available weights for an
UN(ECE) R129 approval mark
is indicated.

2 Checking the category of the
child restraint system.
Check the approval mark of the
child restraint system for which
of the following categories the
child restraint system is suitable.
Also, if there are any uncertainties, check the user’s guide
included with the child restraint
system or contact the retailer of
the child restraint system.

1-2. Child safety

•
•
•
•

“universal”
“semi-universal”
“restricted”
“vehicle specific”

59

*1, 2, 3

1

*1: UN(ECE) R44 and UN(ECE) R129

For safety and security

*2, 3

*2, 3

are U.N. regulations for child
restraint systems.
*2: The child restraint systems men-

tioned in the table may not be available outside of the EU area.

*2, 3

*3: The displayed mark may differ

depending on the product.

n Compatibility of each seating

position with child restraint
systems

Deactivation of front passenger
airbag.
Suitable for “universal” category
child restraint system fixed with
the seat belt.
Suitable for forward-facing “Universal” category child restraint
system fixed with the seat belt.
Suitable for child restraint systems given on recommended
child restraint systems and
compatibility table (P.62).
Suitable for i-Size and ISOFIX
child restraint system.

60

1-2. Child safety
Includes a top tether anchorage
point.

seatback angle until good contact is
achieved.

Activation of front passenger
airbag.
Never use a rearward-facing
child restraint system on the
front passenger seat when the
airbag manual on-off switch is
on.
*1: Move the front seat fully rearward. If

the passenger seat height can be
adjusted, move it to the upper most
position.
*2: Adjust the seatback angle to the

most upright position. When installing a forward-facing child seat, if
there is a gap between the child seat
and the seatback, adjust the

*3: If the head restraint interferes with

your child restraint system, and the
head restraint can be removed,
remove the head restraint.
Otherwise, put the head restraint in
the upper most position.

n Detail information for child restraint systems installation
Seating position

Seat position number

Airbag manual on-off
switch
ON

Seating position suitable
for universal belted
(Yes/No)

OFF

Yes
Forward-facing only

Yes

Yes

Yes

Yes

i-Size seating position
(Yes/No)

No

No

Yes

No

Yes

Seating position suitable
for lateral fixture (L1/L2/No)

No

No

No

No

No

Suitable rearward facing
fixture (R1/R2X/R2/R3/No)

No

No

R1, R2X,
R2, R3

No

R1, R2X,
R2, R3

1-2. Child safety

61

Seating position

Seat position number

Airbag manual on-off
switch
OFF

Suitable forward facing fixture (F2X/F2/F3/No)

No

No

F2X, F2,
F3

No

F2X, F2,
F3

Suitable junior seat fixture
(B2/B3/No)

No

No

B2, B3

No

B2, B3

ISOFIX child restraint systems are divided into different “fixture”. The child
restraint system can be used in the seating positions for “fixture” mentioned
in the table above. For kind of “fixture” relation, confirm the following table.
If your child restraint system has no kind of “fixture” (or if you cannot find
information in the table below), please refer to the child restraint system
“vehicle list” for compatibility information or ask the retailer of your child
seat.
Fixture

Description

F3

Full-height, forward-facing child restraint systems

F2

Reduced-height forward-facing child restraint systems

F2X

Reduced-height forward-facing child restraint systems

R3

Full-size, rearward-facing child restraint systems

R2

Reduced-size, rearward-facing child restraint systems

R2X

Reduced-size, rearward-facing child restraint systems

R1

Rearward-facing infant seat

L1

Left lateral-facing (carrycot) infant seat

L2

Right lateral-facing (carrycot) infant seat

B2

Junior seat

B3

Junior seat

1

For safety and security

ON

62

1-2. Child safety

n Recommended child restraint systems and Compatibility table
Seating position
Recommended
Child Restraint
System

Size
range

Direction
oftravel

Airbag manual
on-off switch
ON

OFF

No

No

61 to 105
Rearcm
ward-fac(Up to 17
ing
kg)

MAXI COSI
Pearl 360 Pro +
>15
FamilyFix 360 month &
ForPro (Yes/No) 76 to 105
ward-faccm
ing
(Up to 17
kg)

Yes

No

Yes

The child restraint systems mentioned in the table may not be available outside the Africa countries.
When securing some types of child
restraint systems in rear seat, it
may not be possible to properly use
the seat belts in positions next to
the child restraint without interfering
with it or affecting seat belt effectiveness. Be sure your seat belt fits
snugly across your shoulder and
low on your hips. If it does not, or if
it interferes with the child restraint,
move to a different position. Failure
to do so may result in death or serious injury.
 When installing a child restraint
in the rear seats, adjust the front
seat so that it does not interfere
with the child or child restraint
system.

 When installing a child seat with
support base, if the child seat
interferes with the seatback
when latching it into the support
base, adjust the seatback rearward until there is no interference.
 If the seat belt shoulder anchor is
ahead of the child seat belt
guide, move the seat cushion
forward.

1-2. Child safety

Child restraint system installation method
Confirm with the operation manual enclosed with the child restraint system
about the installation of the child restraint system.
Installation method

Seat belt attachment

Page

P.64

1

For safety and security

 When installing a junior seat, if
the child in your child restraint
system is in a very upright position, adjust the seatback angle to
the most comfortable position.
And if the seat belt shoulder
anchor is ahead of the child seat
belt guide, move the seat cushion forward.

63

64

1-2. Child safety
Installation method

Page

ISOFIX lower anchorages attachment

P.66

Top tether anchorage
attachment

P.67

Child restraint system fixed
with a seat belt
n Installing child restraint sys-

tem using a seat belt
Install the child restraint system in
accordance to the operation manual enclosed with the child restraint
system.
If the child restraint system on hand
is not within the “universal” category (or the necessary information
is not in the table), refer to the
“Vehicle List” provided by the child
restraint system maker for various
possible installation positions, or
check the compatibility after asking
the retailer of the child seat.
(P.51)

1 If installing the child restraint
system to the front passenger
seat is unavoidable, refer to
P.48 for the front passenger
seat adjustment.
2 Adjust the seatback angle to the
most upright position.
When installing a forward-facing child
seat, if there is a gap between the child
seat and the seatback, adjust the
seatback angle until good contact is
achieved.

3 Rear outboard seats: If the head
restraint interferes with the child
restraint system and the head
restraint can be removed,
remove the head restraint.
(P.200)
Rear center seat: If the head
restraint interferes with the child

1-2. Child safety

restraint system and the head
restraint can be removed,
remove the head restraint. Otherwise, put the head restraint in
the upper most position.
(P.200)

ensure that it is installed
securely. (P.66)
n Removing a child restraint

system installed with a seat
belt
Press the buckle release button
and fully retract the seat belt.
When releasing the buckle, the child
restraint system may spring up due to
the rebound of the seat cushion.
Release the buckle while holding down
the child restraint system.
Since the seat belt automatically reels
itself, slowly return it to the stowing
position.

n When installing a child restraint

5 If your child restraint system is
not equipped with a lock-off (a
seat belt locking feature),
secure the child restraint system
using a locking clip.

system
You may need a locking clip to install the
child restraint system. Follow the
instructions provided by the manufacturer of the system. If your child restraint
system does not provide a locking clip,
you can purchase the following item
from any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer: Locking clip for child
restraint system
(Part No. 73119-22010)

WARNING
n When installing a child restraint

system
Observe the following precautions.
Failure to do so may result in death or
serious injury.

6 After installing the child restraint
system, rock it back and forth to

1

For safety and security

4 Run the seat belt through the
child restraint system and insert
the plate into the buckle. Make
sure that the belt is not twisted.
Securely fix the seat belt to the
child restraint system in accordance to the directions enclosed
with the child restraint system.

65

66

1-2. Child safety

WARNING
l Do not allow children to play with

the seat belt. If the seat belt
becomes twisted around a child’s
neck, it may lead to choking or
other serious injuries that could
result in death. If this occurs and
the buckle cannot be unfastened,
scissors should be used to cut the
belt.

l Ensure that the belt and plate are

securely locked and the seat belt is
not twisted.

Child restraint system fixed
with ISOFIX lower anchorages
n ISOFIX lower anchorages

(ISOFIX child restraint system)
Lower anchorages are provided for
the outboard rear seats. (Tags displaying the location of the anchorages are attached to the seats.)

l Shake the child restraint system left
and right, and forward and backward to ensure that it has been
securely installed.

l After securing a child restraint system, never adjust the seat.

l When a junior seat is installed,

always ensure that the shoulder
belt is positioned across the center
of the child’s shoulder. The belt
should be kept away from the
child’s neck, but not so that it could
fall off the child’s shoulder.

l Follow all installation instructions

provided by the child restraint system manufacturer.

l When installing a child restraint

system in the rear center seat,
adjust both seatbacks at the
sameangle. Otherwise, the child
restraint system cannot be securely
restrained and this may cause
death or serious injuries in the
event of sudden braking, sudden
swerving or an accident.

n Installation with ISOFIX lower

anchorages (ISOFIX child
restraint system)
Install the child restraint system in
accordance to the operation manual enclosed with the child restraint
system.
If the child restraint system on hand
is not within the “universal” category (or the necessary information
is not in the table), refer to the
“Vehicle List” provided by the child
restraint system maker for various
possible installation positions, or
check the compatibility after asking
the retailer of the child seat.
(P.51)
1 Adjust the seatback angle to the
most upright position.

1-2. Child safety
When installing a forward-facing child
seat, if there is a gap between the child
seat and the seatback, adjust the
seatback angle until good contact is
achieved.

3 Check the positions of the exclusive fixing bars, and install the
child restraint system to the
seat.
The bars are installed in the clearance
between the seat cushion and
seatback.

WARNING
n When installing a child restraint

system
Observe the following precautions.
Failure to do so may result in death or
serious injury.

l After securing a child restraint system, never adjust the seat.

l When using the lower anchorages,

be sure that there are no foreign
objects around the anchorages and
that the seat belt is not caught
behind the child restraint system.

l Follow all installation instructions

provided by the child restraint system manufacturer.

l If the seat is adjusted, reconfirm the
security of the child restraint system.

Using a top tether anchorage
n Top tether anchorages

Top tether anchorages are provided
for the outboard seats.
Use top tether anchorages when
fixing the top strap.

4 After installing the child restraint
system, rock it back and forth to
ensure that it is installed
securely. (P.66)

A Top tether anchorages
B Top strap

1

For safety and security

2 If the head restraint interferes
with the child restraint system
installation and the head
restraint can be removed,
remove the head restraint.
(P.200)

67

68

1-2. Child safety

n Fixing the top strap to the top

tether anchorages

WARNING
n When installing a child restraint

Install the child restraint system in
accordance to the operation manual enclosed with the child restraint
system.

system
Observe the following precautions.
Failure to do so may result in death or
serious injury.

1 Remove the head restraint if it
interferes with your child
restraint system. (P.200)

l Firmly attach the top strap and
make sure that the belt is not
twisted.

l Do not attach the top strap to anything other than the top tether
anchorage of the seat the child
restraint system is installed to.

l After securing a child restraint system, never adjust the seat.

l Follow all installation instructions

provided by the child restraint system manufacturer.

l When installing the child restraint

2 Latch the hook onto the top
tether anchorage and tighten
the top strap.
Make sure the top strap is securely
latched. (P.66)

A Hook
B Top strap

system with the head restraint
being raised, after the head
restraint has been raised and then
the top tether anchorage has been
fixed, do not lower the head
restraint.
