# 4-1. Key information

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 4: Before driving, pages 168–172

168

4-1. Key information

Keys

4-1.Key information

The keys
The following keys are provided
with the vehicle.

l To reduce key battery depletion when

the electronic key is to not be used for
long periods of time, set the electronic
key to the battery-saving mode.
(P.192)

l As the electronic key always receives

radio waves, the battery will become
depleted even if the electronic key is
not used. The following symptoms
indicate that the electronic key battery
may be depleted. Replace the battery
when necessary. (P.604)
• The smart entry & start system or the
wireless remote control does not operate.
• The detection area becomes smaller.
• The LED indicator on the key surface
does not turn on.

l You can replace the battery by your-

A Electronic keys
• Operating the smart entry & start system (P.191)
• Operating the wireless remote control
function (P.169)

B Mechanical keys
C Key number plate
n When riding in an aircraft
When bringing an electronic key onto an
aircraft, make sure you do not press any
buttons on the electronic key while
inside the aircraft cabin. If you are carrying an electronic key in your bag, etc.,
ensure that the buttons are not likely to
be pressed accidentally. Pressing a button may cause the electronic key to emit
radio waves that could interfere with the
operation of the aircraft.

n Electronic key battery depletion
l The standard battery life is 1 to 2
years.

l If the battery becomes low, an alarm

will sound in the cabin and a message
will be displayed on the multi-information display when the EV system
stops.

self (P.604). However, as there is a
danger that the electronic key may be
damaged, it is recommended that
replacement be carried out by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

l To avoid serious deterioration, do not

leave the electronic key within 1 m (3
ft.) of the following electrical appliances that produce a magnetic field:
• TVs
• Personal computers
• Cellular phones, cordless phones and
battery chargers
• Recharging cellular phones or cordless phones
• Table lamps
• Induction cookers

l If the electronic key is near the vehicle
for longer than necessary, even if the
smart entry & start system is not used,
the key battery may become depleted
faster than normal. When not using
the smart entry & start system, it is
recommended not to stay with the
electronic key near the vehicle longer
than necessary.

n Replacing the battery
P.604

4-1. Key information

n Confirmation of the registered key

number
The number of keys already registered
to the vehicle can be confirmed. Ask any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer for details.

n If “New Key Registered Contact

l Do not place the keys near medical
electrical equipment such as
low-frequency therapy equipment
or microwave therapy equipment,
and do not receive medical attention with the keys on your person.

n Carrying the electronic key on

your person
Carry the electronic key 10 cm (3.9
in.) or more away from electric appliances that are turned on. Radio
waves emitted from electric appliances within 10 cm (3.9 in.) of the
electronic key may interfere with the
key, causing the key to not function
properly.

n In case of a smart entry & start

system malfunction or other
key-related problems
P.656

n When an electronic key is lost
P.655

NOTICE
n To prevent key damage
l Do not drop the keys, subject them
to strong shocks or bend them.

l Do not expose the keys to high

temperatures for long periods of
time.

Wireless remote control
The electronic keys are equipped
with the following wireless remote
control:

l Do not get the keys wet or wash

them in an ultrasonic washer, etc.

l Do not attach metallic or magnetic
materials to the keys or place the
keys close to such materials.

l Do not disassemble the keys.
l Do not attach a sticker or anything

else to the surface of the electronic
key.

l Do not place the keys near objects
that produce magnetic fields, such
as TVs, audio systems and induction cookers.

A Locks all the doors (P.173)
B Closes the windows* (P.173)
C Unlocks all the doors (P.173)

Opens the windows* (P.173)

4

Before driving

Your Dealer if You Did Not Register
a New Key” is shown on the
multi-information display
This message will be displayed each
time the driver’s door is opened when
the doors are unlocked from the outside
for approximately 10 days after a newel
ectronic key has been registered.
If this message is displayed but you
have not had a new electronic key registered, ask any authorized Toyota retailer
or Toyota authorized repairer, or any reliable repairer to check if an unknown
electronic key (other than those in your
possession) has been registered.

169

170

4-1. Key information

Opens and closes the power
back door (P.179)
*

: These settings must be customized
at any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer.

Using the mechanical key
To take out the mechanical key,
slide the release lever A and take
the key out.
The mechanical key can only be
inserted in one direction, as the key
only has grooves on one side. If the key
cannot be inserted in a lock cylinder,
turn it over and re-attempt to insert it.
After using the mechanical key, store it
in the electronic key. Carry the mechanical key together with the electronic key.
If the electronic key battery is depleted
or the entry function does not operate
properly, you will need the mechanical
key. (P.656)

n If you lose your mechanical keys
P.655
n If a wrong key is used
The key cylinder rotates freely, isolated
from the internal mechanism.

4-1. Key information

Digital Key*
*

: If equipped

A smartphone can be used
instead of the electronic key of
the vehicle by installing the
dedicated Toyota mobile App
on a smartphone. Also, Digital
Key can be shared with your
family or friends using the
Toyota mobile App.
Please Consult your Local
authorized Toyota retailer or
Toyota website for more information.

In order to use the Digital Key, you
need to*:
 Install the Toyota mobile App
 Register the vehicle to the customer’s Toyota mobile App profile
 Accept Connected Services
Terms of Use
 Accept Digital Key Terms of Use
 Follow the Digital Key enrollment
process.
*: Additional payment might be required

to activate Digital Key services,
please consult your local authorized
TOYOTA retailer or TOYOTA website
for more information

Digital key precautions
 A Digital Key can be used when

the smartphone and server can
communicate. The Digital Key
may become unusable if the
smartphone is not connected to
the Internet. Be sure to carry the
electronic key of the vehicle if
staying in locations with unreliable communications conditions
for long periods of time.
 If the smartphone battery is
depleted, the smartphone cannot
be used as Digital Key. If the battery level is low, be sure to
charge the smartphone prior to
going out.
 The Digital Key system is related
to the smart entry & start system.
If the smart entry & start system
has been deactivated in the vehicle customization setting, the
Digital Key will also be disabled.
 Depending on the radio wave
environment, the Digital Key may
not be able to be used. (P.192)
 When transferring vehicle ownership, make sure to delete the
Digital Keys.
 If the vehicle is not operated for
14 days or more, the Digital Key
will not connect automatically.
Therefore, it may take some time
before the system operates after
a door handle is touched.
 A part of the services may be
stopped for a certain period of
time due to server maintenance.
However, registered Digital Keys
can be used during the mainte-

4

Before driving

Digital key usage conditions

171

172

4-1. Key information

nance.
 A smartphone with Toyota mobile
App and Digital Key enabled will
be able to lock and unlock the
doors, start the EV system and
perform any other operations as
same as the electronic key of the
vehicle. Be especially careful not
to lose the smartphone or allow it
to be stolen.
If the smartphone is lost or stolen, contact any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer immediately.

 When taking your vehicle to contact any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer
for an inspection or repairs,
make sure to bring an electronic
key.
 With the Digital Key alone, no
vehicle lights will illuminate when
approached to the vehicle. Also,
with the digital key alone, some
functions, such as the power
back door’s close & lock function, etc., cannot be used.
