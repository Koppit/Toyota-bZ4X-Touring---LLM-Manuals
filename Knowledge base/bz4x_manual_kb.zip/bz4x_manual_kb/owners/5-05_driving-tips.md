# 5-5. Driving tips

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 508–515

508

5-5. Driving tips

Winter driving tips

5-5.Driving tips

Carry out the necessary preparations and inspections before
driving the vehicle in winter.
Always drive the vehicle in a
manner appropriate to the prevailing weather conditions.

l Do not drive at speeds in excess of
the speed limit or the speed limit
specified for the snow tires being
used.

l Use snow tires on all, not just some
wheels.

 Use fluids that are appropriate to
the prevailing outside temperatures.

n Driving with tire chains
Observe the following precautions to
reduce the risk of accidents.
Failure to do so may result in the vehicle being unable to be driven safely,
and may cause death or serious
injury.
l Do not drive in excess of the speed
limit specified for the tire chains
being used, or 50 km/h (30 mph),
whichever is lower.

• Power control unit coolant

l Avoid driving on bumpy road sur-

Preparation for winter

• Heater coolant
• Washer fluid

 Have a service technician
inspect the condition of the
12-volt battery.
 Have the vehicle fitted with four
snow tires or purchase a set of
tire chains for the front tires.
Ensure that all tires are the specified
size and brand, and that chains match
the size of the tires.

WARNING
n Driving with snow tires
Observe the following precautions to
reduce the risk of accidents.
Failure to do so may result in a loss of
vehicle control and cause death or
serious injury.
l Use tires of the specified size.
l Maintain the recommended level of

faces or over potholes.

l Avoid sudden acceleration, abrupt

steering, sudden braking and shifting operations that cause sudden
regenerative braking.

l Slow down sufficiently before entering a curve to ensure that vehicle
control is maintained.

l Do not use LTA (Lane Tracing
Assist) system. (if equipped)

NOTICE
n Repairing or replacing snow tires
Request repairs or replacement of
snow tires from any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer or legitimate
tire retailers.
This is because the removal and
attachment of snow tires affects the
operation of the tire pressure warning
valves and transmitters.

air pressure.

Before driving the vehicle
Perform the following according to

5-5. Driving tips

the driving conditions:
 Do not try to forcibly open a window or move a wiper that is frozen. Pour warm water over the
frozen area to melt the ice. Wipe
away the water immediately to
prevent it from freezing.
 To ensure proper operation of
the climate control system fan,
remove any snow that has accumulated on the air inlet vents in
front of the windshield.
 Check for and remove any
excess ice or snow that may
have accumulated on the exterior lights, outside rear view mirrors, windows, vehicle’s roof,
chassis, around the tires or on
the brakes.

When driving the vehicle
Accelerate the vehicle slowly, keep
a safe distance between you and
the vehicle ahead, and drive at a
reduced speed suitable to road
conditions.

When parking the vehicle
 Turn automatic mode of the parking brake off. Otherwise, the
parking brake may freeze and
not be able to be released automatically.

Also, avoid using the following as the
parking brake may operate automatically, even if automatic mode is off.
• Brake hold system
• Remote parking function (if equipped)

 Park the vehicle and shift the
shift position to P without setting
the parking brake. The parking
brake may freeze up, preventing
it from being released. If the
vehicle is parked without setting
the parking brake, make sure to
block the wheels.
Failure to do so may be dangerous
because it may cause the vehicle to
move unexpectedly, possibly leading to
an accident.

 If the vehicle is parked without
setting the parking brake, confirm that the shift position cannot
be moved out of P.
 If the vehicle is left parked with
the brakes damp in cold temperatures, there is a possibility of
the brakes freezing.
WARNING
n When parking the vehicle
When parking the vehicle without
applying the parking brake, make
sure to chock the wheels. If you do
not chock the wheels, the vehicle may
move unexpectedly, possibly resulting
in an accident.

Selecting tire chains
Use the correct tire chain size when
mounting the tire chains.
Chain size is regulated for each tire
size.

5

Driving

 Remove any snow or mud from
the bottom of your shoes before
getting in the vehicle.

509

510

5-5. Driving tips

l Install tire chains on the front tires as
tightly as possible. Retighten chains
after driving 0.51.0 km (1/41/2
mile).

l Install tire chains following the instructions provided with the tire chains.

NOTICE

A Side chain (3 mm [0.12 in.] in
diameter)
B Side chain (10 mm [0.39 in.] in
width)
C Side chain (30 mm [1.18 in.] in
length)

Cross chain (4 mm [0.16 in.] in
diameter)
Cross chain (14 mm [0.55 in.] in
width)
Cross chain (25 mm [0.98 in.] in
length)

Regulations on the use of
tire chains
Regulations regarding the use of
tire chains vary depending on location and type of road. Always check
local regulations before installing
chains.
n Tire chain installation
Observe the following precautions when
installing and removing chains:
l Install and remove tire chains in a safe
location.

l Install tire chains on the front tires

only. Do not install tire chains on the
rear tires.

n Fitting tire chains
The tire pressure warning valves and
transmitters may not function correctly when tire chains are fitted.

5-5. Driving tips

Utility vehicle precautions
This vehicle belongs to the
utility vehicle class, which has
higher ground clearance and
narrower tread in relation to
the height of its center of gravity.

Utility vehicle feature

 An advantage of the higher
ground clearance is a better view
of the road allowing you to anticipate problems.
 It is not designed for cornering at
the same speeds as ordinary
passenger cars any more than
low-slung sports cars designed
to perform satisfactorily under
off-road conditions. Therefore,
sharp turns at excessive speeds
may cause rollover.

WARNING
n Utility vehicle precautions
Always observe the following precautions to minimize the risk of death or
serious injury or damage to your vehicle:
l In a rollover crash, an unbelted person is significantly more likely to die
than a person wearing a seat belt.
Therefore, the driver and all passengers should always fasten their
seat belts.

l Avoid sharp turns or abrupt maneuvers, if at all possible.
Failure to operate this vehicle correctly may result in loss of control or
vehicle rollover causing death or
serious injury.

l Loading cargo on the roof luggage

carrier will make the center of the
vehicle gravity higher. Avoid high
speeds, sudden starts, sharp turns,
sudden braking or abrupt maneuvers, otherwise it may result in loss
of control or vehicle rollover due to
failure to operate this vehicle correctly.

l Always slow down in gusty cross-

winds. Because of its profile and
higher center of gravity, your vehicle is more sensitive to side winds
than an ordinary passenger car.
Slowing down will allow you to have
better control.

l Do not drive horizontally across

steep slopes. Driving straight up or
straight down is preferred. Your
vehicle (or any similar off-road vehicle) can tip over sideways much
more easily than forward or backward.

Off-road driving
Your vehicle is not designed to be
driven off-road. However, in the

5

Driving

 Specific design characteristics
give it a higher center of gravity
than ordinary passenger cars.
This vehicle design feature
causes this type of vehicle to be
more likely to rollover. And, Utility
vehicles have a significantly
higher rollover rate than other
types of vehicles.

511

512

5-5. Driving tips

event that off-road driving cannot
be avoided, please observe the following precautions to help avoid
the areas prohibited to vehicles.
 Drive your vehicle only in areas
where off-road vehicles are permitted to travel.
 Respect private property. Get
owner’s permission before entering private property.
 Do not enter areas that are
closed. Honor gates, barriers
and signs that restrict travel.
 Stay on established roads. When
conditions are wet, driving techniques should be changed or
travel delayed to prevent damage to roads.
WARNING
n Off-road driving precautions
Always observe the following precautions to minimize the risk of death or
serious injury or damage to your vehicle:

l Drive carefully when off the road.

Do not take unnecessary risks by
driving in dangerous places.

l Do not grip the steering wheel

spokes when driving off-road. A
bad bump could jerk the wheel and
injure your hands. Keep both hands
and especially your thumbs on the
outside of the rim.

l Always check your brakes for effectiveness immediately after driving in
sand, mud, water or snow.

l After driving through tall grass,

mud, rock, sand, water, etc., check
that there is no grass, bush, paper,
rags, stone, sand, etc. adhering or
trapped to the underbody. Clear off
any such matter from the underbody. If the vehicle is used with
these materials trapped or adhering
to the underbody, a breakdown or
fire could occur.

l When driving off-road or in rugged

terrain, do not drive at excessive
speeds, jump, make sharp turns,
strike objects, etc. This may cause
loss of control or vehicle rollover
causing death or serious injury. You
are also risking expensive damage
to your vehicle’s suspension and
chassis.

NOTICE
n To prevent water damage
Take all necessary safety measures
to ensure that water damage to the
traction battery, EV system or other
components does not occur.
l Water entering the motor compart-

ment may cause severe damage to
the EV system.

l Water entering the transmission will

cause deterioration in transmission
quality. The vehicle may not be drivable.

l Water can wash the grease from

wheel bearings, causing rusting
and premature failure, and may
also enter the transmission case,
reducing the gear oil’s lubricating
qualities.

n When you drive through water
If driving through water, such as when
crossing shallow streams, first check
the depth of the water and the bottom
of the riverbed for firmness. Drive
slowly and avoid deep water.

5-5. Driving tips

513

NOTICE
n Inspection after off-road driving
l Sand and mud that has accumu-

lated around brake discs may affect
braking efficiency and may damage
brake system components.

l Always perform a maintenance

inspection after each day of off-road
driving that has taken you through
rough terrain, sand, mud, or water.

5

Driving

514

5-5. Driving tips

515

Interior features

6

6-1. Using the air conditioning
system and defogger
.

ALL AUTO (ECO) control
.......................................516
Automatic air conditioning system .................................518
Heated steering wheel/seat
heaters/seat ventilators/radiant heaters .....................525
6-2. Using the interior lights
Interior lights list................528
6-3. Using the storage features
List of storage features .....531
Luggage compartment features
.......................................534
6-4. Using the other interior features

6

Electronic sunshade .........540
Power outlets (220 VAC 1500
W) ...................................553
When the power outlet (AC
220V/1500 W) cannot be
used properly..................560

Interior features

Other interior features.......541
