# 8-2. Steps to take in an emergency (part 2: If you have a flat tire (vehicles with a spare tire), …)

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 8: When trouble arises, pages 645–667
> Topics in this part: If you have a flat tire (vehicles with a spare tire); If the EV system will not start; If the charging port lids cannot be opened; If you lose your keys; If the electronic key does not operate properly; If the 12-volt battery is discharged; If your vehicle overheats; If the vehicle becomes stuck

8-2. Steps to take in an emergency

645

l Do not disassemble or modify the

If you have a flat tire
(vehicles with a spare
tire)

n To avoid damage to the tire pres-

Your vehicle is equipped with a
spare tire. The flat tire can be
replaced with the spare tire.

NOTICE
repair kit. Do not subject parts such
as the air pressure indicator to
impacts. This may cause a malfunction.

sure warning valves and transmitters
When a tire is repaired with liquid
sealants, the tire pressure warning
valve and transmitter may not operate
properly. If a liquid sealant is used,
contact any authorized Toyota retailer
or Toyota authorized repairer, or any
reliable repairer or other qualified service shop as soon as possible. After
use of liquid sealant, make sure to
replace the tire pressure warning
valve and transmitter when repairing
or replacing the tire. (P.592)

WARNING
n If you have a flat tire
Do not continue driving with a flat tire.
Driving even a short distance with a
flat tire can damage the tire and the
wheel beyond repair, which could
result in an accident.

Before jacking up the vehicle
 Stop the vehicle in a safe place
on a hard, flat surface.
 Set the parking brake.
 Shift the shift position to P.
 Turn off the intrusion sensor and
tilt sensor (if equipped) (P.86)
 Stop the EV system.
 Turn on the emergency flashers.

8

When trouble arises

 Turn off the power back door
system. (P.190)

646

8-2. Steps to take in an emergency

Location of the spare tire, jack and tools

A Jack handle
B Towing eyelet
C Jack

Wheel nut wrench
Spare tire
WARNING
n Using the tire jack
Observe the following precautions.
Improper use of the tire jack may
cause the vehicle to suddenly fall off
the jack, leading to death or serious
injury.

l Do not use the tire jack for any purpose other than replacing tires or
installing and removing tire chains.

l Only use the tire jack that comes

with this vehicle for replacing a flat
tire.
Do not use it on other vehicles, and
do not use other tire jacks for
replacing tires on this vehicle.

l Put the jack properly in its jack
point.

l Do not put any part of your body
under the vehicle while it is supported by the jack.

l Do not start the EV system or drivethe vehicle while the vehicle is
supportedby the jack.

8-2. Steps to take in an emergency

WARNING

647

2 Take out the jack.

l Do not raise the vehicle while
someone is inside.

l When raising the vehicle, do not put
an object on or under the jack.

l Do not raise the vehicle to a height
greater than that required to
replace the tire.

l Use a jack stand if it is necessary to
get under the vehicle.

l When lowering the vehicle, make

sure that there is no-one near the
vehicle. If there are people nearby,
warn them vocally before lowering.

Taking out the spare tire
1 Remove the spare tire cover.

n Replacing a flat tire for vehicles

with power back door
In cases such as when replacing tires,
make sure to canceling the power
back door system (P.190). Failure
to do so may cause the back door to
operate unintentionally if the power
back door switch is accidentally
touched, resulting in hands and fingers being caught and injured.

Taking out the jack

2 Loosen the center fastener that
secures the spare tire.

1 Open the deck board.
8

n When storing the spare tire
Be careful not to catch fingers or
other body parts between the spare
tire and the body of the vehicle.

When trouble arises

WARNING

648

8-2. Steps to take in an emergency

Replacing a flat tire

wheel ornament.

1 Chock the tires.

3 Slightly loosen the wheel nuts
(one turn).
Flat tire

Wheel chock positions

Front left-hand
side

Behind the rear
right-hand side tire

Front right-hand
side

Behind the rear
left-hand side tire

Rear left-hand side

In front of the front
right-hand side tire

Rear right-hand
side

In front of the front
left-hand side tire

2 Vehicles with 20-inch tires: Do
not remove the wheel ornament.
Vehicles with 18-inch tires:
Remove the wheel ornament
using the wrench.
To protect the wheel ornament, place
arag between the wrench and the

4 Turn the A part of the jack by
hand and place the top of the
jack in the position shown in the
illustration.

8-2. Steps to take in an emergency
 Front

649

5 Install the wheel nut wrench in
jack handle.

6 Raise the vehicle until the tire is
slightly raised off the ground.

 Rear

7 Remove all the wheel nuts and
the tire.
When resting the tire on the ground,
place the tire so that the wheel design
faces up to avoid scratching the wheel
surface.

8

When trouble arises

650

8-2. Steps to take in an emergency

WARNING
n Replacing a flat tire
l Do not touch the disc wheels or the

area around the brakes immediately after the vehicle has been
driven.
After the vehicle has been driven
the disc wheels and the area
around the brakes will be extremely
hot. Touching these areas with
hands, feet or other body parts
while changing a tire, etc. may
result in burns.

l Failure to follow these precautions

could cause the wheel nuts to
loosen and the tire to fall off, resulting in death or serious injury.
• Never use oil or grease on the
wheel bolts or wheel nuts.Oil and
grease may cause the wheel nuts
to be excessively tightened,leading
to bolt or disc wheel damage.
Remove any oil or grease that has
adhered when installing the wheel
nuts.

• When installing the wheel nuts,
besure to install them with the
taperedends facing inward.
(P.650)
l In cases such as when replacing
tires, make sure to turn off the
power back door system (P.190).
Failure to do so may cause the back
door to operate unintentionally if the
power back door switch is accidentally touched, resulting in hands and
fingers being caught and injured.

Installing the spare tire
1 Remove any dirt or foreign matter from the wheel contact surface.
If foreign matter is on the wheel contact
surface, the wheel bolts may loosen
while the vehicle is in motion, causing
the tire to come off.

• After replacing a tire, check the
tightening torque as soon as possible.
Wheel nut torque: 103 N•m (10.5
kgf•m, 76 ft•lbf)
• Do not attach a heavily damaged
wheel ornament, as it may fly off the
wheel while the vehicle is moving.
• When installing a tire, only use
wheel nuts that have been specifically designed for that wheel.
• If there are any cracks or deformations in the bolt screws, nut threads
or bolt holes of the wheel, have the
vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

2 Install the tire and loosely
tighten each wheel nut by hand
by approximately the same
amount.
When replacing an aluminum wheel
with a steel wheel, tighten the wheel
nuts until the tapered portion A comes
into loose contact with the disc wheel

8-2. Steps to take in an emergency
seat

.

When replacing an aluminum wheel
with a aluminum wheel, tighten turn the
wheel A nuts until the washers come
into contact with the disc wheel
.

651

103 N•m (10.5 kgf•m, 76 ft•lbf)

5 Stow the flat tire, jack and all
tools.
n The compact spare tire (if
equipped)

l The compact spare tire is identified by
the label “TEMPORARY USE ONLY”
on the tire sidewall. Use the compact
spare tire temporarily, and only in an
emergency.

l Make sure to check the tire inflation
pressure of the compact spare tire.
(P.673)

n When the compact spare tire (if

3 Lower the vehicle.

equipped) is equipped
The vehicle becomes lower when driving with the spare tire compared to when
driving with standard tires.

n When using the compact spare tire

Tightening torque:

n If you have a flat front tire on a road

covered with snow or ice
Install the spare tire on one of the rear
wheels of the vehicle. Perform the following steps and fit tire chains to the
front tires:

8

When trouble arises

4 Securely tighten the wheel nuts
two or three times in the order
shown in the illustration using a
wheel nut wrench.

(if equipped)
As the spare tire is not equipped with a
tire pressure warning valve and transmitter, low inflation pressure of the spare
tire will not be indicated by the tire pressure warning system. Also, if you
replace the spare tire after the tire pressure warning light comes on, the light
remains on.

652

8-2. Steps to take in an emergency

1 Replace a rear tire with the compact
spare tire.
2 Replace the flat front tire with the tire
removed from the rear of the vehicle.
3 Fit tire chains to the front tires.

n Vehicles with 18-inch tires: When

reinstalling the wheel ornament
Align the cutout of the wheel ornament
with the valve stem as shown in the
illustration.

• AHB (Automatic High Beam) (if
equipped)
• Dynamic radar cruise control (if
equipped)
• Cruise control (vehicles without
Toyota Safety Sense)
• EPS
• PCS (Pre-Collision System)
• LTA (Lane Tracing Assist) (if
equipped)
• LDA (Lane Departure Alert) (if
equipped)
• Tire pressure warning system
• Toyota parking assist-sensor

WARNING
n When using the compact spare-

tire (if equipped)
l Remember that the compact spare
tire provided is specificallyd
esigned for use with your vehicle.
Do not use your compact spare tire
on another vehicle.

l Do not use more than one compact
spare tires simultaneously.

l Replace the compact spare tire with

a standard tire as soon as possible.

l Avoid sudden acceleration, abrupt

steering, sudden braking and shifting operations that cause sudden
regenerative braking.

n When the compact spare tire (if

equipped) is attached
The vehicle speed may not be correctly detected, and the following systems may not operate correctly:
• ABS & Brake assist
• VSC
• TRC (Traction Control)

• PKSB (Parking Support Brake) (if
equipped)
• BSM (Blind Spot Monitor) (if
equipped)
• Safe Exit Assist (if equipped)
• RCTA (Rear Crossing Traffic Alert)
(if equipped)
• Toyota Teammate Advanced Park
(if equipped)
• Navigation system

n Speed limit when using the com-

pact spare tire (if equipped)
Do not drive at speeds in excess of
80km/h (50 mph) when a compact
spare tire is installed on the vehicle.
The compact spare tire is not
designed for driving at high speeds.
Failure to observe this precaution
may lead to an accident causing
death or serious injury.

8-2. Steps to take in an emergency

WARNING
n After using the tools and jack
Before driving, make sure all the tools
and jack are securely in place in their
storage location to reduce the possibility of personal injury during a collision or sudden braking.

NOTICE
n Be careful when driving over

bumps with the compact spare
tire (if equipped) installed on the
vehicle.
The vehicle becomes lower when
driving with the compact spare tire
compared to when driving with standard tires. Be careful when driving over
uneven road surfaces.

n Driving with tire chains and the

compact spare tire (if equipped)
Do not fit tire chains to the compact
spare tire.
Tire chains may damage the vehicle
body and adversely affect driving performance.

If the EV system will not
start
Reasons for the EV system not
starting vary depending on the
situation. Check the following
and perform the appropriate
procedure:
Contact any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable
repairer if the problem cannot
be repaired, or if repair procedures are unknown.

The EV system will not start
even though the correct
starting procedure is being
followed. (P.243)
One of the following may be the
cause of the problem:
 The charging cable may be connected to the vehicle. (P.112)
 The electronic key may not be
functioning properly.* (P.656)
 The traction battery may be completely discharged. Charge the
traction battery. (P.108)
 There may be a malfunction in
the immobilizer system.* (P.83)
 There may be a malfunction in
the shift control system.*
(P.245, 633)
 Right-hand drive vehicles only:
There may be a malfunction in

8

When trouble arises

n When replacing the tires
When removing or fitting the wheels,
tires or the tire pressure warning
valve and transmitter, contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer as the tire pressure warning
valve and transmitter may be damaged if not handled correctly.

653

654

8-2. Steps to take in an emergency

the steering lock system.
 The EV system may be malfunctioning due to an electrical problem such as electronic key
battery depletion or a blown fuse.
However, depending on the type
of malfunction, an interim measure is available to start the EV
system. (P.654)
 There is a possibility that the
temperature of the traction battery is extremely low (approximately below -30°C [-22°F]).
(P.95, 244)
*: It may not be possible to shift the shift

position from P.

The interior lights and headlights are dim, or the horn
does not sound or sounds at
a low volume.
One of the following may be the
cause of the problem:
 The 12-volt battery may be discharged. (P.658)
 The 12-volt battery terminal connections may be loose or corroded. (P.585)

The interior lights and headlights do not turn on, or the
horn does not sound.
One of the following may be the
cause of the problem:
 One or both of the 12-volt battery
terminals may be disconnected.

(P.585)
 The 12-volt battery may be discharged. (P.658)
Contact any authorized Toyota retailer
or Toyota authorized repairer, or any
reliable repairer if the problem cannot
be repaired, or if repair procedures are
unknown.

Emergency start function
When the EV system does not
start, the following steps can be
used as an interim measure to start
the EV system if the power switch
is functioning normally.
Do not use this starting procedure
except in cases of emergency.
1 Set the parking brake.
2 Turn the power switch to
ACC.*1, 2
3 Press and hold the power switch
for about 15 seconds while
depressing the brake pedal
firmly.
Even if the EV system can be
started using the above steps, the
system may be malfunctioning.
Have the vehicle inspected by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
*1: ACC mode can be enabled/disabled

on the customize menu. (P.680)
*2: When ACC is disabled, turn the

power switch to ON then OFF, and
perform the following step within 5
seconds.

8-2. Steps to take in an emergency

If you lose your keys
New genuine keys can be
made by any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable
repairer using another key and
the key number stamped on
your key number plate.
Keep the plate in a safe place
such as your wallet, not in the
vehicle.
NOTICE
n When an electronic key is lost
If the electronic key remains lost, the
risk of vehicle theft increases significantly. Visit any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer immediately
with all remaining electronic keys that
were provided with your vehicle.

655

If the charging port lids
cannot be opened
If the charging port lids cannot
be opened when using the normal procedure, the following
procedure can be used to open
the charging port lids.

Opening the charging port
lids
1 Open the hood.
2 Pull the ring section of the emergency release lever and
remove.
3 Pull on the ring part until the
mark on the belt B is in the
position shown in the figure.
Pull the ring horizontally toward the
inside of the vehicle.
After the unlocking operation is completed, push the ring part back to its
original position until it clicks into place.

8

When trouble arises

A Emergency release lever

656

8-2. Steps to take in an emergency

n When unlocking with the emer-

gency release lever
Be sure to observe the following.

If the electronic key
does not operate properly

l Do not apply excessive force to the
ring part

l Do not pull horizontally too much
l If the belt is twisted and difficult to

return, push the belt section back into
its original position.
Use only in an emergency.
If the problem persists, have the vehicle
inspected by any authorized Toyota
retailer or Toyota authorized repairer, or
any reliable repairer immediately if this
occurs.

If communication between the
electronic key and vehicle is
interrupted (P.192) or the
electronic key cannot be used
because the battery is
depleted, the smart entry &
start system and wireless
remote control cannot be used.
In such cases, the doors can
be opened and the EV system
can be started by following the
procedure below.
n When the electronic key does not
work properly

l Make sure that the smart entry & start
system has not been deactivated in
the customization setting. If it is off,
turn the function on.

l Check if battery-saving mode is set. If

it is set, cancel the function. (P.192)

l The electronic key function may be
stopped. (P.192)

NOTICE
n In case of a smart entry & start

system malfunction or other
key-related problems
Take your vehicle with all the electronic keys provided with your vehicle,
to any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.

Locking and unlocking the
doors
Use the mechanical key (P.170)

8-2. Steps to take in an emergency

in order to perform the following
operations.

1 Locks all the doors
2 Unlocks the door
n Key linked functions

657

WARNING
n When using the mechanical key
and operating the power windows
Operate the power window after
checking to make sure that there is no
possibility of any passenger having
any of their body parts caught in the
window.
Also, do not allow children to operate
the mechanical key. It is possible for
children and other passengers to get
caught in the power window.

Starting the EV system
1 Depress the brake pedal.
2 Touch the electronic key to the
power switch.

1 Closes the windows (turn and hold)
2 Opens the windows (turn and hold)

When the electronic key is detected, a
buzzer sounds and the power switch
will turn to ON.
When the smart entry & start system is
deactivated in customization setting
and ACC customization is in on, the
power switch will turn to ACC.

These settings must be customized at
any authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
8

and check that
is shown
on the multi-information display.
4 Press the power switch shortly
and firmly.
In the event that the EV system still
cannot be started, contact any author-

When trouble arises

3 Firmly depress the brake pedal

658

8-2. Steps to take in an emergency

ized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

If the 12-volt battery is
discharged

n Stopping the EV system
Set the parking brake, shift the shift
position to P and press the power switch
as you normally do when stopping the
EV system.

n Replacing the key battery
As the above procedure is a temporary
measure, it is recommended that the
electronic key battery be replaced
immediately when the battery is
depleted. (P.604)
n Alarm (if equipped)
Using the mechanical key to lock the
doors will not set the alarm system.
If a door is unlocked using the mechanical key when the alarm system is set,
the alarm may be triggered. (P.85)
n Changing power switch modes
Release the brake pedal and press the
power switch in step 3 above.
The EV system does not start and
modes will be changed each time the
switch is pressed. (P.246)

The following procedures may
be used to start the EV system
if the vehicle’s 12-volt battery
is discharged.
You can also call any authorized Toyota retailer or Toyota
authorized repairer, or any reliable repairer.

8-2. Steps to take in an emergency

Restarting the EV system
If you have a set of jumper (or
booster) cables and a second vehicle with a 12-volt battery, you can
jump start your vehicle by following
the steps below.

659

2 Open the hood. (P.580)
3 Open the positive (+) battery terminal cover.
While pressing on the claw, open thecover as shown in the illustration.

1 Confirm that the electronic key
is being carried.
When connecting the jumper (or
booster) cables, depending on the situation, the alarm may activate and doors
locked. (P.86)

4 Connect a positive jumper cable clamp to A on your vehicle and connect the clamp on the other end of the positive cable to B on the second vehicle. Then, connect a negative cable clamp to C on the second
vehicle and connect the clamp at the other end of the negative cable to
D.
Use jumper cables that can reach the specified terminals and connect-

8

When trouble arises

660

8-2. Steps to take in an emergency

ing point.

A Positive (+) battery terminal (your vehicle)
B Positive (+) battery terminal (second vehicle)
C Negative (-) battery terminal (second vehicle)

Metallic point shown in the illustration
5 Start the engine of the second
vehicle. Increase the engine
speed slightly and maintain at
that level for approximately 5
minutes to recharge the battery
of your vehicle.
6 Open and close any of the doors
of your vehicle with the power
switch off.
7 Maintain the engine speed of
the second vehicle and start the
EV system of your vehicle by
turning the power switch to ON.
8 Make sure the “READY” indicator comes on. If the indicator
light does not come on, contact
any authorized Toyota retailer or

Toyota authorized repairer, or
any reliable repairer.
9 Once the EV system has
started, remove the jumper
cables in the exact reverse
order from which they were connected.
10Close the positive (+) battery
terminal cover.
Once the EV system starts, have
the vehicle inspected at any authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer as soon as possible.
n Starting the EV system when the

12-volt battery is discharged
The EV system cannot be started by
push-starting.

8-2. Steps to take in an emergency

n To prevent 12-volt battery discharge

l Turn off the headlights, the air condi-

tioning system, the audio system, etc.
while the EV system is off.

l Turn off any unnecessary electrical

components when the vehicle is running at a low speed for an extended
period, such as in heavy traffic.

l When ACC customization is in off,

power is still provided to the multimedia system even though the power
switch is off. To turn off the multimedia
system, use the multimedia system
power switch. Ford etails, refer to the
“Multimedia Owner’s Manual”.

n Charging the 12-volt battery
The electricity stored in the 12-volt battery will discharge gradually even when
the vehicle is not in use, due to natural
discharge and the draining effects of
certain electrical appliances. If the vehicle is left for a long time, the 12-volt battery may discharge, and the EV system
may be unable to start. (The 12-volt battery recharges automatically while the
EV system is operating.)

n When the 12-volt battery is
removed or discharged

l Information stored in the ECU is

cleared. When the 12-volt battery is
depleted, have the vehicle inspected
at any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.
to unlock the doors using the smart
entry & start system when the 12-volt
battery is discharged. Use the wireless remote control or the mechanical
key to lock or unlock the doors.

l The EV system may not start on the

first attempt after the 12-volt battery
has recharged but will start normally
after the second attempt. This is not a
malfunction.

l The power switch mode is memorized
by the vehicle. When the 12-volt battery is reconnected, the system will

return to the mode it was in before the
12-volt battery was discharged.
Before disconnecting the 12-volt battery, turn the power switch off. If you
are unsure what mode the power
switch was in before the 12-volt battery discharged, be especially careful
when reconnecting the 12-volt battery.

l If the 12-volt battery discharges, it

may not be possible to shift the shift
position to other positions. In this
case, the vehicle cannot be towed
without lifting both front wheels
because the front wheels will be
locked.

l The power back door must be initialized. (P.186)

n When replacing the 12-volt battery
l Use a 12-volt battery that conforms to
European regulations.

l Use a 12-volt battery that the case

size is same as the previous one
(LN1), 20 hour rate capacity (20HR) is
equivalent (45Ah) or greater, and performance rating (CCA) is equivalent
(286A) or greater.
• If the sizes differ, the 12-volt battery
cannot be properly secured.
• If an improper 12-volt battery is used,
battery performance may decreaseand the EV system may not be able to
restart.
• If the 20 hour rate capacity is low,
even if the time period where the vehicle is not used is a short time, the
12-volt battery may discharge and the
EV system may not be able to start.
For details, consult any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer as soon
as possible.

8

When trouble arises

l In some cases, it may not be possible

661

662

8-2. Steps to take in an emergency

WARNING
n When removing the 12-volt bat-

tery terminals
Always remove the negative (-) terminal first. If the positive (+) terminal
contacts any metal in the surrounding
area when the positive (+) terminal is
removed, a spark may occur, leading
to a fire in addition to electrical shocks
and death or serious injury.

n Avoiding 12-volt battery fires or

explosions
Observe the following precautions to
prevent accidentally igniting the flammable gas that may be emitted from
the 12-volt battery:
l Make sure each jumper cable is
connected to the correct terminal
and that it is not unintentionally in
contact with any other than the
intended terminal.

l Do not allow the other end of the

jumper cable connected to the “+”
terminal to come into contact with
any other parts or metal surfaces in
the area, such as brackets or
unpainted metal.

l Do not lean over the 12-volt battery.
l In the event that battery fluid (acid)

comes in to contact with the skin or
eyes, immediately wash the
affected area with water and seek
medical attention.
Place a wet sponge or cloth over
the affected area until medical
attention can be received.

l Always wash your hands after handling the 12-volt battery support,
terminals, and other battery-related
parts.

l Do not allow children near the
12-volt battery.

n When replacing the 12-volt battery

l When the vent plug and indicator

are close to the hold down clamp,
the battery fluid (sulfuric acid) may
leak.

l For information regarding 12-volt

battery replacement, contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

l Do not allow the + and - clamps of

the jumper cables to come into contact with each other.

l Do not smoke, use matches, cigarette lighters or allow open flame
near the 12-volt battery.

n 12-volt battery precautions
The 12-volt battery contains poisonous and corrosive acidic electrolyte,
while related parts contain lead and
lead compounds. Observe the following precautions when handling the
12-volt battery:
l When working with the 12-volt battery, always wear safety glasses
and take care not to allow any battery fluids (acid) to come into contact with skin, clothing or the vehicle
body.

NOTICE
n When handling jumper cables
When connecting the jumper cables,
ensure that they do not become
entangled in the cooling fan.
n When connecting jumper cables
Make sure to connect jumper cables
to the specified terminals and connecting point. Failure to do so may
adversely affect the electronic
devices or damage to them.

8-2. Steps to take in an emergency

If your vehicle overheats
When “EV system overheated
Output power reduced” is
shown on the multi-information display, your vehicle may
be overheating.
NOTICE
n Cooling system coolant
The radiator coolant is exclusive for
radiator usage. Damage may occur
when water or any other type of coolant is used, so never use any other
fluid. When there is no “Toyota Genuine Traction Battery Coolant”, immediately contact any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer.

663

sage does not disappear, call
any authorized Toyota retailer or
Toyota authorized repairer, or
any reliable repairer.
If the fan is not operating:
Stop the EV system immediately
and call any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.
4 After the EV system has cooled
down, inspect the hoses and
radiator core (radiator) for any
leaks.

A Radiator
B Cooling fan

Correction procedures

2 Leave the EV system operating
and carefully lift the hood.
3 Check if the cooling fan is operating.
If the fan is operating:
Wait until the “EV system overheated Output power reduced”
message disappears and then
stop the EV system. If the mes-

8

When trouble arises

1 Stop the vehicle in a safe place
and turn off the air conditioning
system.

If a large amount of coolant leaks,
immediately contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

664

8-2. Steps to take in an emergency

5 The coolant level is satisfactory
if it is between the “MAX” and
“MIN” lines on the reservoir.

WARNING
n To prevent an accident or injury

when inspecting under the hood
of your vehicle
Observe the following precautions.
Failure to do so may result in serious
injury such as burns.
l If steam is seen coming from under
the hood, do not open the hood
until the steam has subsided. The
motor compartment may be very
hot.

l Keep hands and clothing (espe-

A Reservoir
B “MAX” line
C “MIN” line

6 If the coolant is insufficient,
replenish with “Toyota Genuine
Traction Battery Coolant”.
If you don’t have “Toyota Genuine Traction Battery Coolant”, contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

cially a tie, a scarf or a muffler)
away from the fan. Failure to do so
may cause the hands or clothing to
be caught, resulting in serious
injury.

l Do not loosen the coolant reservoir

cap while the EV system and radiator are hot. High temperature steam
or coolant could spray out.

NOTICE
n When adding coolant
Add coolant slowly after the EV system has cooled down sufficiently.
Adding cool coolant to a hot EV system too quickly can cause damage to
the EV system.
n To prevent damage to the cooling

1 Remove the bolt and cover.
2 Open the reservoir cap.
Have the vehicle inspected at the
nearest authorized Toyota retailer
or Toyota authorized repairer, or
any reliable repairer as soon as
possible.

system
Observe the following precautions:
l Avoid contaminating the coolant
with foreign matter (such as sand or
dust, etc.).

l Do not use water or any other coolant when refilling coolant. Also, do
not use any additive agents for the
coolant.

8-2. Steps to take in an emergency

If the vehicle becomes
stuck
Carry out the following procedures if the tires spin or the
vehicle becomes stuck in mud,
dirt or snow:

Recovering procedure
1 Stop the EV system. Set theparking brake and shift the shiftposition to P.
2 Remove the mud, snow or sand
from around the front wheels.
3 Place wood, stones or some
other material under the front
wheels to help provide traction.
4 Restart the EV system.
5 Shift the shift position to D or R
and release the parking brake.
Then, while exercising caution,
depress the accelerator pedal.

665

WARNING
n When attempting to free a stuck

vehicle
If you choose to push the vehicle
back and forth to free it, make sure
the surrounding area is clear to avoid
striking other vehicles, objects or people. The vehicle may also lunge forward or lunge back suddenly as it
becomes free. Use extreme caution.

n When shifting the shift position
Be careful not to shift the shift position
with the accelerator pedal depressed.
This may lead to unexpected rapid
acceleration of the vehicle that may
cause an accident resulting in death
or serious injury.

NOTICE
n To avoid damage to the transmission and other components
l Avoid spinning the front wheels and
depressing the accelerator pedal
more than necessary.

l If the vehicle remains stuck even
after these procedures are performed, the vehicle may require
towing to be freed.

n When it is difficult to free the vehicle

Press

8
to turn off TRC.

When trouble arises

666

8-2. Steps to take in an emergency

667

Vehicle specifications

9

9-1. Specifications
.

Maintenance data .............668
9-2. Customization
Customizable features ......675
9-3. Initialization
Items to initialize ...............690
9-4. Free/open source software
Free/open source software
information......................691

9

Vehicle specifications
