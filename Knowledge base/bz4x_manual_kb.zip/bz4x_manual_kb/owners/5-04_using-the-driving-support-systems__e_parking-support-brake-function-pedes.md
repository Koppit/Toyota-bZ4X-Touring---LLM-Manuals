# 5-4. Using the driving support systems (part 5: Parking Support Brake function (pedestrians rear of the vehicle), …)

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 394–432
> Topics in this part: Parking Support Brake function (pedestrians rear of the vehicle); Toyota Teammate Advanced Park

394

5-4. Using the driving support systems

• The collision becomes avoidable with
normal brake operation.
• A vehicle is no longer approaching
from the right or left at the rear of the
vehicle.

l Brake control
• The Parking Support Brake is disabled.
• Approximately 2 seconds have
elapsed since the vehicle was
stopped by brake control.
• The brake pedal is depressed after
the vehicle is stopped by brake control.
n Situations in which the system may

not operate properly
P.378

n Situations in which the system may

operate even if there is no possibility of a collision
P.379

Parking Support Brake
function (pedestrians
rear of the vehicle)*
*: If equipped

If the rear camera sensor
detects a pedestrian behind
the vehicle while backing up
and the system determines
that the possibility of colliding
with the detected pedestrian is
high, a buzzer will sound. If the
system determines that the
possibility of colliding with the
detected pedestrian is
extremely high, the brakes will
be applied automatically to
help reduce the impact of the
collision.

Examples of system operation
The system operates when an
approaching pedestrian is detected
behind the vehicle while backing
up, and when the brake pedal is not
depressed or is depressed late.

5-4. Using the driving support systems

Screen display of pedestrians rear of the vehicle
Displays a message to prompt the
driver to brake when a pedestrian is
detected in the detection area
behind the vehicle.

395

• The Parking Support Brake is enabled.
• The vehicle speed is 15 km/h (9 mph)
or less.
• The shift position is in R.
• When a pedestrian is to the rear of the
vehicle
• The PKSB (Parking Support Brake)
determines that a stronger-than-normal-brake operation is necessary to
avoid a collision.

l Brake control
• EV system output restriction control is
operating.
• The Parking Support Brake determines that an emergency brake operation is necessary to avoid a collision
with a pedestrian.
n The Parking Support Brake func-

A Pedestrian detection icon
B Example: “BRAKE!”

WARNING
function (pedestrians rear of the
vehicle) operates unnecessarily
Depress the brake pedal immediately
after the Parking Support Brake function (pedestrians rear of the vehicle)
operates. (Operation of the function is
canceled by depressing the brake
pedal.)

n Correct use of the Parking Sup-

port Brake function (pedestrians
rear of the vehicle)
P.380

n The Parking Support Brake func-

tion (pedestrians rear of the vehicle) will operate when
The function will operate when the driving assist information indicator is not illuminated (P.152) and all of the
following conditions are met:

l EV system output restriction control

l EV system output restriction control
• The Parking Support Brake is disabled.
• The collision becomes avoidable with
normal brake operation.
• The pedestrian is no longer detected
behind your vehicle.
l Brake control
• The Parking Support Brake is disabled.
• Approximately 2 seconds have
elapsed since the vehicle was
stopped by brake control.
• The brake pedal is depressed after
the vehicle is stopped by brake control.
n Re-enabling the Parking Support

Brake function (pedestrians rear of
the vehicle)
P.388

n Detection area of the Parking Sup-

port Brake function (pedestrians
rear of the vehicle)
The detection area of the Parking Support Brake function (pedestrians rear of
the vehicle) differs from the detection

5

Driving

n If the Parking Support Brake

tion (pedestrians rear of the vehicle) will stop operating when
The function will stop operating if any of
the following conditions are met:

396

5-4. Using the driving support systems

area of the RCD function (P.381).
Therefore, even if the RCD function
detects a pedestrian and provides an
alert, the Parking Support Brake function (pedestrians rear of the vehicle)
may not start operating.

n Situations in which the system may

not operate properly
P.382

n Situations in which the system may

operate unexpectedly
P.383

Toyota Teammate
Advanced Park*
*: If equipped

Function description
The Advanced Park is a system
which assists in a safe and smooth
parking or exiting from a parking
space by displaying the blind spots
around the vehicle and the target
parking spot through a bird’s eye
view, delivering operation guidance
through displays and buzzer operation, and changing the shift position, operating the steering wheel,
accelerator pedal, and brake pedal.
Additionally, the panoramic view
monitor* can display the area in
front, behind, and from above the
vehicle, helping confirm the condition of the area around the vehicle.
The turn signal lights will blink automatically when the parking assistance starts until the vehicle
reaches the target parking spot, to
notify people around the vehicle
that parking is being performed.
Depending on the condition of the
road surface or the vehicle, the distance between the vehicle and a
parking space, etc., it may not be
possible to assist in parking in the
target space.
Only use Advanced Park in accordance with all local road traffic laws
and regulations.

5-4. Using the driving support systems
*: For details on the panoramic view

monitor refer to “Multimedia owner’s
manual”.

n Remote control function (if

equipped)
Remote control function is a system
which assists in parking or exiting
from a parking space selected on
the multimedia display by allowing
changing the shift position, operating the steering wheel, accelerator
pedal, and brake pedal from outside of the vehicle via a
smartphone.

Preparation before using: P.426

Functions
n Perpendicular parking (for-

ward/reverse) function
Assistance is provided from the
position the vehicle is stopped near
the target parking space until the
vehicle is in the parking space.
(P.408)
n Perpendicular exiting (for-

ward/reverse) function
Assistance is provided from the
parked position until the vehicle is
in a position where you can easily

exit from the parking space.
(P.411)
n Parallel parking function

Assistance is provided from the
position the vehicle is stopped near
the target parking space until the
vehicle is in the parking space.
(P.413)
n Parallel exiting function

Assistance is provided from the
parked position until the vehicle is
in a position where you can easily
exit from the parking space.
(P.416)
n Memory function

Assistance is provided until the
vehicle is guided into a previously
registered parking space. (P.418)
n Remote control function (if

equipped)
By operating a smartphone, assistance in parking or exiting from a
nearby target parking space, confirmed on the screen of the
smartphone, is provided from outside of the vehicle. (P.422)
n Trademarks
The Bluetooth® word mark and logos
are registered trademarks owned by
Bluetooth SIG, Inc. and any use of such
marks by Toyota Motor Corporation is
under license. Other trademarks and
trade names are those of their respective owners.

5

Driving

The turn signal lights will blink automatically when the parking assistance, except that for moving the
vehicle forward and backward,
starts until the vehicle reaches the
target parking spot, to notify people
around the vehicle that parking is
being performed.

397

398

5-4. Using the driving support systems

WARNING
n Cautions regarding the use of

Advanced Park, including
Remote control function
The recognition and control capabilities for this system are limited. The
driver should always drive safety by
always being responsible without over
relying on the system and have a
understanding of the surrounding situations.
l As with a normal vehicle, take care
to observe your surroundings while
the vehicle is moving.

l Always pay attention to the vehi-

cle’s surroundings while the system
is operating and depress the brake
pedal as necessary to slow or stop
the vehicle.
If Remote control function is in operation, stop operating the dedicated
smartphone app of Remote control
function (hereafter, dedicated app)
and stop the vehicle.

l When parking, make sure that the

vehicle can be parked in the target
parking space before beginning
operation.

l Depending on the condition of the

road surface or the vehicle, the distance between the vehicle and a
parking space, etc., it may not be
possible to detect a parking space
or the system may not be able to
provide assistance to the point the
vehicle is fully parked.

l This system will guide the vehicle to
appropriate positions for changing
the direction of travel, however, if
you feel that the vehicle is
approaching too close to an adjacent parked vehicle at any time,
depress the brake pedal and
change the shift position. However,
if this is performed, the number of
times the vehicle changes direction
may increase, and the vehicle may
be parked at an angle.

l As certain objects or materials,

such as the following, may not be
detected, make sure to check the
safety of the area around your vehicle and depress the brake pedal to
stop the vehicle if it may collide with
an object.
If Remote control function is in operation, stop operating the dedicated app
and stop the vehicle.
• Thin objects (wires, fences, ropes,
poles, etc.) or objects that appear
like thin from a certain angle of
approach (signs, bicycles, etc.)
• Materials that absorb sound waves
(cotton, snow, etc.)
• Sharp-edged objects (block
walls/columns, wall corners, etc.)
• Objects in lower places (curb
stones/blocks, stairs, parking
blocks, etc.)
• Tall objects with upper sections that
protrude outward (beams, etc.)
• Objects which are not perpendicular to the ground
• Objects to which the vehicle is
approaching diagonally

l Even if there is an object in the target parking space, it may not be
detected and assistance may be
performed.

5-4. Using the driving support systems

WARNING
l If it is likely that your vehicle will col-

lide with a nearby vehicle, object, or
person, or go over the top of a parking block, depress the brake pedal
to stop the vehicle and press the
Advanced Park main switch to disable the system.
If Remote control function is in operation, stop operating the dedicated app
and stop the vehicle.

l Never use only the multimedia dis-

play to view the area behind the
vehicle. The image displayed may
differ than the actual situation.
Using only the screen when backing up may lead to an accident,
such as a collision with another
vehicle. When backing up, make
sure to look directly or use the mirrors to check the safety of the area
around your vehicle, especially
behind the vehicle.

l When the ambient temperature is

l In the following situations, while the

vehicle is stopped and held by
Advanced Park, it may be canceled
and the vehicle may start moving.
Immediately depress the brake
pedal. Failure to do so may lead to
an accident.
If Remote control function is in operation, stop operating the dedicated app
and stop the vehicle.
• When the driver’s door is opened
• When operations instructed by the
system are not performed within a
certain amount of time

• When the brake pedal is depressed
and the vehicle is stopped for a certain amount of time
• When the system malfunctions

l As the steering wheel will turn while

this system is operating, pay attention to the following.
• Be careful so that a necktie, scarf,
or arm does not get caught. Keep
your upper body away from the
steering wheel. Also, keep children
away from the steering wheel.

• Long fingernails may be caught and
when the steering wheel is rotating,
leading to injury.
• In an emergency, depress the
brake pedal to stop the vehicle, and
then press the Advanced Park main
switch to disable the system.
If Remote control function is in operation, stop operating the dedicated app
and stop the vehicle.

l Do not allow anyone to put their

hands outside of a window while
this system is operating.

n To ensure correct operation of

the Advanced Park
Observe the following precautions.
Failing to do so may result in the vehicle being unable to be driven safely
and possibly cause an accident.

l Do not use this system in situations

such as the following:
• When in areas other than common
parking spaces
• When the surface of the parking
space is sand or gravel and is not
clearly defined with parking space
lines

• When the parking space is not
level, such as on a slope, or having
differences in height, holes, or gutters

5

Driving

extremely low, the screen may
appear dark or the displayed image
may become unclear. Also, as moving objects may appear distorted or
may not be able to be seen on the
screen, make sure to directly check
the safety of the area around your
vehicle.

399

400

5-4. Using the driving support systems

WARNING
• Mechanical parking system
• Parking lot with a device which
raises to contact the bottom of the
vehicle
• When the road surface is frozen,
slick, or covered with snow
• When it is extremely hot and the
asphalt is melting
• When there are objects around the
vehicle
• When there is an object between
your vehicle and the target parking
spot or within the target parking
spot (within the displayed blue box)
• When in high pedestrian or vehicle
traffic areas
• When the parking space is in a
location that is difficult to park in
(too narrow for your vehicle, etc.)
• When images are unclear due to
dirt or snow attached to the camera
lens, light being shined into the
camera or shadows

l Make sure to use only standard

sized tires, such as those that were
installed to the vehicle when it was
shipped from the factory. Otherwise, Advanced Park may not operate properly. Also, when the tires
have been replaced, the displayed
position of the lines or box displayed on the screen may become
incorrect. When replacing the tires,
contact any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.

l In situations such as the following, it

may not be possible for the system
to provide assistance to a registered parking spot or to operate correctly:
• When the tires are extremely worn
or the tire inflation pressure is low
• When carrying a heavy load
• When the vehicle is tilted due to the
carried load
• When a heater is installed in the
surface of the parking space (road
surface freeze prevention heater)

• When tire chains or a compact
spare tire is installed to the vehicle

• When the wheels are misaligned,
such after a wheel has been subjected to a strong impact

• When the doors or back door are
not completely closed

• When a pedestrian or passing vehicle is detected during assistance

• When an arm is held outside of a
window

• When a device, such as a towing
hook, bumper protector, bumper
trim, bicycle carrier, snow plow,
etc., is installed

• In inclement weather such as heavy
rain or snow

• When something is incorrectly
detected as a parking line (light,
reflections from a building, difference in height on the parking surface, a gutter, painted road lines,
redrawn lines, etc.)

5-4. Using the driving support systems

WARNING
If the vehicle deviates greatly from the
set parking space in any situation
other than the above, have the vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

n When using Remote control

function
l Remote control function is a function of the Advanced Park system.
When using Remote control function on public roads, be sure to follow all local road traffic laws and
regulations.

l Remote control function can only

be used after agreeing to the disclaimer of the dedicated app.

l Remote control function can only

l As with a normal vehicle, take care

to observe the area around the
vehicle while the vehicle is moving.

l Always pay attention to the vehi-

cle’s surroundings while the system
is operating.

l Make sure that the hood is closed
before operating the system.

l Remote control function is a system
which assists in remote parking or
exiting operations using a
smartphone. When using Remote
control function, the driver must
carry the electronic key and
smartphone and confirm the safety
of the area around the vehicle.

l While using Remote control func-

tion, the vehicle can be stopped by
stop operating the smartphone. The
vehicle can also be stopped by executing a stop operation of the dedicated app, unlocking the doors
using the electronic key, or opening
a door.

l If it seems like your vehicle may

contact an obstruction, etc., stop
operating the smartphone and cancel Remote control function if necessary.

l Regardless of the manner of

smartphone operation, system
operation will only be performed at
a fixed speed.

l Never drive the vehicle while staring at the smartphone screen.

l When driving, make sure to directly

check the safety of the area around
your vehicle.

5

l Do not use Remote control function
when passengers or pets are in the
vehicle.

l In an emergency, the system can

be canceled by operating a switch
on the electronic key or by opening
a door.

l To use Remote control function, it is

necessary to have a smartphone
and the most up-to-date dedicated
app.
Download the dedicated app from the
app store.
Remote Park Europe* (dedicated
app)
*: The name of the application may
subject to change. Check website
for details.

l When registering the vehicle to the
dedicated app, disconnect any
other apps which are connected to
the vehicle.

Driving

perform some driving operations. It
should only be operated by a driver
with a valid driving license. While
using the dedicated app, carry electronic key. While operating, do not
stare at the dedicated app screen,
and pay attention to the vehicle’s
surroundings. In an emergency,
cancel the Remote control function
operation and stop the vehicle.

401

402

5-4. Using the driving support systems

WARNING
l To enable Remote control function,

make sure to disable the Apple
CarPlay/Android Auto™ connection.
• Apple CarPlay is a trademark of
Apple Inc., registered in the U.S.
and other countries.

• Android Auto™ is a trademark of
Google LLC.

l When parking, make sure that the

vehicle can be parked in the target
parking space before beginning
operation.

l Only use Remote control function

on level road surfaces which are
not slick. Do not use Remote control function for parking spaces on a
downward or upward slope.

l While Remote control function is

l When Remote control function is

operating, the driver should remain
within approximately 3 m (9.8 ft.) of
the vehicle. If the driver becomes
more than approximately 3 m (9.8
ft.) away, Remote control function
will be suspended and a message
will be displayed on the
smartphone. Remote control function operation can be resumed by
approaching the vehicle.

l The headlights will be turned on if
the surrounding area is dark.

l If system operation is canceled due

to a malfunction, the emergency
flashers will flash. The emergency
flashers will turn off if any of the following conditions are met:
• A door is opened
• 3 minutes have elapsed since the
emergency flashers began flashing

operating, if a malfunction or system limitation is detected, the following will occur automatically:
• Remote control function will be
canceled

be started when the following conditions are met:
• When the EV system is starting,
after assist mode is selected

• The vehicle will stop

• When the power switch is off

• The shift position will change to P
and the parking brake will be
engaged
• The power switch will turn off (for
some malfunctions, the power
switch will not turn off or cannot be
turned off. Enter the vehicle and
take corrective action according to
the message displayed on the
smartphone.)
• The doors will remain locked

l When starting Remote control function, unlock the doors with wireless
remote control by electronic key.

l Remote control function can only

NOTICE
n Precautions for use Advanced

Park
If the 12-volt battery was discharged
or has been removed and installed,
fold and extend the outside rear view
mirrors.

5-4. Using the driving support systems

NOTICE
n When using Remote control
function

l Check the battery charge level of

the smartphone before using
Remote control function. If the battery of the smartphone dies while
operating Remote control function,
assist will be suspended. Also, if
the battery charge level of the
smartphone is 20% or less when
attempting to start Remote control
function, Remote control function
will not be started.

l Enable Bluetooth® of the
smartphone before using Remote
control function. Remote control
function cannot be used when
Bluetooth® connection is disabled.

l Do not disable the Bluetooth® of the

l While using Remote control func-

tion, if a call is received, etc., and
another app is opened, Remote
control function will be suspended.
Assist can be resumed if the dedicated app is reopened within 3 minutes. If 3 minutes or more elapse,
assist will be canceled.

l While using Remote control func-

tion, if the home button or power
button of the smartphone is
pressed and the screen is locked,
Remote control function will be suspended. Assist can be resumed if
the dedicated app is reopened
within 3 minutes. If 3 minutes or
more elapse, assist will be
canceled.

l Do not force close the dedicated

app while Remote control function
is being used. If the app is force
closed, assist will be canceled.

l When the ambient temperature is

low, it may take time for the system
to start, due to 12-volt battery
charging.

l If the 12-volt battery voltage drops,
assistance will be canceled.

l When using Remote control func-

tion on a slope, the vehicle speed
will be slower and the distance that
the vehicle will approach objects
will become longer than when on a
level road surface.

l If a system temporary failure

occurs, after the vehicle is stopped
by the electronic parking brake or
the shift position being changed to
P, the power switch may turn off
and the system may be canceled.
In this case, have the vehicle
inspected by any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.

l If a system malfunction occurs,

assistance may be temporarily suspended. If the system returns to
normal, operation can be resumed.
Follow the content on the
smartphone screen to resume operation.

l If the EV system has been started
using a remote start, the remote
control function may not operate
properly.

5

Driving

smartphone or disconnect from the
multi-media system while using
Remote control function. If the vehicle cannot be connected to via
Bluetooth®, Remote control function cannot be used.

403

404

5-4. Using the driving support systems

NOTICE

 Side cameras

l After Remote control function com-

pletes, the parking brake will be
engaged as per regulations. As the
parking brake may freeze and not
be able to be released, avoid using
Remote control function in
extremely cold areas. Also, if the
parking brake freezes, it may make
a noise when it is released. However, this does not indicate a malfunction.

l Do not use Remote control function

 Rear camera

when the electronic key battery is
depleted.

Types of cameras and sensors used for the Advanced
Park
Cameras and sensors are used to
detect parked vehicles, making it
easier to identify parking spaces.

 Sensors

 Front camera

P.366
n Camera images
As special cameras are used, the colors
in displayed images may differ from the
actual color.
n Precautions for use
For details on the following, refer to
“Panoramic view monitor” in the “Multimedia owner’s manual”.
l Displayable range of the screens
l Cameras
l Differences between displayed
images and the actual road

l Differences between displayed
images and the actual objects

n Detection range of the cameras and
sensors

l If a parked vehicle is behind the target
parking space and the distance

5-4. Using the driving support systems
between it and the vehicle becomes
far, it may no longer be able to be
detected. Depending on shape or condition of a parked vehicle, the detection range may become short or the
vehicle may not be detected.

l Objects other than parked vehicles,

such as columns, walls, etc., may not
be detected. Also, if they are
detected, they may cause the target
parking space to be misaligned.

n Situations in which parking space

lines may not be recognized properly

l In situations such as the following,

vehicle or trees
• When a camera lens is dirty or covered with water droplets

l In situations such as the following, the

target parking space may not be recognized correctly:
• When there marks from repairs or
other marks on the road surface, or
there is a parking block, traffic bollard,
or other object on the road surface
• When it is raining or has rained and
the road surface is wet and reflective
or there are puddles
• When the area around the vehicle is
dark or backlit
• When the color or brightness of the
road surface is uneven
• When the parking space is on a slope
• When there are diagonal lines (access
aisle) near the parking space
• When the appearance of the parking
space is affected by the shadow of a
parked vehicle (such as shadows from
the grille, side step, etc.)
• When accessories which obstruct the
view of the camera are installed
• When the parking space lines are
faded or dirty, making them unclear
• When the appearance of the parking
space is affected by the shadow of the
vehicle or trees

n Sensor detection information
P.368
n Objects which the sensor may not

be properly detected
P.369

n Situations in which the sensor may

not operate properly
P.369

n Situations in which parking assis-

tance may not operate even if there
is no possibility of a collision
P.369

5

Driving

parking space lines on the road surface may not be detected:
• When the parking space does not use
lines (parking space boundaries are
marked with rope, blocks, etc.)
• When the parking space lines are
faded or dirty, making them unclear
• When the road surface is bright, such
as concrete, and the contrast between
it and the white parking space lines is
small
• When the parking space lines are any
color other than yellow or white
• When the area surrounding the parking space is dark, such as at night, in
an underground parking lot, parking
garage, etc.
• When it is raining or has rained and
the road surface is wet and reflective
or there are puddles
• When the sun is shining directly into a
camera, such as in the early morning
or evening
• When the parking space is covered
with snow or de-icing agent
• When there marks from repairs or
other marks on the road surface, or
there is a traffic bollard, or other object
on the road surface
• When the color or brightness of the
road surface is uneven
• When a camera has been splashed
by hot or cold water and the lens has
fogged up
• When the appearance of the parking
space is affected by the shadow of the

405

406

5-4. Using the driving support systems

WARNING
n Precautions for the cameras and
sensors

l Due to the characteristics of the

camera lens, the position of and
distance to people and objects displayed on the screen may differ
from the actual situation. For
details, refer to “Multimedia owner’s
manual”.

l Make sure to observe the precau-

tions for using the Toyota parking
assist-sensor, otherwise a sensor
may not operate correctly, possibly
leading to an accident. (P.367)

l In situations such as the following,

the sensors may not operate correctly, possibly leading to an accident. Proceed carefully.
• When there is a parked vehicle next
to the target parking space, if the
displayed target parking space is
far from the actual target parking
space, a sensor may be misaligned. Have the vehicle inspected
by any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer.
• Do not install any accessories near
the detection area of the sensors.

Turning the Advanced Park
system on/off
Press the Advanced Park main
switch.
If the switch is pressed while assistance
is being performed, the assistance will
be canceled.

n Operating conditions of the

Advanced Park
Assistance will begin when all of the following conditions are met:

l The brake pedal is depressed
l The vehicle is stopped
l The driver’s seat belt is fastened
l The steering wheel is not being operated

l The accelerator pedal is not
depressed

l All of the doors and the back door are
closed

l The outside rear view mirrors are not
folded

l The parking brake is not engaged
l The dynamic radar cruise control are
not operating

l ABS, VSC, TRC, PCS and PKSB are
not operating

l “X-MODE” is not operating
l The vehicle is not towing a trailer or
another vehicle

l The vehicle is not on a steep slope
l The VSC and TRC are not turned off
If assistance cannot be started, check
the message displayed on the multimedia display. (P.432)

Advanced Park guidance
screens
Guidance screens are displayed on

5-4. Using the driving support systems

the multimedia display.
 Guidance screen (When assis-

tance starts)

407

(forward) function and parking (reverse)
function
: Change the perpendicular parking
(forward) function
: Change the perpendicular parking
(reverse) function

Customize setting button
Select to display the Advanced Park
setting screen. (P.430)

Registration button
A Target parking space box (blue)
B Advice display
C Parking type change button
If multiple buttons are displayed,
depending on the condition of the button its function differs as follows.
or

: Change the target to

Select to begin registering a parking
space.

Remote control function start
button (if equipped)
Select to start parking assistance operation on the smartphone display.
 Guidance screen (When revers-

ing)

Driving

another parking space.
or

: Select the current target

parking space.
: Select to change to the parallel
parking function
: Change the perpendicular parking
(forward/reverse) function

“MODE” button
Select to change between the memory
function and the perpendicular parking
(forward/reverse) function and parallel
parking function. (P.420)

“Start” button
Select to start parking assistance.

Perpendicular parking direction
change button
Select to change between the parking

5

A Operation icon
Displayed when the Advanced Park is
operating.

B Guide lines (yellow and red)
Display points from the center of the
edge of the front or rear bumper to the
target stopping position (yellow)* and
approximately 0.3 m (1 ft.) (red) from
the vehicle.

C Moving object warning icon

408

5-4. Using the driving support systems

Emergency support brake control operation display
“BRAKE!” is displayed.

Toyota parking assist-sensor
display
P.366
*: The yellow lateral line is not dis-

played when the target stopping position is approximately 2.5 m (8.2 ft.) or
more away from the vehicle.

n Toyota parking assist-sensor

pop-up display
Regardless of whether the Toyota parking assist-sensor is off or on (P.367), if
an object is detected by the Toyota parking assist-sensor when the Advanced
Park is operating, the Toyota parking
assist-sensor pop up display will automatically be displayed over the guidance display.

n Brake control operation when

Advanced Park is operating
While the Advanced Park is operating, if
the system determines that the possibility of collision with detected moving or
stationary object is high, the EV system
output restriction control and brake control will operate.
If brake control operates, Advanced
Park operation will be suspended and a
message will be displayed on the
multi-information display.

n Buzzer
Depending on surrounding sounds or
sounds from other systems, it may be
difficult to hear the buzzer of this system.
n If a black screen is displayed on the

multimedia display when the
Advanced Park is operating
The system is being affected by radio
waves or may be malfunctioning. If a
radio antenna is installed near a camera, move it to a location as far from the

cameras as possible. If a radio antenna
is not installed near a camera, and the
screen does not return to normal after
turning the power switch off and then
starting the EV system again, have the
vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

Perpendicular parking (forward/reverse) function
The perpendicular parking (forward/reverse) function can be used
if the target parking space can be
detected when the vehicle is
stopped close and perpendicular to
the center of the parking space.
Also, depending on the condition of
the parking space, etc., if it is necessary to change the direction of
travel of the vehicle, the shift position can be changed by assistance
control.
Parking using the perpendicular parking (forward/reverse) function
1 Stop the vehicle at a position
close and perpendicular to the
center of the target parking
space.

409

5-4. Using the driving support systems
 If there are parking space lines

more*
C Approximately 6 m (19.7 ft.) or

more*
Approximately 5.5 m (18.0 ft.) or
more*
The system can operate even if there is
a vehicle on only one side of the target
parking space.

A Approximately 1 m (3.3 ft.)*
B Approximately 2.5 m (8.2 ft.)*
C Approximately 6 m (19.7 ft.) or

more*
Approximately 5.5 m (18.0 ft.) or
more*

detection of a parking space.
Depending on the surrounding environment, detection may not be possible.

2 Press the Advanced Park main
switch and check that a possible
parking space is displayed on
the multimedia display.
5

Driving

The system can operate even if there is
a parking space line on only one side of
the target parking space.

*: This is a reference measurement for

*: This is a reference measurement for

detection of a parking space.
Depending on the surrounding environment, detection may not be possible.
 If there is an adjacent parked

vehicle

 If a space which your vehicle can
be parked is detected, a target
parking space box will be displayed.
A Approximately 1 m (3.3 ft.)*
B Approximately 3 m (9.8 ft.) or

 If it is possible to parallel park in
the space, select the parking
space, and then select

to

410

5-4. Using the driving support systems

change to the parallel parking
function.
 If it is possible to change the
direction which a parking space
is entered, select the parking
space, and then select
change the direction.

or

 Depending on the surrounding
environment, it may not be possible to use this function. According to the information displayed
on the multimedia display, use
the function on another parking
space.

object, person, or gutter: P.410

4 Perform operations as indicated
by the advice displays until the
vehicle stops in the target parking space.
When the vehicle stops, “Advanced
Park Finished” will be displayed and
parking assistance will end.
If you select
on the multimedia display, the vehicle displayed on the parking assist completion screen will rotate.

3 Select “Start” button.
A buzzer will sound, an operation message will be displayed on the
multi-information display, and assistance will begin operating.

n If you feel that the vehicle is

 When the brake pedal is
released, “Moving Forward...”,
“Backing Up...” will be displayed
and the vehicle will begin moving
forward/reverse.
 To cancel assistance, press the
Advanced Park main switch.
If assistance is canceled, “Advanced
Park Cancelled” will be displayed.
If you feel that the vehicle is approaching close to a surrounding vehicle,

approaching close to a surrounding vehicle, object, person, or gutter
Depress the brake pedal to stop the
vehicle and then change the shift position to change the direction of travel of
the vehicle. At this time, assist will be
suspended. However, if the “Start” button is selected, assist will resume and
the vehicle will move in the direction corresponding to the selected shift position.

n When the brakes have been oper-

ated
When the brakes have been operated,
brake operation sound may be heard.
This does not indicate a malfunction.

5-4. Using the driving support systems

NOTICE
n When using the perpendicular

parking (forward/reverse) function
l Make sure that there are no
obstructions within the yellow guide
lines and between the vehicle and
target parking spot. If there are any
obstructions between the vehicle
and the target parking space, or
between the yellow guide lines,
cancel the function.

l As the target parking space will not

be able to be set correctly if the surface of the parking space is on a
slope or has differences in height,
the vehicle may stray from the target parking space or be slanted.
Therefore, do not use the function
for this kind of parking spot.

l When parking in a narrow parking

function can be used. Also,
depending on the surrounding environment, if it is necessary to
change the direction of travel of the
vehicle, the shift position can be
changed by assistance control.
Leaving a parking space
using the perpendicular exiting (forward/reverse) function
1 With the brake pedal depressed
and P shift position selected,
press the Advanced Park main
switch and check that the exit
direction selection screen is displayed on the multimedia display.

l If a detected parked vehicle is nar-

row or parked extremely close to
the curb, the position at which
assistance will park the vehicle will
also be close to the curb. If it seems
likely the vehicle will collide with
something or drive off of the road,
depress the brake pedal to stop the
vehicle, and then press the
Advance Park main switch to disable the system.

Advanced Park perpendicular exiting (forward/reverse)
function
When exiting from a perpendicular
parking space, if the system determines that exit is possible the perpendicular exiting (forward/reverse)

5

Driving

space, the vehicle may closely
approach an adjacent parked vehicle. If a collision seems likely,
depress the brake pedal to stop the
vehicle.

411

2 Select an arrow on the multimedia display to select the direction
you wish to exit.
If the turn signal lever is operated, only
exit to the left or right can be selected.

3 Depress the brake pedal and
select “Start” button.
A buzzer will sound, an operation mes-

412

5-4. Using the driving support systems

sage will be displayed on the
multi-information display, and assistance will begin operating.

pedal.

n If you feel that the vehicle is

To cancel assistance, press the
Advanced Park main switch.
If assistance is canceled, “Advanced
Park Cancelled” will be displayed.
If you feel that the vehicle is approaching close to a surrounding vehicle,
object, person, or gutter: P.410

4 Perform operations as indicated
by the advice displays until the
vehicle is in a position where
exit is possible.
When the vehicle reaches a position
where exit is possible, “You can exit by
moving the steering wheel” will be displayed. If the steering wheel is operated, “Advanced Park Finished” will be
displayed and assistance will end.
As assistance will end while the vehicle
is moving, grip the steering wheel and
drive forward.
If the steering wheel is not operated,
the vehicle will stop at the exit position.
Assistance can be ended by depressing the accelerator pedal or brake

approaching close to a surrounding vehicle, object, person, or gutter
P.410

n Perpendicular exiting (for-

ward/reverse) function
Do not use perpendicular exiting (forward/reverse) function in any situation
other than when exiting a perpendicular
parking spot. If assistance is started
unintentionally, depress the brake pedal
and stop the vehicle, then press the
Advanced Park main switch to cancel
assistance.

n Situations in which the perpendicu-

lar exiting (forward/reverse) function will not operate
In situations such as the following, the
perpendicular exiting (forward/reverse)
function will not operate:

l When a vehicle which is waiting to
park is in the exit direction

l When a wall, column, or person is

detected as near a front or rear center
or corner sensor

5-4. Using the driving support systems

413

 If there are parking space lines

n When the brakes have been oper-

ated
P.410

Advanced Park parallel parking function

A Approximately 1 m (3.3 ft.)*
B

C Approximately 4.5 m (14.8 ft.) or

more*
Approximately 8 m (26.2 ft.) or
more*

Parking using the parallel
parking function
1 Stop the vehicle with it aligned
near the center of the target
parking space.

5

Approximately 6 m (19.7 ft.)*

*: This is a reference measurement for

detection of a parking space.
Depending on the surrounding environment, detection may not be possible.

Driving

The parallel parking function can be
used if the target parking space can
be detected when the vehicle is
stopped close and aligned with the
center of the parking space. Also,
depending on the condition of the
parking space, etc., if it is necessary to change the direction of
travel of the vehicle, the shift position can be changed by assistance
control.

414

5-4. Using the driving support systems

 If there is an adjacent parked

vehicle

parking space is displayed on
the multimedia display.

 If a space which your vehicle can
be parked is detected, a target
parking space box will be displayed.
A Approximately 1 m (3.3 ft.)*
B Approximately 7 m (23.0 ft.) or

more*
C Approximately 4.5 m (14.8 ft.) or

more*
Approximately 8 m (26.2 ft.) or
more*
*

: This is a reference measurement for
detection of a parking space.
Depending on the surrounding environment, detection may not be possible.

2 Press the Advanced Park main
switch and check that a possible

 If it is possible to perpendicular
parking (forward/reverse) in the
space, select the parking space,
and then select
to change to
the perpendicular parking (forward/reverse) function.
 Depending on the surrounding
environment, it may not be possible to use this function. According to the information displayed
on the multimedia display, use
the function on another parking
space.
3 Select “Start” button.
A buzzer will sound, an operation message will be displayed on the
multi-information display, and assis-

5-4. Using the driving support systems
tance will begin operating.

415

n If you feel that the vehicle is

approaching close to a surrounding vehicle, object, person, or gutter
P.410

n If “No available parking space” is

 When the brake pedal is
released, “Moving Forward...”
will be displayed and the vehicle
will begin moving forward.

displayed
Even if the vehicle is stopped parallel to
a parking space, an adjacent parked
vehicle may not be detected. In this
case, if the vehicle is moved to a position that a parked vehicle can be
detected, assistance can be started.

 To cancel assistance, press the
Advanced Park main switch.
If assistance is canceled, “Advanced
Park Cancelled” will be displayed.

4 Perform operations as indicated
by the advice displays until the
vehicle stops in the target parking space.
When the vehicle stops, “Advanced
Park Finished” will be displayed and
parking assistance will end.
If you select
on the multimedia display, the vehicle displayed on the parking assist completion screen will rotate.

n When the brakes have been oper-

ated
P.410

NOTICE
n When using the parallel parking
function

l Make sure that there are no

obstructions within the yellow guide
lines and between the vehicle and
target parking spot. If any obstructions are detected within the yellow
guide lines or between the vehicle
and the target parking space, the
parallel parking function will be
canceled or suspended.

l As the target parking space will not

be able to be set correctly if the surface of the parking space is on a
slope or has differences in height,
the vehicle may stray from the target parking space or be slanted.
Therefore, do not use the parallel
parking function for this kind of
parking spot.

5

Driving

If you feel that the vehicle is approaching close to a surrounding vehicle,
object, person, or gutter: P.410

416

5-4. Using the driving support systems

NOTICE
l If an adjacent parked vehicle is nar-

row or parked extremely close to
the curb, the position at which
assistance will park the vehicle will
also be close to the curb. If it seems
likely the vehicle will collide with the
curb or drive off of the road,
depress the brake pedal to stop the
vehicle, and then press the
Advanced Park main switch to disable the system.

changed by assistance control.
Leaving a parking space
using the parallel exiting
function
1 With the brake pedal depressed
and P shift position selected,
press the Advanced Park main
switch and check that the exit
direction selection screen is displayed on the multimedia display.

l If there is a wall or other barrier on

the inner side of the parking space,
the vehicle may stop at a position
slightly outside of the set target
parking space.

Advanced Park parallel exiting function
When exiting from a parallel parking space, if the system determines
that exit is possible the parallel exiting function can be used. Also,
depending on the surrounding environment, if it is necessary to
change the direction of travel of the
vehicle, the shift position can be

2 Select an arrow on the multimedia display to select the direction
you wish to exit.
If the turn signal lever is operated, only
exit to the left or right can be selected.

3 Depress the brake pedal and
select “Start” button.
A buzzer will sound, an operation message will be displayed on the
multi-information display, and assistance will begin operating.
To cancel assistance, press the
Advanced Park main switch.
If assistance is canceled, “Advanced
Park Cancelled” will be displayed.

5-4. Using the driving support systems
If you feel that the vehicle is approaching close to a surrounding vehicle,
object, person, or gutter: P.417

4 Perform operations as indicated
by the advice displays until the
vehicle is in a position where
exit is possible.
When the vehicle reaches a position
where exit is possible, “You can exit by
moving the steering wheel” will be displayed. If the steering wheel is operated, “Advanced Park Finished” will be
displayed and assistance will end.
As assistance will end while the vehicle
is moving, grip the steering wheel and
drive forward.
If the steering wheel is not operated,
the vehicle will stop at the exit position.
Assistance can be ended by depressing the accelerator pedal or brake
pedal.

417

n Parallel exiting function
Do not use parallel exiting function in
any situation other than when exiting a
parallel parking spot. If assistance is
started unintentionally, depress the
brake pedal and stop the vehicle, then
press the Advanced Park main switch to
cancel assistance.
n Situations in which the parallel exit-

ing function will not operate
In situations such as the following, the
parallel exiting function will not operate:

l When vehicles waiting at a traffic signal in the exit direction

l When a vehicle is stopped in the area

5

behind where the vehicle will exit

Driving

l When a wall, column, or person is

detected as near a front or rear side
sensor

n If you feel that the vehicle is

approaching close to a surrounding vehicle, object, person, or gutter
P.410

l When the vehicle has been parked on
a curb and a side sensor detects the
road surface

418

5-4. Using the driving support systems

A Approximately 1 m (3.3 ft.)

2 Press the main switch and then
select

l When a vehicle is not parked in front
of the vehicle

l When there is excessive space

If the Advanced Park main switch is
pressed at a parking space without
parking lines or any adjacent parked
vehicles, “No available parking space”
may be displayed. Continuously select
and hold

.

between the front of the vehicle and a
parked vehicle

n When the brakes have been oper-

ated
P.410

Advanced Park memory
function
The memory function can be used
to park in a previously registered
parking space, even if there are no
parking space lines or adjacent
parked vehicles.
Up to 3 parking spaces can be registered.
Registering a parking space

3 Select perpendicular parking
(forward/reverse) function or
parallel parking function.
Only parking spaces for which assist
can be performed are displayed.

1 Stop the vehicle with it aligned
near the center of the target
parking space.

4 Select the parking direction, and
then select “OK” button.
When perpendicular parking (for-

5-4. Using the driving support systems
ward/reverse) was selected in step 3:

419

ward.
If you feel that the vehicle is approaching close to a surrounding vehicle,
object, person, or gutter: P.410

When parallel parking was selected in
step 3:

5

7 Perform operations as indicated
by the advice displays until the
vehicle stops in the target parking space.
8 Check the position that the vehicle has stopped. If necessary,
adjust the position of the parking
spot to be registered using the
arrow buttons, and then select
“Reg.” button.
“Registration Completed” will be dis-

6 Select “Start” button.
A buzzer will sound, an operation message will be displayed on the
multi-information display, and assistance will begin operating.
When the brake pedal is released,
“Moving Forward...” will be displayed
and the vehicle will begin moving for-

Driving

5 Using the arrow buttons, adjust
the position of the parking space
to be registered, and then select
“OK” button.

420

5-4. Using the driving support systems

played on the multimedia display.

If the “MODE” button is displayed, the
button can be touched to change
between the memory function, perpendicular parking (forward/reverse) function and parallel parking function.

 Register the parking space only
if there are no obstructions within
the area shown by the thick
lines.
 The amount that the position of
the parking spot to be registered
can be adjusted is limited.
When parking in a parking
space registered to the memory function
1 Stop the vehicle with it aligned
near the center of the target
parking space.

3 Select the desired parking
space, and then select “Start”
button.
Perform the procedure for the perpendicular parking (forward/reverse) function from step 3. (P.408)

n If you feel that the vehicle is

approaching close to a surrounding vehicle, object, person, or gutter
P.410

n When overwriting a registered

parking space
If the maximum number of parking

spaces have been registered and
is
selected, a registered parking space can
be selected and then overwritten with a
new parking space.

A Approximately 1 m (3.3 ft.)

2 Press the Advanced Park main
switch and check that a possible
parking space is displayed on
the multimedia display.

5-4. Using the driving support systems

421

• When the surrounding area is dark
(at night, etc.)

l In situations such as the following, it

n When multiple parking spaces are

registered
Select the desired parking space, and
then select “Start” button.

may not be possible to register a
parking space.
• When there is insufficient space
between the road and parking
space

• When the road surface around the
parking space does not have any
differences the system can recognize

l If a parking space has been regis-

n When the brakes have been oper-

tered in situations such as the following, assistance may not be able
to be started later or assistance to
the registered position may not be
possible.
• When shadows are cast on the
parking space (there is a carport
over the parking space, etc.)

ated
P.410

5

Driving

NOTICE
n When using the memory function
(P.411, 415)

l The memory function is a function

which provides assistance in parking in a previously registered parking space. If the condition of the
road surface, vehicle, or surrounding area differs from when registration was performed, the parking
space may not be able to be
detected correctly or assistance
may not be provided to the point
that the vehicle is fully parked.

l Do not register a parking space in

situations such as the following, as
the set parking space may not be
able to be registered or assistance
may not be possible later.
• When a camera lens is dirty or covered with water droplets
• When it is raining or snowing

• When there are leaves, garbage, or
other objects which will likely move,
in the parking space
• When the road surface around the
parking space has the same repeating pattern (brick, etc.)

422

5-4. Using the driving support systems

NOTICE
l In situations such as the following, it

may not be possible for the system
to provide assistance to a registered parking spot:
• When the appearance of the parking space is affected by the shadow
of the vehicle or trees
• When an object is detected in the
registered parking space

• When a pedestrian or passing vehicle is detected during assistance
• When the position the vehicle is
stopped when assistance is started
differs from the position when registration was performed
• When the registered parking space
cannot be reached due to the existence of parking blocks, etc.
• When the road surface around the
parking space has changed (road
surface has degraded or been
resurfaced)
• When the sunlight conditions differ
from when registration was performed (due to weather or time of
day)
• When the sun is shining directly into
a camera, such as in the early
morning or evening
• When the color or brightness of the
road surface is uneven
• When a light is temporarily shined
on the parking space (lights of
another vehicle, security light, etc.)
• When the road surface around the
parking space has the same repeating pattern
• When there is a low protrusion on
the road surface near the parking
space

• When the parking space is on a
slope
• When a camera has been splashed
by hot or cold water and the lens
has fogged up
• When a camera lens is dirty or covered with water droplets
• When accessories which obstruct
the view of the camera are installed
If assistance is ended during registration, perform registration again.

l When registering a parking space

to the memory function, if the road
surface cannot be detected “No
available parking space to register”
will be displayed.

l When using the memory function,

make sure to stop immediately in
front of the stop position. Otherwise
the parking space may not be able
to be detected correctly or assistance may not be provided to the
point that the vehicle is fully parked.

l Do not use the memory function if a

camera has been subjected to a
strong impact or images of the panoramic view monitor are misaligned.

l If a camera has been replaced, as

the installation angle of the camera
will have changed, it will be necessary to reregister parking spaces of
the memory function.

Remote control function (if
equipped)
A smartphone can be used to
remotely operate the parking functions and exit functions. Also, assistance can be provided to remotely
move the vehicle forward or backward into a garage, etc.

5-4. Using the driving support systems

Parking using Remote control function
A smartphone can be used to
remotely operate the parking function if the target parking space can
be detected when the vehicle is
stopped close and perpendicular to
the center of the parking space.
Also, depending on the condition of
the parking space, etc., if it is necessary to change the direction of
travel of the vehicle, the shift position can be changed by assistance
control.
1 Stop the vehicle with it aligned
near the center of the target
parking space. (P.408, 413)

the screen of the smartphone
and then execute a start operation.
Start operation of Remote control function while standing approximately 50
cm (1.6 ft.) or more from the vehicle
and out of the path of the vehicle.

7 Checking the safety of the area
around the vehicle, operate the
screen of the smartphone.
While continuously operating the operation area, the vehicle will move and
parking assistance will be performed.
If operation of the screen of the
smartphone is stopped, assistance can
be suspended and the vehicle can be
stopped.
When the operation of the screen of the
smartphone is resumed to move the
vehicle, the vehicle will be locked automatically before moving.

3 Select
and then select “Perpendicular/parallel”.

8 When the parking space is
reached, after the vehicle is
stopped by the parking brake,
the shift position will be changed
to P, the power switch will be
turned off, and the doors will be
locked.

4 Select “OK” button.

A completion screen will be displayed
on the smartphone.

5 Exit the vehicle while carrying
the electronic key and
smartphone, and then start the
dedicated app.
The detection area of the electronic key
is within approximately 3 m (9.8 ft.)
around the vehicle.
If there is an obstruction in the path of
the vehicle, move it before parking the
vehicle. An corn can also be moved
after exit the vehicle.

6 From outside of the vehicle,
confirm the parking space on

n The parking function can be used
even if obstructions exist if

l When using the parking functions at a
parking space made of white lines,
even if an obstruction exists in the
parking space, the space can be set
as the target parking space. This
allows for assistance to continue after
setting a parking space from inside
the vehicle and then exiting the vehicle to move an obstruction, such as a
traffic cone placed in a handicapped
parking space.

l When perpendicular parking using

5

Driving

2 Press the Advanced Park main
switch and check that a possible
parking space is displayed on
the multimedia display.
(P.408, 413)

423

424

5-4. Using the driving support systems

Advanced Park, 3 parking spaces on
each side of the vehicle (up to 6 total)
can be detected. However, when
using Remote control function, only 1
parking space on each side of the
vehicle can be detected.

n When the brakes have been oper-

ated
P.410

Moving the vehicle forward
and backward using Remote
control function
After the vehicle is stopped, assistance can be provided to move the
vehicle into a garage, etc., by using
the forward and backward movement function.
1 Stop the vehicle at the location
you would like to start assistance.

smartphone, and then start the
dedicated app.
The detection area of the electronic key
is within approximately 3 m (9.8 ft.)
around the vehicle.

6 From outside of the vehicle,
confirm the direction of travel on
the screen of the smartphone
and then execute a start operation.
Start operation of Remote control function while standing approximately 50
cm (1.6 ft.) or more from the vehicle
and out of the path of the vehicle. The
detection area of the electronic key is
within approximately 3 m (9.8 ft.)
around the vehicle.

7 Checking the safety of the area
around the vehicle, operate the
screen of the smartphone.
While continuously operating the operation area, the vehicle will move and
forward and reverse movement assistance will be performed.
If operation of the screen of the
smartphone is stopped, assistance can
be suspended and the vehicle can be
stopped.
While assistance is being performed, it
can be stopped part way or the direction of travel of the vehicle can be
changed.

2 Press the Advanced Park main
switch.

8 Execute a power-off operation of
the vehicle on the screen of the
smartphone.

3 Select
and then select “Forward/reverse”.

The power switch will then turn off and
the doors will lock automatically.

4 Adjust as necessary using direction keys then select “OK” button.
5 Exit the vehicle while carrying
the electronic key and

n Changing the direction of travel
While assistance is being performed,
the direction of travel of the vehicle can
be changed by the forward and reverse
movement function.
When there is a wall behind the vehicle,

5-4. Using the driving support systems
etc., by executing a change in the direction of travel on the screen of the
smartphone, the vehicle can be slightly
moved forward to allow loading of items
and then moved back to its original position.

n When the brakes have been oper-

ated
P.410

Exiting using Remote control function
Assistance can be provided to exit
from a perpendicular or parallel
parking space when the power
switch off.

1 While near the parked vehicle,
unlock the doors using the electronic key, and then start the
dedicated app.
If the dedicated app cannot connect to
the vehicle, use the electronic key to
unlock the doors again.

2 Execute a start operation on the
screen of the smartphone.

The power switch will change to ON.

3 Check that a possible exit direction is displayed, select the exit
direction.
4 Checking the safety of the area
around the vehicle, operate the
screen of the smartphone.
While continuously operating the operation area, the vehicle will move and
departure assistance will be performed.
If operation of the screen of the
smartphone is stopped, assistance can
be suspended and the vehicle can be
stopped.
While assistance is being performed, it
can be stopped part way or the direction of travel of the vehicle can be
changed.

5 Move the vehicle to the position
where assistance ends and
enter the vehicle while carrying
the electronic key.
To stop assistance part way, stop operating the smartphone or enter the vehicle.

n When the brakes have been oper-

ated
P.410

Parking using the Remote
control function and memory function
A smartphone can be used to
remotely operate the memory function if the target parking space can
be detected when the vehicle is
stopped close to a parking space
which was previously registered to
the memory function.
Also, depending on the condition of

5

Driving

When forward and backward movement is selected, the maximum distance the vehicle can move is 7 m
(23.0 ft.) from the starting point and
possible to change the direction of
travel.

425

426

5-4. Using the driving support systems

the parking space, etc., if it is necessary to change the direction of
travel of the vehicle, the shift position can be changed by assistance
control.
1 Stop the vehicle with it aligned
near the center of the target
parking space. (P.420)
2 Press the Advanced Park main
switch and check that a possible
parking space is displayed on
the multimedia display.
(P.420)
3 Select
and then select “Perpendicular/parallel”.
4 Select “OK” button.
If the “MODE” button is displayed, the
button can be selected to change
between the memory function, perpendicular parking (forward/reverse) function and parallel parking function.

5 Exit the vehicle while carrying
the electronic key and
smartphone, and then start the
dedicated app.
The detection area of the electronic key
is within approximately 3 m (9.8 ft.)
around the vehicle. If there is a cone or
other obstruction in the path of the vehicle, move it after exiting the vehicle.

6 From outside of the vehicle,
confirm the parking space on
the screen of the smartphone
and then execute a start operation.
Start operation of Remote control function while standing approximately 50
cm (1.6 ft.) or more from the vehicle
and out of the path of the vehicle.

7 Checking the safety of the area
around the vehicle, operate the
screen of the smartphone.
While continuously operating the operation area, the vehicle will move and
parking assistance will be performed.
If operation of the screen of the
smartphone is stopped, assistance can
be suspended and the vehicle can be
stopped.
When the operation of the screen of the
smartphone is resumed to move the
vehicle, the vehicle will be locked automatically before moving.

8 When the parking space is
reached, after the vehicle is
stopped by the parking brake,
the shift position will be changed
to P, the power switch will be
turned off, and the doors will be
locked.
A completion screen will be displayed
on the smartphone.

n When the brakes have been oper-

ated
P.410

Preparation before using
Remote control function
n Preparation before using

Make sure to perform the following
before using Remote control function:
1 Download the dedicated app
from the app store.
2 Turn the power switch to ON
and register the smartphone as
a Bluetooth device to the multimedia system.

5-4. Using the driving support systems
For details on registering a Bluetooth®
device, refer to the “Multimedia owner’s
manual”.

3 Start the dedicated app and register the vehicle.
4 The registered vehicle will be
displayed on the screen of the
smartphone. Select the vehicle.
The name and image of the vehicle can
be changed on the new vehicle registration screen.
Vehicles can be added through the
menu screen.

n Remote control function on/off

1 Select
and then select
“Advanced Park” on the multimedia display.
2 Select “Remote Park” to turn it
on/off. (The default setting is
on.)

If the switch is pressed while assistance
is being performed, the assistance will
be canceled.

NOTICE
n Remote control function
l When using Remote control func-

tion, make sure carry an electronic
key in your pocket, etc.

l If an electronic key is held together
with a smartphone, etc., the electronic key may not be able to be
detected.

l Vehicles with a digital key: Remote
control function cannot be used
when carrying only a digital key.
The driver should always carry the
electronic key.

l When entering the vehicle after

using Remote control function,
make sure that the electronic key is
brought into the vehicle and all of
the doors are closed.
Vehicles with a power easy access
system: After entering the vehicle and
ending Remote control function operation, the seat return function will
operate when the driver’s seat belt is
fastened or the brake pedal is
depressed.

l If the power switch is turned off

when Remote control function operation has finished or been
canceled, the doors will be locked
automatically. However, if a door is
open, it may not be locked. Check
the vehicle condition after Remote
control function operation has finished.

l When the doors are locked after

4 Select
button displayed on
the multimedia display.

Remote control function operation
has finished or been canceled, an
alarm may sound if someone is
detected inside the vehicle.

n Situations in which the function
may not operate correctly

l When the functions of the smart

entry & start system may not operate correctly: P.192

5

Driving

3 Press the Advanced Park main
switch.

427

428

5-4. Using the driving support systems

NOTICE
l When the vehicle is near fluorescent lights

l Radio wave interference: P.195
n Electronic key battery consumption

l When Remote control function is

being used, the electronic key battery will be used as the electronic
key will continuously send and
receive radio waves.

Advanced Park operation will be
canceled. Firmly hold the steering
wheel and depress the brake pedal
to stop the vehicle.
As system operation has been
canceled, begin the operation again or
continue parking manually, using the
steering wheel.

 The Advanced Park main switch
is pushed

l If the electronic key battery is

 The shift position has been
changed to P

n Situations in which the sensors

 The parking brake is engaged

P.369

 A door or the back door is
opened

depleted: P.604

may not operate properly

l When using Remote control func-

tion, visibility of the area around the
vehicle may be limited. Make sure
to check the following when using
Remote control function:
• The vehicle and area around the
vehicle are clearly visible
• There are no people, animals, or
objects in the path of the vehicle
• An appropriate distance from the
vehicle can be maintained and the
safety of yourself and others can be
ensured
• Caution for the area around the
vehicle is always maintained and
there is no potential for danger
• You can cancel Remote control
function immediately if necessary

 The driver’s seat belt is unfastened
 The outside rear view mirrors are
folded
 The TRC or VSC is turned off
 The TRC, VSC or ABS operates
 “X-MODE” switch is pushed
 The vehicle is towing a trailer or
another vehicle
 The power switch is pressed
 The system determines assistance cannot be continued in the
current parking environment
 The system malfunctions

Advanced Park
cancelation/suspension

 While the vehicle was stopped,
“Cancel” was selected on the
multimedia display

n Assistance will be canceled

n Assistance will be suspended

when
In situations such as the following,

when
In situations such as the following,
Advanced Park operation will be

5-4. Using the driving support systems

suspended.
Assistance can be started again by following the directions displayed on the
multimedia display.
Also, when assistance is suspended, if
the shift position is changed twice with
the brake pedal depressed, assistance
will be canceled in that shift position.

429

Advanced Park assistance is
met, with the exception suspension due to a door being opened
or the driver’s seat belt being
released
 When 5 minutes have elapsed
since Remote control function
operation was started

However, if assistance is suspended by
changing the shift position, assistance
will be canceled if the shift position is
changed once.

 When 3 minutes have elapsed
since any operation was performed

 The steering wheel is operated

 When 30 seconds have elapsed
with the vehicle not being able to
be driven, even though the
screen of the smartphone is
being operated to drive the vehicle

 The accelerator pedal is
depressed
 The shift position has been
changed

 Camera switch is pressed
n Remote control function assis-

tance will be canceled when
(vehicles with Remote control
function)
In situations such as the following,
Remote control function operation
will be canceled.
As system operation has been
canceled, while carrying an electronic key, enter the vehicle and
park the vehicle manually, using the
steering wheel.
 When a condition for stopping

 When a power-off operation of
the vehicle is executed on the
screen of the smartphone
 When the dedicated app is force
closed
 When the vehicle is on a steep
slope
 When an electronic key is
detected inside the vehicle while
Remote control function operation is suspended
 When the ambient temperature
is -10°C (14°F) or less
n Remote control function assis-

tance will be suspended when
(vehicles with Remote control
function)
In situations such as the following,
assistance will be suspended.

5

Driving

 A moving object or stationary
object that may collide with your
vehicle has been detected,
resulting in the operation of the
EV system output control/braking
control.

430

5-4. Using the driving support systems

 When the Bluetooth® communication between the smartphone
and multimedia system get lost
 When an operation on the
smartphone is suspended
 When the dedicated app is
pushed to the background (a call
is received, the home button is
pressed, etc.)
 When electronic key does not
detected
 When there is an obstruction in
the movement direction of the
vehicle
 When the vehicle is operated
while it is being driven by assistance
 When the smart key is operated
while it is being driven by assistance
 When the door is unlocked while
it is being driven by assistance
 When a door is opened while the
vehicle is being driven

Changing the Advanced
Park settings
Select
on the multimedia display, and then select “Advanced
Park”.
n Remote Park (vehicles with

Remote control function)
Remote control function can be
turned on/off.

n Speed profile

The vehicle speed for when assistance is performed can be set.
This setting cannot be changed when
registering a parking space to the memory function.

n Obstacle detection range

The distance from which obstacles
will be avoided while assistance is
being performed can be set.
n Preferred parking method

The preferred parking direction displayed when at a parking space
which perpendicular (forward/reverse) or parallel parking is
possible can be set.
n Preferred parking direction

The preferred parking direction displayed when it is possible to pull
perpendicular forward or reverse
into a parking space can be
selected.
n Preferred exit direction (per-

pendicular)
The preferred exit direction displayed when it is possible to pull
forward or reverse to the left or right
out of a parking space can be
selected.
n Preferred exit direction (paral-

lel)
The preferred exit direction displayed when it is possible to exit to
the left or right from a parallel parking space can be selected.

5-4. Using the driving support systems

n Camera view when parking

the memory function.)

The display angle of the camera
image when using the perpendicular parking (forward/reverse) function or parallel parking function can
be set.

n Rear accessory setting

n Camera view when exiting

The display angle of the camera
image when using the perpendicular exiting (forward/reverse) function or parallel parking exit function
can be set.
n Parking path adjustment

The course for when parking assistance is operating can be adjusted
inward or outward.

n Road width adjustment

When parking assistance is started,
the amount of lateral movement
while the vehicle is moving forward
can be adjusted.
n Park position adjustment (for-

ward)
The position at which perpendicular
parking (forward) is completed can
be adjusted. (Except when using
the memory function.)
n Park position adjustment

(reverse)
The position at which perpendicular
parking (reverse) is completed can
be adjusted. (Except when using

If an accessory, such as a trailer
hitch, has been installed to the rear
of the vehicle, the length of the rear
of the vehicle can be adjusted to
help avoid colliding with objects to
the rear of the vehicle.
n Clear registered parking space

The parking spaces registered to
the memory function can be
deleted. Parking space information
cannot be deleted when assistance is being performed or when
registering parking space information to the memory function.
NOTICE

5

l Take care when using the park

position adjustment (forward) or
park position adjustment (reverse)
for adjusting because the vehicle
may collide with parking blocks,
curb stones, or other low objects.

l If it is likely that your vehicle will collide with a nearby vehicle/object,
parking block, curb stone, etc.,
depress the brake pedal to stop the
vehicle and press the Advanced
Park main switch to disable the system.

Changing the dedicated app
settings (vehicles with
Remote control function)
n Toyota parking assist-sensor

warning sound ON/OFF
(Smartphone setting)
The warning sounds of the Toyota
parking assist-sensor from the ded-

Driving

If the tires are worn, the path of vehicle
may be offset from the center of the
parking space. In this case, use this
setting to adjust the parking course.

431

432

5-4. Using the driving support systems

icated app can be enabled/disabled.
n Toyota parking assist-sensor

warning sound volume adjustment (Smartphone setting)
The volume of the warning sounds
of the Toyota parking assist-sensor
from the dedicated app can be
adjusted using the Remote Park
app.

Advanced Park displayed
messages
The operating state, assistance
operation, etc. of the Advanced
Park is displayed on the multimedia
display. If a message is displayed,
respond according to the content
displayed.
n If “No available parking space” is

displayed
Move the vehicle to a location where a
parking space or parking lines can be
detected.

n If “Unavailable in current condi-

tion” is displayed
Move the vehicle to another location and
use the system.

n If “Not enough space to exit” is dis-

played
The parallel parking exit function cannot
be used due to a situation such as the
distance between your vehicle and vehicles parked in front of and behind your
vehicle being short, the existence of an
object in the exit direction, etc.
Check the conditions of the area around
your vehicle and exit from the parking
space manually.

n If “Cannot control speed” is dis-

played
The system judged that it cannot adjust
the speed of the vehicle when using the
system in an area with a slope or step
and assistance was canceled.
Use the system in a level location.

n If “Obstacle detected” is displayed
As a moving object or stationary object
that may collide with your vehicle has
been detected, the EV system output
control/braking control operates to suspend Advanced Park assistance.
Check the condition of the surrounding
area. To resume assistance, select the
“Start” button on the multimedia display.

n If “No available parking space to
register” is displayed

This message is displayed when
is
selected at a parking space that cannot
be detected.
Operate the system at a parking space
where differences in the road surface
can be recognized. (P.418)
