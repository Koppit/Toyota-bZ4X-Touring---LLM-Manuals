# 4-5. Opening, closing the windows

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 4: Before driving, pages 218–220

218

4-5. Opening, closing the windows

Power windows

4-5.Opening, closing the windows

Opening and closing the
power windows
The power windows can be opened
and closed using the switches.
Operating the switch moves the
windows as follows:

n Catch protection function
If an object becomes caught between
the door and window while the window
is opening, window movement is
stopped.
n When the window cannot be

opened or closed
When the jam protection function or
catch protection function operates unusually and the door window cannot be
opened or closed, perform the following
operations with the power window
switch of that door.

l Stop the vehicle. With the power

switch in ON, within 4 seconds of the
jam protection function or catch protection function activating, continuously operate the power window
switch in the one-touch closing direction or one-touch opening direction so
that the door window can be opened
and closed.

1 Closing
2 One-touch closing*
3 Opening
4 One-touch opening*
*: To stop the window partway, operate

the switch in the opposite direction.

n The power windows can be oper-

ated when
The power switch is in ON.

n Operating the power windows after

turning the EV system off
The power windows can be operated for
approximately 45 seconds even after
the power switch is turned to ACC or
turned off. They cannot, however, be
operated once either front door is
opened.

n Jam protection function
If an object becomes jammed between
the window and the window frame while
the window is closing, window movement is stopped and the window is
opened slightly.

l If the door window cannot be opened

and closed even when performing the
above operations, perform the following procedure for function initialization.
1 Turn the power switch to ON.
2 Pull and hold the power window
switch in the one-touch closing
direction and completely close the
door window.
3 Release the power window switch
for a moment, resume pulling the
switch in the one-touch closing
direction, and hold it there for
approximately 6 seconds or more.
4 Press and hold the power window
switch in the one-touch opening
direction. After the door window is
completely opened, continue holding
the switch for an additional 1 second
or more.
5 Release the power window switch
for a moment, resume pushing the
switch in the one-touch opening
direction, and hold it there for
approximately 4 seconds or more.
6 Pull and hold the power window
switch in the one-touch closing

4-5. Opening, closing the windows
direction again. After the door window is completely closed, continue
holding the switch for a further 1 second or more.
If you release the switch while the window is moving, start again from the
beginning.
If the window reverses and cannot be
fully closed or opened, have the vehicle
inspected by any authorized Toyota
retailer or Toyota authorized repairer, or
any reliable repairer.

n Door lock linked window operation
l The power windows can be opened
and closed using the mechanical key.*
(P.657)

l The power windows can be opened
and closed using the wireless remote
control.* (P.173)

l The alarm may be triggered if the

WARNING
Observe the following precautions.
Failing to do so may result in death or
serious injury.

n Closing the windows
l The driver is responsible for all the

power window operations, including
the operation for the passengers. In
order to prevent accidental operation, especially by a child, do not let
a child operate the power windows.
It is possible for children and other
passengers to have body parts
caught in the power window. Also,
when riding with a child, it is recommended to use the window lock
switch. (P.220)

l Check to make sure that all passengers do not have any part of their
body in a position where it could be
caught when a window is being
operated.

n Power windows open reminder

function
A buzzer sounds and a message is
shown on the multi-information display
in the instrument cluster when the power
switch is turned off and the driver’s door
is opened with the power windows open.

n Speech command window operation*
*
: If equipped
The power windows can be opened
andclosed using the speech command
system.For details, refer to the “Multimedia owner’s manual”.

n Customization
Some functions can be customized.
(P.675)

l When using the wireless remote

control or mechanical key and operating the power windows, operate
the power window after checking to
make sure that there is no possibility of any passenger having any of
their body parts caught in the window. Also do not let a child operate
window by the wireless remote control or mechanical key. It is possible
for children and other passengers
to get caught in the power window.

4

Before driving

alarm is set and the power window is
closed using the door lock linked
power window operation function.
(P.85)
*: These settings must be customized at
any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.

219

220

4-5. Opening, closing the windows

WARNING
l When exiting the vehicle, turn the

power switch off, carry the key and
exit the vehicle along with the child.
There may be accidental operation, due to mischief, etc., that may
possibly lead to an accident.

n Jam protection function
l Never use any part of your body to
intentionally activate the jam protection function.

l The jam protection function may not
work if something gets jammed just
before the window is fully closed.
Be careful not to get any part of
your body jammed in the window.

n Catch protection function
l Never use any part of your body or

clothing to intentionally activate the
catch protection function.

l The catch protection function may

not work if something gets caught
just before the window is fully
opened. Be careful not to get any
part of your body or clothing caught
in the window.

Preventing accidental operation (window lock switch)
This function can be used to prevent children from accidentally
opening or closing a passenger
window.
Press the switch.
The indicator A will come on and the
passenger windows will be locked.
The passenger windows can still be
opened and closed using the driver’s
switch even if the lock switch is on.

n The power windows can be oper-

ated when
The power switch is in ON.

n When the 12-volt battery is discon-

nected
The window lock switch is disabled. If
necessary, press the window lock switch
after reconnecting the 12-volt battery.
