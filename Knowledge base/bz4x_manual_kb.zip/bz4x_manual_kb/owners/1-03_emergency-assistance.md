# 1-3. Emergency assistance

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 1: For safety and security, pages 69–82

1-3. Emergency assistance

eCall*1, 2

1-3.Emergency assistance

*1

: If equipped

*2

: Operates within the eCall coverage.
The system name differs depending
on the country.

System components

Speaker
*

: This button is intended for communication with the eCall system operator.
Other SOS buttons available in other
systems of a motor vehicle do not
relate to the device and are not
intended for communication with the
eCall system operator.

Emergency Notification Services
n Automatic Emergency Calls

If any airbag deploys, the system is
designed to automatically call the
eCall control center.* The answering operator receives the vehicle’s
location, the time of the incident
and the vehicle VIN, and attempts
to speak with the vehicle occupants
to assess the situation. If the occupants are unable to communicate,
the operator automatically treats
the call as an emergency and contacts the nearest emergency services provider (112 system etc.) to
describe the situation and request
that assistance be sent to the location.
*: In some cases, the call cannot be

made. (P.70)

n Manual Emergency Calls

In the event of an emergency, press
the “SOS” button to call the eCall
A Microphone
B “SOS” button*
C Indicator lights

control center.* The answering
operator will determine your vehicle’s location, assess the situation,
and dispatch the necessary assis-

1

For safety and security

eCall is a telematics service
that uses Global Navigation
Satellite System (GNSS) data
and embedded cellular technology to enable the following
emergency calls to be made:
Automatic emergency calls
(Automatic Collision Notification) and manual emergency
calls (by pressing the “SOS”
button). This service is
required by European Union
Regulations.

69

70

1-3. Emergency assistance

tance required.
Make sure to open the cover before
pressing the “SOS” button.

ing or the backup battery may be
depleted.
 If the red indicator light blinks for
approximately 30 seconds during
an Emergency Call, the call has
been disconnected or the cellular
network signal is weak.
WARNING
n When the Emergency Call may

If you accidentally press the “SOS” button, tell the operator that you are not
experiencing an emergency.
*: In some cases, the call cannot be

made. (P.70)

Indicator lights
When the power switch is turned to
ON, the red indicator light will illuminate for 10 seconds and then the
green indicator light will illuminate,
indicating that the system is enabled. The indicator lights indicate
the following:
 If the green indicator light illuminates and stays on, the system is
enabled.
 If the green indicator light
flashes, an automatic or manual
Emergency Call is being made.
 If the red indicator light illuminates and a buzzer sounds 5
times (on some models) at any
time other than immediately after
the power switch is turned to ON,
the system may be malfunction-

not be made
l It may not be possible to make
Emergency Calls in any of the following situations. In such cases,
report to emergency services provider (112 system etc.) by other
means such as nearby public
phones.
• Even when the vehicle is in the cellular phone service area, it may be
difficult to connect to the eCall control center if the reception is poor or
the line is busy. In such cases, even
though the system attempts to connect to the eCall control center, you
may not be able to connect to the
eCall control center to make Emergency Calls and contact emergency
services.
• When the vehicle is out of the cellular phone service area, the Emergency Calls cannot be made.
• When any related equipment (such
as the “SOS” button panel, indicator
lights, microphone, speaker, DCM,
antenna, or any wires connecting
the equipment) is malfunctioning,
damaged or broken, the Emergency Call cannot be made.

1-3. Emergency assistance

WARNING

l If the 12-volt battery’s voltage

decreases or there is a disconnection, the system may not be able to
connect to the eCall control center.

l The Emergency Call system might
not work outside of EU area,
depending on the available infrastructure in the country.

n When the Emergency Call sys-

tem is replaced with a new one
The Emergency Call system should
be registered. Contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

n For your safety
l Please drive safely.

The function of this system is to
assist you in making the Emergency Call in case of accidents
such as traffic accidents or sudden
medical emergencies, and it does
not protect the driver or passengers
in any way. Please drive safely and
fasten your seatbelts at all times for
your safety.

l In case of an emergency, make
lives the top priority.

l If you smell anything burning or

other unusual smells, leave the
vehicle and evacuate to a safe area
immediately.

l If the airbags deploy when the sys-

tem is operating normally, the system makes emergency call. The
system also makes emergency call
when the vehicle is struck from the
rear or rolls over, even if the airbags
do not deploy.

l For safety, do not make the Emer-

gency Call while driving.
Making calls during driving may
cause mishandling of the steering
wheel, which may lead to unexpected accidents.
Stop the vehicle and confirm the
safety of your surroundings before
making the Emergency Call.

l When changing fuses, please use

the specified fuses. Using other
fuses may cause ignition or smoke
in the circuit and lead to a fire.

l Using the system while there is

smoke or an unusual smell may
cause a fire. Stop using the system
immediately and consult any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

NOTICE
n To prevent damage
Do not pour any liquids onto the
“SOS” button panel, etc. and do not
impact it.

n If the “SOS” button panel,

speaker or microphone malfunctions during an Emergency Call
or manual maintenance check
It may not be possible to make Emergency Calls, confirm the system status, or communicate with the eCall
control center operator. If any of the
above equipment is damaged, please
consult any authorized Toyota retailer
or Toyota authorized repairer, or any
reliable repairer.

1

For safety and security

• During an Emergency Call, the system makes repeated attempts to
connect to the eCall control center.
However, if it cannot connect to the
eCall control center due to poor
radio wave reception, the system
may not be able to connect to the
cellular network and the call may
finish without connecting. The red
indicator light will blink for approximately 30 seconds to indicate this
disconnection.

71

72

1-3. Emergency assistance

System overview of added service
n Data processing flow

A Server
B Storage
C Processing

DCM
1 Activation of data sharing is done by enabling a service on the “MyT by
Toyota” app or purchasing a service that requires data collection.
2 Server activates the service in the DCM and defines which vehicle data
to collect.
3 Defined vehicle data is collected by the DCM.
4 Data is shared with the server.
5 Data is stored in the server.
6 Data is processed in the server for fulfilling the service.
7 Processed data is presented to the customer.
For a list of eligible services in your region please visit the Toyota website or
contact any authorized Toyota retailer or Toyota authorized repairer, or any
reliable repairer.

1-3. Emergency assistance

73

Implementing Regulation
Implementing Regulation Annex1 PART3 User Information

Conformity

1. DESCRIPTION OF THE ECALL IN-VEHICLE SYSTEM
1.1.

Overview of the 112-based eCall in-vehicle system, its operation and functionalities

1.2.

The 112-based eCall service is a public service
of general interest and is accessible free of
charge.

O

1.3.

The 112-based eCall in-vehicle system is activated by default. It is activated automatically by
means of in-vehicle sensors in the event of a
severe accident. It will also be triggered automatically when the vehicle is equipped with a TPS
system which does not function in the event of a
severe accident.

O

1.4.

The 112-based eCall in-vehicle system can also
be triggered manually, if needed. Instructions for
manual activation of the system

O

1.5.

In the event of a critical system failure that would
disable the 112-based eCall in-vehicle system,
the following warning will be given to the occupants of the vehicle

O

1

For safety and security

2. INFORMATION ON DATA PROCESSING

O

74

1-3. Emergency assistance
Implementing Regulation Annex1 PART3 User Information

Conformity

2.1.

Any processing of personal data through the
112-based eCall in-vehicle system shall comply
with the personal data protection rules provided
for in Directives 95/46/EC and 2002/58/EC, and
in particular, shall be based on the necessity to
protect the vital interests of the individuals in
accordance with Article 7(d) of Directive
95/46/EC.

O

2.2.

Processing of such data is strictly limited to the
purpose of handling the emergency eCall to the
single European emergency number 112.

O

2.3. Types of data and its recipients

2.3.1.

The 112-based eCall in-vehicle system may collect and process only the following data: Vehicle
Identification Number, Vehicle type (passenger
vehicle or light commercial vehicle), Vehicle propulsion storage type (gasoline/diesel/CNG/LPG/electric/hydrogen), Vehicle last
three locations and direction of travel, Log file of
the automatic activation of the system and its
timestamp.

O

2.3.2.

Recipients of data processed by the 112-based
eCall in-vehicle system are the relevant public
safety answering points designated by the
respective public authorities of the country on
which territory they are located, to first receive
and handle eCalls to the single European emergency number 112.

O

1-3. Emergency assistance
Implementing Regulation Annex1 PART3 User Information

75

Conformity

2.4. Arrangements for data processing
The 112-based eCall in-vehicle system is
designed in such a way as to ensure that the
data contained in the system memory is not
available outside the system before an eCall is
triggered.

O

2.4.2.

The 112-based eCall in-vehicle system is
designed in such a way as to ensure that it is not
traceable and not subject to any constant tracking in its normal operation status.

O

2.4.3.

The 112-based eCall in-vehicle system is
designed in such a way as to ensure that data in
the system internal memory is automatically and
continuously removed.

O

2.4.3.1.

The vehicle location data is constantly overwritten in the internal memory of the system so as
always to keep maximum of the last three
up-to-date locations of the vehicle necessary for
the normal functioning of the system.

O

2.4.3.2.

The log of activity data in the 112-based eCall
in-vehicle system is kept for no longer than necessary for attaining the purpose of handling the
emergency eCall and in any case not beyond 13
hours from the moment an emergency eCall was
initiated.

O

2.4.1.

1

For safety and security

76

1-3. Emergency assistance
Implementing Regulation Annex1 PART3 User Information

Conformity

2.5. Modalities for exercising data subject’s rights

2.5.1.

The data subject (the vehicle’s owner) has a right
of access to data and as appropriate to request
the rectification, erasure or blocking of data, concerning him or her, the processing of which does
not comply with the provisions of Directive
95/46/EC. Any third parties to whom the data
have been disclosed have to be notified of such
rectification, erasure or blocking carried out in
compliance with this Directive, unless it proves
impossible or involves a disproportionate effort.

O

2.5.2.

The data subject has a right to complain to the
competent data protection authority if he or she
considers that his or her rights have been
infringed as a result of the processing of his or
her personal data.

O

2.5.3.

Contact service responsible for handling access
requests (if any):
P.77

O

3. INFORMATION ON THIRD PARTY SERVICES AND OTHER ADDED VALUE
SERVICES (IF FITTED)

1-3. Emergency assistance
Implementing Regulation Annex1 PART3 User Information

Conformity

3.1.

Description of the operation and the functionalities of the TPS system/added value service

P.72

3.2.

Any processing of personal data through the
TPS system/other added value service shall
comply with the personal data protection rules
provided for in Directives 95/46/EC and
2002/58/EC.

O

3.2.1.

Legal basis for the use of TPS system and/or
added value services and for processing data
through them

The European Union
General
Data Protection Regulation

3.3.

The TPS system and/or other added value services shall process personal data only on the
base of the explicit consent of the data subject
(the vehicle’s owner or owners).

O

3.4.

Modalities for data processing through TPS system and/or other added value services, including
any necessary additional information regarding
traceability, tracking and processing of personal
data

P.72

3.5.

The owner of a vehicle equipped with a TPS
eCall system and/or other added value service in
addition to the 112-based eCall in-vehicle system
has the right to choose to use the 112-based
eCall in-vehicle system rather than the TPS eCall
system and the other added value service.

O

3.5.1.

Contact details for handling TPS eCall system
deactivation requests

N/A

Country

Contact information

Austria

datenschutz@toyota-frey.at

Belgium/Luxembourg

privacy@toyota.be

Croatia

dpcp@toyota.hr

Czech Republic/Hungary/Slovakia adatvedelem@toyota-ce.com

1

For safety and security

n Service responsible for handling access requests

77

78

1-3. Emergency assistance
Country

Contact information

Denmark

toyota@toyota.dk og

Estonia

privacy@toyota.ee

Finland

tietosuoja@toyota.fi

France

delegue.protectiondonnees@toyota-europe.com

Germany

Toyota.Datenschutz@toyota.de

Great Britain

privacy@tgb.toyota.co.uk

Greece

customer@toyota.gr

Iceland

personuvernd@toyota.is

Ireland

customerservice@toyota.ie

Italy

tmi.dpo@toyota-europe.com

Netherlands

www.toyota.nl/klantenservice

Norway

personvern@toyota.no

Poland

klient@toyota.pl

Portugal

gestaodadospessoais@toyotacaetano.pt

Romania

relatii.clienti@toyota.ro

Slovenia

dpcp@toyota.si

Spain

clientes@toyota.es/dpo@toyota.es.

Sweden

integritet@toyota.se

Switzerland

info@toyota.ch

n Certification
P.710

1-3. Emergency assistance

ERA-GLONASS/EVAK*1, 2,
3

*1: If equipped
*2: Operates within regions offering

*3: The system name differs depending

on the country.

The Emergency Call system is
a device installed on a vehicle
to determine its location and
movement direction (using
GLONASS [Global Navigation
Satellite System] and GPS
[Global Positioning System]
signals), and ensure the generation and transmission of vehicle information (in a
nonadjustable form) in case of
traffic accidents or other incidents on motor roads in the
countries offering emergency
notification services. In addition, it ensures two-way voice
communication between the
vehicle and an
ERA-GLONASS/EVAK system
operator through cellular networks (GSM).

This service is mandatory
according to the technical regulations of the Customs Union.

System components

A Microphone
B “SOS” button*
C Indicator lights
*: This button is intended for communi-

cation with the
ERA-GLONASS/EVAK system operator.
Other SOS buttons available in other
systems of a motor vehicle do not
relate to the device and are not
intended for communication with the
ERA-GLONASS/EVAK system operator.

1

For safety and security

emergency notification services. Ask
any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer for details.

Automatic Emergency Calls
(via Automatic Collision Notification) and manual Emergency
Calls (by pressing the “SOS”
button) can be made to the
ERA-GLONASS/EVAK control
center.

79

80

1-3. Emergency assistance

Emergency Notification Services
n Automatic Emergency Calls

If any airbag deploys, the system is
designed to automatically call the
ERA-GLONASS/EVAK control
center.* The answering operator
receives the vehicle’s location, the
time of the incident and the vehicle
VIN, and attempts to speak with the
vehicle occupants to assess the situation. If the occupants are unable
to communicate, the operator automatically treats the call as an emergency and contacts the nearest
emergency services provider (112
system etc.) to describe the situation and request that assistance be
sent to the location.
*: In some cases, the call cannot be

made. (P.81)

n Manual Emergency Calls

In the event of an emergency, press
the “SOS” button to call the
ERA-GLONASS/EVAK control
center.* The answering operator will
determine your vehicle’s location,
assess the situation, and dispatch
the necessary assistance required.
If you accidentally press the “SOS” button, tell the operator that you are not
experiencing an emergency.

Indicator lights
When the power switch is turned to
ON, the red indicator light will illuminate for 10 seconds and then the
green indicator light will illuminate,
indicating that the system is enabled. The indicator lights indicate
the following:
 If the green indicator light illuminates and stays on, the system is
enabled.
 If the green indicator light flashes
twice per second, an automatic
or manual Emergency Call is
being made.
 If no indicator lights illuminate,
the system is not enabled.
 If the red indicator light illuminates at any time other than
immediately after the power
switch is turned to ON, the system may be malfunctioning or
the backup battery may be
depleted. Contact any authorized
Toyota retailer or Toyota authorized repairer, or any reliable
repairer.
 If the red indicator light blinks for
approximately 30 seconds during
an Emergency Call, the call has
been disconnected or the cellular
network signal is weak.

*: In some cases, the call cannot be

made. (P.81)

Device test mode
A test mode is provided for to check
the performance of the Emergency

1-3. Emergency assistance

Call system. To test the device,
contact any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.
WARNING
n When the Emergency Call may

• When the vehicle is out of the cellular phone service area, the Emergency Calls cannot be made.
• When any related equipment (such
as the “SOS” button panel, indicator
lights, microphone, speaker, DCM,
antenna, or any wires connecting
the equipment) is malfunctioning,
damaged or broken, the Emergency Call cannot be made.

• This device may not function if a
shock is applied to it.

l If the 12-volt battery’s voltage

decreases or there is a disconnection, the system may not be able to
connect to the
ERA-GLONASS/EVAK control
center.

n When the Emergency Call sys-

tem is replaced with a new one
The Emergency Call system should
be registered. Contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

n For your safety
l Please drive safely.

The function of this system is to
assist you in making the Emergency Call in case of accidents
such as traffic accidents or sudden
medical emergencies, and it does
not protect the driver or passengers
in any way. Please drive safely and
fasten your seatbelts at all times for
your safety.

l In case of an emergency, make
lives the top priority.

l If you smell anything burning or

other unusual smells, leave the
vehicle and evacuate to a safe area
immediately.

1

For safety and security

not be made
l It may not be possible to make
Emergency Calls in any of the following situations. In such cases,
report to emergency services provider (112 system etc.) by other
means such as nearby public
phones.
• Even when the vehicle is in the cellular phone service area, it may be
difficult to connect to the
ERA-GLONASS/EVAK control
center if the reception is poor or the
line is busy. In such cases, even
though the system attempts to connect to the ERA-GLONASS/EVAK
control center, you may not be able
to connect to the
ERA-GLONASS/EVAK control
center to make Emergency Calls
and contact emergency services.

• During an Emergency Call, the system makes repeated attempts to
connect to the
ERA-GLONASS/EVAK control
center. However, if it cannot connect to the ERA-GLONASS/EVAK
control center due to poor radio
wave reception, the system may
not be able to connect to the cellular network and the call may finish
without connecting. The red indicator light will blink for approximately
30 seconds to indicate this disconnection.

81

82

1-3. Emergency assistance

WARNING
l Since the system detects shocks,

the automatic reporting may not
always occur synchronized with the
operation of the airbag system. (If
the vehicle is struck from behind,
etc.)

l For safety, do not make the Emer-

gency Call while driving.
Making calls during driving may
cause mishandling of the steering
wheel, which may lead to unexpected accidents.
Stop the vehicle and confirm the
safety of your surroundings before
making the Emergency Call.

l When changing fuses, please use

the specified fuses. Using other
fuses may cause ignition or smoke
in the circuit and lead to a fire.

l Using the system while there is

smoke or an unusual smell may
cause a fire. Stop using the system
immediately and consult any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

NOTICE
n To prevent damage
Do not pour any liquids onto the
“SOS” button panel, etc. and do not
impact it.

n If the “SOS” button panel,

speaker or microphone malfunctions during an Emergency Call
or manual maintenance check
It may not be possible to make Emergency Calls, confirm the system status, or communicate with the
ERA-GLONASS/EVAK control center
operator. If any of the above equipment is damaged, please consult any
authorized Toyota retailer, Toyota
authorized repairer, or any reliable
repairer.
