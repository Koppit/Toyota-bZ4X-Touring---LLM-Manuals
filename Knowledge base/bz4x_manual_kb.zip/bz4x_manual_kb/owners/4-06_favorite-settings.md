# 4-6. Favorite settings

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 4: Before driving, pages 221–226

4-6. Favorite settings

221

Driving position memory

4-6.Favorite settings

This feature automatically
adjusts the positions of the
driver’s seat and outside rear
view mirrors to make entering
and exiting the vehicle easier
or to suit your preferences.
Driving positions can be
recorded for 3 drivers that has
been registered for My Settings.

For details about My Settings,
refer to P.224.

Enabling easier driver entry
and exit (power easy access
system)
When all of the following have been
performed, the driver’s seat is automatically adjusted to a position that
allows driver to enter and exit the
vehicle easily.
• The shift position has been
shifted to P.
• The power switch has been
turned to OFF.
• The driver’s seat belt has been
unfastened.

n Operation of the power easy

access system
When exiting the vehicle, the power
easy access system may not operate if
the seat is already close to the rearmost
position, etc.

n Customization
The seat movement amount settings of
the power easy access system can be
customized. (P.675)

WARNING
n While the power easy access

system is operating and the
steering wheel and seat is moving
Be careful not to get body parts or
luggage caught. Failure to do so may
cause an injury or damage to the luggage.

4

Before driving

When electronic key assignment is registered for My Settings, the driving position for
each driver can be recalled
(memory recall function).

When any of the following has been
performed, the driver’s seat automatically return to it original position.
• The power switch has been
turned to ACC or ON.
• The driver’s seat belt has been
fastened.

222

4-6. Favorite settings

Recording a driving position
into memory button
1 Check that the shift position is in
P.
2 Turn the power switch to ON.
3 Adjust the driver’s seat and outside rear view mirrors to the
desired positions.
4 While pressing the “SET” button, or within 3 seconds after the
“SET” button is pressed, press
button “1” or “2” until the buzzer
sounds.

WARNING
n Seat adjustment caution
Take care during seat adjustment so
that the seat does not strike the rear
passenger or squeeze your body
against the steering wheel.

Recalling a driving position
1 Check that the shift position is in
P.
2 Turn the power switch to ON.
3 Press one of the buttons for the
driving position you want to
recall until the buzzer sounds.

If the selected button has already been
preset, the previously recorded position
will be overwritten.

n To stop the position recall opera-

n Seat position that can be memo-

tion part-way through
Perform any of the following operations:

rized (P.196)
The adjusted positions other than the
position adjusted by lumbar support
switch can be recorded.

l Press the “SET” button.
l Press button “1” or “2”.
l Operate any of the seat adjustment

n In order to correctly use the driving

n Using the voice control system*

position memory function
If a seat position is already in the
fur-thest possible position and the seat
is operated in the same direction, the
recorded position may be slightly differ-ent when it is recalled.

switches.

*: If equipped

The following operations can be performed using the voice control system:

l Driving position registration
l Driving position recall (only when the

shift position is in P)
For details, refer to the “Multimedia

4-6. Favorite settings
owner’s manual”

n Operating the driving position

memory after turning the power
switch off
Recorded seat positions can be activated up to 180 seconds after the
driver’s door is opened and another 60
seconds after it is closed again.

n When recalling the driving position
Take care so that a head restraint does
not contact the ceiling or a sun visor.

n If the 12-volt battery is discon-

nected
The memorized positions are erased

n When the recorded seat position

n Jam protection function
While the driving position is recalled or
the power easy access system is operating, if an object is stuck behind the
front seat, the front seat will stop and
then slightly move forward. When the
jam protection function operates, the
seat stops at a position other than the
set seat position. Check the seat position.

Recalling a driving position
automatically when getting
in the vehicle (memory
recall function) (driver’s seat
only)
n When an individual is identi-

fied using My Settings:
The driving positions can be automatically recalled for each driver
registered in My Settings. (P.224)

 Driving position registration procedure
When the shift position is shifted to P
after driving the vehicle, the current
driving position will be recorded.

 Driving position recall procedure
1 Carry only the key that has been
assigned and registered in My
Settings, and then unlock and
open the driver’s door using the
smart entry & start system or
wireless remote control.
The driving position will move to the
recorded position.
If the driving position is in a position
that has already been recorded, the
seat will not move.

2 Turn the power switch to ACC or
ON.
The seat will move to the recorded
position.

 Memory recall function
cancelation procedure
How to cancel the memory call function
varies depending on the authentication
device.
For details, refer to the “Multimedia
owner’s manual”.

n Recalling the driving position using
the memory recall function

l The timing of operation may differ

depending on the device used to identify an individual.

l As a driving position can be registered
to each electronic key, if 2 or more
keys are carried, the recall driving
position may different.

4

Before driving

cannot be recalled
The seat position may not be recalled in
some situations when the seat position
is recorded in a certain range. For
details, contact any authorized Toyota
retailer or Toyota authorized repairer, or
any reliable repairer.

223

224

4-6. Favorite settings

My Settings

 Bluetooth® devices
An individual can be identified if the

Drivers are identified using
devices such as electronic
keys to store the driving position and vehicle settings for
each. Then the information can
be recalled the next time the
vehicle is driven.
Authentication devices can be
assigned in advance to drivers
so that they can drive using
their preferred settings.
Settings for 3 drivers can be
stored in My Settings.
For information on authentication devices registration/ deletion, changing the driver’s
name, initializing driver registered settings, manually
switching drivers and deleting
drivers registration, refer to the
“Multimedia owner’s manual”.

same Bluetooth® device that was used
as a hands-free phone the last time the
vehicle was entered is connected to the
multimedia system.
For information on how to connect
Bluetooth® devices, refer to the “Multimedia owner’s manual”.
If an individual is identified by detecting
an electronic key, identification by
Bluetooth® device will not be performed.
*: If equipped

Recalled functions
When an individual is identified
from an authentication device, settings for the following functions are
recalled:
 Driving position (memory recall
function)

Types of assigned authentication devices

After an individual is identified, the driving position that was set when driving
was last completed is recalled when
either of the following operations is performed.

An individual can be identified
using the following authentication
devices:

Identification using electronic key: The
driver’s door is unlocked and opened
using the smart entry & start system or
wireless remote control.

 Electronic key

 Vehicle settings that can be

An individual is identified when the
smart entry & start system detects their
electronic key.

 Face identification*
Individuals are identified by detecting
the face from the driver monitor.

setusing the multimedia display*
When an individual is identified, the
vehicle settings used when the power
switch was last turned off are recalled.

 Safe driving support function*

4-6. Favorite settings

225

When an individual is identified, the
vehicle settings used when the power
switch was last turned off are recalled.
*: Some settings are excluded

4

Before driving

226

4-6. Favorite settings
