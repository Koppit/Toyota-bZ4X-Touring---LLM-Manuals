# 4-4. Adjusting the steering wheel and mirrors

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 4: Before driving, pages 203–217

4-4. Adjusting the steering wheel and mirrors

Steering wheel

203

4-4.Adjusting the steering wheel and mirrors

Adjustment procedure
1 Hold the steering wheel and
push the lever down.

n After adjusting the steering

wheel
Make sure that the steering wheel is
securely locked. Otherwise, the steering wheel may move suddenly, possibly causing an accident, resulting in
death or serious injury.

Sounding the horn
Press on or close to the
mark.

After adjustment, pull the lever up to
secure the steering wheel.

WARNING
n Caution while driving
Do not adjust the steering wheel while
driving.
Doing so may cause the driver to mishandle the vehicle and cause an accident, resulting in death or serious
injury.

4

Before driving

2 Adjust to the ideal position by
moving the steering wheel horizontally and vertically.

204

4-4. Adjusting the steering wheel and mirrors

Inside rear view mirror*
*

: If equipped

The rear view mirror’s position
can be adjusted to enable sufficient confirmation of the rear
view.

Adjusting the height of rear
view mirror
The height of the rear view mirror
can be adjusted to suit your driving
posture.
Adjust the height of the rear view
mirror by moving it up and down.

WARNING
n Caution while driving
Do not adjust the position of the mirror while driving.
Doing so may lead to mishandling of
the vehicle and cause an accident,
resulting in death or serious injury.

Anti-glare function
Responding to the level of brightness of the headlights of vehicles
behind, the reflected light is automatically reduced.

This function turns on each time the
power switch is turned to ON.

n To prevent sensor error
To ensure that the sensors operate
properly, do not touch or cover them.

4-4. Adjusting the steering wheel and mirrors

Digital Rear-view Mirror*
*

: If equipped

The Digital Rear-view Mirror is
a system that uses the camera
on the rear of the vehicle and
displays its image on the display of the Digital Rear-view
Mirror.

205

l As the range of the image displayed
by the Digital Rear-view Mirror is
different from that of the mirror,
make sure to check this difference
before driving.

System components

The Digital Rear-view Mirror
can be changed between mirror mode and digital mirror
mode by operating the lever.

WARNING
Observe the following precautions.
Failure to do so may result in death or
serious injury.

n Before using the Digital Rearview
Mirror
l Make sure to adjust the mirror
before driving. (P.207)
• Change to mirror mode and adjust
the position of the Digital Rear-view
Mirror so that the area behind your
vehicle can be viewed properly.
• Change to digital mirror mode and
adjust the display settings.

A Camera indicator
Indicates that the camera is operating
normally.

B Icon display area
Displays icons, adjusting gauge, etc.
(P.207)

C Select/adjust button
Press to change the setting of the item
you want to adjust.

Menu button
Press to display the icon display area
and select the item you want to adjust.

Lever
Operate to change between digital mirror mode and mirror mode.

Changing modes
Operate the lever to change
between digital mirror mode and
mirror mode.

4

Before driving

The Digital Rear-view Mirror
allows the driver to see the
rear view despite obstructions,
such as the head restraints or
luggage, ensuring rear visibility. Also, the rear seats are not
displayed and privacy of the
passengers is enhanced.

206

4-4. Adjusting the steering wheel and mirrors
roof (if equipped).

l Any of the following conditions may

1 Digital mirror mode
Displays an image of the area behind
the vehicle.
will illuminate in this mode.

2 Mirror mode
Turns off the display of the Digital Rearview Mirror allows it to be used as an
mirror.

n Digital mirror mode operating con-

dition
The power switch is turned to ON.
When the power switch is changed from
ON to OFF or ACC, the image will disappear after several seconds.

n When using the Digital Rearview
Mirror in digital mirror mode

l If it is difficult to see the displayed

image due to light reflected off the
Digital Rear-view Mirror, the camera
being dirty or covered with water droplets, dust, etc., or if lights of a vehicle
behind your vehicle or the displayed
image are bothering you, change to
mirror mode.

l When it is raining, if the image is

unclear due to water on the rear window, operate the rear wiper.

l When the back door is open, the Digital Rear-view Mirror image may not
display properly. Before driving, make
sure the back door is closed.

l If the display is difficult to see due to
reflected light, close the electronic
sunshade for the panoramic moon

occur when driving in the dark, such
as at night. None of them indicates
that a malfunction has occurred.
• Colors of objects in the displayed
image may differ from their actual
color.
• Depending on the height of the lights
of the vehicle behind, the area around
the vehicle may appear white and
blurry.
• Automatic image adjustment for
brighter surrounding image may
cause flickering.
If it is difficult to see the displayed
image or flickering bothers you, change
to mirror mode.

l The Digital Rear-view Mirror may

become hot while it is in digital mirror
mode. This is not a malfunction.

l Depending on your physical condition
or age, it may take longer than usual
to focus on the displayed image. In
this case, change to mirror mode.

l Do not let passengers stare at the displayed image when the vehicle is
being driven, as doing so may cause
motion sickness.

n When the system malfunctions
If the symbol shown in the illustration is
displayed when using the Digital
Rear-view Mirror in digital mirror mode,
the system may be malfunctioning. The
symbol will disappear in a few seconds.
Operate the lever, change to mirror
mode and have the vehicle inspected by
any authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

207

4-4. Adjusting the steering wheel and mirrors

Adjusting the mirror
n Adjusting the mirror height

The height of the rear view mirror
can be adjusted to suit your driving
posture.
Change to mirror mode, adjusting
the height of the rear view mirror by
moving it up and down.

3 Press
or
change the setting.

to

The icons will disappear if a button is
not operated for approximately 5 seconds or more.
Icons

Settings
Select to adjust the
brightness of the display.
Select to adjust the area
displayed up/down.
Select to adjust the area
displayed to the left/right.
Select to adjust the
angle of the displayed
image.

4

: The area

mode)
Settings of the display in the digital
mirror mode, on/off operation of the
automatic anti-glare function, etc.
can be changed.
1 Press the menu button.
The icons will be displayed.

moves one phase clockwise by 1 push
: The area
moves one phase counter clockwise by 1 push
Select to zoom in/out the
displayed image.
Select to enable/disable
the automatic anti-glare
function.*
Responding to the
brightness of the headlights of vehicles behind,
the reflected light is automatically adjusted.

2 Press the menu button repeatedly and select the item you
want to adjust.

The automatic anti-glare
function is enabled each
time the power switch is
changed to ON.
*: This is a function for the mirror mode,

however, the setting can also be

Before driving

n Display settings (digital mirror

208

4-4. Adjusting the steering wheel and mirrors

changed while using the digital mirror
mode.

n Enabling/disabling the auto-

matic anti-glare function (mirror mode)
The automatic anti-glare function in
the mirror mode can be enabled/disabled. The setting can be
changed in both the digital mirror
mode and the mirror mode.
 When using the digital mirror

mode
P.207

may appear distorted. This is not a
malfunction.

l If the brightness of the Digital Rear-

view Mirror is set too high, it may
cause eye strain. Adjust the Digital
Rear-view Mirror to an appropriate
brightness. If your eyes become tired,
change to mirror mode.

l The brightness of the Digital

Rear-view Mirror will change automatically according to the brightness of
the area in front of your vehicle.

n To prevent the light sensors from

malfunctioning
To prevent the light sensors from malfunctioning, do not touch or cover them.

 When using the mirror mode

1 Press the menu button.
The icons will be displayed.

WARNING
Observe the following precautions.
Failure to do so may result in death or
serious injury.

2 Press
or
to
enable (“ON”)/disable (“OFF”)
the automatic anti-glare function.
The icons will disappear if a button is
not operated for approximately 5 seconds or more.

n Adjusting the display (digital mirror
mode)

l The icons will disappear if a button is

not operated for approximately 5 seconds or more.

l If the displayed image is adjusted, it

n While driving
l Do not adjust the position of the

Digital Rear-view Mirror or adjust
the display settings while driving.
Stop the vehicle and operate the
Digital Rear-view Mirror control
switches.
Failure to do so may cause a steering wheel operation error, resulting
in an unexpected accident.

4-4. Adjusting the steering wheel and mirrors

WARNING
l Always pay attention to the vehi-

cle’s surroundings.
The size of the vehicles and other
objects may look different when in
digital mirror mode and mirror mode.
When backing up, make sure to
directly check the safety of the area
around your vehicle, especially
behind the vehicle.
Additionally, if a vehicle approaches
from the rear in the dark, such as at
night, the surrounding area may
appear dim.

Cleaning the Digital Rearview Mirror
n Cleaning the mirror surface

If the mirror surface is dirty, the
image on the display may be difficult to see.
Clean the mirror surface gently
using a soft dry cloth.

NOTICE
n To prevent the camera from malfunctioning

l Observe the following precautions,

otherwise the Digital Rear-view Mirror may not operate properly.

• Do not strike or hit the camera or
subject it to a strong impact, as the
camera installation position and
angle may be changed because the
camera unit is designed to be
waterproof.
• Do not remove, disassemble or
modify the camera.
• Do not allow an organic solvent, car
wax, window cleaner or glass coating to adhere to the camera. If this
happens, wipe it off as soon as possible.
• When cleaning the camera lens,
wipe the camera lens with a damp
soft cloth. When it is difficult to
clean it with a cloth, use a swab. Do
not strongly rub the camera lens, as
it may be scratched and will not be
able to transmit a clear image.
• When applying colored film (including transparent film) to the rear window glass, do not apply it to the
area in front of the camera. If film is
applied to the area in front of the
camera, the image from the camera
may not display properly.

l Do not subject the camera to a
n The camera
The camera for the Digital Rear-view
Mirror is located as shown.

strong impact as this could cause a
malfunction.
If this happens, have the vehicle
inspected by any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer as
soon as possible.

4

Before driving

n To prevent causes of fire
If the driver continues using the Digital Rear-view Mirror while smoke or
odor comes from the mirror, it may
result in fire. Stop using the system
immediately and contact any authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

209

210

4-4. Adjusting the steering wheel and mirrors

NOTICE
l Do not block the vent holes of the

mirror. Otherwise, the mirror may
be hot, leading to a malfunction or a
fire.

If you notice any symptoms
If you notice any of the following symptoms, refer to the following table for
the likely cause and the solution.
If the symptom is not resolved by the solution, have the vehicle inspected
by any authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

4-4. Adjusting the steering wheel and mirrors
Symptom

Likely cause
The mirror surface is dirty.

211

Solution
Clean the mirror surface
gently, using a soft dry
cloth.
Change to mirror mode.

Sunlight or headlights are shin- (If the light is coming
through the panoramic
ing directly into the Digital
moon roof [if equipped],
Rear-view Mirror.
close the sunshade or electronic sunshade.)

The image is difficult
to see.

4

Before driving

• The vehicle is in a dark area.
• The vehicle is near a TV
tower, broadcasting station,
electric power plant, or other
location where strong radio
waves or electrical noise
may be present.
• The temperature around the
camera is extremely
Change to mirror mode.
high/low.
• The ambient temperature is (Change back to digital mirror mode when the condiextremely low.
tions have improved.)
• It is raining or humid.
• Sunlight or headlights are
shining directly into the camera lens.
• The vehicle is under fluorescent lights, sodium lights,
mercury lights, etc.
• Exhaust gas is obstructing
the camera.

212

4-4. Adjusting the steering wheel and mirrors
Symptom

Likely cause

Solution

Have the vehicle inspected
Foreign matters such as water by any authorized Toyota
droplets or dust is on the cam- retailer or Toyota authorized repairer, or any reliaera lens.
ble repairer.

The luggage in the luggage
compartment is reflected off
the rear window glass and
obstructing the camera.
The image is difficult
to see.

 Change to mirror mode.
 Move the luggage to a
position where it does
not obstruct the camera
or cover it with a black
cloth to reduce the
amount it is reflected off
the rear window glass.
Change to mirror mode.

The rear window glass is
fogged up.

After defogging the rear
window using the rear window defogger (P.521),
use the digital mirror mode
again.

The outside of the rear window Use the rear window wiper
glass is dirty.
to remove dirt.

The image is out of
alignment.

The inside of the rear window
glass is dirty.

Have the vehicle inspected
by any authorized Toyota
retailer or Toyota authorized repairer, or any reliable repairer.

The back door is not fully
closed.

Fully close the back door.

Change to mirror mode and
have the vehicle inspected
The camera or its surrounding
by any authorized Toyota
area has received a strong
retailer or Toyota authorimpact.
ized repairer, or any reliable repairer.

4-4. Adjusting the steering wheel and mirrors
Symptom

Likely cause

Solution

The system may be malfunctioning.

Change to mirror mode and
have the vehicle inspected
by any authorized Toyota
retailer or Toyota authorized repairer, or any reliable repairer.

The display is dim and
is displayed.
goes off.

213

Reducing the cabin temperature is recommended
to reduce the temperature
of the mirror.

The Digital Rear-view Mirror is
(
will disappear when
extremely hot.
the mirror becomes cool.)
(The display will gradually
is displayed.

Change to mirror mode and
have the vehicle inspected
by any authorized Toyota
retailer or Toyota authorThe lever may be malfunction- ized repairer, or any reliable repairer.
ing.
(To change to mirror mode,
press and hold the menu
button for approximately 10
seconds.)

4

Before driving

The lever cannot be
operated properly.

become more dim. If the temIf
does not disappear
perature continues to increase,
even though the mirror is
the Digital Rearview Mirror will
cool, have the vehicle
turn off.)
inspected by any authorized Toyota retailer or
Toyota authorized repairer,
or any reliable repairer.

214

4-4. Adjusting the steering wheel and mirrors

Outside rear view mirrors
The rear view mirror’s position
can be adjusted to enable sufficient confirmation of the rear
view.

Adjustment procedure
 Type A

1 To select a mirror to adjust,
press the switch.

n When using the outside rear view

mirrors in a cold weather
When it is cold and the outside rear view
mirrors are frozen, it may not be possible to fold/extend them or adjust the mirror surface. Remove the ice, snow, etc.
covering the outside rear view mirrors.

A Left

WARNING
n Important points while driving
Observe the following precautions
while driving.
Failing to do so may result in loss of
control of the vehicle and cause an
accident, resulting in death or serious
injury.

B Right

2 To adjust the mirror, press the
switch.

l Do not adjust the mirrors while driving.

l Do not drive with the mirrors folded.
l Both the driver and passenger side

mirrors must be extended and properly adjusted before driving.

A Up
B Right
C Down

Left

4-4. Adjusting the steering wheel and mirrors
 Type B

1 When selecting the mirror to
adjust, the indicator on the
switch illuminates.

215

n Defogging the mirrors (vehicles

with outside rear view mirror defoggers)
The outside rear view mirrors can be
cleared using the mirror defoggers. Turn
on the rear window defogger to turn on
the outside rear view mirror defoggers.
(P.521)

n Automatic adjustment of the mirror

angle
A desired mirror face angle can be
entered to memory and recalled automatically by the driving position memory.
(P.221)

A Left
B Right
Pressing the same switch again will put
the switch in neutral.

n When the mirror defoggers are

operating (if equipped)
Do not touch the rear view mirror surfaces, as they can become very hot
and burn you.

Folding and extending the
mirrors (Type A)

A Up
B Right
C Down

Left
n Mirror angle can be adjusted when
The power switch is in ACC or ON.

1 Extends the mirrors
2 Folds the mirrors
Putting the outside rear view mirro
rfolding switch in the neutral position
sets the mirrors to automatic mode.
Automatic mode allows the folding or
extending of the mirrors to be linked to
locking/unlocking of the doors.

4

Before driving

2 To adjust the mirror, press the
switch.

WARNING

216

4-4. Adjusting the steering wheel and mirrors

Folding and extending the
mirrors (Type B)
n Using the switch

Press the switch to fold the mirrors.
Press it again to extend them to the
original position.

n When disconnecting and recon-

necting 12-volt battery terminals
The automatic folding/extending mirror
function will return to off as default. To
turn the function on, press the switch
again to select on.

n Customization
Some functions can be customized.
(P.675)

WARNING
n When a mirror is moving
To avoid personal injury and mirror
malfunction, be careful not to get your
hand caught by the moving mirror.

n Setting automatic mode

Press the “AUTO” switch to set
automatic mode.
When in automatic mode, the indicator

A will come on.

Automatic mode allows the folding
or extending of the mirrors to be
linked to locking/unlocking of the
doors.
Pressing the switch once more will
return to manual mode.

Linked mirror function when
reversing (if equipped)
When the mirror select switch is in
the “L” or “R” position, the outside
rear view mirrors will automatically
angle downwards when the vehicle
is reversing in order to give a better
view of the ground.
To disable this function, move the
mirror select switch to the neutral
position (between “L” and “R”).
n Adjusting the mirror angle

when the vehicle is reversing
With the shift position in R, adjust
the mirror angle at a desired position.
The adjusted angle will be memorized and the mirror will automatically tilt to the memorized angle
whenever the shift position is
shifted to R from next time.
The memorized downward tilt position

4-4. Adjusting the steering wheel and mirrors

217

of the mirror is linked to the normal
position (angle adjusted with the shift
position in other than R). Therefore, if
the normal position is changed after
adjustment, the tilt position will also
change.
When the normal position is changed,
readjust the angle in reversing.

4

Before driving
