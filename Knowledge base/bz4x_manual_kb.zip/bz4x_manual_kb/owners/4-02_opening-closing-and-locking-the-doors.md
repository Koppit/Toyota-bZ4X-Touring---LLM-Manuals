# 4-2. Opening, closing and locking the doors

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 4: Before driving, pages 173–195

4-2. Opening, closing and locking the doors

Side doors

4-2.Opening, closing and locking the doors

173

n Using the wireless remote

control

The vehicle can be locked and
unlocked using the entry function, wireless remote control or
door lock switches.

Unlocking and locking the
doors from the outside
n Smart entry & start system

Carry the electronic key to enable
this function.

1 Locks all the doors
Check that the door is securely locked.
Press and hold to close the windows.*

2 Unlocks all the doors
Press and hold to open the windows.*

4

*

1 Grip the front door handle or
rear door handle to unlock the
doors.*
Make sure to touch the sensor on the
back of the handle.
The doors cannot be unlocked for 3
seconds after the doors are locked.
*: The door unlock settings can be

changed.

2 Touch the lock sensor (the
indentation on the side of the
front door handle) to lock all the
doors.
Check that the door is securely locked.

n Switching the door unlock function
It is possible to set which doors the entry
function unlocks using the wireless
remote control.
1 Turn the power switch to OFF.
2 Cancel the intrusion sensor and tilt
sensor of the alarm system to prevent unintended triggering of the
alarm while changing the settings. (if
equipped) (P.85)
3 When the indicator light on the key
surface is not on, press and hold
or
for approximately 5
seconds while pressing and holding
.
The setting changes each time an operation is performed, as shown below.
(When changing the setting continuously, release the buttons, wait for at
least 5 seconds, and repeat step 3.)

Before driving

: This setting must be customized at
any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer.

174

4-2. Opening, closing and locking the doors

Multi-information
display/Beep

(Left-hand drive
vehicles)

(Right-hand drive
vehicles)
Exterior: Beeps 3
times

Exterior: Beeps
twice

Unlocking function
Holding the
driver’s door handle unlocks only
the driver’s door.

A buzzer sounds to indicate that the windows are operating.

n Security feature
If a door is not opened within approximately 30 seconds after the vehicle is
unlocked, the security feature automatically locks the vehicle again.

n When the door cannot be locked by

Holding any of the
passenger door
handles unlocks all
the doors.

the lock sensor on the surface of
the door handle
When the door cannot be locked even if
the lock sensor on the surface of the
door handle is touched by a finger, touch
the lock sensor with the palm.
When gloves are being worn, remove
the gloves.

Holding a door
handle unlocks all
the doors.

To prevent unintended triggering of the
alarm, unlock the doors using the wireless remote control and open and close
a door once after the settings have been
changed. (If a door is not opened within
30 seconds after
is pressed, the
doors will be locked again and the alarm
will automatically be set.)
In a case that the alarm is triggered,
immediately stop the alarm. (P.85)

n Impact detection door lock release

system
If the vehicle is involved in a severe
frontal or rear collision, manual release
handle operation will be enabled for all
of the doors.
Depending on the force of the impact or
the type of accident, however, the system may not operate.

n Operation signals
The emergency flashers flash to indicate
that the doors have been
locked/unlocked. (Locked: Once;
Unlocked: Twice)

n Open door warning buzzer
If an attempt to lock the doors is made
when a door is not fully closed, a buzzer
sounds continuously for 5 seconds.
Fully close the door to stop the buzzer,
and lock the vehicle once more.
n Setting the alarm (if equipped)
Locking the doors will set the alarm system. (P.85)
n Conditions affecting the operation

of the smart entry & start system or
wireless remote control
P.192

n If the smart entry & start system or
the wireless remote control does
not operate properly

l Use the mechanical key to lock and
unlock the doors. (P.656)

l Replace the key battery with a new
one if it is depleted. (P.604)

4-2. Opening, closing and locking the doors

n If the 12-volt battery is discharged
The doors cannot be locked and
unlocked using the smart entry & start
system or wireless remote control. Lock
or unlock the doors using the mechanical key. (P.656)
n Passenger and rear seat reminder
function

l In order to remind you not to forget

l The passenger and rear seat

reminder function determines that luggage, etc. has been placed in the front
passenger seat or a rear seat based
on opening and closing of the front
passenger door or a rear door. Therefore, depending on the situation, the
passenger and rear seat reminder
function may not operate and you may
still forget luggage, etc. in the front
passenger seat or a rear seat, or it
may operate unnecessarily.

l The rear seat reminder function can
be enabled/disabled. (P.675)

n Customization
Settings (e.g. unlocking function using a
key) can be changed. (Customizable
features:P.675)

WARNING
n To prevent an accident
Observe the following precautions
while driving the vehicle.
Failure to do so may result in a door
opening and an occupant falling out,
resulting in death or serious injury.
l Ensure that all doors are properly
closed and locked.

l Do not pull the inside handle of the

doors while driving.
Be especially careful for the front
doors, as the doors may be opened
even if the inside lock buttons are in
locked position

l Set the rear door child-protector

locks when children are seated in
the rear seats.

4

Before driving

luggage, etc. in the front passenger
seat or a rear seat, when the power
switch is turned off after any of the following conditions are met, a buzzer
will sound and a message will be displayed on the multi-information display for approximately 6 seconds.
• The EV system is started within
approximately 15 minutes after opening and closing a rear door or the front
passenger’s door.
• A rear door or the front passenger’s
door has been opened and closed
after the EV system was started.
The second reminder will not be activated if a rear door or the front passenger door was opened before the doors
are locked.
When this function is disabled by following the message displayed on the
meters, the passenger and rear seat
reminder will be off.
This function will be re-enabled when
the EV system is turned on.
However, if a front passenger door and
rear door is opened and then closed
within approximately 2 seconds, the
passenger and rear seat reminder function may not operate.

175

176

4-2. Opening, closing and locking the doors

WARNING
n When opening or closing a door
When closing a door, swing it closed
with slight force applied to it. If you
press on the door by hand to close it,
it may not be closed completely.
Check the surroundings of the vehicle
such as whether the vehicle is on an
incline, whether there is enough
space for a door to open and whether
a strong wind is blowing. When opening or closing the door, hold the door
handle tightly to prepare for any
unpredictable movement.
n When using the wireless remote

control and operating the power
windows
Operate the power windows after
checking to make sure that there is no
possibility of any passenger having
any of their body parts caught in the
windows. Also, do not allow children
to operate the wireless remote control. It is possible for children and
other passengers to get caught in the
power windows.

Unlocking and locking the
doors from the inside
n Using the door lock switches

1 Locks all the doors
2 Unlocks all the doors

n Using the inside lock buttons

1 Locks all the doors
2 Unlocks all the doors
The front doors can be opened by pulling the inside handle even if the lock
buttons are in the lock position.

n Locking the front doors from the

outside without a key
1 Move the inside lock button to the
lock position. (P.176)
2 Close the door.
The door cannot be locked if the power
switch is in ACC or ON, or the electronic
key is left inside the vehicle.
Depending on the position of the electronic key, the key may not be detected
correctly and the door may be locked.

n If a symbol indicating one or more

doors are open is shown on the
multi-information display
The hood or one or more of the doors
are not fully closed. The system also
indicates which doors are not fully
closed. If the vehicle reaches a speed of
5 km/h (3 mph), a buzzer sounds to indicate that the door(s) are not yet fully
closed. Make sure that the hood and all
the doors are closed.

4-2. Opening, closing and locking the doors

Rear door child-protector
lock
The door cannot be opened from
inside the vehicle when the lock is
set.

Function

Speed linked
door locking
function

177

Operation
All doors are automatically locked
when the vehicle
speed is approximately 20 km/h (12
mph) or higher.

All doors are automatically locked
Shift position
linked door lock- when shifting the
shift position other
ing function
than P.

These locks can be set to prevent children from opening the rear doors. Push
down on each rear door switch to lock
both rear doors.

Automatic door locking and
unlocking systems
The following functions can be set
or canceled:
For instructions on customizing, refer to
P.675.

All doors are automatically unlocked
when shifting the
shift position to P.

Driver’s door
linked door
unlocking function

All doors are automatically unlocked
when driver’s door is
opened within
approximately 45
seconds after turning the power switch
off.

4

Before driving

1 Unlock
2 Lock

Shift position
linked door
unlocking function

178

4-2. Opening, closing and locking the doors

Power back door
The power back door can be
opened using the power back
door opener switch, smart
entry & start system or wireless remote control.
WARNING
Observe the following precautions.
Failure to do so may result in death or
serious injury.

n Before driving the vehicle
Make sure that the power back door
is fully closed. If the power back door
is not fully closed, it may open unexpectedly while driving, causing an
accident.

n Caution while driving
l Keep the power back door closed

while driving.
If the power back door is left open, it
may hit nearby objects while driving
or luggage may be unexpectedly
thrown out, causing an accident.

l Never let anyone sit in the luggage
compartment. In the event of sudden braking, sudden swerving or a
collision, they are susceptible to
death or serious injury.

n When children are in the vehicle
Observe the following precautions.
Failure to do so may result in death or
serious injury.

l Do not allow children to play in the

luggage compartment.
If a child is accidentally locked in the
luggage compartment, they could
have heat exhaustion or other injuries.

l Do not allow a child to open or

close the power back door.
Doing so may cause the power back
door to move unexpectedly, or cause
the child’s hands, arms, head, or neck
to be caught by the closing power
back door.

n Operating the power back door
Observe the following precautions.
Failure to do so may cause parts of
the body to be caught, resulting in
death or serious injury.
l Remove any heavy loads, such as

snow and ice, from the power back
door before opening it. Failure to do
so may cause the power back door
to suddenly shut again after it is
opened.

l When opening or closing the power
back door, thoroughly check to
make sure the surrounding area is
safe.

l If anyone is in the vicinity, make

sure they are safe and let them
know that the power back door is
about to open or close.

l Use caution when opening or clos-

ing the power back door in windy
weather as it may move abruptly in
strong wind.

l The power back door may suddenly

shut if it is not opened fully, while on
a steep incline.
Make sure that the power back door
is secured before using the luggage
compartment.

4-2. Opening, closing and locking the doors

179

WARNING
l When closing the power back door,
take extra care to prevent your fingers, etc., from being caught.

1 Unlocks all the doors
l When closing the power back door,

make sure to press it lightly on its
outer surface. If the back door handle is used to fully close the power
back door, it may result in hands or
arms being caught.

The doors cannot be unlocked for 3
seconds after the doors are locked.

2 Locks all the doors
Check that the door is securely locked.

n Using the wireless remote

P.169

4

l Do not pull on the back door spindle

n Using the door lock switches

l If a bicycle carrier or similar heavy

P.176

object is attached to the power back
door, it may suddenly shut again
after being opened, causing someone’s hands, arms, head or neck to
be caught and injured. When
installing an accessory part to the
power back door, using a genuine
Toyota part is recommended.

Unlocking and locking the
power back door from the
outside
n Using the entry function

Carry the electronic key to enable
this function.

Unlocking and locking the
power back door from the
inside

Opening/closing the power
back door
n Using the wireless remote

control
Press and hold the switch for
approximately 1 second.
The power back door automatically
opens/closes.
The power back door can be operated
when it is locked*.
Pressing the switch while the power
back door is opening/closing will stop
the operation.

Before driving

(P.188) to close the power back
door, and do not hang on the back
door spindle.
Doing so may cause hands to be
caught or the back door spindle to
break, causing an accident.

180

4-2. Opening, closing and locking the doors

Pressing and holding the switch again
for approximately 1 second will operate
the power back door in the opposite
direction.
*: Opening of the power back door

when it is locked can be disabled by
a customized setting. (P.679)

n Opening the back door using

the back door opener switch
When the power back door is
unlocked: Press the back door
opener switch.
When the power back door is
locked: While carrying the electronic key on your person, press
and hold the power back door
opener switch.
The power back door automatically
opens.

n Opening/closing the power

back door from the inside

Pressing the switch while the power
back door is opening stops the operation.
Pressing the switch again will open the
back door automatically.

Press and hold the switch for
approximately 1 second.
A buzzer sounds and the power back
door automatically opens/closes.
Unlock the power back door before
operating.
Pressing the switch while the power
back door is opening/closing stops the
operation.
Pressing and holding the switch again
for approximately 1 second will operate
the power back door in the opposite
direction.

n Using the power back door

switch on the back door
 Close
Press the

switch.

The power back door automatically
closes.
Pressing the

switch while the

power back door is closing will stop the
operation.
When the switch is pressed again
during the halted operation, the back
door will perform the reverse operation.

4-2. Opening, closing and locking the doors

181

the back door (close & lock
[Walk-Away] function)*
*

: This setting can be customized at
any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer.

1 Close all of the doors except the
back door, carrying an electronic
 Close the back door and lock all
doors (close & lock function)

key and press the
switch on
the lower part of the back door.

Close all of the doors except the back
door, carrying an electronic key and

A different buzzer than the normal one
will sound and the close & lock
(Walk-Away) function will go into
standby.

press the

switch on the lower part

of the back door.
A different buzzer than the normal one
will sound and the power back door will
begin closing automatically. When the
power back door is closed, all of the
doors will lock simultaneously and
operation signals will indicate that all of
the doors have been locked.
switch while the

power back door is operating will stop
the operation.
When the

switch is pressed again

during the halted operation, the power
back door will be closed.

 Close the back door and lock all
doors after moving away from

Before driving

Pressing the

4

2 While the buzzer is sounding,
move away from the back door.
When the sensor detects that you are
away from the back door, the emergency flashers will flash, and the
buzzer will sound. Depending on the
direction of moving away from the back
door, the location and how to hold the
electronic key or circumstances, it may
not be detected properly.
All the doors other than the back door
will be locked, and after the back door
is closed, the back door will also be
locked. When all the doors have been
closed and locked, the buzzer will
sound and the emergency flashers will
flash.
The standby state is canceled if you do
not move away from the back door for
30 seconds. To operate the function
again, perform the procedure again

182

4-2. Opening, closing and locking the doors

from the beginning.
If the
switch is pressed after the
back door operation has stopped, the
close & lock (Walk-Away) function will
go into standby again.

to 27.6 in.) from the rear
bumper.

n Closing the power back door

using the back door handle
Lower the power back door using
the back door handle, then a
buzzer will sound and the power
back door will automatically close.
A Kick sensor
B Hands Free Power Back Door
operation detection area
C Smart entry & start system operation detection area (P.191)

n Using the kick sensor (vehi-

cles with Hands Free Power
Back Door)
When operating the Hands Free
Power Back Door, make sure that
the power switch is in OFF, the
Hands Free Power Back Door
operation is enabled (P.184) and
you are carrying an electronic key.
1 While carrying an electronic key,
stand within the smart entry &
start system operation range,
approximately 50 to 70 cm (19.7

2 Perform a kick operation by
moving your foot to within
approximately 10 cm (3.9 in.) of
the rear bumper and then pulling
your foot back after the buzzer
sounds.
 Perform the entire kick operation
within 1 second.
 The Hands Free Power Back
Door will not start operating while
a foot is detected under the rear
bumper.
 Operate the Hands Free Power
Back Door without contacting the
rear bumper with your foot.
 If another electronic key is in the
cabin or luggage compartment, it
may take slightly longer than nor-

4-2. Opening, closing and locking the doors

mal for the operation to occur.

183

n Power back door operating condi-

tions
The power back door can automatically
open and close under the following conditions:

l When the power back door system is
enabled. (P.179)

l When the power switch is in ON, in

A Kick sensor
B Hands Free Power Back Door
operation detection area

If a foot is moved under the rear
bumper while the back door is operating, the back door will stop moving.
If a foot is moved under the rear
bumper again during the halted operation, the back door will perform the
reverse operation.
The buzzer can be turned off with the
customize function. (P.675)

n Operation of the power back door
l A buzzer sounds and the emergency

flashers flash twice to indicate that the
power back door is opening/closing.
disabled, the power back door does
not operate but it can be opened and
closed by hand.

l When the power back door automatically opens, if an abnormality due to
people or objects is detected, operation will stop.

n Jam protection function
Sensors are equipped on both sides of
the power back door. If anything
obstructs the power back door while it is
closing, the back door will automatically
operate in the opposite direction or stop.

n Luggage compartment lights
l The luggage compartment lights turn
on when the back door is opened.

l When the power switch is turned off,

the lights will go off automatically after
20 minutes.

n Back door closer
In the event that the power back door is
left slightly open, the back door closer
will automatically close it to the fully
closed position.
Whatever the state of the power switch,
the power back door closer operates.

4

l When the power back door system is

n Fall-down protection function
While the power back door is opening
automatically, applying excessive force
to it will stop the opening operation to
prevent the power back door from suddenly shutting.

Before driving

3 When the kick sensor detects a
kicking motion with the foot, the
buzzer sounds, and when the
foot being pulled is detected, the
power back door automatically
fully opens or fully closes.

addition to the above for the opening
operations, the power back door operates for any of the following conditions:
• The parking brake is engaged.
• The brake pedal is depressed.
• The shift position is in P.

184

4-2. Opening, closing and locking the doors

n Back door closing assist
If the back door is lowered manually
when the back door is stopped at an
open position, the back door will fully
close automatically.
n Back door reserve lock function
This function is a function which
reserves locking of all doors, beforehand, when the power back door is
open.
When the following procedure is performed, all the doors except the power
back door are locked and then power
back door will also be locked at the
same time it is closed.
1 Close all of the doors, except the
power back door.
2 During the power back door closing
operation, lock the doors using the
smart entry & start system from the
side doors (P.173) or the wireless
remote control. (P.169)
Operation signals will indicate that all
the doors have been closed and locked.
(P.174)

l If the electronic key is placed inside

the vehicle after starting a close operation via the door reserve lock function, the electronic key may become
locked inside the vehicle.

l If the back door does not fully close

due to the operation of the jam protection function, etc., while the back door
is automatically closing after a door
reserve lock operation is performed,
the door reserve lock function is
canceled and all the doors will unlock.

l Before leaving the vehicle, make sure
that all the doors are closed and
locked.

n Close & lock function
When the power back door is open, this
function closes the power back door and
then locks all of the doors simultaneously.
When the following procedures are performed and there are no electronic keys
for the vehicle within the vehicle, all of
the doors will lock when the power back

door is completely closed.
1 Close all of the doors except the
power back door.
2 While carrying an electronic key,
press the
switch on the lower
part of the power back door
(P.180).
A different buzzer than the normal one
will sound and then the power back door
will begin closing automatically. When
the power back door is closed, all of the
doors will lock simultaneously and operation signals will indicate that all of the
doors have been locked.
The double locking system* will not
operate at this time.
*: If equipped

n Situations in which the close & lock

function may not operate properly
In the following situations, the close &
lock function may not operate properly:

l If the

switch on the lower part of
the power back door (P.180) is
pressed by a hand which is holding an
electronic key

l If the

switch on the lower part of
the power back door (P.180) is
pressed when the electronic key is in
a bag, etc. that is placed on the
ground

l If the

switch on the lower part of
the power back door (P.180) is
pressed with the electronic key not
near the vehicle.

n Hands Free Power Back Door oper-

ating conditions (vehicles with
Hands Free Power Back Door)
The Hands Free Power Back Door will
open/close automatically when the following conditions are met:

l The Hands Free Power Back Door
operation is enabled (P.190)

l The power switch is in OFF.
l The electronic key is within the opera-

4-2. Opening, closing and locking the doors
tional range. (P.191)

l A foot is put near the lower center part

185

when the vehicle is being washed or
in heavy rain

of the rear bumper and moved away
from the rear bumper.
The power back door may also be
operated by putting a hand, an elbow,
a knee, etc. near the lower center part
of the rear bumper and moving it away
from the rear bumper. Make sure to
put it close enough to the center part
of the rear bumper.

l When mud, snow, ice, etc. is attached

n Situations in which the Hands Free

If an accessory has been installed, turn
the Hands Free Power Back Door operation setting off.

Power Back Door may not operate
properly (vehicles with Hands Free
Power Back Door)
In the following situations, the Hands
Free Power Back Door may not operate
properly:

l When a foot remains under the rear
bumper

l If the rear bumper is strongly hit with a

l When standing excessively close to
the rear bumper

l When an external radio wave source
interferes with the communication
between the electronic key and the
vehicle (P.192)

l When charging from an external

power source or connecting the AC
charging cable

l When the vehicle is parked near an

electrical noise source which affects
the sensitivity of the Hands Free
Power Back Door, such as a pay parking spot, gas station, electrically
heated road, or fluorescent light

l When the vehicle is near a TV tower,
electric power plant, radio station,
large display, airport or other facility
that generates strong radio waves or
electrical noise

l When a large amount of water is

applied to the rear bumper, such as

a while near objects that may move
and contact the rear bumper, such as
plants

l When an accessory is installed to the
rear bumper

n Preventing unintentional operation

of the Hands Free Power Back Door
(vehicles with Hands Free Power
Back Door)
When an electronic key is in the operation range, the Hands Free Power Back
Door may operate unintentionally, so be
careful in the following situations.

l When a large amount of water is

applied to the rear bumper, such as
when the vehicle is being washed or
in heavy rain

l When dirt is wiped off the rear bumper
l When a small animal or small object,
such as a ball, moves under the rear
bumper

l When an object is moved from under
the rear bumper

l If someone is swinging their legs while
sitting on the rear bumper

l If the legs or another part of some-

one’s body contacts the rear bumper
while passing by the vehicle

l When the vehicle is parked near an

electrical noise source which affects
the sensitivity of the Hands Free
Power Back Door, such as a pay parking spot, gas station, electrically
heated road, or fluorescent light

l When the vehicle is near a TV tower,
electric power plant, radio station,
large display, airport or other facility
that generates strong radio waves or
electrical noise

4

Before driving

foot or is touched for a while

If the rear bumper has been touched for
a while, wait for a short time before
attempting to operate the Hands Free
Power Back Door again.

to the rear bumper

l When the vehicle has been parked for

186

4-2. Opening, closing and locking the doors

l When operated while a person is too
close to the rear bumper

3 Move the cover.

l If luggage, etc. is set near the rear
bumper

l If accessories or a vehicle cover is
installed/removed near the rear
bumper

l When the vehicle is being towed
To prevent unintentional operation, turn
the Hands Free Power Back Door operation setting off. (P.190)

4 Move the lever.

n When reconnecting the 12-volt bat-

tery
To enable the power back door to operate properly, close the back door manually.

n If the power back door opener is

inoperative
The power back door can be unlocked
from the inside
1 Remove the cover.
To prevent damage, cover the tip of the
screwdriver with a rag.

5 When installing, reverse the steps
listed.

n Customization
Some functions can be customized.
(P.675)

WARNING
n Back door closer
l In the event that the power back

2 Loosen the screw.

door is left slightly open, the back
door closer will automatically close
it to the fully closed position. It
takes several seconds before the
back door closer begins to operate.
Be careful not to catch fingers or
anything else in the power back
door, as this may cause bone fractures or other serious injuries.

4-2. Opening, closing and locking the doors

WARNING
l Use caution when using the back

door closer as it still operates when
the power back door system is
canceled.

n Power back door
Observe the following precautions
when operating the power back door.
Failure to do so may cause death or
serious injury.

l Check the safety of the surrounding
area to make sure there are no
obstacles or anything that could
cause any of your belongings to get
caught.

l If anyone is in the vicinity, make

sure they are safe and let them
know that the power back door is
about to open or close.
turned off while the power back
door is operating automatically, the
automatic operation is stopped. The
power back door then has to be
operated manually. Take extra care
when on an incline, as the power
back door may open or close unexpectedly.

l If the operating conditions of the

power back door are no longer met,
a buzzer may sound and the power
back door may stop opening or
closing. The power back door then
has to be operated manually. Take
extra care when on an incline, as
the power back door may open or
close abruptly.

l On an incline, the power back door
may suddenly shut after it opens.
Make sure the power back door is
fully open and secure.

l In the following situations, the

power back door may detect an
abnormality and automatic operation may be stopped. In this case,
the power back door has to be
operated manually. Take extra care
when on an incline, as the power
back door may open or close
abruptly.
• When the power back door contacts
an obstacle
• When the 12-volt battery voltage
suddenly drops, such as when the
power switch is turned to ON or the
EV system is started during automatic operation

l If a bicycle carrier or similar heavy

object is attached to the power back
door, the power back door may not
operate, causing itself to malfunction, or the power back door may
suddenly shut again after being
opened, causing someone’s hands,
arms, head or neck to be caught
and injured.
When installing an accessory part to
the power back door, ask any authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer
for details.

n Jam protection function
Observe the following precautions.
Failure to do so may cause death or
serious injury.
l Never use any part of your body to
intentionally activate the jam protection function.

l The jam protection function may not
work if something gets caught just
before the power back door fully
closes. Be careful not to catch fingers or anything else.

l The jam protection function may not
work depending on the shape of the
object that is caught. Be careful not
to catch fingers or anything else.

4

Before driving

l If the power back door system is

187

188

4-2. Opening, closing and locking the doors

WARNING
n Hands Free Power Back Door (if

l Do not touch the spindle rod with
gloves or other fabric items.

equipped)
Observe the following precautions
when operating the Hands Free
Power Back Door.
Failure to do so may cause death or
serious injury.

l Do not attach any accessories

l Check the safety of the surrounding

function
Do not apply excessive force to the
power back door while the power
back door closer is operating. Applying excessive force may cause the
power back door closer to malfunction.

area to make sure there are no
obstacles or anything that could
cause any of your belongings to get
caught.

l When putting your foot near the

lower center part of the rear bumper
and moving it from the rear bumper,
be careful not to touch the exhaust
pipes until they have cooled down
sufficiently, as touching hot exhaust
pipes can cause burns.

l Do not leave the electronic key

within the effective range (detection
area) of the luggage compartment.

NOTICE
n Back door spindles
The back door is equipped with spindles that hold the power back door in
place. Observe the following precautions.
Failure to do so may cause damage
to the power back door spindle,
resulting in malfunction.

other than genuine Toyota parts to
the power back door.

l Do not place your hand on the spindle or apply lateral forces to it.

n To prevent back door closer mal-

n To prevent malfunction of the
power back door

l Make sure that there is no ice

between the power back door and
frame that would prevent movement of the power back door. Operating the power back door when
excessive load is present on the
power back door may cause a malfunction.

l Do not apply excessive force to the
power back door while the power
back door is operating.

l Take care not to damage the sen-

sors (installed on the right and left
edges of the power back door) with
a knife or other sharp object. If the
sensor is disconnected, the power
back door will not close automatically.

n Close & lock function
When closing the power back door
using the close & lock function, a different buzzer than the normal one will
sound before the operation begins.

l Do not attach any foreign objects,

such as stickers, plastic sheets, or
adhesives to the spindle rod.

To check that the operation has
started correctly, check that a different
buzzer than the normal one has
sounded.

4-2. Opening, closing and locking the doors

NOTICE
Additionally, when the power back
door is fully closed and locked, operation signals will indicate that all of the
doors have been locked.
Before leaving the vehicle, make sure
that the operation signals have operated and that all of the doors are
locked.

n Hands Free Power Back Door

precautions (if equipped)
The kick sensor is located behind
lower center part of the rear bumper.
Observe the following to ensure that
the Hands Free Power Back Door
function operates properly:

l Keep the lower center part of the

l Do not apply coatings that have a

rain clearing (hydrophilic) effect, or
other coatings, to the lower center
part of the rear bumper.

l Do not park the vehicle near objects

that may move and contact the
lower center part of the rear
bumper, such as grass or trees.
If the vehicle has been parked for a
while near objects that may move
and contact the lower center part of
the rear bumper, such as grass or
trees, the kick sensor may not operate. In this situation, move the vehicle from the current position and
then check if the kick sensor operates.
If it does not operate, have the vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

l Do not subject the rear bumper to a

strong impact.
If the rear bumper has been subjected
to a strong impact, the Hands Free
Power Back Door may not operate
properly.
If the Hands Free Power Back Door
does not operate in the following situations, have the vehicle inspected by
any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.
• The kick sensor or its surrounding
area has been subjected to a strong
impact.
• The lower center part of the rear
bumper is scratched or damaged.

l Do not disassemble the rear
bumper.

l Do not attach stickers to the rear
bumper.

l Do not paint the rear bumper.
l If a bicycle carrier or similar heavy

object is attached to the power back
door, disable the Hands Free
Power Back Door.

4

Before driving

rear bumper clean at all times.
If the lower center part of the rear
bumper is dirty or covered with
snow, the kick sensor may not operate. In this situation, clean off the
dirt or snow, move the vehicle from
the current position and then check
if the kick sensor operates.
If it does not operate, have the vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

189

190

4-2. Opening, closing and locking the doors

Changing settings of the
power back door system
The settings for the power back
door can be changed from the settings screen of the multimedia display. (P.677)
When the power back door settings
have been changed, they will not be
reset even if the power switch is turned
OFF.

n Canceling the adjusted open position of the power back door

Press and hold the
switch on the
lower part of the power back door for 7
seconds.
After the buzzer sounds 4 times, it
sounds twice more. When the power
back door does the opening operation
the next time, the door will open to the
initial settings position.

To return the settings to their previous
values, it is necessary to use the
set-tings screen of the multimedia display again.

Adjusting the open position
of the power back door
The open position of the power
back door can be adjusted.
1 Stop the power back door at the
desired position. (P.180)
2 Press and hold the
switch
on the lower part of the power
back door for 2 seconds.
When the settings are completed, the
buzzer sounds 4 times.
When opening the power back door the
next time, the power back door will stop
at that position.

n Customization
The automatic opening stop position for
the power back door can also be
changed from the multimedia display.
(P.677)
When the stop position has been set by
both the vehicle side power back door
open/close switch and the multimedia
display, priority will be given to whichever one was set most recently.

4-2. Opening, closing and locking the doors

Smart entry & start system
The following operations can
be performed simply by carrying the electronic key on your
person, for example in your
pocket. The driver should
always carry the electronic
key.
 Locks and unlocks the doors
(P.173)
 Locks and unlocks the back
door (P.179)
 Starts and stops the EV system (P.243)

partment

n Effective range (areas within which
the electronic key is detected)

A When locking or unlocking the
doors

The system can be operated whenthe
electronic key is with in about 0.7 m (2.3
ft.) of the front door handles, rear door
handles and back door opener switch.
(Only the doors detecting the key can be
operated.)

B When starting the EV system or
changing power switch modes

The system can be operated when the
electronic key is inside the vehicle.

A Antennas outside the cabin (front)
B Antennas outside the cabin (rear)
C Antennas inside the cabin
Antenna inside the luggage compartment
Antenna outside the luggage com-

n Alarms and warning messages
An alarm sounds and warning messages are displayed on the multi-information display to protect against
unexpected accidents or theft of the
vehicle resulting from erroneous operation. When a warning message is displayed, take appropriate measures
based on the displayed message.
(P.627)
When only an alarm sounds, circumstances and correction procedures are
as follows.
l When an exterior alarm sounds once
for 5 seconds

4

Before driving

n Antenna location

191

192

4-2. Opening, closing and locking the doors

Situation

Correction
procedure

Close all of
An attempt was made
the doors and
to lock the vehicle while
lock the doors
a door was open.
again.

l When an interior alarm sounds continuously

Situation

Correction
procedure

The power switch was
Turn the
turned to ACC while the
power switch
driver’s door was open
off and close
(The driver’s door was
the driver’s
opened when the power
door.
switch was in ACC).
The power switch was
Close the
turned off while the
driver’s door.
driver’s door was open.

l If the smart entry & start system has

not been used for 14 days or longer,
the doors cannot be unlocked at any
doors except the driver’s door. In this
case, take hold of the driver’s door
handle, or use the wireless remote
control or the mechanical key, to
unlock the doors.

n Turning an electronic key to battery-saving mode

l When battery-saving mode is set, battery depletion is minimized by stopping the electronic key from receiving
radio waves.

Press

twice while pressing and

holding
. Confirm that the electronic key indicator flashes 4 times.
While the battery-saving mode is set,
the smart entry & start system cannot be
used. To cancel the function, press any
of the electronic key buttons.

n If “Key Detected in Vehicle” is

shown on the multi-information
display
An attempt was made to lock the doors
using the smart entry & start system
while the electronic key was still inside
the vehicle. Retrieve the electronic key
from the vehicle and lock the doors
again.

n Battery-saving function
The battery-saving function will be activated in order to prevent the electronic
key battery and the 12-volt battery from
being discharged while the vehicle is not
in operation for a long time.
l In the following situations, the smart

entry & start system may take some
time to unlock the doors.
• The electronic key has been left near
the vehicle for a certain amount of
time.
• The smart entry & start system has
not been used for a few days or
longer.

Electronic keys that will not be used for
long periods of time can be set to the
battery-saving mode in advance.

n When electronic key function stops
If the position of the electronic key has
not changed for a certain amount of time
such as when the electronic key is left
some where,the function of the electronic key stops to reduce depletion of
the battery.
In this case, function can automatically
be restored by moving the position of
the key such as by lifting it up.
n Conditions affecting operation
The smart entry & start system, wireless
remote control and immobilizer system
use weak radio waves. In the following

4-2. Opening, closing and locking the doors
situations, the communication between
the electronic key and the vehicle may
be affected, preventing the smart entry
& start system, wireless remote control
and immobilizer system from operating
properly. (Ways of coping: P.656)

193

lock/unlock the doors by performing any
of the following:

l Bring the electronic key close to either
front door handle and operate the
entry function.

l Near a TV tower, electric power plant,

l Operate the wireless remote control.
If the doors cannot be locked/unlocked
using the above methods, use the
mechanical key. (P.656)
If the EV system cannot be started using
the smart entry & start system, refer to
P.657

l When the electronic key is in contact

n Note for the entry function
l Even when the electronic key is within

l When the electronic key battery is
depleted

gas station, radio station, large display, airport or other facility that generates strong radio waves or electrical
noise

l When other wireless keys (that emit

radio waves) are being used nearby

l When carrying the electronic key

together with the following devices
that emit radio waves
• Portable radio, cellular phone, cordless phone or other wireless communication devices
• Another electronic key or a wire less
key that emits radio waves
• Personal computers or personal digital assistants (PDAs)
• Digital audio players
• Portable game systems

l If window tint with a metallic content or
metallic objects are attached to the
rear window

the effective range (detection areas),
the system may not operate properly
in the following cases:
• The electronic key is too close to the
window or outside door handle, near
the ground, or in a high place when
the doors are locked or unlocked.
• The electronic key is on the instrument panel, luggage compartment,
floor, or in the door pockets or glove
box when the EV system is started or
power switch modes are changed.
• The electronic key is blocked by a
body between the electronic key and
the vehicle when the door is unlocked.

l Do not leave the electronic key on top

of the instrument panel or near the
door pockets when exiting the vehicle.
Depending on the radio wave reception conditions, it may be detected by
the antenna outside the cabin and the
door will become lockable from the
outside, possibly trapping the electronic key inside the vehicle.

l As long as the electronic key is within

l When the electronic key is placed

near a battery charger or electronic
devices

the effective range, the doors may be
locked or unlocked by anyone. However, only the doors detecting the
electronic key can be used to unlock
the vehicle.

l When the vehicle is parked in a pay

l Even if the electronic key is not inside

parking spot where radio waves are
emitted
If the doors cannot be locked/unlocked
using the smart entry & start system,

the vehicle, it may be possible to start
the EV system if the electronic key is
near the window.

l The doors may unlock if a large

4

Before driving

with, or is covered by the following
metallic objects
• Cards to which aluminum foil is
attached
• Cigarette boxes that have aluminum
foil inside
• Metallic wallets or bags
• Coins
• Hand warmers made of metal
• Media such as CDs and DVDs

194

4-2. Opening, closing and locking the doors

amount of water splashes on the door
handle, such as in the rain or in a car
wash when the electronic key is within
the effective range. (The door will
automatically be locked after approximately 30 seconds if the doors are not
opened and closed.)

l If the wireless remote control is used

to lock the doors when the electronic
key is near the vehicle, there is a possibility that the door may not be
unlocked by the entry function. (Use
the wireless remote control to unlock
the doors.)

l Touching the door lock sensor while

wearing gloves may delay or prevent
lock operation. Remove the gloves
and touch the lock sensor again.

l When the lock operation is performed

using the lock sensor, recognition signals will be shown up to two consecutive times. After this, no recognition
signals will be given.

l If the door handle becomes wet while

the electronic key is within the effective range, the door may lock and
unlock repeatedly. In that case, follow
the following correction procedures to
wash the vehicle:
• Place the electronic key in a location 2
m (6 ft.) or more away from the vehicle. (Take care to ensure that the key
is not stolen.)
• Set the electronic key to battery-saving mode to disable the smart entry &
start system. (P.192)

l If the electronic key is inside the vehi-

cle and a door handle becomes wet
during a car wash, a message may be
shown on the multi-information display and a buzzer will sound outside
the vehicle. To turn off the alarm, lock
all the doors.

l The lock sensor may not work prop-

erly if it comes into contact with ice,
snow, mud, etc. Clean the lock sensor
and attempt to operate it again.

l A sudden approach to the effective

range or door handle may prevent the
doors from being unlocked. In this

case, return the door handle to the
original position and check that the
doors unlock before pulling the door
handle again.

l If there is another electronic key in the
detection area, it may take slightly
longer to unlock the doors after the
door handle is gripped.

n When the vehicle is not driven for
extended periods

l To prevent theft of the vehicle, do not
leave the electronic key within 2 m (6
ft.) of the vehicle.

l The smart entry & start system can be
deactivated in advance.

l Setting the electronic key to bat-

tery-saving mode helps to reduce key
battery depletion. (P.192)

n To operate the system properly
Make sure to carry the electronic key
when operating the system. Do not get
the electronic key too close to the vehicle when operating the system from the
outside of the vehicle.
Depending on the position and holding
condition of the electronic key, the key
may not be detected correctly and the
system may not operate properly. (The
alarm may go off accidentally, or the
door lock prevention may not operate.)
n If the smart entry & start system
does not operate properly

l If the doors cannot be locked or

unlocked and the back door cannot be
opened, perform the following.
• Bring the electronic key close to the
door handle and perform a lock or
unlock operation.
• Bring the electronic key close to the
button on the back door (P.179) and
press the button.
• Use the wireless remote control.
If the doors cannot be locked or
unlocked by perform the above, use the
mechanical key. (P.656) However, if
the mechanical key is used while the
alarm system is set, the warning will

4-2. Opening, closing and locking the doors
sound. (P.85)

l If the EV system cannot be started,
refer to P.657

n Customization
Settings (e.g. smart entry & start system) can be changed. (Customizable
features :P.675)
If the smart entry & start system has
been deactivated by a customized setting, refer to the explanations for the following operations.

l Locking and unlocking the doors: Use
the wireless remote control or
mechanical key. (P.173, 179, 656)

l Starting the EV system and changing

195

l Users of any electrical medical

device other than implantable cardiac pacemakers, cardiac
resynchronization therapy-pacemakers or implantable cardioverter
defibrillators should consult the
manufacturer of the device for information about its operation under
the influence of radio waves.
Radio waves could have unexpected effects on the operation of
such medical devices.

Ask any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer for details on disabling
the entry function.

power switch modes: P.657

l Stopping the EV system: P.245
4

WARNING
with electronic devices
l People with implantable cardiac
pacemakers, cardiac
resynchronization therapy-pacemakers or implantable cardioverter
defibrillators should maintain a reasonable distance between themselves and the smart entry & start
system antennas. (P.191)
The radio waves may affect the
operation of such devices. If necessary, the entry function can be disabled. Ask any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer for
details, such as the frequency of
radio waves and timing of the emitted radio waves. Then, consult your
doctor to see if you should disable
the entry function.

Before driving

n Caution regarding interference
