# 5-3. Operating the lights and wipers

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 260–275

260

5-3. Operating the lights and wipers

Headlight switch

5-3.Operating the lights and wipers

The headlights can be turned
on and off automatically or
manually.

Turning on the lights
Operating the

*: When the 3

switch turns on the lights as follows:

switch is turned to the position and released, the switch auto-

matically returns to the position 2

.
Illumination condition

Position

In bright environment

In dark environment

The headlights, front position, tail, license plate and instrument panel lights turn on

1

The headlights, front position,
tail, license plate and instru- The headlights, front position,
ment panel lights turn off
tail, license plate and instrument panel lights turn on
The daytime running lights

2

(P.262) turn on*2

3

*1

The daytime running lights,
front position, tail, license
plate and instrument panel
lights turn on

*1: To change the illumination condition to

The front position, tail, license
plate and instrument panel
lights turn on*3
,

switch must be held in the

position for approximately 1 second before releasing it. If the switch is

5-3. Operating the lights and wipers

261

not held in position for approximately 1 second, the lights will continue to operate
according to the

condition.

*2: The tail, license plate and instrument panel lights turn on and off automatically

according to the brightness of the vehicle surroundings.
*3

: The lights can only be turned on when the vehicle is stopped or being driven at
low speeds. However, when the vehicle exceeds a certain speed or has been
driven for a certain period of time, this mode is automatically canceled and the
illumination condition returns to

.

Turning off the lights
When the

switch is held in position 3

for 2 second or more, the

headlight switch operates as follows.
When the switch is turned to the position 1

or 3

while the lights

are off, the state in which the lights are turned off will be released.
5

Driving

*

: When the switch is turned to the position 3
matically returns to the position 2

and released, the switch auto-

.
Illumination condition

Position

3

In bright environment

In dark environment

The headlights, front position,
tail, license plate and instru- The headlights, front position,
ment panel lights turn off
tail, license plate and instruThe daytime running lights
(P.262) turn on

ment panel lights turn off*

*: The lights can only be turned off when the shift position is P or the parking brake

is applied. When the shift position is shifted out of P and the parking brake is

262

5-3. Operating the lights and wipers

released, the state in which the lights are turned off will be canceled.
.

n AUTO mode can be used when
The power switch is in ON.

n Light reminder buzzer

n Daytime running light function

A buzzer sounds when the power switch
is turned off and the driver’s door is
opened while the lights are turned on.

To make your vehicle more visible to
other drivers during daytime driving, the
daytime running lights turn on automatically whenever the EV system is started
and the parking brake is released with
the headlight switch in the
position.
(Illuminate brighter than the front position lights.) Daytime running lights are
not designed for use at night.

n Headlight control sensor
The sensor may not function properly if
an object is placed on the sensor, or
anything that blocks the sensor is
affixed to the windshield. Doing so interferes with the sensor detecting the level
of ambient light and may cause the
automatic headlight system to malfunction.

n Automatic light off system
l When the light switch is in the
position: The headlights turn off automatically if the power switch is turned
to ACC or off.

l When the light switch is in

position: The headlights and all the lights
turn off automatically if the power
switch is turned to ACC or off.
To turn the lights on again, turn the
power switch to ON, or turn the light
switch off once and then back to

or

n Automatic headlight leveling sys-

tem (if equipped)
The level of the headlights is automatically adjusted according to the number
of passengers and the loading condition
of the vehicle to ensure that the headlights do not interfere with other road
users.

n 12-volt battery-saving function
In order to prevent the 12-volt battery of
the vehicle from discharging, if the light
switch is in the
or
position
when the power switch is turned off, the
12-volt battery saving function will operate and automatically turn off all the
lights after approximately 20 minutes.
When the power switch is turned to ON,
the 12-volt battery-saving function will
be disabled.
When any of the following are performed, the 12-volt battery-saving function is canceled once and then
reactivated. All the lights will turn off
automatically 20 minutes after the
12-volt battery-saving function has been
reactivated:

l When the headlight switch is operated
l When a door is opened or closed
n Customization
Some functions can be customized.
(P.680)

NOTICE
n To prevent 12-volt battery dis-

charge
Do not leave the lights on longer than
necessary when the EV system is not
operating.

5-3. Operating the lights and wipers

263

Turning on the high beam
headlights

Manual headlight leveling
dial (if equipped)
1 With the headlights on, push the
lever away from you to turn on
the high beams.
Pull the lever toward you to the center
position to turn the high beams off.

The level of the headlights can be
adjusted according to the number
of passengers and the loading condition of the vehicle.

2 Pull the lever toward you and
release it to flash the high
beams once.

5

Driving

You can flash the high beams with the
headlights on or off.

Extended Headlight Lighting
system
This system allows the headlights
and front position lights to be turned
on for 30 seconds when the power
switch is off.
Pull the lever toward you and
release it with the light switch is in
after turning the power switch

1 Raises the level of the headlights
2 Lowers the level of the headlights
n Guide to dial settings
Occupancy and luggage
load conditions

Dial position

off.

Occupants

Pull the lever toward you and release it
again to turn off the lights.

Luggage
load

Driver

None

0

Driver and
front passenger

None

0.5

264

5-3. Operating the lights and wipers

Occupancy and luggage
load conditions

Dial position

Occupants

Luggage
load

All seats
occupied

None

2

All seats
occupied

Full luggage loading

3

Driver

Full luggage loading

3.5

AHS (Adaptive
High-beam System)*
*: If equipped

The Adaptive High-beam System uses a front camera
located on the upper portion of
the windshield to detect the
brightness of the lights of vehicles ahead, streetlights, etc.,
and automatically controls the
light distribution of the headlights.
WARNING
n For safe use
Do not overly rely on the Adaptive
High-beam System. Always drive
safely, taking care to observe your
surroundings and turning the high
beams on or off manually if necessary.
n To prevent unintentional opera-

tion of the Adaptive High-beam
System
When it is necessary to disable the
system: P.279

System controls
 According to the vehicle speed,
the brightness and illuminated
area of the high beams are
adjusted.
 When driving around a curve, the
system uses the high beams to
brightly illuminate the direction of
travel of the vehicle.
 The high beams are illuminated
so that the area around a vehicle

5-3. Operating the lights and wipers

ahead is shaded. (Shaded high
beam)
The shaded high beam helps ensure
forward visibility while reducing the dazzling effect on the drivers of vehicles
ahead.

A Area illuminated by the high
beams
B Area illuminated by the low
beams

Using the Adaptive
High-beam System
1 Press the Adaptive High-beam
System switch.

2 Turn the headlight switch to the
or

position.

When the headlight switch lever is in
the low beam position, the AHS will be
enabled and the AHS indicator will illuminate.

n System operating conditions
l When all of the following conditions

are met, the high beams will illuminate
and the system will operate:
• The vehicle speed is approximately 15
km/h (9 mph) or more*.
• The area ahead of the vehicle is dark.
*: When driving around a curve at a
vehicle speed of approximately 30
km/h (19 mph) or more, the direction
of travel of the vehicle will be brightly
illuminated.

l When all of the following conditions

are met, the headlights will change to
the shaded high beams according to
the position of vehicles ahead:
• The vehicle speed is approximately 15
km/h (9 mph) or more.
• The area ahead of the vehicle is dark.
• There is a vehicle ahead with lights
on.
• There are few streetlights or other
lights on the road ahead.

l If any of the following conditions are

met, the system will change to the low
beams:
• The vehicle speed is approximately 12
km/h (7.5 mph) or lower.
• The area ahead of the vehicle is not

5

Driving

 According to the distance to a
preceding vehicle, the illuminated area of the low beams is
adjusted.

265

266

5-3. Operating the lights and wipers

dark.
• There are many vehicles ahead.
• There are many streetlights or other
lights on the road ahead.

n Front camera detection
l In the following situations, the high

beams may not be automatically
changed to the shaded high beams:
• When a vehicle cuts in front of your
vehicle
• When another vehicle crosses in front
of the vehicle
• When vehicles ahead are repeatedly
detected and then hidden due to
repeated curves, road dividers or
roadside trees
• When a vehicle ahead approaches
from a far lane
• When a vehicle ahead is far away
• When a vehicle ahead has no lights
• When the lights of a vehicle ahead are
dim
• When a vehicle ahead is reflecting
strong light, such as the headlights of
your vehicle
• Situations in which the sensors may
not operate properly: P.283

l The high beams may change to the

shaded high beams if a vehicle ahead
that is using fog lights without its
headlights turned on is detected.

l House lights, street lights, traffic sig-

nals, and illuminated billboards or
signs and other reflective objects may
cause the high beams to change to
the shaded high beams, cause the
high beams not to change to the
shaded high beams, or change the
area that is not illuminated.

l The following may change the speed

at which the shaded areas change or
the timing at which the headlights
change to the low beams:
• The brightness of lights of vehicles
ahead
• The movement and direction of vehicles ahead
• The distance between the vehicle and
a vehicle ahead
• When a vehicle ahead only has lights
illuminated on one side

• When a vehicle ahead is a
two-wheeled vehicle
• The condition of the road (gradient,
curve, condition of the road surface,
etc.)
• The number of passengers and
amount of luggage

l The light distribution control of the

headlights may not match the driver’s
expectations

l Bicycles and other small vehicles may
not be detected.

l In the following situations, the system

may not be able to correctly detect the
brightness of the surroundings. This
may cause the low beams to remain
on or the high beams to flash or dazzle pedestrians or vehicles ahead. In
such a case, it is necessary to manually change between the high beams
and low beams.
• When there are lights similar to headlights or tail lights in the surrounding
area
• When headlights or tail lights of vehicles ahead are turned off, dirty, changing color, or not aimed properly
• When the headlights are repeatedly
changing between the high beams
and low beams.
• When use of the high beams is inappropriate or when the high beams
may be flashing or dazzling pedestrians or other drivers.
• When the vehicle is used in an area in
which vehicles travel on the opposite
side of the road of the country for
which the vehicle was designed, for
example using a vehicle designed for
right-hand traffic in a left-hand traffic
area, or vice versa
• When it is necessary to disable the
system: P.279
• Situations in which the sensors may
not operate properly: P.283

n Customization
The settings of some functions can be
changed. (P.675)

5-3. Operating the lights and wipers

267

Turning the high beams
on/off manually

high beams may cause problems or
distress to other drivers or pedestrians nearby.

n Changing to the high beams

1 Pull the lever rearward and then
return it to its original position.

1 Push the lever forward.
The AHS indicator will turn off and the
high beam indicator will turn on.
Pull the lever to its original position to
enable the Adaptive High-beam System again.

n Changing to the low beams

The AHS indicator will turn off.
Press the switch to enable the Adaptive
High-beam System again.

Temporarily changing to the
low beams
It is recommended to switch to the
low beams when use of the high
beams is inappropriate or when the

5

Driving

1 Press the Adaptive High-beam
System switch.

The high beams will illuminate while the
lever is pulled, however, after the lever
is returned to its original position, the
low beams will remain on for a certain
amount of time. After this, the Adaptive
High-beam System will operate.

268

5-3. Operating the lights and wipers

AHB (Automatic High
Beam)*
*: If equipped

The Automatic High Beam
uses a front camera located on
the upper portion of the windshield to detect the brightness
of the lights of vehicles ahead,
streetlights, etc., and automatically changes the head lights
between the high beams and
low beams.

2 Turn the headlight switch to the
or

position.

When the headlight switch lever is in
the low beam position, the AHB system
will be enabled and the AHB indicator
will illuminate.

WARNING
n For safe use
Do not overly rely on the Automatic
High Beam. Always drive safely, taking care to observe your surroundings
and turning the high beams on or off
manually if necessary.

n To prevent unintentional opera-

tion of the Automatic High Beam
System
When it is necessary to disable the
system: P.279

n Automatic operating conditions of
the high beams

l When all of the following conditions

are met, the high beams will illuminate
automatically:
• The vehicle speed is approximately 30
km/h (19 mph) or more.
• The area ahead of the vehicle is dark.
• There are no vehicles ahead with
lights on.
• There are few streetlights or other
lights on the road ahead.

l If any of the following conditions are

Using the Automatic High
Beam system
1 Press the Automatic High Beam
switch.

met, the headlights will change to the
low beams:
• Vehicle speed drops below approximately 25 km/h (16 mph).
• The area ahead of the vehicle is not
dark.
• There is a vehicle ahead with lights
on.
• There are many streetlights or other
lights on the road ahead.

n Front camera detection
l In the following situations, the high

beams may not be automatically
changed to the low beams:
• When a vehicle cuts in front of your
vehicle
• When another vehicle crosses in front

5-3. Operating the lights and wipers
of the vehicle
• When vehicles ahead are repeatedly
detected and then hidden due to
repeated curves, road dividers or
roadside trees
• When a vehicle ahead approaches
from a far lane
• When a vehicle ahead is far away
• When a vehicle ahead has no lights
• When the lights of a vehicle ahead are
dim
• When a vehicle ahead is reflecting
strong light, such as own headlights
• Situations in which the sensors may
not operate properly: P.283

l The headlights may change to the low
beams if a vehicle ahead that is using
fog lights without its headlights turned
on is detected.

l House lights, street lights, traffic signals, and illuminated billboards or
signs may cause the high beams to
change to the low beams, or the low
beams to remain on.

l The following may change the timing

l The headlights may change between

the high beams and low beams unexpectedly.

l Bicycles and other small vehicles may
not be detected.

l In the following situations, the system

may not be able to correctly detect the
brightness of the surroundings. This

may cause the low beams to remain
on or the high beams to flash or dazzle pedestrians or vehicles ahead. In
such a case, it is necessary to manually change between the high beams
and low beams.
• When there are lights similar to headlights or tail lights in the surrounding
area
• When headlights or tail lights of vehicles ahead are turned off, dirty, changing color, or not aimed properly
• When the headlights are repeatedly
changing between the high beams
and low beams.
• When use of the high beams is inappropriate or when the high beams
may be flashing or dazzling pedestrians or other drivers.
• When the vehicle is used in an area in
which vehicles travel on the opposite
side of the road of the country for
which the vehicle was designed, for
example using a vehicle designed for
right-hand traffic in a left-hand traffic
area, or vice versa
• When it is necessary to disable the
system: P.279
• Situations in which the sensors may
not operate properly: P.283

Turning the high beams
on/off manually
n Changing to the high beams

1 Push the lever forward.
The AHB indicator will turn off and the
high beam indicator will turn on.
Pull the lever to its original position to
enable the Automatic High Beam sys-

5

Driving

at which the headlights change to the
low beams:
• The brightness of lights of vehicles
ahead
• The movement and direction of vehicles ahead
• The distance between the vehicle and
a vehicle ahead
• When a vehicle ahead only has lights
illuminated on one side
• When a vehicle ahead is a
two-wheeled vehicle
• The condition of the road (gradient,
curve, condition of the road surface,
etc.)
• The number of passengers and
amount of luggage

269

270

5-3. Operating the lights and wipers

tem again.

n Changing to the low beams

1 Press the Automatic High Beam
switch.
The AHB indicator will turn off.
Press the switch to enable the Automatic High Beam system again.

Temporarily changing to the
low beams
It is recommended to switch to the
low beams when use of the high
beams is inappropriate or when the
high beams may cause problems or
distress to other drivers or pedestrians nearby.
1 Pull the lever rearward and then
return it to its original position.
The high beams will illuminate while the
lever is pulled, however, after the lever
is returned to its original position, the
low beams will remain on for a certain

amount of time. After this, the Automatic High Beam system will operate.

5-3. Operating the lights and wipers

Fog light switch
When in difficult driving conditions, such as in rain and fog,
turn on the rear fog light to
notify following vehicles the
existence of your vehicle.

Turning on the fog lights

271

Windshield wipers and
washer
Operating the lever can change
wiper operation to automatic/manual or squirt washer
fluid.
NOTICE
n When the windshield is dry
Do not use the wipers, as they may
damage the windshield.

Operating the wiper lever
Operating the

lever operates

the wipers or washer as follows:

Turns the rear fog light off

2

Turns the rear fog light on

Releasing the switch ring returns it to
.
Operating the switch ring again turns
the rear fog light off.

n Fog light can be used when
The headlights are turned on.

NOTICE
n To prevent 12-volt battery dis-

charge
Do not leave the lights on longer than
necessary when the EV system is off.

1

Off

5

Driving

1

When AUTO is selected, the wipers
will operate automatically when the
sensor detects falling rain. The system automatically adjusts wiper timing in accordance with rain volume
and vehicle speed.

272

5-3. Operating the lights and wipers

2

Rain-sensing operation

3

Low speed operation

4

High speed operation

5

Temporary operation

When AUTO is selected, the sensor
sensitivity can be adjusted by turning the switch ring.

operate while the vehicle is moving.)
When the power switch is in ON and
the headlights are on, if the lever is
pulled, the headlight cleaners will operate once. After this, the headlight
cleaners will operate every 5th time the
lever is pulled.

n The windshield wipers and washer

can be operated when
The power switch is in ON.

n Effects of vehicle speed on wiper

operation
Vehicle speed affects the intermittent
wiper interval.

n Raindrop sensor
l The raindrop sensor judges the

6 Increases the sensitivity
7 Decreases the sensitivity

amount of raindrops.
An optical sensor is adopted. It may
not operate properly when sunlight
from the rising or setting of the sun
intermittently strikes the windshield, or
if bugs, etc. are present on the windshield.

l If the wiper switch is turned to the

8

Washer/wiper dual operation

Pulling the lever operates the wipers
and washer.
The wipers will automatically operate a
couple of times after the washer squirts.
(After operating several times, the wipers operate once more time after a
short delay to prevent dripping. However, the dripping prevention does not

position while the power switch is
in ON, the wipers will operate once to
show that AUTO mode is activated.

l If the temperature of the raindrop sensor is 85°C (185°F) or higher, or -15°C
(5°F) or lower, automatic operation
may not occur. In this case, operate
the wipers in any mode other than
AUTO.

n If no windshield washer fluid

sprays
Check that the washer nozzles are not

5-3. Operating the lights and wipers
blocked, if there is washer fluid in the
washer fluid tank.

n Using the voice control system
The following operations can be performed using the voice control system:

273

n To prevent 12-volt battery dis-

charge
Do not leave the wipers on longer
than necessary when the EV system
is off.

l Operating the windshield wipers only
once

l Operating the windshield cleaning

washer (it can be performed only
when the vehicle is stopped)
For details regarding the voice control
system, refer to “Multimedia owner’s
manual”.

WARNING
n Caution regarding the use of

windshield wipers in AUTO mode
The windshield wipers may operate
unexpectedly if the sensor is touched
or the windshield is subject to vibration in AUTO mode. Take care that
your fingers, etc. do not become
caught in the windshield wipers.
washer fluid
When it is cold, do not use the washer
fluid until the windshield becomes
warm. The fluid may freeze on the
windshield and cause low visibility.
This may lead to an accident, resulting in death or serious injury.

NOTICE
n When the washer fluid tank is

empty
Do not operate the switch continually
as the washer fluid pump may overheat.

n When a nozzle becomes blocked
In this case, contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.
Do not try to clear it with a pin or other
object. The nozzle will be damaged.

Driving

n Caution regarding the use of

5

274

5-3. Operating the lights and wipers

Rear window wiper and
washer
NOTICE
n When the rear window is dry
Do not use the wiper, as it may damage the rear window.

4

Washer/wiper dual operation

Pushing the lever operates the wiper
and washer.
The wiper will automatically operate a
couple of times after the washer squirts.
The washer will automatically operate
and clean the rear camera.*

Operating the wiper lever
Operating the
switch operates the rear wiper as follows:

*

: Refer to “Multimedia owner’s manual”.

n The rear window wiper and washer

can be operated when
The power switch is in ON.

n Using the voice control system
The following operations can be performed using the voice control system:
l Operating the rear window wiper only
once

l Operating the rear window washer (it

can be performed only when the vehicle is stopped)
For details regarding the voice control
system, refer to “Multimedia owner’s
manual”.

1

Off

2

Intermittent operation

3

Normal operation

n If no washer fluid sprays
Check that the washer nozzle is not
blocked if there is washer fluid in the
washer fluid tank.
n Reverse-linked rear window wiper

function
When the shift position is shifted to R
when the front wipers are operating, the
rear window wiper will operate once.

n Back door opening linked rear win-

dow wiper stop function
When the rear window wiper is operating, if the back door is opened while the
vehicle is stopped, operation of the rear
window wiper will be stopped to prevent
anyone near the vehicle from being
sprayed by water from the wiper. When
the back door is closed, wiper operation
will resume.

5-3. Operating the lights and wipers

NOTICE

275

Headlight cleaner switch

n When the washer fluid tank is

empty
Do not operate the switch continually
as the washer fluid pump may overheat.

n When a nozzle becomes blocked
In this case, contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.
Do not try to clear it with a pin or other
object. The nozzle will be damaged.

Washer fluid can be sprayed
on the headlights.

Enabling the system
Press the switch to clean the headlights.

n To prevent 12-volt battery dis-

charge
Do not leave the wipers on longer
than necessary when the EV system
is off.

5

n The headlight cleaners can be

n Windshield washer linked opera-

tion
When the power switch is in ON and the
headlights are on, if the lever is pulled,
the headlight cleaners will operate once.
After this, the headlight cleaners will
operate every 5th time the lever is
pulled. (P.271)

NOTICE
n When the washer fluid tank is

empty
Do not press the switch continually as
the washer fluid pump may overheat.

Driving

operated when
The power switch is in ON and the
headlight switch is turned on.
