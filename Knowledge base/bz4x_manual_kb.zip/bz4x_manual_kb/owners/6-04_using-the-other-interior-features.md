# 6-4. Using the other interior features

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 6: Interior features, pages 540–563

540

6-4. Using the other interior features

Electronic sunshade*

6-4.Using the other interior features

*

: If equipped

Use the overhead switches to
operate the electronic sunshade.

Operating the electronic
sunshade

tion has stopped completely.

l The electronic sunshade may operate

in reverse if the electronic sunshade is
subject to an impact due to the
surroundings or the driving conditions.

n When the electronic sunshade

does not close normally
Perform the following initialization procedure.
1 Turn the power switch to ON.
2 Press and hold the “CLOSE” side of
the switch.
It closes until it is near the fully closed
position and then stops. After that, it
operates in the opening direction then
closes to the fully closed position.
If the switch is released at the incorrect
time, the procedure will have to be performed again from the beginning.

1 Open*
2 Close*
*: To stop the electronic sunshade part-

way, lightly press the either end of the
switch.

n The electronic sunshade can be

operated when
The power switch is in ON.

n Jam protection function for the
electronic sunshade

l If an object becomes jammed

between the electronic sunshade and
the sunshade frame while the electronic sunshade is closing, the electronic sunshade movement is stopped
and the electronic sunshade is
opened slightly.

l When the jam protection function has

operated, even if the “CLOSE” side of
the switch is pressed again, the electronic sunshade will not move in the
close direction until the reverse opera-

If the automatic opening and closing
function does not work normally even
after performing the operations above,
have the vehicle inspected by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

WARNING
Observe the following precautions.
Failure to do so may result in death or
serious injury.

6-4. Using the other interior features

WARNING

541

Other interior features

n Opening and closing the electronic sunshade

Sun visors

l Check to make sure that all passengers do not have any part of their
body in a position where it could be
caught when the electronic sunshade is being operated.

l Do not let a child operate the electronic sunshade. Closing the electronic sunshade on someone can
cause death or serious injury.

n Jam protection function
l Never use any part of your body to
intentionally activate the jam protection function.

l The jam protection function may not

n To prevent burns or injuries
Do not touch the area between the
underside of the panoramic moon
roof and the electronic sunshade.
Your hand may get caught and you
could injure yourself. Also, if the vehicle is left in direct sunlight for a long
time, the underside of the panoramic
moon roof could become very hot and
could cause burns.

Vanity mirrors
Slide the cover to open.
The light turns on when the cover is
opened.

6

Interior features

work if something gets caught just
before the electronic sunshade is
fully closed. Also, the jam protection function is not designed to
operate while the switch is being
pressed. Take care so that your fingers, etc., do not get caught.

1 To set the visor in the forward
position, flip it down.
2 To set the visor in the side position, flip down, unhook, and
swing it to the side.

n Vanity lights
If the vanity lights remain on when the
power switch is turned off, the lights will
go off automatically after 20 minutes.

542

6-4. Using the other interior features

NOTICE
n To prevent 12-volt battery dis-

charge
Do not leave the vanity lights on for
extended periods while the EV system is off.

Power outlets

NOTICE
n When power outlet is not in use
To avoid damaging the power outlet,
close the power outlet lid when the
power outlet is not in use.
Foreign objects or liquids that enter
the power outlet may cause a short
circuit.
n To prevent 12-volt battery dis-

Please use as a power supply for
electronic goods that use less than
12 VDC/10 A (power consumption
of 120 W).

charge
Do not use the power outlet longer
than necessary when the EV system
is off.

When connecting multiple devices,
make sure that the total power consumption of all the connected
devices is less than 120 W.

the vehicle
When turning the power switch off,
make sure to disconnect accessories
designed for charging, such as portable chargers, power banks, etc. from
the power outlets.
If such an accessory is left connected,
the following may occur:
l The doors will not be able to
belocked.

Open the lid.

n To prevent incorrect operation of

l The opening screen will be dis-

played on the multi-information display.

l The interior lights, instrument panellights, etc. will illuminate.

n The power outlet can be used when
The power switch is in ACC or ON, or
the multimedia system is on.

n When stopping the EV system
Disconnect electrical devices with
charging functions, such as mobile battery packs.
If such devices are left connected, the
EV system may not stop normally.

USB Type-C charging ports
The USB Type-C charging ports
are used to supply electricity to
external devices. Use the appropriate terminal for each charging port
type.
The USB Type-C charging ports
are for charging only.They are not
designed for data transfer or other
purposes.
Depending on the external device,

6-4. Using the other interior features

543

it may not charge properly.

 Vehicles with rear seat heaters

Refer to the manual included with
the device before using a USB
Type-C charging port.

These USB Type-C charging ports are
capable of high power output. An output
up to 60 W max on a single port or 60
W combined (shared) is possible.

n Using the USB Type-C charg-

ing ports
 Center console

The USB Type-C charging ports operate at multiple voltage and multiple
wattage levels.

The USB Type-C charging ports are
used to supply 3 A of electricity at 5 V
to external devices.

n The USB Type-C charging ports can

 Vehicles without rear seatheat-

These USB Type-C charging ports are
capable of high power output.
An output up to 60 W max on a single
port or 60 W combined (shared) is possible.
The USB Type-C charging ports operate at multiple voltage and multiple
wattage levels.

n Situations in which the USB Type-C

6

l If a device which consumes more than

Interior features

ers

be used when
The power switch is in ACC or ON, or
the multimedia system is on.
charging ports may not operate
correctly

3 A at 5 V is connected (center console)

l If a device which consumes more than
3 A at 20 V is connected (rear)

l If a device designed to communicate
with a personal computer, such as a
USB memory device, is connected

l If the connected external device is
turned off (depending on device)

l If the temperature inside the vehicle is
high, such as after the vehicle has
been parked in the sun

n About connected external devices
Depending on the connected external
device, charging may occasionally be
suspended and then start again. This is
not a malfunction.

544

6-4. Using the other interior features

NOTICE
n To prevent damage to the USB
Type-C charging ports

l Do not insert foreign objects into
the ports.

l Do not spill water or other liquids
into the ports.

l Do not apply excessive force to or
impact the USB Type-C charging
ports.

l Do not disassemble or modify the
USB Type-C charging ports.

n To prevent damage to external

devices
l Do not leave external devices in the
vehicle. The temperature inside the
vehicle may become high, resulting
in damage to an external device.

l Do not push down on or apply

wirelesspowerconsortium.com/
This function cannot be used with
portable devices that are larger
than the charging tray. Also,
depending on the portable device, it
may not operate as normal. Please
read the operation manual for portable devicesto be used.
n The “Qi” logo

The Qi logo is a trademark of the
Wireless Power Consortium. Qi ID:
14561

n Name for all parts

unnecessary force to an external
device or the cable of an external
device while it is connected.

n To prevent 12-volt battery dis-

charge
Do not use the USB Type-C charging
ports for a long period of time with the
EV system stopped.

Wireless charger
A portable device can be charged
by just placing Qi standard wireless
charge compatible portable devices
according to the Wireless Power
Consortium, such as smart phones
and mobile batteries, etc., on the
charge area.
The compatible portable devices
can be found on the following Wireless Power Consortium website.
https://www.

A Operation indicator light
B Charge area*
C Charging tray

Approximately 2.5 cm (1.0 in.)

6-4. Using the other interior features

Approximately 10 cm (3.9 in.)
*

: The wireless charger detects the
position of the charging coil inside the
portable device and automatically
moves its own coil within the charge
area to align with it.
Charging is possible if the center of
the coil of the portable deviceis
placed within the charge area. If 2 or
more portable devices are placed on
the charging tray, their charging coils
may not be properly detected and
they may not be charged.

n Using the wireless charger

Place the portable device on the
charging tray.
Place the charging side of the portable
device down with the center of the
device in the center of the charge area.

If charging is not occurring, refer to “Situations in which the function may not
operate normally” (P.550)
When charging is complete, the operation indicator light (green) comes on.

n Recharging function

 When charging is complete and
after a fixed time in the charge

suspension state, charging
restarts.
 When a portable device is
moved significantly in the charge
area, the charging coil is disconnected and charging is stopped
momentarily. However, if there is
a charging coil in the charge
area, the charging coil inside the
wireless charger will move
toward it and then charging
restarts. Place the mobile device
near the center of the charging
area again.
n Rapid charging function

 The following portable devices
support rapid charging.
• Portable devices compliant with WPC
Ver1.3.2 and compatible with rapid
charging
• iPhone’s with an iOS version that
supports 7.5 W charging (iPhone 8
and later models)

6

• Portable devices compatible with
Galaxy original rapid charging standard.

Interior features

When charging, the operation indicator
light (orange) on the wireless charger
comes on.

545

 When a portable device that supports rapid charging is charged,
charging automatically switches
to the rapid charging function.

546

6-4. Using the other interior features

n Lighting conditions of operation indicator light
Operation indicator light
Charging tray
side

Multimedia system screen side

Turning off

Disappear

Green (comes
on)

Gray

Orange (comes
on)

Blue

Conditions
When the Multimedia power supply is off or
power switch is off
On Standby (charging possible state)*1
When charging is complete*2
Charging

*1

: Charging power will not be output during standby. A metallic object will not be
heated, if it is placed on the wireless charger in this state.

*2: Depending on the portable device, there are cases where the operation indicator

light will continue being lit up orange even after the charging is complete.

n The wireless charger is not working properly

The following are situations in which the wireless charger does not work
properly and how to deal with the possible causes.
Operation indicator Multimedia system
light
screen

Orange (Flashing
repeatedly once
every second)

Green (Flashing
repeatedly once
every second)

Suspected causes/Handling method
Vehicle to wireless charger communication failure

Gray

 If the EV system is operating, stop
and then restart the EV system.
If the power switch is in ACC, start the EV
system. (P.243)
Wireless charger and multimedia system
communication failure

Disappear

 If the EV system is operating, stop
and then restart the EV system.
If the power switch is in ACC, start the EV
system. (P.243)

6-4. Using the other interior features
Operation indicator Multimedia system
light
screen

547

Suspected causes/Handling method
AM radio stations are being automatically
selected

Green (comes on)

Blue

 Wait until the system has completed
the automatic selection of AM radio
stations. In the case that automatic
selection cannot be completed, stop
automatic selection.
The smart entry & start system is detecting the key.
 Wait until the key detection is
completed.

6

Interior features

548

6-4. Using the other interior features

Operation indicator Multimedia system
light
screen

Suspected causes/Handling method
Foreign substance detection:
A metallic foreign substance is in the
charge area, and so the abnormal heating
prevention function of the metallic foreign
substance operated
 Remove the foreign substance from
the charge area.
Portable device misaligned/distanced
from charging surface:
The center of charging coil in the portable
device moved outside of the charging
area, or lens convex is large, or case is
thick so the abnormal heating prevention
function operated

Green (comes on)

Gray

 Remove the portable device from
the wireless charger, after 5 seconds, then place the portable device
so that it is near the center of the
wireless charger. Also, if a case or
cover is installed to the portable
device, remove it.
Battery protection function of portable
device:
Before full charging, battery protection
function of portable device operated
 Confirm the setting of portable
device.
Continued detection of an electronic key:
When a Multimedia function is used
through vehicle customization, the electronic key is continually detected without
being confirmed
 In this case, turn the power switch
ACC or ON to confirm the key.

6-4. Using the other interior features
Operation indicator Multimedia system
light
screen

Orange (Repeatedly flashes 4 times
continuously)

549

Suspected causes/Handling method
Safety shutdown resulting when the temperature within the wireless charger
exceeded the set value

Gray

n The wireless charger can be oper-

ated when
The power switch is in ACC or ON, or
the multimedia system is on.

n Usable portable devices
l Qi standard wireless charge standard

can be used on compatible devices.
However, compatibility with portable
devices that comply with Qi Ver. 1.0,
1.3.2 and later versions, and Qi2 MPP
(Magnet Power Profile) is not guaranteed.

l Starting with mobile phones and

smartphones, it is aimed for low
power electrically supplied portable
devices of no more than 5 W.

supported by the following portable
devices.
• Charging at 7.5 W or less is supported
by iPhone’s that support 7.5 W charging.
• Charging at 10 W or less is supported
by Galaxy device that support 10 W
charging of original standard.
• Charging at 15 W or less is supported
by portable devices compliant with
EPP output as defined by WPC standard Ver. 1.3.2.

n Using the smart entry & start sys-

tem
If the smart entry & start system detects
the electronic key while a device is
being charged, charging will be temporarily stopped. When the electronic key
is detected, charging will automatically

start again.

n When covers and accessories are

attached to portable devices
Do not charge in situations where cover
and accessories not able to handle Qi
are attached to the portable device.
Depending on the type of cover (including for certain genuine manufacturer
parts) and accessory charging may not
be possible. In addition, Qi2 is not supported. As a result, charging may not be
possible when an accessory and cover
that comply with Qi2 are installed. When
charging is not performed even with the
portable device placed on the charge
area, remove the cover and accessories.

n Important points of the wireless
charger

l If the electronic key cannot be

detected within the vehicle interior,
charging can not be done. When the
door is opened and closed, charging
may be temporarily suspended.

l When charging, the wireless charging
device and portable device will get
warmer, however this is not a malfunction.
When a portable device gets warm
while charging, charging may stop
due to the protection function on the
portable device side. In this case,
when the temperature of the portable
device drops significantly, charge
again.
The fan may start operating to lower
the temperature inside the wireless
charger, however this is not a mal-

6

Interior features

l However, charging exceeding 5 W is

 Stop charging, remove the portable
device from the charging tray wait
for the temperature to drop, and
then start charging again.

550

6-4. Using the other interior features

function.

n Operation sounds
A buzzing noise may be heard when
pressing the power switch to turn to
ACC or ON or when detecting a portable
device. However, this is not a malfunction.
n Cleaning the wireless charger
P.567

n Situations in which the function

may not operate normally
Devices may not be charged normally in
the following situations.

l The portable device is fully charged
l The portable device is being charged
with a cable connected

l There is foreign matter between the
charge area and portable device

l Charging has caused the portable
device to heat up

l The temperature around the wireless

charger is 35°C (95°F) or higher, such
as in extreme heat

l The portable device is placed with its
charging surface facing up

l The small portable device such as

foldable type is placed in an area misaligned from the charge area

l The portable device is larger than the
charging tray

l The camera lens protrudes 3 mm

(0.12 in) or more from the surface of
the portal device

l The vehicle is in an area where strong

electrical waves or noise are emitted,
such as near a television tower, power
plant, gasoline station, broadcasting
station, large display, airport, etc.

l The electronic key is not inside the
vehicle

l Any of the following objects is stuck or

installed between the charging side of
the portable device and the charge
area.
• Thick cases or covers

• A case or cover attached with an uneven or tilted surface, so that the charging side is not flat
• Thick decorations
• Accessories, such as finger rings,
straps, etc.
• Cover to protect camera lens

l When there is a gap between the

charging side of the portable device
and the charge area due to a protrusion such as a camera on the charging side of the portable device.

l When the portable device is in contact

with, or is covered by any of the following metallic objects:
• A card that has metal on it, such as
aluminum foil, etc.
• A pack of cigarettes that includes aluminum foil
• A wallet or bag that is made of metal
• Coins
• A heating pad
• CDs, DVDs or other media
• A metal accessory
• A case or cover made of metal
• A flip type case with a magnet on the
charging side of the portable device

l Electric wave type wireless remote
controls are being used nearby

l 2 or more portable devices are placed
on the charging tray at the same time

l If you use a device with a built-in

S-Pen (Galaxy Note series, etc.) and
the device with the S-Pen inserted is
on the tray.

l When using an external power supply
If charging is abnormal or the operation
indicator light continues to flash for any
other reason, the wireless charger may
be malfunctioning. Contact any authorized Toyota retailer or Toyota authorized
repairer, or any reliable repairer.
n If the smartphone OS has been

updated
If the smartphone OS has been updated
to a newer version, its charging specifications may have changed significantly.
For details, check the information on the
manufacturer’s website.

6-4. Using the other interior features

n Trademark information
iPhone is a trademark of Apple Inc., registered in the U.S. and other countries.
Galaxy is a trademark or registered
trademark of Samsung Electronics
Co.,Ltd.
n Certification
P.710

551

l Do not attach an aluminum sticker

or other metallic object to the side
of the portable device (or to its case
or cover) that touches the charge
area

l Do not use the charging tray as a
small storage space

l Do not subject to a strong force or
impact

WARNING
n Caution while driving

l Do not disassemble, modify or
remove

When charging a portable device, for
safety reasons, the driver should not
operate the main part of the portable
device while driving.

l Do not charge devices other than

n Caution while in motion
Do not charge lightweight devices
such as wireless headphones while in
motion. These devices are very light
and may be ejected from the charging
tray, which may lead to unforeseen
accidents.

l Do not perform charging if the

n Caution regarding interference

n To prevent malfunctions or burns
Observe the following precautions.
Failure to do so may result in a equipment failure and damage, catch fire,
burns due to overheat or electric
shock.
l Do not insert any metallic objects
between the charge area and the
portable device while charging
l Do not attach metallic objects, such
as aluminum stickers, to the charging area.

l Keep away from magnetic items
charging area is dirty

l Do not cover with a cloth or similar
material

NOTICE
n To prevent malfunctions and data
corruptions
l When charging, bringing a credit, or
other magnetic card, or magnetic
storage media close to the charge
area may clear any stored data due
to magnetic influence.
Furthermore, the electronic key
may not operate due to magnetic
interference if the electronic key for
the vehicle is placed on the mobile
phone terminal while charging or an
open space.
Also, do not bring a wristwatch or
other precision instrument close to
the charge area since doing so may
cause it to malfunction.

6

Interior features

with electronic devices
People with implantable cardiac pacemakers, cardiac resynchronization
therapy-pacemakers or implantable
cardioverters, as well as any other
electrical medical device, should consult their physician about the usage of
the wireless charger.

specified portable devices

552

6-4. Using the other interior features

NOTICE
l Do not charge with a non-contact IC
card such as a transportation system IC card inserted between the
charging side of a portable device
and the charge area. The IC chip
may become extremely hot and
damage the portable device or IC
card. Be especially careful not to
charge a portable device inside a
case or cover with a non-contact IC
card attached.

Coat hooks
The coat hooks are provided with
the rear assist grips.

l Do not leave portable devices

inside the vehicle. The inside of the
vehicle can become hot in extreme
heat, which could cause a malfunction.

n To prevent 12-volt battery dis-

charge
Do not use the wireless charger for a
long period of time when the EV system is stopped.

WARNING
n Items that must not be hung on

the hook
Do not hang coat hangers or other
hard or sharp objects on the hook. If
the SRS curtain shield airbags deploy,
these items may become projectiles,
causing death or serious injury.

Armrest
Fold down the armrest for use.

Assist grips
An assist grip installed on the ceiling can be used to support your
body while sitting on the seat.

NOTICE
n To prevent damage to the arm-

rest
Do not apply too much load on the
armrest.

6-4. Using the other interior features

WARNING
n Assist grip
Do not use the assist grip when getting in or out of the vehicle or rising
from your seat.

NOTICE
n To prevent damage to the assist

grip
Do not hang any heavy object or put a
heavy load on the assist grip.

553

Power outlets (220 VAC
1500 W)*
*: If equipped

This system allows the use of
electrical devices with a total
power consumption of 1500 W
at 220 VAC in the vehicle.

Precautions for using the
power outlets while parked
Observe the following precautions
before starting the power supply:
 Park the vehicle on a solid and
level place.
Block the wheels as needed.

 Check that the hood is closed.
 Check that the parking brake is
engaged.
 Check that the P shift position is
selected.

6

Interior features

Supplying power to electrical
devices outside the vehicle is
not recommended, as it may
violate the laws and regulations of the country or region
where it is used. When supplying power to electrical devices
outside the vehicle, check the
laws and regulations with the
relevant local government of
each country or region in
advance. Also, be careful not
to drag electrical devices and
cords when moving the vehicle.

554

6-4. Using the other interior features

 Check that the power switch is
off.
 Note that the alarm system cannot be enabled during the power
supply. For theft prevention, do
not leave valuable items, etc. in
the cabin or luggage compartment.
 Check that AC charging is not
performed.

Names for all parts
n Switches

Using the power outlets
(1500 W)
1 Check that the parking brake is
engaged. securely depress the
brake pedal, and press the
power switch. (P.243)
2 Check that the READY indicator
is illuminated, and press the “AC
220 V” switch.
The power outlet can be used when the
indicator on the “AC 220 V” switch is
illuminated.
The power outlet is turned off/on each
time the “AC 220 V” switch is pressed.

3 Open the lid, and fully and
securely insert the plug of the
device into the power outlet.
(P.555)

Stopping the use of the
power outlets (1500 W)
A Power switch (P.243)
B Power outlet
C “AC 220 V” switch

Follow the procedure described
below:
1 Turn the connected devices off.
2 Press the “AC 220 V” switch to
turn the power outlet off.
3 Disconnect each plug from the
power outlets.

6-4. Using the other interior features

4 Close the lid of each power outlet.

Connecting a device
n When connecting a device

Make sure to read the instruction
manual which came with a device
and observe warnings on the
device.
Before connecting a device to the
power outlet, make sure that the
device is turned off.
1 Open the lid, and fully and
securely insert the plug of the
device into the power outlet.
Do not leave the plug halfway
inserted.
In the following situations, use
cable extension, etc. and connect
the plug securely to the power outlet:

 When the plug of a device is
heavy, possibly causing it to
come off the power outlet.
If the device to be used has a
ground wire, use a conversion
adapter available on the market
and connect the ground wire to the
ground terminal of the conversion
adapter.

n Power outlets
l With these power outlets, use devices

which operate on 220 VAC and have a
combined maximum power consumption of 1500 W or less. If a device is
connected and the power consumption is exceeded, a protection circuit
may be activated and the power supply function may be stopped.

l Some of the devices that consume a
large amount of power, such as an
electric grille, may require the exclusive use of the power outlets. When
such a device is connected, do not
connect other device(s) to the power
outlets.

l When multiple devices are connected,
depending on the device, a connected
device may not operate properly. For
such a device, use exclusively the
power outlets.

l When a power outlet is being used,

depending on the device to be used,
the current flow may be high and the
initial peak wattage may exceed 1500
W.
In this situation, the protection function may activate and stop the power
supply function.

l When a power outlet is being used,

depending on the device to be used, it
may cause interference with TV and
radio broadcasts.

n Devices which may not operate

correctly
The following devices may not operate
properly even if the combined power
consumption is 1500 W or less:

l Devices with high initial peak wattage
l Devices requiring larger amount of
power supply than the power consumption specified in its instruction
manual

l Measuring devices that process precise data

l Devices that require an extremely stable power supply

6

Interior features

 When the plug of a device is too
large to allow it to be inserted
fully and securely into the power
outlet.

555

556

6-4. Using the other interior features

l Devices that require a constant power
supply from the power outlet, such as
a device with a timer.

l Do not attempt to modify, disassem-

n When the power outlets are used

ble, or repair a Power outlet. For
information on repairs, contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

l The doors cannot be locked/unlocked

l Keep the power outlets free of dust

while the vehicle is parked or
stopped

using the smart entry & start system.

l The doors cannot be locked/unlocked
using an electronic key. The doors
can only be locked/unlocked using a
mechanical key.

l When a door is opened/closed, a

buzzer may sound or “Key Not
Detected Check Key Location” may
be displayed on the multi-information
display. Check that an electronic key
is carried with you.

l When the vehicle’s surroundings

become dark while supplying power,
the headlights etc. turn on automatically. Refer to P.260for information
about the lights.

l AC charging or DC charging cannot

and foreign matter. Also, make sure
to clean the power outlets periodically.

l Hold the plug body to plug in/out of
a power outlet. Do not touch the
plug blades. Do not pull on a cord
for unplugging, as otherwise the
plug or cord may be damaged.

l Stop the use immediately if abnor-

mal heat is observed on a cord or
power outlet. To prevent the cord or
power outlet from becoming hot,
observe the following precautions:

• Do not connect 2 or more
multi-point outlet adapters, such as
dual adapters.

be performed.

WARNING
n For safe use
Observe the following precautions.
Failure to do so may lead to an accident, resulting in death or serious
injury.
l Do not allow children or other peo-

ple not used to the operation to perform the power supply by
themselves.

l Do not disconnect the plug of a

device while your hands are wet or
insert a pin or other object into the
power outlet. Also, if a liquid or
snow is on the power outlet, dry the
outlet before using it.

• When an extension cord reel is
used, make sure to draw the whole
cord out of the reel.

6-4. Using the other interior features

WARNING
l If the device to be used has a

ground wire, use a conversion
adapter available on the market
and connect the ground wire to the
ground terminal of the conversion
adapter.

l If the plug of a device fits loosely in

a power outlet, even though it is
fully inserted, replace the power
outlet. For information on replacement, contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

n Cautions when power supply
People with implantable cardiac pacemakers or cardiac resynchronization
therapy-pacemakers should not carry
out the power supply procedure. Ask
someone else to do it.
l Do not approach the charger,
charging cable and the vehicle during power supply.
Power supply procedure may affect
the operation of pacemakers.
l Do not remain in the vehicle during

l Do not enter the vehicle (including

the luggage compartment) to
retrieve something from it, or for
any purpose.
Power supply procedure may affect
the operation of pacemakers.

n Devices to be connected
l Make sure to read any instruction

manual which came with a device
and observe any warnings on the
device.

l Do not connect a device to a power

outlet if the device is malfunctioning
or its plug is damaged.

l Otherwise, the device may be further malfunctioning, especially
when the outside temperature is
high or low.

l Devices requiring to be installed on

a level place may not operate properly.

l Do not use devices, other than

waterproof devices, in a place
where water, such as rain, is
splashed over or where it is humid.

l Do not use a device that has been
or likely to have been merged in
water or absorbed water within.

l Do not connect a medical device,

as depending on the vehicle condition, the power supply function may
be temporarily stopped.

n When the power outlets are used

while the vehicle is parked or
stopped
l The power outlets are designed to
be connected to electric devices,
such as lighting devices. Do not use
them as a generator that supplies
power to a house, etc. Also, when
they are to be used on an emergency power supply device for
homes, such as an exclusive
device having connection to an
external power source, or a device
whose power supply circuit for
external power source is separate
from electric wiring of power companies, consult with the manufacturer or a retailer of the device.

l When using a power outlet, make

sure to securely engage the parking
brake and shift the shift position to
P. Otherwise, the vehicle may
move, possibly leading to an accident.

l When using a power outlet, do not
move away from the vehicle.

6

Interior features

power supply.
Power supply procedure may affect
the operation of pacemakers.

557

558

6-4. Using the other interior features

WARNING

l Do not put your head or hands any-

ing weather when lightning may
occur. Stop supplying power if lightning is observed during power supply.

where inside the motor compartment, as the cooling fan may
operate suddenly. Keep hands and
clothing (especially a tie, scarf, etc.)
away from the fan as they may get
caught in a fan.

l Do not use the power outlets if the

l Do not stop the vehicle near objects

l Do not perform rapid charging dur-

vehicle has a vehicle cover
installed.

l Do not use a power outlet when the

vehicle is parked on a slanted place
or a slope. When a power outlet is
being used, do not move the vehicle or cause it to be inclined.

l Observe the following precautions
when a connected cord is to be
brought outside the vehicle:

• Take due care for not allowing rain
to enter. If the power outlet is wet
with raindrops, dry it before use.
• Prevent the cord from being caught
in the window or door.
• Allow slack in a connected cord. Do
not cause it to be extraordinary
tense.

which burn easily.

l Do not use in places where corro-

sive gases or fluids are generated.

n Use of a power outlet while driv-

ing
l In situations such as the following,
do not use an electric device while
driving. Also, do not use a device if
it cannot be secured within the vehicle.
• When a device is likely to distract
the driver and be a hindrance to
safe driving, such as a TV,
video/DVD player, etc.
• When an inadequately secured
device is likely to fall over in case of
sudden braking or an accident
• When a device is likely to cause fire
if it falls or generates heat
• When a device is likely to cause
burns, such as a toaster, microwave, electric heater, electric kettle,
coffee maker, etc.

• Do not start off the vehicle by mistake.

• When a device is likely to fall under
the pedals and prevent the brake
pedal from being depressed, such
as a hair dryer, AC adapter, mouse,
etc.

l Do not wash the vehicle when using

l Do not use devices which produce

a power outlet.

l Make sure that the hood is closed.

steam while the windows are
closed. Doing so may cause the
windows to fog up, reducing visibility and making it difficult to drive
safely. Also, the steam may damage or negatively affect other
devices. If the device must be used,
stop the vehicle and open the windows before use.

6-4. Using the other interior features

WARNING
n Onboard traction battery charger
The onboard traction battery charger
is located in the motor compartment.
Make sure to observe the following
precautions regarding the onboard
traction battery charger. Failure to
observe these precautions may result
in death or serious injury such as
burns and electric shocks.
l The onboard traction battery
charger is hot during power supply.
Do not touch the onboard traction
battery charger, as doing so may
result in burns.

559

l When not using a power outlet,

make sure to close the lid. If foreign
matter or a liquid enters the power
outlet, it may cause a malfunction
or short circuit.

l Do not disassemble, repair or modify the onboard traction battery
charger. When the onboard traction battery charger needs to be
repaired, consult any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

NOTICE
n To avoid short circuit or malfunc-

l Do not set a toaster or other device

which generates heat near the interior components or on a seat. Heat
may cause these parts to melt or
burn.

l Do not use devices which are sen-

sitive to vibration or heat in the
vehicle. These devices may malfunction due to vibration while driving or heat while the vehicle is
parked in the sun.

6

Interior features

tion
Observe the following precautions.
Failure to do so may lead to the
power outlets not operating correctly
or damage to the vehicle or a connected device.

560

6-4. Using the other interior features

When the power outlet

(AC 220V/1500 W)* cannot be used properly
*

: If equipped

When the power outlets cannot
be used, even though the normal procedure is followed,
check each of the following
items.

When the power outlets cannot be used properly
When the power outlets cannot be
used, even though the normal procedure is followed, check each of
the following items.
n Power outlets cannot be used
Likely cause

Correction procedure

Stop AC charging,
disconnect the
AC charging is in charging connector
and restart the proprogress
cedure from the
beginning.
When the traction battery,
onboard traction
Wait for the outside
battery charger,
temperature to
etc. are hot in
decrease, and then
conditions such
press the “AC 220 V”
as when the outswitch again.
side temperature
is especially
high.

Likely cause

Correction procedure

When the traction battery,
onboard traction Wait for the outside
battery charger, temperature to
etc. are cold in increase, and then
conditions such press the “AC 220 V”
as when the out- switch again.
side temperature
is especially low.
Disconnect the
power source plug of
the electrical device
and check that the
electrical device itself
is not malfunctioning.
Then, press the “AC
220 V” switch again.
Electrical device
If the indicator on the
does not operate
“AC 220 V” switch
does not illuminate,
turn the power switch
off and restart the
procedure from the
beginning. Check the
instruction manual of
the electrical device.

6-4. Using the other interior features
Likely cause

561

Correction procedure

Disconnect the
power source plug of
the electrical device
Total power con- and check that the
total power consumption
exceeds 1500 W sumption does not
exceed 1500 W.
Then, press the “AC
220 V” switch again.

If the power outlets cannot be used
even after performing the procedures above, have the vehicle
inspected by any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.

6

Interior features

Disconnect the
power source plug of
the electrical device
and check the items
below. Then, press
the “AC 220 V”
switch again.
 No foreign matter
Short circuit in
such as a pin has
the power outlet
been inserted
 No substances
such as drinking
water, rain or snow
are adhered
 No dirt or dust is
adhered

562

6-4. Using the other interior features

563

Maintenance and care

7

7-1. Maintenance and care
.

Cleaning and protecting the
vehicle exterior ...............564
Cleaning and protecting the
vehicle interior ................567
7-2. Maintenance
Maintenance requirements
(except for Eurasian Economic Union) ..................571
Maintenance requirements (For
Eurasian Economic Union)
.......................................572
Scheduled maintenance ...574
7-3. Do-it-yourself maintenance
Do-it-yourself service precautions ................................578
Hood .................................580
Positioning a floor jack......581
Motor compartment ..........583

7

Tires..................................589
Wheels..............................600
Air conditioning filter .........602
Electronic key battery .......604
Checking and replacing fuses
.......................................606
Light bulbs ........................608

Maintenance and care

Tire inflation pressure .......599
