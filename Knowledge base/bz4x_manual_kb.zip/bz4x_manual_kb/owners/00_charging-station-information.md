# CHARGING STATION INFORMATION

> Source: Toyota bZ4X Touring — Owner's Manual, Front/back matter, pages 820–820

820
CHARGING STATION INFORMATION

A Auxiliary catch lever (P.580)
B Charging port lid (P.103)
C Power back door switch (P.180)

Hood lock release lever (P.580)
Tire inflation pressure (P.673)
External power source

P.108

Time needed for charging

P.111

Traction battery type

P.670

Cold tire inflation pressure

P.673
