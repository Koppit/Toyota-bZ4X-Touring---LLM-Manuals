# 7-3. Do-it-yourself maintenance

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 7: Maintenance and care, pages 578–608

578

7-3. Do-it-yourself maintenance

Do-it-yourself service
precautions

7-3.Do-it-yourself maintenance

If you perform maintenance by
yourself, be sure to follow the
correct procedure as given in
these sections.

Maintenance
Items

Parts and tools

12-volt battery
condition
(P.585)

• Warm water
• Baking soda
• Grease
• Conventional
wrench (for terminal clamp bolts)
• Distilled water

• In order to ensure
maximum performance of the traction battery cooling
system and limit
risks of battery
short circuit and
other damage to
your vehicle,
Toyota recommends using
Power control
“Toyota Genuine
unit coolant level
Traction Battery
(P.585)
Coolant”or similar
high-quality ethylene glycol-based,
low electric conductivity coolant,
non-amine and
non-borate coolant with azole additives.
• Funnel (used only
for adding coolant)

7-3. Do-it-yourself maintenance

579

Items

Parts and tools

The motor compartment contains
many mechanisms and fluids that
may move suddenly, become hot, or
become electrically energized. To
avoid death or serious injury, observe
the following precautions.

Heater coolantlevel(P.583)

• “Toyota Super
Long Life Coolant”or a similar
high quality ethylene glycol-based,
non-silicate,
non-amine,
non-nitrite and
non-borate coolant with long-life
hybrid organic acid
technology “Toyota
Super Long Life
Coolant” is
pre-mixed with
50% coolant and
50% deionized
water.
• Funnel (used only
for adding coolant)
• Fuse with same
amperage rating
as original

l Do not smoke, cause sparks or

Fuses (P.606)
Radiator
(P.584)


• Tire pressure
gauge
• Compressed air
source

Washer fluid
(P.588)

• Water or washer
fluid containing
antifreeze (for winter use)
• Funnel (used only
for adding water or
washer fluid)

n When working on the motor compartment

l Make sure that “POWER ON” on

the multi-information display and
the “READY” indicator are both off.

l Keep hands, clothing and tools
away from the moving fan.

l Be careful not to touch the motor,
power control unit, radiator, etc.,
right after driving as they may be
hot. Coolant and other fluids may
also be hot.

l Do not leave anything that may

burn easily, such as paper and
rags, in the motor compartment.
expose an open flame to the 12-volt
battery. 12-volt battery fumes are
flammable.

l Be extremely cautious when working on the 12-volt battery. It contains poisonous and corrosive
sulfuric acid.

l Never touch, disassemble, remove
or replace the high voltage parts,
cables and their connectors. It can
cause severe burns or electric
shock that may result in death or
serious injury.

l Take care because brake fluid can

harm your hands or eyes and damage painted surfaces. If fluid gets
on your hands or in your eyes, flush
the affected area with clean water
immediately. If you still experience
discomfort, consult a doctor.

7

Maintenance and care

Tire inflation
pressure
(P.599)

WARNING

580

7-3. Do-it-yourself maintenance

WARNING

Hood

n When working near the electric

cooling fan or radiator grille
Be sure the power switch is off.
With the power switch in ON, the
electric cooling fan may automatically
start to run if the air conditioning is on
and/or the coolant temperature is
high. (P.584)

Opening the hood
1 Pull the hood lock release lever.
The hood will pop up slightly.

n Safety glasses
Wear safety glasses to prevent flying
or falling material, fluid spray, etc.
from getting in your eyes.

NOTICE
n If the fluid level is low or high
It is normal for the brake fluid level to
go down slightly as the brake pads
wear or when the fluid level in the
accumulator is high.
If the reservoir needs frequent refilling, it may indicate a serious problem.

2 Push the auxiliary catch lever to
the left and lift the hood.

7-3. Do-it-yourself maintenance

3 Hold the hood open by insertingthe supporting rod intothe
slot.

581

Positioning a floor jack
When using a floor jack, follow
the instructions in the manual
provided with the jack and perform the operation safely.
When raising your vehicle with
a floor jack, position the jack
correctly. Improper placement
may damage your vehicle or
cause injury.

Location of the jack point
n Front

WARNING
n Pre-driving check

n After installing the support rod

into the slot
Make sure the rod is properly inserted
into the slot to prevent the hood from
shutting on your head or body.

NOTICE
n When closing the hood
Be sure to return the support rod to its
clip before closing the hood.
Closing the hood without returning the
support rod properly could cause the
hood to bend.

7

Maintenance and care

Check that the hood is fully closed
and locked.
If the hood is not locked properly, it
may open while the vehicle is in
motion and cause an accident, which
may result in death or serious injury.

582

7-3. Do-it-yourself maintenance

n Rear

7-3. Do-it-yourself maintenance

583

Motor compartment
Components

A Heater coolant reservoir (P.583)
B Washer fluid tank (P.588)
C Power control unit coolant reservoir (P.585)

7

12-volt battery (P.585)
Radiator (P.584)
Electric cooling fan

Checking the heater coolant
The coolant level is satisfactory if it
is between the “MAX” and “MIN”
lines on the reservoir when the EV
system is cold.

Maintenance and care

Fuse box (P.606)

584

7-3. Do-it-yourself maintenance

A Reservoir cap
B “MAX” line
C “MIN” line
If the level is on or below the “MIN” line,
add coolant up to the “MAX” line.
(P.663)

n Coolant selection
Only use “Toyota Super Long Life Coolant” or a similar high quality ethylene
glycol-based, non-silicate, non-amine,
non-nitrite, and non-borate coolant with
long-life hybrid organic acid technology.
“Toyota Super Long Life Coolant” is a
mixture of 50% coolant and 50% deionized water.
(Minimum temperature: -35°C [-31°F])
For more details about coolant, contact
any authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
n If the coolant level drops within a

short time of replenishing
Visually check the radiator, hoses,
power control unit coolant reservoir caps
and water pump.
If you cannot find a leak, have any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer, test the cap and check for leaks
in the cooling system.

WARNING
n When the heater system is hot
Do not remove the heater coolant reservoir caps.
The heater system may be under
pressure and may spray hot coolant if
the cap is removed, causing serious
injuries, such as burns.

NOTICE
n When adding coolant
Coolant is neither plain water nor
straight antifreeze. The correct mixture of water and antifreeze must be
used to provide proper lubrication,
corrosion protection and cooling. Be
sure to read the antifreeze or coolant
label.
n If you spill coolant
Be sure to wash it off with water to
prevent it from damaging parts or
paint.

Checking the radiator
Check the radiator and clear away
any foreign objects.
If either of the above parts is
extremely dirty or you are not sure
of their condition, have your vehicle
inspected by any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.
WARNING
n When the EV system is hot
Do not touch the radiator as they may
be hot and cause serious injuries,
such as burns.
n When the electric cooling fan is

operating
Do not touch the motor compartment.
With the power switch in ON, the
electric cooling fan may automatically
start to run if the air conditioning is on
and/or the coolant temperature is
high. Be sure the power switch is off
when working near the electric cooling fan or radiator grille.

7-3. Do-it-yourself maintenance

Checking the power control
unit coolant
The coolant level is satisfactory if it
is between the “MAX” and “MIN”
lines on the reservoir when the EV
system is cold.

585

any authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

n If the coolant level drops within a

short time of replenishing
Visually check the hoses, heater coolant
reservoir caps, drain cock and water
pump.
If you cannot find a leak, have any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer, test the cap and check for leaks
in the cooling system.

WARNING
n When the EV system is hot

A Reservoir cap
B “MAX” line

Do not remove the power control unit
coolant reservoir caps.
The cooling system may be under
pressure and may spray hot coolant if
the cap is removed, causing serious
injuries, such as burns.

C “MIN” line
If the level is on or below the “MIN” line,
add coolant up to the “MAX” line.

n Coolant selection

n When adding coolant
Coolant is neither plain water nor
straight antifreeze. The correct mixture of water and antifreeze must be
used to provide proper lubrication,
corrosion protection and cooling. Be
sure to read the antifreeze or coolant
label.

n If you spill coolant
Be sure to wash it off with water to
prevent it from damaging parts or
paint.

Checking the 12-volt battery
Check the 12-volt battery as follows.
n 12-volt battery exterior

Make sure that the 12-volt battery
terminals are not corroded and that

7

Maintenance and care

In order to ensure maximum performance of the traction battery cooling
system and limit risks of battery short
circuit and other damage to your vehicle, Toyota recommends using “Toyota
Genuine Traction Battery Coolant” or
similar high-quality ethylene glycol-based, low electric conductivity coolant, non-amine and non-borate coolant
with azole additives.
Toyota cannot guarantee that the use of
a product other than “Toyota Genuine
Traction Battery Coolant” will prevent
risks of battery short circuit or other
damage.
Never use water as it will cause damage.
Do not reuse coolant that has been
removed from the radiator.
For more details about coolant, contact

NOTICE

586

7-3. Do-it-yourself maintenance

there are no loose connections,
cracks, or loose clamps.

A Terminals

at the cell.

3 Put the vent plug back on and
close it securely.

B Hold-down clamp

n Before recharging

n Checking 12-volt battery fluid

When recharging, the 12-volt battery
produces hydrogen gas which is flammable and explosive. Therefore,
observe the following precautions
before recharging:

Check that the level is between the
“UPPER LEVEL” and “LOWER
LEVEL” lines.

l If recharging with the 12-volt battery

installed on the vehicle, be sure to disconnect the ground cable.

l Make sure the power switch on the

charger is off when connecting and
disconnecting the charger cables to
the 12-volt battery.

n After recharging/reconnecting the
12-volt battery

l The EV system may not start. Follow

A “UPPER LEVEL” line
B “LOWER LEVEL” line
If the fluid level is at or below the
“LOWER LEVEL” line, add distilled
water.

n Adding distilled water

1 Remove the vent plug.
2 Add distilled water.
If the “UPPER LEVEL” cannot be seen,
check the fluid level by looking directly

the procedure below to initialize the
system.
1 Shift the shift position to P.
2 Open and close any of the doors.
3 Restart the EV system.

l Unlocking the doors using the smart

entry & start system may not be possible immediately after reconnecting the
12-volt battery. If this happens, use
the wireless remote control or the
mechanical key to lock/unlock the
doors.

l Start the EV system with the power
switch in ACC*. The EV system may
not start with the power switch turned
off. However, the EV system will oper-

7-3. Do-it-yourself maintenance
ate normally from the second attempt.

l The power switch mode is recorded

by the vehicle. If the 12-volt battery is
disconnected and reconnected, the
vehicle will return the power switch
mode to the status it was in before the
12-volt battery was disconnected.
Make sure to turn off the power switch
before disconnecting the 12-volt battery. Take extra care when connecting
the 12-volt battery if the power switch
mode prior to the 12-volt battery being
disconnected is unknown.

If the EV system will not start even after
multiple attempts at all the methods
above, contact any authorized Toyota
retailer or Toyota authorized repairer, or
any reliable repairer.
*: ACC mode can be enabled/disabled

on the customize menu. (P.675)

WARNING
n Chemicals in the 12-volt battery

l Do not smoke or light a match near
the 12-volt battery.

l Avoid contact with eyes, skin and

n Where to safely charge the

12-volt battery
Always charge the 12-volt battery in
an open area. Do not charge the
12-volt battery in a garage or closed
room where there is insufficient ventilation.

n Emergency measures regarding
electrolyte

l If electrolyte gets in your eyes

Flush your eyes with clean water for
at least 15 minutes and get immediate medical attention. If possible,
continue to apply water with a
sponge or cloth while traveling to
the nearest medical facility.

l If electrolyte gets on your skin

Wash the affected area thoroughly.
If you feel pain or burning, get medical attention immediately.

l If electrolyte gets on your clothes

It can soak through clothing on to
your skin. Immediately take off the
clothing and follow the procedure
above if necessary.

l If you accidentally swallow electro-

lyte
Drink a large quantity of water or
milk. Get emergency medical attention immediately.

n When there is insufficient 12-volt

battery fluid
Do not use if there is insufficient fluid
in the 12-volt battery. There is a possible danger that the 12-volt battery
may explode.

clothes.

l Never inhale or swallow electrolyte.
l Wear protective safety glasses

when working near the 12-volt battery.

l Keep children away from the
12-volt battery.

NOTICE
n When recharging the 12-volt bat-

tery
Never recharge the 12-volt battery
while the EV system is operating.
Also, be sure all accessories are
turned off.

7

Maintenance and care

Batteries contain poisonous and corrosive sulfuric acid and may produce
hydrogen gas which is flammable and
explosive. To reduce the risk of death
or serious injury, take the following
precautions while working on or near
the 12-volt battery:
l Do not cause sparks by touching
the 12-volt battery terminals with
tools.

587

588

7-3. Do-it-yourself maintenance

NOTICE
n When adding distilled water
Avoid overfilling. Water spilled during
12-volt battery recharging may cause
corrosion.

Adding the washer fluid
If any washer does not work or the
warning message appears on the
multi-information display, the
washer tank may be empty.
Add washer fluid.

WARNING
n When adding washer fluid
Do not add washer fluid when the EV
system is hot or operating as washer
fluid contains alcohol and may catch
fire if spilled on the motor, etc.

NOTICE
n Do not use any fluid other than

washer fluid
Do not use soapy water or antifreeze
instead of washer fluid.
Doing so may cause streaking on the
vehicle’s painted surfaces, as well as
damaging the pump leading to problems of the washer fluid not spraying.

n Diluting washer fluid
Dilute washer fluid with water as necessary.
Refer to the freezing temperatures
listed on the label of the washer fluid
bottle.

7-3. Do-it-yourself maintenance

Tires
Replace or rotate tires in
accordance with maintenance
schedules and treadwear.

Checking tires
Check if the treadwear indicators
are showing on the tires. Also
check the tires for uneven wear,
such as excessive wear on one
side of the tread.
Vehicles with a spare tire: Check
the spare tire condition and pressure if not rotated.

shown by a “TWI” or “

589

” mark, etc.,

molded into the sidewall of each tire.
Replace the tires if the treadwear indicators are showing on a tire.

n When to replace your vehicle’s

tires
Tires should be replaced if:

l The treadwear indicators are showing
on a tire.

l You have tire damage such as cuts,

splits, cracks deep enough to expose
the fabric, and bulges indicating internal damage.

l A tire goes flat repeatedly or cannot

be properly repaired due to the size or
location of a cut or other damage.
If you are not sure, consult any authorized Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

n Tire life
Any tire over 6 years old must be
checked by a qualified technician even if
it has seldom or never been used or
damage is not obvious.
n If the tread on snow tires wears

down below 4 mm (0.16 in.)
The effectiveness of the tires as snow
tires is lost.

n When inspecting or replacing

A New tread

tires
Observe the following precautions to
prevent accidents.
Failure to do so may cause damage
to parts of the drive train as well as
dangerous handling characteristics,
which may lead to an accident resulting in death or serious injury.

B Worn tread

l Do not mix tires of different makes,

C Treadwear indicator
The location of treadwear indicators is

models or tread patterns.
Also, do not mix tires of remarkably
different treadwear.

Maintenance and care

WARNING

7

590

7-3. Do-it-yourself maintenance

WARNING
l Do not use tire sizes other than

those recommended by Toyota.

l Do not mix differently constructed

tires (radial, bias-belted or bias-ply
tires).

l Do not mix summer, all season and
snow tires.

l Do not use tires that have been

used on another vehicle.
Do not use tires if you do not know
how they were used previously.

l Vehicles with an emergency tire

puncture repair kit: Do not tow anything if a tire that has been repaired
using the emergency tire puncture
repair kit is installed.
The load on the tire may cause
unexpected damage to the tire.

NOTICE
n Driving on rough roads
Take particular care when driving on
roads with loose surfaces or potholes.
These conditions may cause losses in
tire inflation pressure, reducing the
cushioning ability of the tires. In addition, driving on rough roads may
cause damage to the tires themselves, as well as the vehicle’s
wheels and body.
n If tire inflation pressure of each

tire becomes low while driving
Do not continue driving, or your tires
and/or wheels may be ruined.

Tire rotation
Rotate the tires in the order shown.

A Front
To equalize tire wear and help extend
tire life, Toyota recommends that tire
rotation is carried out approximately
every 10000 km (6000 miles).

n When rotating the tires
Make sure that the power switch is off. If
the tires are rotated while the powerswitch is in ON, the tire position informationwill not be updated.
If this accidentally occurs, either turn the
power switch to off and then to ON, or
initialize the tire pressure warning system after checking that the tire pressure
is properly adjusted.

Tire pressure warning system
Your vehicle is equipped with a tire
pressure warning system that uses
tire pressure warning valves and
transmitters to detect low tire inflation pressure before serious problems arise.
The tire pressure warning system
of this vehicle adopts a 2-type
warning system. (P.622)

7-3. Do-it-yourself maintenance
 Multi-information display

591

to detect sudden tire ruptures (bursting,
etc.).

 The tire pressure detected by the
tire pressure warning system can
be displayed on the multi-information display and the multimedia display.
n Routine tire inflation pressure

 Multimedia display

checks
The tire pressure warning system does
not replace routine tire inflation pressure
checks. Make sure to check tire inflation
pressure as part of your routine of daily
vehicle checks.

n Tire inflation pressure
l It may take a few minutes to display

the tire inflation pressure after the
power switch is turned to ON. It may
also take a few minutes to display the
tire inflation pressure after inflation
pressure has been adjusted.

 When “Adjust Pressure” is displayed (Normal Warning)

 When “Immediately Check tyre
when Safe” is displayed on the
multi-information display (Emergency Warning)
A warning with the tire pressure warning light and warning buzzer when
there is a known level of low tire pressure with the appearance of the tire due
to pressure suddenly lowering.
However, the system may not be able

temperature. The displayed values
may also be different from the values
measured using a tire pressure
gauge.

n Situations in which the tire pres-

7

l In the following cases, the tire pres-

Maintenance and care

A warning with the tire pressure warning light and warning buzzer when
there is an unknown level of low tire
pressure with the appearance of the tire
due to natural air leakage as well as the
pressure lowering due to changes in
the pressure according to the outside
temperature.

l Tire inflation pressure changes with

sure warning system may not operate properly

sure warning system may not operate
properly.
• If non-genuine Toyota wheels are
used.
• A tire has been replaced with a tire
that is not an OE (Original Equipment)
tire.
• A tire has been replaced with a tire
that is not of the specified size.
• Tire chains, etc. are equipped.
• If a window tint that affects the radio
wave signals is installed.
• If there is a lot of snow or ice on the
vehicle, particularly around the wheels
or wheel housings.
• If the tire inflation pressure is

592

7-3. Do-it-yourself maintenance

extremely higher than the specified
level.
• If tires not equipped with tire pressure
warning valves and transmitters are
used.
• If the ID code on the tire pressure
warning valves and transmitters is not
registered in the tire pressure warning
computer.

l Performance may be affected in the

following situations.
• Near a TV tower, electric power plant,
gas station, radio station, large display, airport or other facility that generates strong radio waves or electrical
noise
• When carrying a portable radio, cellular phone, cordless phone or other
wireless communication device

l If tire position information is not cor-

rectly displayed due to the radiowave
conditions, the display may becorrected by driving and changing the
radio wave conditions.

l When the vehicle is parked, the time

taken for the warning to start or go off
could be extended.

n When replacing the tires and

wheels
If the ID code of the tire pressure warning valve and transmitter is not registered, the tire pressure warning system
will not work properly. In this case, after
driving for about 10 minutes, the tire
pressure warning light blinks for 1 minute and stays on to indicate a system
malfunction.

NOTICE
n Repairing or replacing tires,

wheels, tire pressure warning
valves, transmitters and tire
valve caps
l When removing or fitting the
wheels, tires or the tire pressure
warning valves and transmitters,
contact any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer as
the tire pressure warning valves
and transmitters may be damaged
if not handled correctly.

l When tire inflation pressure declines

l Make sure to install the tire valve

Installing tire pressure warning valves and transmitters

l When replacing tire valve caps, do

rapidly for example when a tire has
burst, the warning may not function.

When replacing tires or wheels, tire
pressure warning valves and transmitters must also be installed.
When new tire pressure warning
valves and transmitters are
installed, new ID codes must be
registered in the tire pressure warning computer and the tire pressure
warning system must be initialized.
(P.596)

caps. If the tire valve caps are not
installed, water could enter the tire
pressure warning valves and the
tire pressure warning valves could
be bound.
not use tire valve caps other than
those specified. The cap may
become stuck.

7-3. Do-it-yourself maintenance

NOTICE
n To avoid damage to the tire pres-

sure warning valves and transmitters (vehicles with an
emergency tire puncture repair
kit)
When a tire is repaired with liquid
sealants, the tire pressure warning
valve and transmitter may not operate
properly. If a liquid sealant is used,
contact any authorized Toyota retailer
or Toyota authorized repairer, or any
reliable repairer or other qualified service shop as soon as possible. After
use of liquid sealant, make sure to
replace the tire pressure warning
valve and transmitter when repairing
or replacing the tire.

Registering the position of
each wheel
n When to register the position

of each wheel
It is necessary to register the position of each wheel after performing
a tire rotation.

n Registering the position of

each wheel

The wheel position registration procedure cannot be performed while the
vehicle is moving.

3 Select
display.

on the multimedia

4 Select “Vehicle customise”.
5 Select “Tyre pressure”.
6 Select “Tyre rotation”.
7 Select “Continue”.
A message indicating that wheel position registration is being performed will
be displayed on the multi-information
display. “---” will be displayed for the tire
inflation pressure of each tire and
wheel position registration will begin.

8 Drive straight (with occasional
left and right turns) at approximately 40 km/h (25 mph) or
more for approximately 10 to 30
minutes.
When wheel position registration is
complete, a message indicating that
registration has been completed and
the inflation pressure of each tire will be
displayed on the multi-information display.
Even if it is not possible to drive continuously at approximately 40 km/h (25
mph) or more, registration can be completed by driving for a long time. However, if registration does not complete
after driving for 1 hour or more, park the
vehicle in a safe place and leave it with
the power switch in ON for approximately 15 minutes or more, and then
perform the driving procedure again.

n When performing wheel position
registration

1 Park the vehicle in a safe place,
turn the power switch off and
wait 15 minutes or more.

l Normally, wheel position registration

2 Start the EV system.

l Wheel position registration is per-

can be completed within approximately 30 minutes.
formed while driving at a vehicle

7

Maintenance and care

Wheel position registration can be
performed by oneself. Wheel position registration is performed by
driving forward with moderate left
and right turns. However, depending on the driving conditions and
driving environment, registration
may take some time to complete.

593

594

7-3. Do-it-yourself maintenance

speed of approximately 40 km/h (25
mph) or more.

n Wheel position registration procedure

l If the power switch is turned off while

registering the wheel position, the
next time the power switch is turned to
ON, the wheel position registration will
resume and it will not be necessary to
restart the procedure.

l While the position of each wheel is

being determined and the inflation
pressures are not being displayed, if
the inflation pressure of a tire drops,
the tire pressure warning light will
come on.

n If the wheel position cannot be registered easily

l In the following situations, wheel posi-

tion registration may take longer than
usual to be completed or may not be
possible.
• Vehicle is not driven at approximately
40 km/h (25 mph) or more
• Vehicle is driven on unpaved roads

l If wheel position registration does not

complete after driving for 1 hour or
more, park the vehicle in a safe place
for approximately 15 minutes and then
drive the vehicle again.

l If the vehicle is reversed during wheel

due to carried load, etc.
 When the tire inflation pressure
is changed such as when the tire
size is changed.
If the tire inflation pressure has
been adjusted to the specified
level, perform the tire inflation setting procedure by selecting specified inflation pressure on the
multimedia display. (P.594)
When the tire inflation pressure is
to be other than specified, such as
when tires other than the specified
size are used, etc., set the tire inflation pressure using the current
pressure. Make sure to adjust the
tire inflation pressure of each tire to
the appropriate level before performing tire pressure setting. The
tire pressure warning system operates based on this tire inflation
pressure. (P.595)
n Setting by selecting a speci-

fied tire inflation pressure

position registration, all data collected
until then will be cleared. Perform driving again.

1 Start the EV system.

Setting the tire pressure

2 Select
display.

n When you need to setting the

tire pressure
In the following situations, it will be
necessary to perform the tire inflation pressure setting procedure of
the tire pressure warning system.
 When the specified tire inflation
pressure has changed, such as

The tire inflation pressure cannot be set
while the vehicle is moving.

on the multimedia

3 Select “Vehicle customise”.
4 Select “Tyre pressure”.
5 Select “Set indicated air pressure” and then select the
desired front and rear tire pressures.
6 Select “OK”.

7-3. Do-it-yourself maintenance
The tire pressure warning light will
slowly blink 3 times.
After setting the tire inflation pressure, a
message indicating that setting has
been completed will be displayed on
the multi-information display.

595

the multi-information display.

n Warning performance of the tire

pressure warning system (Setting
using the current tire inflation pressure)

n Setting using the current tire

inflation pressure
1 Adjust the tire inflation pressure
of each tire to the appropriate
level.
Make sure to adjust the tire inflation
pressure with the tires cold.

2 Start the EV system.
The tire inflation pressure cannot be set
while the vehicle is moving.

3 Select
display.

on the multimedia

5 Select “Tyre pressure”.
6 Select “Set current air pressure”.
7 Select “Continue”.
The tire pressure warning light will
slowly blink 3 times and a message
indicating that tire inflation pressure is
being set will be displayed on the
multi-information display.
After setting the tire inflation pressure, a
message indicating that setting has
been completed will be displayed on

setting using the current tire inflation
pressure, the warning timing of the tire
pressure warning system will vary
according to the conditions under
which tire pressure setting was performed. Therefore, a warning may be
output even if the tire inflation pressure drops slightly or if the tire inflation
pressure increases above that when
the tire inflation pressure was set.

l Make sure to perform the tire pressure

setting procedure after adjusting the
tire inflation pressure. Also, make sure
the tires are cold before performing
the tire pressure setting procedure or
adjusting the tire inflation pressure.

n Tire inflation pressure setting procedure (Setting using the current
tire inflation pressure)

l If the power switch is turned off while

setting the tire inflation pressure, the
next time the power switch is turned to
ON, the setting procedure will resume
and it will not be necessary to restart
the procedure.

l If the tire inflation pressure setting

procedure is started unnecessarily,
adjust the tire inflation pressure to the
specified level with the tires cold and
then perform setting by selecting a
specified tire inflation pressure, or perform the tire inflation pressure setting

7

Maintenance and care

4 Select “Vehicle customise”.

l When performing the tire pressure

596

7-3. Do-it-yourself maintenance

procedure with the current tire inflation
pressure.

n If the tire inflation pressure cannot
be set easily

l Normally, it takes approximately 3

minutes to complete the setting procedure to the current tire inflation pressure.

l If the tire pressure warning light does

not blink 3 times when starting the tire
inflation pressure setting procedure,
the procedure may not have started.
Perform the procedure again from the
beginning.

l If tire inflation pressure setting proce-

dure cannot be completed after performing the above procedure, contact
any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.

WARNING
n When setting using the current

tire inflation pressure
Make sure to adjust the tire inflation
pressure of each tire to the appropriate level before performing tire pressure setting. Otherwise, the tire
pressure warning light may not illuminate even if the tire inflation pressure
drops or may illuminate even though
the tire inflation pressure is normal.

Registering ID codes
n When to register ID codes

The tire pressure warning valve
and transmitter is equipped with a
unique ID code. When new tire
pressure warning valves and transmitters are installed, new ID codes
must be registered in the tire pressure warning computer.

n How to registration ID code

Before performing ID code registration, make sure that no wheels with
tire pressure warning valve and
transmitters installed are near the
vehicle.
1 Park the vehicle in a safe place,
turn the power switch off and
wait 15 minutes or more.
2 Start the EV system.
The ID code registration procedure
cannot be performed while the vehicle
is moving.

3 Select
display.

on the multimedia

4 Select “Vehicle customise”.
5 Select “Tyre pressure”.
6 Check if the desired wheel set
(“Set 1” or “Set 2”) is displayed.
ID codes will be registered to the displayed wheel set.
To change the wheel set to be registered, select the displayed set, and
then select the wheel set you wish to
register.
If ID codes have already been registered for that wheel set, the tire pressure warning light will slowly blink 3
times, and a message indicating that
change is occurring will be displayed on
the multi-information display.

7-3. Do-it-yourself maintenance

7 Select “New tyre registration”.
8 Select “Continue”.
The tire pressure warning light will
slowly blink 3 times and a message
indicating that ID code registration is
being performed will be displayed on
the multi-information display. Wheel set
changing will be canceled and registration will begin.
When registration is being performed,
the tire pressure warning light will blink
for approximately 1 minute then illuminate and “---” will be displayed for the
inflation pressure of each tire on the
multi-information display.

9 Drive straight (with occasional
left and right turns) at approximately 40 km/h (25 mph) or
more for approximately 10 to 30
minutes.

10If the tire inflation pressure of
the wheel set installed differs
from that of the previous set, it
will be necessary to perform the
tire inflation pressure setting
procedure of the tire pressure
warning system. (P.594)
If the specified tire inflation pressure is
the same, it will not be necessary to
perform the tire inflation pressure setting procedure.

n When registering ID codes
l Normally, wheel position registration
can be completed within approximately 30 minutes.

l ID code registration is performed

while driving at a vehicle speed of
approximately 40 km/h (25 mph) or
more.

l ID codes can be registered by your-

self, but depending on the driving conditions and driving environment,
registration may take some time to
complete.

l When using a wheel set which all of

the ID codes have already been registered, the wheel set can be changed
in a short amount of time. (P.598)

n If ID codes are not registered easily
l In the following situations, ID code

registration may take longer than
usual to be completed or may not be
possible.
• When the vehicle has not been
parked for approximately 15 minutes
or more before being driven
• Vehicle is not driven at approximately
40 km/h (25 mph) or more
• Vehicle is driven on unpaved roads
• Vehicle is driven near other vehicles
and system cannot recognize tire
pressure warning valve and transmitters of your vehicle over those of other
vehicles
• Wheel with tire pressure warning
valve and transmitter installed is
inside or near the vehicle

l If the vehicle is reversed during regis-

tration, all data collected until then will
be cleared. Perform driving again.

l If registration does not complete after

driving for 1 hour or more, perform the
ID code registration procedure again
from the beginning.

l If the tire pressure warning light does

not blink 3 times when starting ID
code registration procedure, the procedure may not have started. Perform
the procedure again from the begin-

7

Maintenance and care

When registration is complete, the tire
pressure warning light will turn off and a
message indicating that registration
has been completed will be displayed
on the multi-information display.
Registration may take longer than normal to complete if the vehicle speed
cannot be maintained at approximately
40 km/h (25 mph) or more. If registration cannot be completed after driving
for 1 hour or more, perform the registration procedure again from the beginning.

597

598

7-3. Do-it-yourself maintenance

ning.

l If the ID codes cannot be registered

even when performing the above procedure, contact any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer.

Canceling ID code registration

 Only a change between both
registered wheel set is possible,
mixing between these wheel sets
is not supported.
 While registering ID codes, it
may not be possible to change
between wheel sets normally.
Cancel registration before
changing between wheel sets.

To cancel ID code registration after
it has been started, select “New
tyre registration” again on the multimedia display.

1 Install the desired wheel set.

If ID code registration has been
canceled, the tire pressure warning
light will turn off.

2 Select
display.

If the warning light does not turn off, ID
code registration may not have been
cancelled correctly. To cancel registration, select “New tyre registration” again
on the multimedia display.

Selecting wheel set
Your vehicle is equipped with a tire
pressure warning system with a
function to register two sets of ID
codes. This allows for registration
of a second wheel set, for example
a winter set.
 The wheel set can be changed
only if a second wheel set has
been registered to the system. If
a second wheel set has not been
registered, “Set 2 (Unregistered)”
will be displayed and it will not be
possible to change to the
selected wheel set.
ID codes can be registered by yourself.
(P.596)

n Changing ID codes between

different wheel sets

on the multimedia

3 Select “Vehicle customise”.
4 Select “Tyre pressure”.
5 Select the wheel set (“Set 1” or
“Set 2”) displayed for the set
selection setting.
6 Select the wheel set you wish to
register, and then select “OK”.
The tire pressure warning light will
slowly blink 3 times, a message indicating that change is occurring will be displayed, and the wheel set change will
begin.
Wheel set change will begin and the tire
pressure warning light will blink for 1
minute and then illuminate. Also, while
the change is being performed, “---” will
be displayed for the tire inflation pressure of each tire on the multi-information display.
After approximately 2 minutes, the
wheel set change will complete, the tire
pressure warning light will turn off, and
a completion message will be displayed
on the multi-information display.
If changing does not complete after
approximately 4 minutes, a message
indicating that the change could not be

7-3. Do-it-yourself maintenance
completed will be displayed.
Check which wheel set is installed and
perform the change procedure again
from the beginning.

7 If the specified tire inflation pressure of the wheel set installed
differs from that of the previous
set, it will be necessary to perform the tire inflation pressure
setting procedure of the tire
pressure warning system.
(P.594)
If the specified tire inflation pressure is
the same, it will not be necessary to
perform the tire inflation pressure setting procedure.

8 Register the position of each
wheel. (P.593)

599

Tire inflation pressure
Make sure to maintain proper
tire inflation pressure. Tire
inflation pressure should be
checked at least once per
month. However, Toyota recommends that tire inflation
pressure be checked once
every two weeks.
n Effects of incorrect tire inflation

pressure
Driving with incorrect tire inflation pressure may result in the following:

l Reduced electricity consumption efficiency

l Reduced driving comfort and poor
handling

l Reduced tire life due to wear
l Reduced safety
l Damage to the drive train
If a tire needs frequent inflating, have it
checked by any authorized Toyota
retailer or Toyota authorized repairer, or
any reliable repairer.

7

n Instructions for checking tire infla-

l Check only when the tires are cold.

If your vehicle has been parked for at
least 3 hours or has not been driven
for more than 1.5 km or 1 mile, you
will get an accurate cold tire inflation
pressure reading.

l Always use a tire pressure gauge.

It is difficult to judge if a tire is properly
inflated based only on its appearance.

l It is normal for the tire inflation pres-

sure to be higher after driving as heat
is generated in the tire. Do not reduce
tire inflation pressure after driving.

Maintenance and care

tion pressure
When checking tire inflation pressure,
observe the following:

600

7-3. Do-it-yourself maintenance

l Passengers and luggage weight

should be placed so that the vehicle is
balanced.

WARNING
n Proper inflation is critical to save

tire performance
Keep your tires properly inflated.
If the tires are not properly inflated,
the following conditions may occur
which could lead to an accident
resulting in death or serious injury:

l Excessive wear
l Uneven wear
l Poor handling
l Possibility of blowouts resulting
from overheated tires

l Air leaking from between tire and
wheel

l Wheel deformation and/or tire damage

l Greater possibility of tire damage

while driving (due to road hazards,
expansion joints, sharp edges in the
road, etc.)

NOTICE
n When inspecting and adjusting

tire inflation pressure
Be sure to put the tire valve caps back
on.
If a valve cap is not installed, dirt or
moisture may get into the valve and
cause an air leak, resulting in
decreased tire inflation pressure.

Wheels
If a wheel is bent, cracked or
heavily corroded, it should be
replaced. Otherwise, the tire
may separate from the wheel
or cause a loss of handling
control.

Wheel selection
When replacing wheels, care
should be taken to ensure that they
are equivalent to those removed in
load capacity, diameter, rim width
and inset*.
Replacement wheels are available
at any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer.
*: Conventionally referred to as offset.

Toyota does not recommend using
the following:
 Wheels of different sizes or types
 Used wheels
 Bent wheels that have been
straightened
n When replacing wheels
The wheels of your vehicle are equipped
with tire pressure warning valves and
transmitters that allow the tire pressure
warning system to provide advance
warning in the event of a loss in tire
inflation pressure. Whenever wheels are
replaced, tire pressure warning valves
and transmitters must be installed.
(P.592)

7-3. Do-it-yourself maintenance

WARNING
n When replacing wheels
l Do not use wheels that are a different size from those recommended
in the Owner’s Manual, as this may
result in a loss of handling control.

l Never use an inner tube in a leak-

ing wheel which is designed for a
tubeless tire. Doing so may result in
an accident, causing death or serious injury.

n When installing the wheel nuts
Never use oil or grease on the wheel
bolts or wheel nuts. Oil and grease
may cause the wheel nuts to be
excessively tightened, leading to bolt
or disc wheel damage.
In addition, the oil or grease can
cause the wheel nuts to loosen and
the wheel may fall off, causing an
accident and resulting in death or
serious injury. Remove any oil or
grease from the wheel bolts or wheel
nuts.
n Use of defective wheels prohib-

NOTICE
n Replacing tire pressure warning
valves and transmitters

l Because tire repair or replacement

may affect the tire pressure warning
valves and transmitters, make sure
to have tires serviced by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer or other qualified service
shop. In addition, make sure to purchase your tire pressure warning
valves and transmitters at any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

l Ensure that only genuine Toyota

wheels are used on your vehicle.
Tire pressure warning valves and
transmitters may not work properly
with non-genuine wheels.

Aluminum wheel precautions
 Use only Toyota wheel nuts and
wheel nut wrenches designed for
use with your aluminum wheels.
 When rotating, repairing or
changing your tires, check that
the wheel bolts are still tight after
driving 1000 km (621 miles).
 Be careful not to damage the
aluminum wheels when using
tire chains.
 Use only Toyota genuine balance
weights or equivalent and a plastic or rubber hammer when balancing your wheels.

7

Maintenance and care

ited
Do not use cracked or deformed
wheels.
Doing so could cause the tire to leak
air during driving, possibly causing an
accident.

601

602

7-3. Do-it-yourself maintenance

Air conditioning filter

4 Vehicles with footwell lights:
Unplug the connector.

The air conditioning filter must
be changed regularly to maintain air conditioning efficiency.

Removing the air conditioning filter
1 Turn the power switch off.
Confirm that the charging connector is
not connected.

2 Open the front passenger’s
door.
3 While pressing the claw, hold
handle
panel.

and remove the

5 Unlock the filter cover ( A ), pull
the filter cover out of the claws
( B ), and remove the filter
cover.

6 Hold the filter case A and
remove the lower filter case.

7-3. Do-it-yourself maintenance

7 Hold the filter case A and pulldown the upper filter case.

603

rear of the vehicle.

10When installing, reverse thesteps listed.
n When installing the filter cover
Slide the recessed part
of the filter
cover on the upper surface of the upper
filter case
as shown in the figure,
and attach it so that it is lifted toward the
insertion part of the cover attachment.
 Left-hand drive vehicles

8 Hold the filter case A and
remove the upper filter case.
Dust and dirt (fallen leaves, etc.) may
have accumulated within the bottom of
the air conditioning unit, so remove it
with a vacuum cleaner.
 Right-hand drive vehicles

7

n Checking interval
Inspect and replace the air conditioning
filter according to the maintenance
schedule. In dusty areas or areas with
heavy traffic flow, early replacement
may be required. (Except for Eurasian
Economic Union: For scheduled maintenance information, please refer to the
“Toyota Service Booklet” or “Toyota Warranty Booklet”.)
n If air flow from the vents decreases

dramatically
The filter may be clogged. Check the filter and replace if necessary.
Install so that the arrow points to the

Maintenance and care

9 Remove the air conditioning filter from the upper and lower filter case and replace it with a
new one.

604

7-3. Do-it-yourself maintenance

WARNING

Electronic key battery

n When replacing the air condition-

ing filter
Observe the following precautions.
Failure to do so may resultin the air
conditioning system operating during
the procedure, possibly resulting in
injury.
Check that the charging connector is
not connected.

NOTICE
n When using the air conditioning
system

Replace the battery with a new
one if it is depleted.
As the key may be damaged if
the following procedure is not
performed properly, it is recommended that key battery
replacement be performed by
any authorized Toyota retailer
or Toyota authorized repairer,
or any reliable repairer.

l Make sure that a filter is always

installed.
Using the air conditioning system
without a filtermay cause damage
to the system.

l The filter is replaceable. When

cleaning the filter, do not clean with
water or an air gun.

n If the electronic key battery is

depleted
The following symptoms may occur:

l The smart entry & start system and

wireless remote control will not function properly.

l The operational range will be reduced.

n To prevent damage to the filter

cover
When moving the filter cover in the
direction of arrow to release the fitting, pay attention not to apply excessive force to the claws. Otherwise, the
claws may be damaged.

Items to prepare
Prepare the following before replacing the battery:
 Flathead screwdriver
 Small flathead screwdriver
 Lithium battery CR2450
n Use a CR2450 lithium battery
l Batteries can be purchased at any

authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer, local electrical appliance
shops or camera stores.

l Replace only with the same or equivalent type recommended by the manufacturer.

l Dispose of used batteries according to
the local laws.

7-3. Do-it-yourself maintenance

Replacing the battery

605

nal facing up.

1 Remove the lock and take out
the mechanical key.

2 Remove the cover.
Use a screwdriver of an appropriate
size. Forcedly prying may cause the
cover damaged.
To prevent damage to the key, cover
the tip of the flathead screwdriver with a
tape.

4 When installing the key cover
and mechanical key, install by
conducting step 2 and step 1
with the directions reversed.
WARNING
n Battery precautions
Observe the following precautions.
Failure to do so may result in death or
serious injury.

l Do not swallow the battery. Doing
so may cause chemical burns.

l A coin battery or button battery is

used in the electronic key. If a battery is swallowed, it may cause
severe chemical burns in as little as
2 hours and may result in death or
serious injury.
teries from children.

3 Remove the depleted battery
using a small flathead screwdriver.

l If the cover cannot be firmly closed,

When removing the cover, the electronic key module may stick to the
cover and the battery may not be visible.
In this case, remove the electronic key
module in order to remove the battery.
When removing the battery, use a
screwdriver of an appropriate size.
Insert a new battery with the “+” termi-

l If you accidentally swallow a battery

stop using the electronic key and
stow the key in the place where
children cannot reach, and then
contact any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.

or put a battery into a part of your
body, get emergency medical attention immediately.

Maintenance and care

l Keep away new and removed bat-

7

606

7-3. Do-it-yourself maintenance

n To prevent battery explosion or

Checking and replacing
fuses

l Do not expose batteries to

If any of the electrical components do not operate, a fuse
may have blown. If this happens, check and replace the
fuses as necessary.

l Do not burn, break or cut a battery.

Checking and replacing
fuses

n Certification for the smart entry

1 Turn the power switch off.

WARNING
leakage of flammable liquid or
gas
l Replace the battery with a new battery of the same type. If a wrong
type of battery is used, it may
explode.
extremely low pressure due to high
altitude or extremely high temperatures.

& start system
CAUTION
RISK OF EXPLOSION IF BATTERY
IS REPLACED BY AN INCORRECT
TYPE.
DISPOSE OF USED BATTERIES
ACCORDING TO THE INSTRUCTIONS

Confirm that the charging connector is
not connected.

2 Open the fuse box cover.
 Motor compartment

Push the tab in and lift the lid off.

NOTICE
n When replacing the battery
Use a flathead screwdriver of appropriate size. Applying excessive force
may deform or damage the cover.

n For normal operation after

replacing the battery
Observe the following precautions to
prevent accidents:

l Always work with dry hands.

Moisture may cause the battery to
rust.

l Do not touch or move any other

component inside the remote control.

l Do not bend either of the battery
terminals.

 Left side instrument panel

Remove the lid.

7-3. Do-it-yourself maintenance

3 Remove the fuse.
Only type A fuse can be remove
dusing the pullout tool.

4 Check if the fuse is blown.
Replace the blown fuse with a new fuse
of an appropriate amperage rating. The
amperage rating can be found on the
fuse box lid.
 Type A

607

A Normal fuse
B Blown fuse
 Type C

A Normal fuse
B Blown fuse
n After a fuse is replaced
l When installing the lid, make sure that
the tab is installed securely.

l If the lights do not turn on even after
the fuse has been replaced, a bulb
may need replacement.

l If the replaced fuse blows again, have
the vehicle inspected by any authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

7

n If there is an overload in a circuit
The fuses are designed to blow, protecting the wiring harness from damage.

B Blown fuse

n When replacing an electronic com-

 Type B

ponent, such as a lights,etc.
Toyota recommends that you use genuine Toyota products designed for this
vehicle. Because certain bulbs are connected to circuits designed to prevent
overload, non-genuine parts or parts not
designed for this vehicle may be unusable.

Maintenance and care

A Normal fuse

608

7-3. Do-it-yourself maintenance

WARNING

Light bulbs

n To prevent system breakdowns

and vehicle fire
Observe the following precautions.
Failure to do so may cause damage
to the vehicle, and possibly a fire or
injury.

l Never use a fuse of a higher

amperage rating than that indicated, or use any other object in
place of a fuse.

If any exterior light does not
turn on, have it replaced by
any authorized Toyota retailer
or Toyota authorized repairer,
or any reliable repairer.

l Always use a genuine Toyota fuse

n LED lights
The lights consist of a number of LEDs.
If any of the LEDs burn out, take your
vehicle to any authorized Toyota retailer
or Toyota authorized repairer, or any reliable repairer to have the light replaced.

l Do not modify the fuses or fuse

n Condensation build-up on the

or equivalent.
Never replace a fuse with a wire,
even as a temporary fix.
boxes.

NOTICE
n Before replacing fuses
Have the cause of electrical overload
determined and repaired by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer as soon as possible.

inside of the lens
Temporary condensation build-up on the
inside of the headlight lens does not
indicate a malfunction. Contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer for more information in the following situations:

l Large drops of water have built up on
the inside of the lens.

l Water has built up inside the headlight.

n When replacing an electronic com-

ponent, such as a lights, etc.
P.607
