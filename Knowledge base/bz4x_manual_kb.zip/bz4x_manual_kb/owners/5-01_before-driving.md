# 5-1. Before driving

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 227–242

227

Driving

5-1. Before driving
.

Driving the vehicle ............229
Cargo and luggage ...........235
Trailer towing ....................237
5-2. Driving procedures
Power (ignition) switch......243

5
LCA (Lane Change Assist)
........................................304
LDA (Lane Departure Alert)
........................................307
PDA (Proactive driving assist)
........................................312

Shift position .....................247

FCTA (Front Crossing Traffic
Alert) ...............................317

Turn signal lever ...............253

RSA (Road Sign Assist) ....320

Parking brake ...................254
Brake Hold ........................257

Dynamic radar cruise control
........................................324

5-3. Operating the lights and wipers

Cruise control (vehicles with
Toyota Safety Sense) .....335

Headlight switch ...............260

Cruise control (vehicles without
Toyota Safety Sense) .....339
Speed limiter.....................343

AHB (Automatic High Beam)
.......................................268

Emergency Driving Stop System..................................346

Fog light switch .................271

BSM (Blind Spot Monitor)
........................................348

Windshield wipers and washer
.......................................271
Rear window wiper and washer
.......................................274
Headlight cleaner switch...275
5-4. Using the driving support
systems
Toyota Safety Sense software
update ............................276
Toyota Safety Sense.........278
Driver monitor ...................286
PCS (Pre-Collision System)
.......................................288
LTA (Lane Tracing Assist)
.......................................299

Rear Vehicle Approaching Indication ..............................354
Automatic Rear Flashing Hazard Lights........................357
Secondary Collision Brake
(Rear Impacts while Stopped)
........................................359
Safe Exit Assist .................361
Toyota parking assist-sensor
........................................366
RCTA (Rear crossing traffic
alert) function..................375
RCD (Rear camera detection)
........................................380

5

Driving

AHS (Adaptive High-beam
System) ..........................264

228
PKSB (Parking Support Brake)
....................................... 384
Parking Support Brake function
(static objects front and rear of
the vehicle/static objects
around the vehicle) ........ 389
Parking Support Brake function
(moving vehicles rear of the
vehicle) .......................... 393
Parking Support Brake function
(pedestrians rear of the vehicle) ................................. 394
Toyota Teammate Advanced
Park ............................... 396
Multi-terrain Monitor......... 433
Snow mode...................... 497
X-MODE .......................... 497
Driving assist systems ..... 502
5-5. Driving tips
Winter driving tips ............ 508
Utility vehicle precautions
....................................... 511

5-1. Before driving

Driving the vehicle

5-1.Before driving

The specified procedures
should be observed to ensure
safe driving:

Driving procedure
n Before starting the EV system

Check that the charging cable is
disconnected. (P.115, 120)
n Starting the EV system

229

n Parking the vehicle

1 Depress the brake pedal to stop
the vehicle completely.
2 If the parking brake is released,
set the parking brake. (P.254)
Make sure the parking brake indicator
light is on.

3 Shift the shift position to P.
(P.248)
Check that the shift position indicator
shows P and the parking brake indicator is illuminated.

P.243

4 Press the power switch to stop
the EV system.

n Driving

5 Slowly release the brake pedal.

1 With the brake pedal depressed,
shift the shift position to D.

6 Lock the door, making sure that
you have the electronic key on
your person.

Check that the shift position indicator
shows D.

If the parking brake is in automatic
mode, the parking brake will be
released automatically. (P.254)

3 Gradually release the brake
pedal and gently depress the
accelerator pedal to accelerate
the vehicle.
n Stopping

1 Depress the brake pedal.
2 If necessary, set the parking
brake. (P.254)
If the vehicle is to be stopped for an
extended period of time, shift the shift
position to P. (P.248)

n Starting off on a steep uphill

1 Firmly depress the brake pedal
and shift the shift position to D.
The hill-start assist control will be activated.

2 Set the parking brake. (P.254)
3 Release the brake pedal and
gently depress the accelerator
pedal to accelerate the vehicle.
4 Release the parking brake.
(P.254)
n Driving in the rain
l Drive carefully when it is raining,

because visibility will be reduced, the
windows may become fogged-up, and
the road will be slippery.

l Drive carefully when it starts to rain,
because the road surface will be

5

Driving

2 If the parking brake is set,
release the parking brake.
(P.254)

If parking on a hill, block the wheels as
needed.

230

5-1. Before driving

especially slippery.

l Refrain from high speeds when driv-

ing on an expressway in the rain,
because there may be a layer of water
between the tires and the road surface, preventing the steering and
brakes from operating properly.

n Restraining the EV system output
(Brake Override System)

l When the accelerator and brake pedals are depressed at the same time,
the EV system output may be
restrained.

l A warning message is displayed on

the multi-information display while the
system is operating.

n Breaking in your new Toyota
To extend the life of the vehicle, observing the following precautions is recommended:
l For the first 300 km (200 miles):
Avoid sudden stops.

l For the first 800 km (500 miles):
Do not tow a trailer.
l For the first 2000 km (1200 miles):

• Do not drive at extremely high
speeds.
• Avoid sudden acceleration.
• Do not drive at a constant speed for
extended periods.

WARNING
Observe the following precautions.
Failure to do so may result in death or
serious injury.

n When starting the vehicle
Always keep your foot on the brake
pedal while stopped with the
“READY” indicator is illuminated. This
prevents the vehicle from creeping.

n When driving the vehicle
l Do not drive if you are unfamiliar

with the location of the brake and
accelerator pedals to avoid
depressing the wrong pedal.
• Accidentally depressing the accelerator pedal instead of the brake
pedal will result in sudden acceleration that may lead to an accident.
• When backing up, you may twist
your body around, leading to difficulty in operating the pedals. Make
sure to operate the pedals properly.
• Make sure to keep a correct driving
posture even when moving the
vehicle only slightly. This allows you
to depress the brake and accelerator pedals properly.
• Depress the brake pedal using your
right foot. Depressing the brake
pedal using your left foot may delay
response in an emergency, resulting in an accident.

l The driver should pay extra atten-

tion to pedestrians. As there is no
engine noise, the pedestrians may
misjudge the vehicle’s movement.
Even though the vehicle is
equipped with the Acoustic Vehicle
Alerting System, drive with care as
pedestrians in the vicinity may still
not notice the vehicle if the surrounding area is noisy.

l During normal driving, do not turn

off the EV system. Turning the EV
system off while driving will not
cause loss of steering or braking
control, however, power assist to
the steering will be lost. This will
make it more difficult to steer
smoothly, so you should pull over
and stop the vehicle as soon as it is
safe to do so.
In the event of an emergency, such
as if it becomes impossible to stop
the vehicle in the normal way:
P.610

5-1. Before driving

WARNING
l Use regenerative braking to main-

tain a safe speed when driving
down a steep hill.
Using the brakes continuously may
cause the brakes to overheat and
lose effectiveness. (P.247)

l If “Regenerative Braking Limited

Press Brake to Decelerate” appears
on the multi-information display,
firmly depress the brake pedal to
decelerate the vehicle. (P.627)

l Do not adjust the positions of the

steering wheel, the seat, or the
inside or outside rear view mirrors
while driving.
Doing so may result in a loss of
vehicle control.

l Always check that all passengers’

arms, heads or other parts of their
body are not outside the vehicle.

l AWD/4WD models: Do not drive the

l Do not drive across a river or

through other bodies of water.
This may cause electric/electronic
components to short circuit, damage the EV system or cause other
serious damage to the vehicle.

n When driving on slippery road
surfaces

l Sudden braking, acceleration and
steering may cause tire slippage
and reduce your ability to control
the vehicle.

l Sudden acceleration or regenerative braking due to shift changing
could cause the vehicle to skid,
resulting in an accident.

l After driving through a puddle,

lightly depress the brake pedal to
make sure that the brakes are functioning properly. Wet brake pads
may prevent the brakes from functioning properly. If the brakes on
only one side are wet and not functioning properly, steering control
may be affected.

n When shifting the shift position
l Do not let the vehicle roll backward
while a forward driving position is
selected, or roll forward while the
shift position is in R.
Doing so may result in an accident
or damage to the vehicle.

l Do not shift the shift position to P

while the vehicle is moving.
Doing so can damage the transmission and may result in a loss of
vehicle control.

l Do not shift the shift position to R

while the vehicle is moving forward.
Doing so can damage the transmission and may result in a loss of
vehicle control.

l Do not shift the shift position to a

driving position while the vehicle is
moving backward.
Doing so can damage the transmission and may result in a loss of
vehicle control.

l Changing the shift position to N

while the vehicle is moving will disengage the EV system. Regenerative braking is not available with the
EV system disengaged.

5

Driving

vehicle off-road.
This is not a AWD/4WD vehicle
designed for off-road driving. Proceed with all due caution if it
becomes unavoidable to drive
off-road.

231

232

5-1. Before driving

WARNING
l Be careful not to change the shift

position with the accelerator pedal
depressed. Changing the shift position to any positions other than P or
N may lead to unexpected rapid
acceleration of the vehicle that may
cause an accident and result in
death or serious injury.
After changing the shift position,
make sure to confirm the current
shift position displayed on the shift
position indicator inside the meter.

n If you hear a squealing or scrap-

ing noise (brake pad wear indicators)
Have the brake pads checked and
replaced by any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer as soon as
possible.
Rotor damage may result if the pads
are not replaced when needed.
It is dangerous to drive the vehicle
when the wear limits of the brake
pads and/or those of the brake discs
are exceeded.

n When the vehicle is stopped
l Do not depress the accelerator

pedal unnecessarily.
If the shift position is in any position
other than P or N, the vehicle may
accelerate suddenly and unexpectedly, causing an accident.

l In order to prevent accidents due to
the vehicle rolling away, always
keep depressing the brake pedal
while stopped with the “READY”
indicator is illuminated, and apply
the parking brake as necessary.

l If the vehicle is stopped on an

incline, in order to prevent accidents caused by the vehicle rolling
forward or backward, always
depress the brake pedal and
securely apply the parking brake as
needed.

n When the vehicle is parked
l Do not leave glasses, cigarette

lighters, spray cans, or soft drink
cans in the vehicle when it is in the
sun.
Doing so may result in the following:
• Gas may leak from a cigarette
lighter or spray can, and may lead
to a fire.
• The temperature inside the vehicle
may cause the plastic lenses and
plastic material of glasses to
deform or crack.
• Soft drink cans may fracture, causing the contents to spray over the
interior of the vehicle, and may also
cause a short circuit in the vehicle’s
electrical components.

l Do not leave cigarette lighters in the
vehicle. If a cigarette lighter is in a
place such as the glove box or on
the floor, it may be lit accidentally
when luggage is loaded or the seat
is adjusted, causing a fire.

l Do not attach adhesive discs to the
windshield or windows. Do not
place containers such as air fresheners on the instrument panel or
dashboard. Adhesive discs or containers may act as lenses, causing
a fire in the vehicle.

l Do not leave a door or window

open if the curved glass is coated
with a metallized film such as a silver-colored one. Reflected sunlight
may cause the glass to act as a
lens, causing a fire.

5-1. Before driving

WARNING
l Always apply the parking brake,

shift the shift position to P, stop the
EV system and lock the vehicle.
Do not leave the vehicle unattended while the “READY” indicator
is illuminated.
If the vehicle is parked with the shift
position in P but the parking brake
is not set, the vehicle may start to
move, possibly leading to an accident.

n When taking a nap in the vehicle
Always turn the EV system off. Otherwise, you may accidentally move the
shift position or depress the accelerator pedal, causing the vehicle to unintentionally move, which can lead to an
accident, resulting in death or serious
injury.

more cautiously.
Braking distance increases when
the brakes are wet, and this may
cause one side of the vehicle to
brake differently than the other
side. Also, the parking brake may
not securely hold the vehicle.

l If the electronically controlled brake

system does not operate, do not follow other vehicles closely and avoid
hills or sharp turns that require
braking.
In this case, braking is still possible,
but the brake pedal should be
depressed more firmly than usual.
Also, the braking distance will
increase. Have your brakes fixed
immediately.

l The brake system consists of 2 or

more individual hydraulic systems;
if one of the systems fails, the
other(s) will still operate. In this
case, the brake pedal should be
depressed more firmly than usual
and the braking distance will
increase. Have your brakes fixed
immediately.

n If the vehicle becomes stuck

(AWD models)
Do not spin the wheels excessively
when any of the tires is up in the air,
or the vehicle is stuck in sand, mud,
etc. This may damage the driveline
components or propel the vehicle forward or backward, causing an accident.

NOTICE
n When driving the vehicle
l Do not depress the accelerator and

5

l Do not use the accelerator pedal or

Driving

n When braking
l When the brakes are wet, drive

233

brake pedals at the same time during driving, as this may restrain the
EV system output.

depress the accelerator and brake
pedals at the same time to hold the
vehicle on a hill.

n Avoiding damage to vehicle parts
l Do not turn the steering wheel fully
in either direction and hold it there
for an extended period of time.
Doing so may damage the power
steering.

l When driving over bumps in the

road, drive as slowly as possible to
avoid damaging the wheels, underside of the vehicle, etc.

234

5-1. Before driving

NOTICE
n If you get a flat tire while driving
A flat or damaged tire may cause the
following situations. Hold the steering
wheel firmly and gradually depress
the brake pedal to slow down the
vehicle.
l It may be difficult to control your
vehicle.
l The vehicle will make abnormal
sounds or vibrations.

l The vehicle will lean abnormally.
Information on what to do in case of a
flat tire (P.634, 645)

n When encountering flooded

roads
Do not drive on a road that has
flooded after heavy rain, etc. Doing so
may cause the following serious damage to the vehicle:
l Short in electrical components

l Traction battery damage caused by
water immersion

In the event that you drive on a
flooded road and the vehicle is
flooded, be sure to have any authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer
check the following:

If the shift control system is damaged
by flooding, it may not be possible to
shift the shift position to P, or from P
to other positions. In this case, contact any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.

n When parking the vehicle
Always set the parking brake, and
shift the shift position to P. Failure to
do so may cause the vehicle to move
or the vehicle may accelerate suddenly if the accelerator pedal is accidentally depressed.

n When involved in a minor acci-

dent
Damage to the traction battery or battery peripheral components could
cause malfunctions. Even if it is a
minor accident, have the vehicle
inspected by any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer.

Sudden start restraint control (Drive-Start Control
[DSC])

l Brake function

When the following unusual operation is performed with the accelerator pedal depressed, the EV system
output may be restrained.

l Changes in quantity and quality of

 When the shift position to R*.

l Lubricant condition for the bearings

 When the shift position is shifted
from P or R to forward drive shift

transmission fluid, etc.

and suspension joints (where possible), and the function of all joints,
bearings, etc.

l Components connected to the traction battery.

position such as D*.
When the system operates, a message
appears on the multi-information display. Read the message and follow the
instruction.
*: Depending on the situation, the shift

position may not be changed.

5-1. Before driving

n Drive-Start Control (DSC)
l When the TRC is turned off (P.503),

sudden start restraint control also
does not operate. If your vehicle have
trouble escaping from the mud or
fresh snow due to sudden start
restraint control operation, deactivate
TRC (P.503) so that the vehicle may
become able to escape from the mud
or fresh snow.
Also, sudden start restraint control will
not operate in the following conditions:
When “X-MODE” is selected (if
equipped)

235

Cargo and luggage
Take notice of the following
information about storage precautions, cargo capacity and
load:
WARNING
n Things that must not be carried

in the luggage compartment
The following things may cause a fire
if loaded in the luggage compartment:
l Receptacles containing gasoline

l Aerosol cans

l Do not stack cargo and luggage in
the luggage compartment higher
than the seatbacks.

l When you fold down the rear seats,
long items should not be placed
directly behind the front seats.

l Never allow anyone to ride in the

luggage compartment. It is not
designed for passengers. They
should ride in their seats with their
seat belts properly fastened.

l Do not place cargo or luggage in or

on the following locations.
• At the feet of the driver

• On the front passenger or rear
seats (when stacking items)
• On the luggage cover

5

Driving

n Storage precautions
Observe the following precautions.
Failure to do so may prevent the pedals from being depressed properly,
may block the driver’s vision, or may
result in items hitting the driver or
passengers, possibly causing an accident.
l Stow cargo and luggage in the luggage compartment whenever possible.

236

5-1. Before driving

WARNING
• On the instrument panel
• On the dashboard
• In front of the instrument cluster

l Secure all items in the occupant
compartment.

n Load and distribution
l Do not overload your vehicle.
l Do not apply loads unevenly.

Improper loading may cause deterioration of steering or braking control which may cause death or
serious injury.

n When using a roof luggage car-

rier
Observe the following precautions:
l Place the cargo so that its weight is
distributed evenly between the front
and rear axles.

l If loading long or wide cargo, never

exceed the vehicle overall length or
width. (P.668)

l Before driving, make sure the cargo

is securely fastened on the roof luggage carrier.

l Loading cargo on the roof luggage

carrier will make the center of gravity of the vehicle higher. Avoid high
speeds, sudden starts, sharp turns,
sudden braking or abrupt maneuvers, otherwise it may result in loss
of control or vehicle rollover due to
failure to operate this vehicle correctly and result in death or serious
injury.

l If driving for a long distance, on

rough roads, or at high speeds,
stop the vehicle now and then during the trip to make sure the cargo
remains in its place.

l Do not exceed 75 kg (165 lb.) cargo
weight on the roof luggage carrier.

NOTICE
n When loading cargo (vehicles

with panoramic moon roof)
Be careful not to scratch the surface
of the panoramic moon roof.

5-1. Before driving

237

Trailer towing

load before towing. (P.668)

Your vehicle is designed primarily as a passenger carrying
vehicle. Towing a trailer will
have an adverse effect on handling, performance, braking,
durability, and electricity consumption. Your safety and satisfaction depend on the proper
use of correct equipment and
cautious driving habits. For
your safety and the safety of
others, do not overload the
vehicle or trailer.

Towing hitch/bicycle holder
bracket

Toyota warranties do not apply
to damage or malfunction
caused by towing a trailer for
commercial purposes.
Ask your local authorized
Toyota retailer or Toyota
authorized repairer, or any reliable repairer for further details
before towing, as there are
additional legal requirements
in some countries.

Weight limits
Check the allowable towing capacity, GVM (Gross Vehicle Mass),
MPAC (Maximum Permissible Axle
Capacity), and permissible drawbar

Other products of a suitable nature
and comparable quality may also
be used.
For vehicles where the towing
device ball or the bicycle holder
attachment ball, when installed,
partially obstructs the visibility of
any of the rear lamps and/or license
plate, the following shall be considered:
 Do not use towing devices that
have a tow ball that cannot be
easily removed or repositioned.
 Do not use bicycle holder brackets that have an attachment ball
that cannot be easily removed or
repositioned.
All detachable towing devices balls
or bicycle holder attachment balls
should be removed or repositioned
when not in use.

5

Driving

To tow a trailer safely, use
extreme care and drive the
vehicle in accordance with the
trailer’s characteristics and
operating conditions.

Toyota recommends the use of the
genuine Toyota towing devices or
bicycle holder brackets if available.

238

5-1. Before driving

Important points regarding
trailer loads
n Total trailer weight and per-

missible drawbar load

A Gross vehicle mass
The combined weight of the driver, passengers, luggage, towing hitch, total
curb mass and drawbar load should not
exceed the gross vehicle mass by more
than 100 kg (220.5 lb.). Exceeding this
weight is dangerous.

B Maximum permissible rear axle
capacity
The weight borne by the rear axle
should not exceed the maximum permissible rear axle capacity by 15% or
more. Exceeding this weight is dangerous.

A Total trailer weight
Weight of the trailer itself plus the trailer
load should be within the maximum
towing capacity. Exceeding this weight
is dangerous. (P.668)
When towing a trailer, use a friction
coupler or friction stabilizer (sway control device).

B Permissible drawbar load
Allocate the trailer load so that the
drawbar load is greater than 25 kg
(55.1 lb.) or 4% of the towing capacity.
Do not let the drawbar load exceed the
indicated weight. (P.668)

n Information tag (manufac-

turer’s label)

The values for towing capacity were
derived from testing conducted at sea
level. Take note that EV system output
and towing capacity will be reduced at
high altitudes.

WARNING
n When the gross vehicle mass or

maximum permissible axle
capacity is exceeded
Failing to observe this precaution may
lead to an accident causing death or
serious injury.

l Add an additional 20.0 kPa (0.2
kgf/cm2 or bar, 3 psi) to the recommended tire inflation pressure
value. (P.673)

l Do not exceed the established

speed limit for towing a trailer in
built-up areas or 100 km/h (62
mph), whichever is lower.

5-1. Before driving

Installation positions for the
towing hitch/bracket and
hitch ball

3
4
5
6
7

239

1224 mm (48.2 in.)
617 mm (24.3 in.)
487 mm (19.2 in.)
95 mm (3.7 in.)
374 mm (14.7 in.)

n Tire information
l Increase the tire inflation pressure to
20.0 kPa (0.2 kgf/cm2 or bar, 3 psi)
greater than the recommended value
when towing. (P.673)

l Increase the air pressure of the trailer

tires in accordance with the total
trailer weight and according to the values recommended by the manufacturer of your trailer.

n Trailer lights
l Check that the turn signal lights and

l Please consult any authorized Toyota

retailer or Toyota authorized repairer,
or any reliable repairer when installing
trailer lights, as incorrect installation
may cause damage to the vehicle’s
lights. Please take care to comply with
your state’s laws when installing trailer
lights.

n When towing a trailer
Disable the following systems, as the
systems may not operate properly.
l LTA (Lane Tracing Assist) (P.299)
l LCA (Lane Change Assist) (if
equipped) (P.304)

l LDA (Lane Departure Alert) (P.307)
l Dynamic radar cruise control (if
equipped) (P.324)

l Cruise control (P.335, 339)
l BSM (Blind Spot Monitor) (if
equipped) (P.348)

l Toyota parking assist-sensor

5

Driving

1 537 mm (21.1 in.)
2 537 mm (21.1 in.)

stoplights are operating correctly
every time you hitch up the trailer.
Directly wiring up to your vehicle may
damage the electrical system and
stop the lights from functioning correctly.

240

5-1. Before driving

(P.366)

l RCTA (Rear Crossing Traffic Alert)
function (if equipped) (P.375)

l RCD (Rear Camera Detection) function (if equipped) (P.380)

l PKSB (Parking Support Brake) (if
equipped) (P.384)

n Break-in schedule
Toyota recommends that vehicles fitted
with new power train components
should not be used for towing trailers for
the first 800 km (500 miles).
n Safety checks before towing
l Check that the maximum load limit for
the towing hitch/bracket hitch ball is
not exceeded. Bear in mind that the
coupling weight of the trailer will add
to the load exerted on the vehicle.
Also make sure that the total load
exerted on the vehicle is within the
range of the weight limits. (P.238)

l Ensure that the trailer load is secure.
l Supplementary outside rear view mir-

rors should be added to the vehicle if
the traffic behind cannot be clearly
seen with standard mirrors. Adjust the
extending arms of these mirrors on
both sides of the vehicle so that they
always provide maximum visibility of
the road behind.

n Maintenance
l Maintenance must be performed more
frequently when using the vehicle for
towing due to the greater weight burden placed on the vehicle compared
to normal driving.

l Retighten all bolts securing the hitching ball and bracket after towing for
approximately 1000 km (600 miles).

n If trailer sway occurs
One or more factors (crosswinds, passing vehicles, rough roads, etc.) can
adversely affect handling of your vehicle
and trailer, causing instability.

l If trailer swaying occurs:

• Firmly grip the steering wheel. Steer

straight ahead.
Do not try to control trailer swaying by
turning the steering wheel.
• Begin releasing the accelerator pedal
immediately but very gradually to
reduce speed.
Do not increase speed. Do not apply
vehicle brakes.
If you make no extreme correction with
the steering or brakes, your vehicle and
trailer should stabilize.

l After the trailer swaying has stopped:
• Stop in a safe place. Get all occupants
out of the vehicle.
• Check the tires of the vehicle and the
trailer.
• Check the load in the trailer.
Make sure the load has not shifted.
Make sure the tongue weight is appropriate, if possible.
• Check the load in the vehicle.
Make sure the vehicle is not overloaded after occupants get in.
If you cannot find any problems, the
speed at which trailer swaying occurred
is beyond the limit of your particular
vehicle-trailer combination. Drive at a
lower speed to prevent instability.
Remember that swaying of the towing
vehicle-trailer increases as speed
increases.

NOTICE
n When the rear bumper strength-

ening material is aluminum
Ensure the steel bracket part does not
come directly in contact with that
area.
When steel and aluminum come into
contact, there is a reaction similar to
corrosion, which will weaken the section concerned and may result in
damage. Apply a rust inhibitor to parts
that will come in contact when attaching a steel bracket.

Guidance
Your vehicle will handle differently

5-1. Before driving

241

when towing a trailer. In order to
avoid accident, death or serious
injury, keep the following in mind
when towing:

is especially true when driving on
wet or slippery road surfaces.

n Checking connections

Executing sharp turns when towing
may result in the trailer colliding
with your vehicle. Decelerate well in
advance when approaching turns
and take them slowly and carefully
to avoid sudden braking.

between trailer and lights
Stop the vehicle and check the
operation of the connection
between the trailer and lights after
driving for a brief period as well as
before starting off.
n Practicing driving with a cou-

pled trailer
 Get the feel for turning, stopping
and reversing with the trailer
coupled by practicing in an area
with no or light traffic.

n Increasing vehicle-to-vehicle

distance
At a speed of 10 km/h (6 mph), the
distance to the vehicle running
ahead of you should be equivalent
to or greater than the combined
length of your vehicle and trailer.
Avoid sudden braking that may
cause skidding. Otherwise, the
vehicle may spin out of control. This

input/cornering

n Important points regarding

turning
The wheels of the trailer will travel
closer to the inside of the curve
than the wheels of the vehicle. To
make allowance for this, take the
turns wider than you would normally do.

5

n Important points regarding

stability
Vehicle movement resulting from
uneven road surfaces and strong
crosswinds will affect handling. The
vehicle may also be rocked by
passing buses or large trucks. Frequently check behind when moving
alongside such vehicles. As soon
as such vehicle movement occurs,
immediately start to decelerate
smoothly by slowly applying the
brakes. Always steer the vehicle
straight ahead while braking.
n Passing other vehicles

Consider the total combined length
of your vehicle and trailer and
ensure that the vehicle-to-vehicle
distance is sufficient before execut-

Driving

 When reversing with a coupled
trailer, hold the section of the
steering wheel nearest to you
and rotate clockwise to turn the
trailer left or counterclockwise to
turn it right. Always rotate a little
at a time to prevent steering
error. Have someone guide you
when reversing to lessen the risk
of an accident.

n Sudden acceleration/steering

242

5-1. Before driving

ing lane changes.
n When parking the vehicle

Always place wheel chocks under
the wheels of both the vehicle and
trailer. Set the parking brake and
shift the shift position to P.
WARNING
Follow all the instructions described in
this section. Failure to do so could
cause an accident resulting in death
or serious injury.

n Trailer towing precautions
When towing, make sure that none of
the weight limits are exceeded.
(P.238)

n To avoid accident or injury
l Vehicles with a compact spare tire:
Do not tow a trailer when the compact spare tire is installed on your
vehicle.

l Vehicles with the emergency tire
puncture repair kit: Do not tow a
trailer when the tire installed is
repaired with the emergency tire
puncture repair kit.

n Vehicle speed in towing
Observe the legal maximum speeds
for trailer towing.
n Before descending hills or long

declines
Reduce speed and downshift. However, never downshift suddenly while
descending steep or long downhill
grades.

n Operation of the brake pedal
Do not hold the brake pedal
depressed often or for long periods of
time. Doing so may result in the brake
overheating or reduce braking effects.
