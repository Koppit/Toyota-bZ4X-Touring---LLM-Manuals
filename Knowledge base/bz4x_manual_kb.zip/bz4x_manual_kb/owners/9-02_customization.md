# 9-2. Customization

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 9: Vehicle specifications, pages 675–689

675

9-2. Customization

Customizable features

9-2.Customization

Your vehicle includes a variety
of electronic features that can
be personalized to your preferences. The settings of these
features can be changed by
using the multimedia system,
or at any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable
repairer.
Some of the customizable features are changed in conjunction with the settings of My
Settings. (P.224)

Customizing vehicle features

For functions whose level can be
adjusted, such as volume, sensor sensitivity, etc., slide the icon on the bar.

n To change setting with

1 Select
display.

on the multimedia

2 Select “Driving assist”.
3 Select the item to change the
settings of from the list.
Each time the switch is selected, the
setting will be enabled/disabled.
When enabling is selected, the item
display will be emphasized.

n During customization
Stop the vehicle in a safe place, apply
the parking brake, and shift the shift
position to P. Also, to prevent 12-volt
battery discharge, leave the EV system
operating while customizing the features.

n To change setting with

n Using the

1 Select
display.

Some vehicle customize settings can

on the multimedia

2 Select “Vehicle customise” or
“Driving assist”.
3 Select the item to change the
settings of from the list.
For functions that can be turned on/off,
select

(ON) /

icon

also be changed through the

icon.

NOTICE
n During customization
To prevent 12-volt battery discharge,
ensure that the EV system is operating while customizing features.

9

(OFF).

Some function settings are changed simultaneously with other functions
being customized. Contact any authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer for further details.
A Settings that can be changed using the multimedia system

Vehicle specifications

Customizable Features

676

9-2. Customization

B Settings that can be changed by any authorized Toyota retailer or Toyota
authorized repairer, or any reliable repairer

Definition of symbols: O = Available, — = Not available
n Alarm* (P.85)
Function

Customized setting

A

B

—

O

A

B

Charging Current

 8A
 16A
 24A
 MAX

O

—

Charging limit

 50%
 60%
 70%
 80%
 90%
 Full

O

—

DC charging power

 50 kW
 75 kW
 100 kW
 125 kW
 MAX

O

—

Traction battery cooler

 On
 Off

O

—

Deactivates the alarmwhen
 On
the doors areunlocked using
 Off
the mechanical key
*: If equipped

n Charging system (P.115, 120)
Function

Customized setting

n Gauges, meters and multi-information display (P.156, 159)

The language, units of measure, etc. of some items displayed on the meter
or multi-information display will be changed according to settings on the
multimedia display. Refer to “Multimedia owner’s manual”.

677

9-2. Customization
Function

Customized setting

A

B

Suggestion function

 On
 On (when the vehicle is stopped)
 Off

O

O

Stop light indicator

 On
 Off

O

—

A

B

 On
 Off

O

—

 On
 Off

—

O

A

B

—

O

n Passenger and rear seat reminder (P.175)
Function
Rear seat reminder function*
Passenger and rear seat
reminder function*

Customized setting

*: This setting changes in accordance with My Settings

n Door lock (P.173, 656)
Function

Customized setting

 All doors unlocked in one step
Unlocking using a mechani Driver’s door unlocked in one step, all
cal key
doors unlocked in two step
 On
 Off

O

O

Shift position linked door
locking function

 On
 Off

O

O

Shift position linked door
unlocking function

 On
 Off

O

O

Driver’s door linked door
unlocking function

 On
 Off

O

O

A

B

n Power back door (P.178)
Function

Customized setting

Power back door opening
position

 1 to 5
 User optional setting

O

—

Power back door operation

 On
 Off

O

—

9

Vehicle specifications

Speed linked door locking
function

678

9-2. Customization
Function

Customized setting

A

B

Buzzer volume

 Small
 Nomal
 Large

O

—

Operation buzzer

 On
 Off

—

O

 On
 Off

O

O

Kick in buzzer (kick sensor)*

 On
 Off

—

O

Close & lock (walk away)
function

 On
 Off

—

O

Hands Free Power Back
Door (kick sensor)*

*: If equipped

n Smart entry & start system and wireless remote control (P.169,

191)
Function
Operation signal (Emergency flashers)

Customized setting
 On
 Off

Time elapsed before auto 30 seconds
matic door lock function is
 60 seconds
activated if door is not
 120 seconds
opened after being unlocked
Open door warning buzzer

 On
 Off

A

B

O

O

—

O

—

O

A

B

n Smart entry & start system (191)
Function

Customized setting

Smart entry & start system

 On
 Off

O

O

Smart door unlocking

 Driver’s door
 All the doors

O

O

Time elapsed before unlock-  Off
ing all the door when grip 1.5 seconds
ping and holding the driver’s  2 seconds
door handle
 2.5 seconds

—

O

679

9-2. Customization

n Wireless remote control (P.169)
Function

Customized setting

A

B

Wireless remote control

 On
 Off

—

O

Unlocking operation

 All doors unlocked in one step
 Driver’s door unlocked in one step, all
doors unlocked in two step

O

O

 On (Unlocking all the door)
 On (Unlocking back door only)
 Off

—

O

A

B

—

O

The function that activates
the

switch ofthe wire-

less remote control when
locking the door(P.179)

n Driving position memory (P.221)
Function

Customized setting

Selection the door linking
 Driver’s door
driving position memory with
 All doors
door unlock operation

n Enabling easier driver entry and exit (power easy access system)

(P.221)
Function

Customized setting

 Off
Driver’s seat slide movement
 Full
when exiting the vehicle
 Partial

A

B

O

O

A

B

n Outside rear view mirrors (P.214)
Function

Customized setting

9
—

O

Vehicle specifications

 Off
 Linked to the locking/unlocking of the
Automatic mirror folding and
doors
extending operation
 Linked to operation of the power
switch

680

9-2. Customization

n Power windows (P.218)
Function

Customized setting

A

B

Mechanical key linked oper-  On
ation
 Off

—

O

Wireless remote control
linked operation

 On
 Off

—

O

Wireless remote control
linked operation signal
(buzzer)

 On
 Off

—

O

A

B

O

O

A

B

—

O

A

B

Light sensor sensitivity

 Darker
 Dark
 Normal
 Bright
 Brighter

O

O

Time elapsed before headlights turn off (Extended
Headlight Lighting system)

 30 seconds
 60 seconds
 90 seconds
 120 seconds

—

O

n Power switch (P.246)
Function
ACC customization
Enabling/Disabling ACC
mode

Customized setting
 On
 Off

n Reverse warning buzzer (P.247)
Function
Signal (buzzer) when the
shift position is in R

Customized setting
 Continual
 Mute

n Automatic light control system (P.260)
Function

Customized setting

681

9-2. Customization

n Adaptive High-beam System*1 (P.264)
Function

Customized setting

A

B

—

O

Brightness and illuminated
 15 km/h (9 mph)
area adjustment of the high
 30 km/h (19 mph)
beams according to the vehi 60 km/h (37 mph)
cle speed

—

O

Intensity adjustment of the
high beams when driving
 ON
around a curve (illuminates
 OFF
the area in the direction vehicle is turning more brightly)

—

O

Projection distance adjustment of the low beams
according to the distance to
a preceding vehicle

 ON
 OFF

—

O

High beam light distribution
control for rain

 ON
 OFF

—

O

Light distribution control for
urban areas

 ON
 OFF

—

O

Adaptive High-beam System

 ON
 OFF*2

*1: If equipped
*2: The headlights will operate under Automatic High Beam control. (P.268)

n Pre-Collision System (P.288)
Function

Customized setting

A

B
—

Pre-Collision System

 ON
 OFF

O

Warning timing*

 Later
 Default
 Earlier

O

—

Vehicle specifications

*: This setting changes in accordance with My Settings

9

682

9-2. Customization

n Front Crossing Traffic Alert*1(P.317)
Function

Customized setting

A

B

Front Crossing Traffic Alert

 ON
 OFF

O

—

Alert timing*2

 Later
 Default
 Earlier

O

—

A

B

 ON
 OFF

O

—

Alert timing*

 Default
 Earlier

O

—

Alert options*

 Vibration
 Audible

O

—

A

B

O

—

*1: If equipped
*2: This setting changes in accordance with My Settings

n Lane Departure Alert system (LDA) (P.307)
Function
Lane Departure Alert system (LDA)*

Customized setting

*: This setting changes in accordance with My Settings

n Lane Change Assist*1 (P.304)
Function
Lane Change Assist*2

Customized setting
 ON
 OFF

*1: If equipped
*2: This setting changes in accordance with My Settings

n Dynamic Radar Cruise Control (DRCC)*1/ Speed Limiter*1 (P.324)
Function

Customized setting

A

B

Extended Resume Time*1,2

 ON
 OFF

O

—

Overtake prevention*2

 ON
 OFF

O

—

683

9-2. Customization
Function

Customized setting

A

B

O

—

 1km/h (1 mph)
Speed setting (short press)*2  5km/h (5 mph)
 10km/h (10 mph)

O

—

 1km/h (1 mph)
Speed setting (long press)*2  5km/h (5 mph)
 10km/h (10 mph)

O

—

Acceleration setting*2

 Low
 Mid
 High

DRCC (RSA)*2

 ON
 OFF

O

—

Speed limit offset*2

 -5 to 5

O

—

Guide message*2

 ON
 OFF

O

—

Curve speed reduction*2

 OFF
 Low
 Mid
 High

O

—

A

B

 ON
 OFF

O

—

Support sensitivity*2

 Low
 Mid
 High

O

—

Deceleration Assist (DA)*2

 ON
 OFF

O

—

 ON
 OFF

O

—

*1: If equipped
*2: This setting changes in accordance with My Settings

n Proactive Driving Assist*1 (P.312)
Function
Proactive Driving Assist
(PDA)*2

(OAA)*2
*1

: If equipped

*2

: This setting changes in accordance with My Settings

9

Vehicle specifications

Obstacle Anticipation Assist

Customized setting

684

9-2. Customization

n Road Sign Assist*1 (P.320)
Function

Customized setting

A

B

 ON
 OFF

O

—

 None
 Visual
 Visual and Audible

O

—

Other notifications method
 None
(For vehicles with a multime-  Visual
 Visual and Audible
dia system)*2

O

—

O

—

O

—

A

B

O

—

A

B

O

—

Road Sign Assist*2
Excess speed notification
method*2

Excess speed notification
level*2, 3

 10 km/h (5 mph)
 5 km/h (3 mph)
 2 km/h (1 mph)

Speed limit change notifica-  ON
 OFF
tion*2
*1: If equipped
*2: This setting changes in accordance with My Settings
*3: The customized setting varies according to country

n Driver break suggestion (P.307)
Function
Driver break suggestion

Customized setting
 ON
 OFF

n Driver monitor*1 (P.286)
Function
Warning function*2

Customized setting
 ON
 OFF

*1: If equipped
*2: This setting changes in accordance with My Settings

685

9-2. Customization

n BSM (Blind Spot Monitor)*1 (P.348)
Function
BSM (Blind Spot Monitor)

Customized setting

A

B

O

—

O

—

 Later
 Default
 Earlier

O

—

 On
 Off

O

—

A

B

 On
 Off

O

—

 Soft
 Normal
 Loud

O

—

 On
 Off

Outside rear view mirror indi-  Dim
 Bright
cator brightness*2
Alert timing for presence of
approaching vehicle (sensitivity)*2
Buzzer warning*2
*1: If equipped
*2: This setting changes in accordance with My Settings

n RCTA (Rear crossing traffic alert) function*1 (P.375)
Function
RCTA (Rear crossing traffic
alert)
Buzzer volume of RCTA
when operating*2, 3

Customized setting

*1: If equipped
*2: The sound volume is linked among the Toyota parking assist-sensor, RCTA, and

RCD.
*3

: This setting changes in accordance with My Settings

n Safe Exit Assist*1 (P.361)
Function

Outside rear view mirrors
display*2
Detection sensitivity*2

A

B

 On
 Off

O

—

 On
 Off

O

—

 Low
 Mid
 High

O

—

Vehicle specifications

Safe Exit Assist

9
Customized setting

686

9-2. Customization

*1: If equipped
*2: This setting changes in accordance with My Settings

n Rear Vehicle Approaching Indication*1 (P.354)
Function
Rear Vehicle Approaching
Indication*2
Alert timing for presence of
approaching vehicle (sensitivity)*2

Customized setting

A

B

 On
 Off

O

—

 Later
 Default
 Earlier

—

O

A

B

*1: If equipped
*2: This setting changes in accordance with My Settings

n Toyota parking assist-sensor (P.366)
Function
Toyota parking assist-sen-

Customized setting

sor*1

 On
 Off

O

—

Buzzer volume of Toyota
parking assist-sensor when

 Level 1~3

O

—

 Near
 Standard

O*3

—

Distance from which the rear
 Near
center sensor starts detec Standard
tion

O*3

—

operating*1, 2
Distance from which the
front center sensor starts
detection

*1: This setting changes in accordance with My Settings
*2: The sound volume is linked among the Toyota parking assist-sensor, RCTA (if

equipped), and RCD (if equipped).
*3: For vehicles with panoramic view monitor, the setting can be changed on the

panoramic view monitor settings screen. For details, refer to “Multimedia owner’s
manual”.

687

9-2. Customization

n PKSB (Parking Support Brake)*1 (P.384)
Function

Customized setting

A

B

O

—

A

B

O

—

A

B

O

—

 Slow
Vehicle speed during opera Standard
tion
 Fast

O

—

Distance to objects

 Standard
 Far

O

—

Preferred parking method

 Parallel
 Perpendicular

O

—

Preferred parking direction

 Reverse
 Forward

O

—

Preferred exit direction (per-  Left
pendicular)
 Right

O

—

Preferred exit direction (par-  Left
allel)
 Right

O

—

PKSB (Parking Support
Brake) function

*2

 ON
 OFF

*1

: If equipped

*2: This setting changes in accordance with My Settings

n RCD (Rear Camera Detection) function* (P.380)
Function
RCD (Rear Camera Detection) function

Customized setting
 ON
 OFF

*: If equipped

n Toyota Teammate Advanced Park*(P.396)
Function
Remote Park*

Customized setting
 On
 Off

9

 Standard
 Wide

O

—

Camera view when exiting

 Standard
 Wide

O

—

Vehicle specifications

Camera view when parking

688

9-2. Customization
Function

Customized setting

A

B

Parking path adjustment

 -3 (Inward) to +3 (Outward)

O

—

Road width adjustment

 Narrow
 Slightly narrow
 Standard

O

—

Park position adjustment
(forward)

 -3 (Rearward) to +3 (Frontward)

O

—

Park position adjustment
(reverse)

 -3 (Rearward) to +3 (Frontward)

O

—

Rear accessory setting

 Off
 10 cm (3.9 in.)
 20 cm (7.9 in.)
 30 cm (11.8 in.)
 40 cm (15.7 in.)

O

—

O

—

A

B

O

O

A

B

Clear registered parking
space

—

*: If equipped

n Automatic air conditioning system (P.518)
Function
A/C auto switch operation

Customized setting
 On
 Off

n Illumination (P.528)
Function

Customized setting

Time elapsed before the
interior lights turn off

 Off
 7.5 seconds
 15 seconds
 30 seconds

O

—

Operation after the power
switch is turned off

 On
 Off

—

O

Operation when the doors
are unlocked

 On
 Off

—

O

Operation when you
approach the vehicle with
the electronic key on your
person

 On
 Off

—

O

689

9-2. Customization
Function

Customized setting

A

B

Footwell lights, shift lights,
inside door handle lights,
door trim ornament lights,
center console light, instrument panel ornament lights
and console box light

 On
 Off

—

O

Time elapsed before the
outer foot lights turn off

 Off
 15 seconds

O

—

Operation of the outer foot
lights when you approach
the vehicle with the electronic key on your person

 On
 Off

—

O

Operation of the outer foot
lights when the doors are
unlocked

 On
 Off

—

O

Door illumination when Safe
 On
Exit Assist (SEA) is operat Off
ing*

O

—

*: If equipped

n Vehicle customization
l When the speed linked door locking

l When the smart entry & start system

is off, the entry unlock function cannot
be customized.

l When the doors remain closed after

unlocking the doors and the timer activated automatic door lock function
activates, signals will be generated in
accordance with the operational sig-

9

Vehicle specifications

function and shift position linked door
locking function are both on, the door
lock operates as follows.
• When shifting the shift position to any
position other than P, all the doors will
be locked.
• If the vehicle is started with all the
doors locked, the speed linked door
locking function will not operate.
• If the vehicle is started with any door
unlocked, the speed linked door locking function will operate.

nal (Emergency flashers) function setting.
