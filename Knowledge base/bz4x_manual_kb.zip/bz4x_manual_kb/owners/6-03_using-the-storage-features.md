# 6-3. Using the storage features

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 6: Interior features, pages 531–539

6-3. Using the storage features

531

List of storage features

6-3.Using the storage features

Location of the storage features

6

A Bottle holders (P.533)
C Cup holders (P.532)

Console box (P.532)
Open tray (P.533)
WARNING
n Items that should not be left in

the vehicle
Do not leave glasses, lighters or
spray cans in the storage spaces, as
this may cause the following when
cabin temperature becomes high:

l Glasses may be deformed by heat

or cracked if they come into contact
with other stored items.

l Lighters or spray cans may

explode. If they come into contact
with other stored items, the lighter
may catch fire or the spray can may
release gas, causing a fire hazard.

n When storage compartments is

not in use
When driving or when the console
box is not in use, keep it closed. In the
event of sudden braking or sudden
swerving, an accident may occur due
to an occupant being struck by an
open lid or the items stored inside.

Interior features

B Ticket holders (P.533)

532

6-3. Using the storage features

Console box
Press a button to open the consolebox.

Cup holders
 Front

The console box can be openedfrom either side.

 Rear

Pull down the armrest.

WARNING
n Caution while driving
Keep the console box closed.
Injuries may result in the event of an
accident or sudden braking.

WARNING
n Items unsuitable for the cup

NOTICE
n To prevent damage to the con-

sole box
Do not apply excessive force to the
armrest.

holder
Do not place anything other than cups
or aluminum cans in the cup holders.
Other items may be thrown out of the
holders in the event of an accident or
sudden braking, possibly causing
injury. If possible, cover hot drinks to
prevent burns.

6-3. Using the storage features

533

Bottle holders
 Front

Open tray
 Rear

WARNING

ing on its size or shape.

NOTICE
n Items that should be not stowed

in the bottle holders
Do not place open bottles or glass
and paper cups containing liquid in
the bottle holders. The contents may
spill and glasses may break.

6

Observe the following precautions
when putting items in the open tray.
Failure to do so may cause items to
be thrown out of the tray in the event
of sudden braking or steering. In
these cases, the items may interfere
with pedal operation or cause driver
distraction, resulting in an accident.
l Do not store items in the tray that
can easily shift or roll out.

Interior features

n Bottle holders
l When storing a bottle, close the cap.
l The bottle may not be stored depend-

n Caution while driving

l Do not stack items in the tray higher
than the edge of tray.

l Do not put items in the tray that

may protrude over the edge of tray.

Ticket holders
Flip down the visor.

534

6-3. Using the storage features

Luggage compartment
features
Cargo hooks

NOTICE
n To prevent damage to the gro-

cery bag hooks
Do not hang any object heavier than 4
kg (8.8 lb.) on the grocery bag hooks.

Pull down the hook to use.
The cargo hooks are provided for
securing loose items.

Deck board
n Changing the deck board posi-

tions (vehicles with an emergency tire puncture repair kit)
Height of the deck floor can be
changed by setting the deck board
under the floor.

WARNING
n When cargo hooks are not in use
To avoid injury, always return the
hooks to their stowed positions when
not in use.

Grocery bag hooks

A Upper
B Lower

6-3. Using the storage features

1 Pull up the tab to raise the deck
board and move it toward you to
remove.

2 Place the deck board through
the groove and move forward.

535

1 Pull up the tab to raise the deck
board and fold it forward.

2 Deck board in a standing state,
put the edge into the holes.

6

When taking out the tools, the deck
board can be set upright.
When the back surface (resin surface) of the deck board is facing up,
flip it back to the original position.

WARNING
n When operating the deck board
Do not place anything on the deck
board when operating the board. Otherwise, your fingers may be caught or
an accident may result causing injuries.

n Caution while driving
Keep the deck board closed.
In the event of sudden braking, an
accident may occur due to an occupant being struck by the deck board
or the items stored under the deck
board.

Deck under tray
Pull up the tab to raise the deckboard and fold it forward.

Interior features

n Setting the deck board upright

536

6-3. Using the storage features

 Vehicles with a spare tire

Luggage cover
n Removing the luggagecover

unit
1 Pull up the tab to raise thedeck
board and fold it forward.
(P.535)
2 Pull the strap to lift up the right
deck board and remove it.
 Vehicles with an emergency tire

puncture repair kit

n Warning reflector
Depending on the size and shape of the
warning reflector case, you may not be
able to store it.

 Vehicle with woofer

Pull the strap to lift up the right deck
board and remove it.

 Vehicle without woofer

Pull the strap to lift up both deck boards
and remove them.

WARNING
n Caution while driving
Keep the deck board closed.
In the event of sudden braking, an
accident may occur due to an occupant being struck by the deck board
or the items stored under the deck
board.

3 Take out the luggage coverunit.

6-3. Using the storage features
 Vehicle with woofer

537

2 Pull out the luggage cover and
hook it on to the anchors.

 Vehicle without woofer

n Removing the luggage cover

1 Release the cover from the left
and right anchors and allow it to
retract.

n Installing the luggage cover

1 Compress the both ends of the
luggage cover and insert into
the recess to install.

6

Interior features

2 Compress the end of the luggage cover and lift the luggage
cover up.

538

6-3. Using the storage features

n Stowing the luggage cover

 Vehicle with woofer

unit
1 Pull up the tab to raise the deck
board and fold it forward.
(P.535)
2 Pull the strap to lift up the right
deck board and remove it.
 Vehicle with woofer

Pull the strap to lift up the right deck
board and remove it.

1 Insert the left end of the luggage
cover unit into the groove on the
left side of the deck.
2 Insert the right end of the luggage cover unit into the groove
on the right side of the deck
side.
 Vehicle with woofer

 Vehicle without woofer

Pull the strap to lift up both deck boards
and remove them.

3 To store the luggage cover unit,
compress both ends until they
lock.

1 Insert the left end of the luggage
cover unit into the groove on the
left side of the deck.
2 Insert the right end of the luggage cover unit into the groove
on the right side of the deck
side.

6-3. Using the storage features

539

WARNING
n Luggage cover
l When installing/stowing the lug-

gage cover, make sure that the luggage cover is securely
installed/stowed. Failure to do so
may result in serious injury in the
event of sudden braking or acollision.

l Do not place anything on the lug-

gage cover. In the event of sudden
braking or turning, the item may go
flying and strike an occupant. This
could lead to an unexpected accident, resulting in death or serious
injury.

l Do not allow children to climb on

the luggage cover. Climbing on the
luggage cover could result in damage to the luggage cover, possibly
causing death or serious injury to
the child.

6

Interior features
