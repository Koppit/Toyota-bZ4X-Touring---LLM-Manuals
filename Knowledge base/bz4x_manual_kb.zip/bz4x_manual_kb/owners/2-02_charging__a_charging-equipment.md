# 2-2. Charging (part 1: Charging equipment, …)

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 2: Electric Vehicle system, pages 103–131
> Topics in this part: Charging equipment; Locking and unlocking the AC charging connector; Charging methods; Charging tips; Things to know before charging; How to use AC charging; How to use DC charging; Using the charging schedule function

2-2. Charging

103

Charging equipment

2-2.Charging

Charging equipment and names

2

Electric Vehicle system

A AC charging inlet
B Charging indicator (P.105) and Charging inlet light
C DC charging inlet

Charging port lid (P.104)
Caution label/identification label (P.104)
AC charging cable*
Charging port
*: It is an example for explanation and may differ from the actual item. The AC

charging cable can be purchased at any authorized Toyota retailer or Toyota
authorized repairer, or any reliable repairer.
For proper handling and precautions for the AC charging cable, refer to the
owner's manual that comes with it.
AC charging cable designed for other models or different model year vehicles
may not be able to be used on your vehicle, even if they are Toyota genuine
charging cables.

104

2-2. Charging

n Identification label
Identification labels are attached to the vehicle, charging cable and charger to inform
the user of which device they should use. The meaning of the each identification
label is as follows:
Identification
label

Supply
type

AC

DC

Standard

EN 62196-2

EN 62196-3

Configuration

Type of
accessory

Voltage range

TYPE 2

 Charging
port lid
 Charging
connector

≤ 480V RMS

FF

 Charging
port lid
 Charging
connector

50 V to 500 V

Opening/closing the charging port lid
n Open

Unlock the charging port lid by
unlocking the doors. (P.173)
Slightly open the charging port lid
by pressing the rear edge of it. (the
position shown in the illustration)
Fully open the charging port lid by
hand.

n Close

Move the charging port lid to the
slightly open position and then
press the rear edge (the position
shown in the illustration) to close it.
Charging port lid also locks when

2-2. Charging

the doors are locked.

105

charging port lid. In that case, push
again with the door unlocked and
release the lid lifter, and close the charging port lid again.

2

n When the charging port lids cannot

Charging indicator

n The charging port lid will be locked
when

The illumination/flashing pattern
changes to inform the user of the
charging status in the following
ways.

l In the following cases, the charging

port lid will be locked.
• The doors are locked with the wireless
remote control
• The doors are locked with the smart
entry & start system
• The doors are locked with the
mechanical key
• The doors are locked with the door
lock switches

l Vehicles with an alarm: If the doors

are locked by the security function
when the charging port lid is closed,
the charging port lid will also be
locked. (P.85)

l If the charging port lid is closed after

the doors are locked, the charging
port lid will not be locked. In that case,
after unlocking the doors once, the
charging port lid can be locked by
locking the doors.

n About lid lifter
The charging port lid is not closed if the
lid lifter is pushing in before closing the

Illumination/flashing pattern
Illuminated

Vehicle condition
 Charging is in progress*1
 Traction battery heater
(P.109) is operating

Electric Vehicle system

be opened
P.655

106

2-2. Charging

Illumination/flashing pattern

Vehicle condition

When charging schedule is
registered (P.125) and
*2
normally AC charging cable is connected to vehicle
Flashes

Flashes
rapidly*2

When charging cannot be
carried out due to malfunction in a power source or
the vehicle, etc. (P.140)

*1: The indicator is dimmed when the

charging is done.
*2: Flashes for a certain period of time,

and then turns off.

Locking and unlocking
the AC charging connector
Helps to prevent the AC charging connector from being disconnected while charging or
tampering such as someone
other than the user taking
away the charging cable.

Locking and unlocking the
AC charging connector
n Locking the charging connec-

tor
The charging connector will be
automatically locked when inserting
it into the AC charging inlet.

n Unlocking the charging con-

nector
The AC charging connector will be
unlocked when the doors are
unlocked using the smart entry &
start system or wireless remote
control.
n AC charging connector lock func-

tion
If the AC charging connector is

2-2. Charging
locked/unlocked repeatedly, it may not
work temporarily due to protect the system by AC charging system. In this
case, wait for a while before connecting
the AC charging connector to AC charging inlet again.
The AC charging connector lock function does not guarantee that theft of the
AC charging cable will be prevented,
and is not necessarily effective for all
mischiefs.

n Unlocking the AC charging connec-

tor during charging
If the AC charging connector is unlocked
during charging, charging will be
stopped. Once the security function
works, charging may not restart automatically. In this case, remove the AC
charging connector* and insert it again.
*: When the AC charging connector is
removed, the charging schedule will
be updated. (P.125)

n If the AC charging connector can-

not be unlocked
Use the following procedure to unlock
the AC charging connector if the charging connector cannot be removed after
unlocking the doors.
Do not unlock the AC charging connector this way unless it is an emergency.
If the problem is not solved, have the
vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer immediately.
1 Open the hood. (P.580)
2 Pull the emergency release wire.
The AC charging connector is unlocked
and can be removed.

n When the AC charging connector

cannot be inserted into the AC
charging inlet
Check that the connector lock pin is not
lowered.
If the connector lock pin is lowered, the
connector lock is operating. Unlock the
doors using the smart entry & start system or wireless remote control and
unlock the AC charging connector lock
and check that the connector lock pin is
not lowered.
3 After unlocking the AC charging connector, fix the handle of the emer-

2

Electric Vehicle system

n Security function for unlocking
After the doors are unlocked, if the
doors are locked again or approximately
180 seconds elapse before removing
the AC charging connector, the AC
charging connector will be locked again.

107

108

2-2. Charging
gency release wire to the
attachment.

Charging methods
The following methods can be
used to charge the traction
battery.

Types of charging methods
NOTICE
n When locking the AC charging

connector
Observe the following precautions.
Failure to do so may cause a malfunction in the charging connector
locking system.
l Check that the AC charging connector is compatible with this vehicle.
An AC charging connector of the
different type or a charging connector with damaged or deformed
insertion part may not be locked.

l Do not apply excessive force to the
AC charging connector after the
charging connector is inserted.
When removing the AC charging
connector, make sure to unlock the
AC charging connector.

n AC charging (P.115)

This is a charging method used
when charging from an AC socket
with the AC charging cable or
charging that use an AC charger.
By setting charging schedule, it is also
possible to charge at the desired date
and time. (P.125)

n DC charging (P.120)

This charging method uses a DC
charger that complies with IEC
61851 and IEC 62196. The traction
battery can be charged in a shorter
time than AC charging.
IEC is an abbreviation for an international standard established by
the International Electrotechnical
Commission.

Charging-linked functions
This vehicle is equipped with several functions that are linked with
charging.
n My Room Mode (P.136)

When the charging cable is connected to the vehicle, electrical
components such as the air conditioning system and audio system

2-2. Charging

can be used by the power supply

109

ignored and charging starts.

from an external power source*.

n Traction battery cooler

*

When the traction battery is hot and
the AC charging cable is connected
to the vehicle, this function cools
the traction battery to protect it.

: Depending on the situation, electricity
of the traction battery may be consumed.

n Traction battery heater

The function may operate when
continuously driving at high speeds
such as driving on highways or
freeways, or during DC charging.

 The operation of this function is
stopped automatically when the
charging cable is disconnected
or if the charging cable is left
connected to the vehicle for
approximately 3 days.

charging
P.137

 When the charging schedule is
set (P.125), this function operates according to the charging
start time.
n Traction battery warming con-

trol
This control operates after the
charging cable remains connected
to the vehicle for approximately 3
days and the traction battery heater
automatically stops. It automatically
insulates the traction battery in
extremely low temperatures.
 This control stops 31 days after
the charging cable is connected,
even if it is still connected to the
vehicle.
 When this control operates,
charging schedule settings are

n Using My Room Mode during DC

n Traction battery heater
l Traction battery heater may operate

when charging is not being performed.

l When traction battery heater is operating, the charging indicator illuminates.

l When traction battery heater is operating during charging, the charging
may take longer than normal.

l The remaining charge of the traction

battery declines when the traction battery heater operates, it might be necessary to recharge the traction battery
again in order to supplement the
remaining charge.

n Traction battery cooler
l For AC charging: Traction battery

cooler settings can be changed on the
multimedia. (P.110)

l The charging indicator is illuminated
while traction battery cooler is on
standby or operating.

l When the charge level of the traction
battery is low, the traction battery
cooler may not operate, even if the
temperature of the traction battery is
high.

l When the following conditions are met
while the traction battery cooler is

2

Electric Vehicle system

When the outside temperature is
low and the charging cable is connected to the vehicle, this function
automatically warms the traction
battery until it reaches a certain
temperature.

110

2-2. Charging

operating, the cooling operation will
stop.
• The hood is opened.
• The power switch is turned to ACC or
ON.
• The shift position is changed to any
position other than P.
• The remaining charge of the traction
battery drops below a certain amount.

l The traction battery cooler operates

using power supplied by the traction
battery and an external power source.
• While the traction battery cooler is
operating, the charge of the traction
battery will increase and decrease
with in a certain range, and will not
increase as during charging.
• When the traction battery cooler operates, charger will recognize it as the
battery being charged. If this function
operates while a charger which
charges a charging fee is connected
to the vehicle, charging fees will apply.

Charging tips
This section explains methods for using the charging
function for this vehicle and
checking information related
to charging.

Systematically charging
To enable the use of battery electric
vehicle, we recommend systematically charging the vehicle.
n Before leaving home

In order to use the Electric Vehicle,
charge the traction battery at home
before leaving.

n Changing of the traction battery

cooler setting
Setting can be changed on the multimedia.
Use the multimedia and select
,
“Vehicle customise”, “Charging”, “Battery cooling”, and change the setting.
When selecting to off, the traction battery output may be restricted depending
on the driving situation.

n On the way to the destination

or at the destination
When the remaining charge of the
traction battery gets low, recharge
the battery at the nearest charging
station.

2-2. Charging

111

remaining capacity of the traction
battery, outside temperature, and
specifications of the charger.
The time until charging completed
may not be displayed if the charging current to the traction battery
becomes smaller and the charging
time becomes longer.
n After returning home

2

Setting the charging schedule
allows you to charge the traction
battery at the desired time such as
late at night or early in the morning.
Furthermore, the charging schedule can be set to automatically
charge the traction battery every
day or at the same time on certain
days. (P.125)

Checking information
related to charging
Information related to charging is
displayed and can be checked on
the multi-information display.
n While charging

When any door is opened during
charging with the power switch off,
the current charging condition and
approximate time remaining until
charging is complete are displayed
for a certain period of time.
The actual charging time and the
charging power may differ depending on conditions such as the

n After charging is complete

When any door is opened with the
power switch off after charging is
complete, a message detailing the
results of the charging is displayed
for a while.
Also, a message is displayed if an
operation that stops charging is
performed or a situation where
charging cannot be performed
occurs.
When a message is displayed, follow the instructions displayed on
the screen. (P.146)

Electric Vehicle system

In order to drive the next time,
charge the traction battery.

112

2-2. Charging

Things to know before
charging
Make sure to read the following precautions before charging the traction battery.
n Safety functions
l The EV system will not start while the

charging cable is attached to the vehicle, even if the power switch is operated.

l If the charging cable is connected

while the “READY” indicator is illuminated, the EV system will stop automatically and driving will not be
possible.

WARNING
n Cautions when charging
People with implantable cardiac pacemakers or cardiac resynchronization
therapy-pacemakers should not carry
out the charging procedure. Ask
someone else to do it.
l Do not approach the charger,
charging cable and the vehicle during charging.
Charging procedure may affect the
operation of pacemakers.
l Do not remain in the vehicle during
charging.
Charging procedure may affect the
operation of pacemakers.

l Do not enter the vehicle (including

the luggage compartment) to
retrieve something from it, or for
any purpose.
Charging procedure may affect the
operation of pacemakers.

n When the charging cable is con-

nected to the vehicle
Do not change the shift position from
P.
In the unlikely event that the charging
cable has been damaged, the shift
position may change from P to
another position and the vehicle could
move, possibly leading to an accident.

n Charging precautions
This vehicle has been designed to
allow charging from an external
power source using an AC charging
cable for exclusive use with standard
household AC sockets. However, the
vehicle differs greatly from standard
household electrical goods in the following ways, and incorrect usage
could cause fire or electric shock,
possibly leading to death or serious
injury.
l When charging, a large amount of
current will flow for a long time.

l Depending on the charging environment, perform charging outdoors.

NOTICE
n Charging precautions
To charge properly, follow the procedure after reading the explanation
below. Charging is intended to be carried out by licensed drivers only who
properly understand the charging procedure.
l Do not allow people who is not
used to charging, such as children,
to perform charging without supervision.
l When charging with a charger, follow the procedures for using each
charger.

2-2. Charging

Confirm the following before
charging
Before charging, always check the
following items.
 The parking brake is applied.
(P.254)
 The power switch is turned to off.
(P.243)

If these light switches are turned on,
then these features will consume electricity, and charging time will increase.

decline gradually when the traction battery is in use. The rate at which it
declines will differ in accordance with
environmental conditions and the way in
which the vehicle is used. Observing the
following can help suppress the decline
in the traction battery capacity.

l Avoid parking the vehicle in high temperature areas, under direct sunlight
when the traction battery is fully
charged.

l Avoid accelerating and decelerating
frequently and suddenly.

l Avoid frequent driving at high speed.
l Use the charging schedule function as
much as possible in order to fully
charged the traction battery before
starting off. (P.125)

n During charging
l The charging starting time may differ

l Avoid frequent DC charging
Also, if the capacity of the traction battery capacity reduces, the distance that
can be driven decreases. However,
vehicle performance does not significantly become worse.

l During charging, sounds may be

n When the remaining charge of the

depending on the state of the vehicle,
but this does not indicate a malfunction.
heard from near the traction battery in
accordance with the operation of the
air conditioning system or traction battery cooler (P.109).

l Depending on radio wave conditions,
interference may be heard on the
radio.

n When charging using a public

traction battery is low after charging
In the following situations, the remaining
charge of the traction battery after
charging completes may be less than
normal in order to protect the traction
battery (the driving range after the battery is fully charged may be shorter).*

charging facility, check the setting
of the charging schedule function.

l Charging is performed when the out-

l When the charging schedule is regis-

l Charging is performed immediately

tered, temporarily turn off the function
or turn “Charge Now” on. (P.126)

l When the charging schedule is set to

on, charging will not start even if the
AC charging cable is connected. Also,
charging fee may occur due to connection of the AC charging cable.

n Capacity reduction of the traction

battery
The capacity of the traction battery will

side temperature is low or high

after high-load driving or in extreme
heat
In any other situation, if the remaining
charge of the traction battery is significantly lower than normal after charging
completes, have the vehicle inspected
by any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.

2

Electric Vehicle system

 Lights such as the headlights,
emergency flashers and interior
lights, etc., are turned off.

113

114

2-2. Charging

*: When this occurs, even if the remain-

ing charge display of the traction battery shows that it is fully charged, the
remaining charge rapidly decreases
faster than normal.

n When the charging amount sent to

the traction battery decreases
When the charging power to the traction
battery becomes low due to the use of
the air conditioner or the operation of the
traction battery heater, the charging
amount to the traction battery or the
remaining charge of the traction battery
may decrease.

n Charging time may increase
In the following situations, charging time
may become longer than normal:

l In very hot or very cold temperatures.
l When the traction battery becomes
hot, such as immediately after
high-load driving.

l The vehicle is consuming a lot of electricity, for example, when the headlights are on, etc.

l When using My Room Mode.
(P.136)

l When opening the hood while charging

l There is a power outage during charging.

l When adjusting the power supply with
the charger.

l There is a drop in the voltage of external power source.

l The charge in the 12-volt battery is

low, for example due to the vehicle
being left unused for a long period of
time.

l When the upper limit of charging current is changed in the charging current setting of the vehicle (P.117)

l When the traction battery heater operates. (P.109)

l When the traction battery cooler is

operated before charging. (P.109)

l When the plug generates heat due to
a loose socket connection, etc.

l When frequently and repeatedly using
DC charging.

l When selecting “DC Charging power”
setting other than “Max”.

l When the temperature of charging-related parts is high.

l When the vehicle restricts the flow of
electricity to be charged due to the
conditions of the connected external
power source.

n AC charging electricity
This vehicle can be charged up to
approximately 11kW or 22kW*.
However, depending on the used AC
charger or AC charging cable, charging
electricity may be limited.
*: If equipped

2-2. Charging

How to use AC charging
This section explains the procedure for charging the traction battery with AC charging
cable.
When using an AC charger,
make sure to check the operation instructions on the AC
charger.

When charging
1 Prepare the AC charging cable.
2 Insert the plug of the AC charging cable into the electrical
socket of the external power
source.
Make sure to hold the body of the plug
and insert it firmly into the socket.
When the remote switch is equipped,
turn it on.

3 Unlock the doors and open the
charging port lid. (P.104)
The charging inlet light A will illuminate.

NOTICE
n When using the AC charging

related parts
To prevent damage to the AC charging related parts, observe the following precautions.
l When removing the AC charging
cable, check that the AC charging
connector is unlocked.

l Do not apply a vibration to the AC

charging connector while charging.
Charging may be stopped.

l Do not insert anything but the AC
charging connector into the AC
charging inlet.

l Do not disassemble, repair or modify the AC charging inlet. When the
AC charging inlet needs to be
repaired, consult any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

Charging precautions
P.113

4 Insert the AC charging connector into the AC charging inlet.
Align the guide position on the bottom
of the AC charging connector, and push
the AC charging connector straight into
the AC charging inlet as far as possible.
When connecting the AC charging connector into the AC charging inlet, make
sure that the identification symbols are
the same.
When the AC charging connector is
inserted straight as far as possible, it

2

Electric Vehicle system

When the charging schedule is
registered, make sure “Charge
Now” is turned on before
charging. (P.131)

115

116

2-2. Charging

will automatically lock. (P.106)

refer to P.139.

n When connecting the AC charging

connector
If the door is opened or the power switch
is turned to ON with the AC charging
connector connected, the charging
cable indicator turns on to notify that the
AC charging connector is connected.

5 Confirm that the charging indicator of the charging port is illuminated.
Charging will not start if the charging
indicator does not illuminate when the
AC charging connector is inserted.
(P.105)
Charging will not start if the AC charging connector is not locked. However,
depending on the type of the AC
charger of the public charging station,
the AC charging connector will not be
locked if the operation to start the
charging is not performed.
If the charging indicator is flashing, the
charging schedule is registered.
(P.125)
The charging indicator will turn off when
charging is completed.
The charging indicator will also turn off
when charging is stopped for some reason before completion. In this case,

n If the charging indicator of the

charging port flashes after connecting the AC charging cable
The charging schedule (P.125) is registered and charging cannot be performed. To cancel charging using the
charging schedule and start charging,
perform any of the following procedures.

l Turn “Charge Now” on (P.127, 131)
l While the charging indicator is flash-

ing, remove and reconnect the AC
charging connector immediately. The
setting of charging current and charging limit will be temporarily initialized
(P.117).

n When the AC charging connector

cannot be inserted into the AC
charging inlet
P.107

2-2. Charging

117

n Safety function
Charging will not start when the charging connector is not locked.
Also, charging will be stopped if the AC
charging connector is unlocked during
charging. When restarting charging, do
one of the followings, and check that the
charging indicator of the charging port
illuminates.

If changing the charging current setting
while charging, it may cause house
lights to flicker or trip a circuit breaker.
*1: 3 phase charging, the selected current is applied per phase.

l Remove and reinsert the AC charging

tings
The upper limit of the charge capacity
can be changed on the multimedia.
The selected upper limit value is common to AC charging and DC charging.

connector

l Lock the doors

n Charging at a public charging sta-

tion with authentication function
When a door is unlocked during charging, the AC charging connector is
unlocked and charging will be stopped.
In this case, the charging station
authentication is canceled and charging
may not be able to restart. Reconnect
the AC charging connector and perform
authentication for the charging station.

n When your circuit breaker trips dur-

ing charging
The upper limit of the charging current
can be changed on the multimedia.
1 Select

.

2 Select “Vehicle customise”.
3 Select “Charging”.
4 Select “Charging current”.
5 Select “24A”, “16A” or “8A”.*1
During charging, the maximum charging
current will be restricted to the set current or lower.*2
If the breaker still trips while charging,
even after changing the upper limit of
the charging current, check if the connected power source meets the specified charging conditions. (P.107)
Although the charging current setting
can be changed even while charging, it
may take some time for the change to
become effective.

lengthen the charging time.

n Changing the “Charging limit” set-

1 Select

.

2
3
4
5

Select “Vehicle customise”.
Select “Charging”.
Select “Charging limit”.
Select “Full”, “90%”, “80%”, “70%”,
“60%” or “50%”.
If the setting is changed during DC
charging, charging may stop due to the
operation of the DC charger timer and
the traction battery cannot be fully
charged.

n To initialize the setting of charging

current and charging limit temporarily
Remove the AC charging connector
within 15 seconds after connecting it,
and then reconnect it immediately. The
setting of charging current and charging
limit will be temporarily initialized.
Also, if the procedure above is performed while the charging indicator is
flashing normally and the charging
schedule is registered, “Charge Now” is
turned on. (P.116)

n Protection function of AC charging

inlet overheating
By installing a temperature sensor to the
AC charging inlet, prevents parts from
melting when the temperature rises due
to foreign matter entering the AC charging connector.
When a certain temperature increase is
detected, charging is stopped immedi-

2

Electric Vehicle system

n Charging time may increase
P.114

*2: Restricting the charging current will

118

2-2. Charging

ately.
After this, when the power switch is off,
a message will be displayed on the
multi-information display. (P.627)

WARNING
n When charging
Observe the following precautions.
Failure to do so may cause an unexpected accident, resulting in death or
serious injury.
l Before charging, check that the AC
charging inlet is not deformed,
damaged or corroded, and check
that the inlet is free of foreign matter such as dirt, snow and ice.
If there is dirt or dust in these areas,
remove completely before inserting
the AC charging connector.
l Before inserting the charging plug

into the AC charger, make sure
there is no dirt or dust on the terminal areas. If there is dirt or dust in
these areas, remove completely
before inserting the charging plug.

l Do not touch the terminals of the

AC charging connector and AC
charging inlet with a sharp metal
objects (needles, etc.) or hands, or
short them with foreign objects.

l In order to stop charging at the

charging station, follow the instructions of the AC charger.

l If any heat, smoke, odors, noise or

other abnormalities are noticed during charging, stop charging immediately.

l Do not charge the vehicle during a
lightning storm.

l Prevent the AC charging cable from
being caught in the door or back
door.

l Do not connect conversion adapt-

ers between the AC charging connector and AC charging inlet.

l Make sure to connect the AC

charging cable to a socket within
reach and do not use an extension
cord.

l Close the hood before using the

charging system.
The cooling fan may start operating
suddenly. Touching or getting close
to rotating parts such as the fan
may cause your hands or clothes
(especially a necktie or scarf) to
become caught and result in a serious injury.

l If AC charging cable installed on

another vehicle is used, charging
may be stopped.

n Onboard traction battery charger
The onboard traction battery charger
is located in the motor compartment.
Make sure to observe the following
precautions regarding the onboard
traction battery charger. Failure to
observe these precautions may result
in death or serious injury such as
burns and electric shocks.
l The onboard traction battery
charger is hot during charging. Do
not touch the onboard traction battery charger, as doing so may result
in burns.

l Do not disassemble, repair or modify the onboard traction battery
charger. When the onboard traction battery charger needs to be
repaired, consult any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

NOTICE
n When charging
Do not insert the plug into the AC
charging inlet.
The AC charging inlet may be damaged.

2-2. Charging

NOTICE
n Using private power generator
Do not use private power generators
as a power source for charging.
Doing so may make charging unstable, the voltage may be insufficient,
and the charging operation may stop.
Noise may be heard from around the
motor room, even if charging can be
continued.

119

2 Make sure to hold the body of
the AC charging connector and
pull it towards you.

2

n Usable temperature range
l Do not charge if the outside temper-

l Do not leave the vehicle or the AC

3 Close the charging port lid.
Lock the doors to lock the charging port
lid. (P.104)

charging cable in areas where the
outside temperature is lower than
-40°C (-40°F).

n Charging station
Due to the environment in which the
power equipment is located, charging
may be unstable due to noise, the
voltage may be insufficient, and the
charging operation may stop.

After charging
1 Unlock the doors to unlock the
AC charging connector.
(P.106)
The charging inlet light will illuminate
when the doors are unlocked.
If the charging connector is unlocked
during charging (while the charging
indicator is illuminated), charging will be
interrupted.

n When the outside temperature is

low or high
The level shown on the SOC (State of
Charge) gauge (P.156) may drop
slightly when the power switch is turned
to ON, even if charging has been completed and the traction battery is fully
charged. However, this does not indicate a malfunction.

n When stopping charging on the

meter display
1 While the charging status is displayed on the multi-information display, press “OK” of the meter control
switches.
2 Select “Yes”.
Charging will stop.

Electric Vehicle system

ature is -30°C (-22°F) or below, as it
is likely that charging will take
longer.

120

2-2. Charging

n When removing the AC charging

connector
Unlock the doors using the smart entry
& start system or wireless remote control to unlock the AC charging connector, check that the lock is released, and
then pull the AC charging connector
towards you. (P.106)

n If the AC charging connector can-

not be unlocked
P.107

NOTICE
n After charging
After removing the AC charging connector from the AC charging inlet,
make sure to close the charging port
lid.
If the charging port lid is left open,
water or foreign objects may enter the
AC charging inlet, which could lead to
vehicle damage.

How to use DC charging
This section explains the DC
charging procedure for the
traction battery.
When using a DC charger,
make sure to check the operation instructions of the DC
charger.
Using “Battery preconditioning” adjusts the traction battery temperature to the
optimum state during DC
charging. By keeping the traction battery at the optimum
temperature, charging time
can be shortened. (P.132)
WARNING
n When using a DC charger
Observe the following precautions.
Failure to do so may cause an unexpected accident, resulting in death or
serious injury.
l Use a DC charger that complies
with IEC 61815 and IEC 62196.
l Do not use the charging cable
longer than 30 meters.

Confirm the following before
charging
P.113

When charging
1 Unlock the doors and open the
charging port lid. (P.104)

2-2. Charging

2 If the charging port lid is
opened, the charging inlet light

121

charger.

A will illuminate.

2

5 Operate the DC charger and
start the charging.

4 Insert the DC charging connector firmly and fully into the DC
charging inlet.
Insert the DC charging connector and it
will lock automatically.
When inserting the DC charging connector into the DC charging inlet, make
sure that the identification symbols are
the same.
The DC charging connector shape and
treatment will differ depending on the
type of DC charger.
Perform the operations in accordance
to handling procedures of the DC

Follow the handling procedures of the
DC charger to start charging.
Charging starts after a system check is
done.
Stop the charging in accordance to the
handling procedures of the DC charger
when it is desired to interrupt the DC
charging.

n When connecting the DC charging

connector
If the door is opened or the power switch
is turned to ON with the DC charging
connector connected, the charging
cable indicator turns on to notify that the
DC charging connector is connected.

Electric Vehicle system

3 Open the DC charging inlet cap.

122

2-2. Charging

n Charging time may increase
P.114
n When the DC charging connector

cannot be inserted into the DC
charging inlet
P.107

l Quickly move from the DC charging
space for other users after the DC
charging is completed.

l If DC charging is performed while the

traction battery is extremely cold, such
as in cold weather, steam may come
out of the motor compartment or dew
may be formed on the hood. This is
because the heat, generated while the
traction battery is warmed, causes
snow, ice, or frost to evaporate. This is
not a malfunction.

n If a message indicating vehicle

error on the DC charger side is displayed
Even if a message indicating vehicle
error on the DC charger side (ex. vehicle
error found, vehicle error occurred, etc.)
is displayed, there is no vehicle fault but
possibly a communication error between
the DC charger and vehicle. In this case,
there may be a terminal damage (bad
contact) in the DC charging connector.
If there is no error with the vehicle, contact the facility manager of the DC
charger.

l The charge amount is corrected when

the traction battery is fully charged, so
100% remaining the traction battery
may not be displayed.

n How to set the DC charging power
You can change the DC charging power
limit on the multimedia.
1 Select

.

2
3
4
5

cannot be heard due to noise occurrence during DC charging.

Select “Vehicle customise”.
Select “Charging”.
Select “DC charging power”.
Select from “Max”, “125kW”,
“100kW”, “75kW”, “50kW”.
The maximum power when charging is
limited to the selected power or less. If
“Max” is selected, the vehicle will be
charged with the maximum power that
can be charged.

l As the battery approaches full charge,

n Changing the “Charging limit” set-

n During DC charging
l The current charging condition can be
checked on the multi-information display.

l The actual charging time may differ

from that displayed on the DC charger
during charging.

l There may be occasions the radio

the charging speed will decrease and
it will take longer to complete charging.

l Depending on the specifications of the
charger, charging will stop before fully
charging.

l The time to complete charging may

change, or charging may stop before
reaching the upper limit of the charge
capacity, due to the remaining charge
of the traction battery, the outside temperature, the specifications of the
charger, etc.

l It is recommended to avoid frequent
DC charging to prevent a decline in
the traction battery capacity.

tings
P.117

n If the DC charging power limit and

“Charging limit” settings cannot be
changed
Remove the DC charging connector and
immediately reinsert it while the charging indicator is flashing in green. The
settings will be changed to the default
settings.
The settings will be return to the customized setting next time the charging is
performed.
If the DC charging connector is locked
immediately after inserting it, press

2-2. Charging
switch of the wireless remote control or
the door unlock switch on the driver’s
side 3 times at intervals of about one
second to stop DC charging, and then
remove the DC charging connector.

WARNING

l Do not touch the terminals of the

DC charging connector or inlet with
metallic sharp tips (wires and needles), or allow a short circuit to
occur with foreign objects.

l Do not insert anything other than

the DC charging connector into the
DC charging inlet.

l Check that the DC charging cable is
not coiled up or pinned underneath
heavy objects.

l Be sure the charging inlet makes

direct contact with the DC charging
connector.
Do not connect conversion adapters, extension cords, etc., between
the DC charging connector and DC
charging inlet.

l When DC charging is interrupted,

follow the handling procedures of
the DC charger.
Immediately stop the DC charging
when there is an outbreak of heat,
smoke, strange noises or smells,
etc., during charging.

l Check that the DC charging con-

nector and DC charging inlet do not
have foreign objects or snow or ice
attached to it.
If anything is attached to the inlet,
be sure to completely remove the
material before connecting the DC
charging connector.

l Do not charge the vehicle when

there is a possibility of lightning.
If you notice lightning while charging the vehicle, do not touch the
vehicle and the DC charging cable.

l Do not get the DC charging inlet
terminals wet.

l Close the hood when using DC

charging.
The cooling fan may suddenly start
to run. Keep hands and clothing
(especially a tie, a scarf or a muffler) away from the fan. Failure to
do so may cause the hands or
clothing to be caught, resulting in
serious injury.

n When connecting the DC charging connector

l Follow the handling procedures of

the DC charger to connect the DC
charging connector. If the connector
is not connected properly, the system cannot recognize the connection, and it may be possible to start
the EV system.

l Do not remove the DC charging

connector from the DC charging
inlet during DC charging. After
operating the DC charger to stop
charging, remove the DC charging
connector from the DC charging
inlet.

2

Electric Vehicle system

n Warnings for DC charging
Be sure to observe the following when
using DC charging.
Failure to do so may cause an accident that could lead to death or serious injury.
l Check that the DC charger and DC
charging inlet are not damaged. If
there is any damage to the DC
charging inlet, do not perform a DC
charge and have it inspected immediately at any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.

123

124

2-2. Charging

NOTICE
n When using DC charging
Make sure to follow the handling procedures of the DC charger. If the procedures are not followed properly, the
vehicle and the DC charger may be
damaged.

3 Close the DC charging inlet cap,
and then close the charging port
lid.

After charging
1 Operate the DC charger and
stop the charging.
The DC charging connector will be
unlocked when charging is completed,
while carrying the electronic key on
your person or when the doors are
unlocked.

2 Remove the DC charging connector.
The DC charging connector shape and
treatment will differ depending on the
type of DC charger.
Perform the operations in accordance
to handling procedures of the DC
charger.
Return the removed DC charging connector to its original position.

n If the EV system was not started

after DC charging and the EV system has been started by pressing
the power switch
If the system check after DC charging
does not finish properly, the EV system
may not start even if the power switch is
pressed with the brake pedal
depressed.
If the EV system is started when the
power switch is pressed again, this is
not a malfunction.

n When DC charging cannot be

stopped
If DC charging from the DC charger cannot be stopped due to a malfunction,
etc., press the door unlock button, either
on the wireless remote control or on the
driver’s door, three times at about 1 second intervals. Then the DC charging will
be stopped.

n When stopping charging using the

charging stop button
1 Press “OK” of the meter control
switches while the charging status is

2-2. Charging
displayed on the multi-information
display.

125

Using the charging
schedule function
AC charging can be carried out
at the desired time by registering the charging schedule.

n If the DC charging connector can-

not be unlocked
P.107

n After DC charging
Even if the traction battery is charged to
the upper limit value that is set, the level
of charge displayed on the DC charger
may be lower than the actual one.

WARNING
n Cautions after DC charging
After charging is completed, make
sure to remove the DC charging connector from the DC charging inlet
before starting the EV system.
If the vehicle is started off with the
connector still connected, it could
lead to an accident, possibly resulting
in death or serious injury.

NOTICE
n Precautions after DC charging
Be sure to close the DC charging inlet
cap, and then close the charging port
lid after removing the DC charging
connector from the DC charging inlet.

n Schedule function
Charging schedule is performed according to the day and time shown on the
multimedia. For details, refer to the
“Multimedia owner’s manual”.

Setting of the charging
schedule function
When registering the charging
schedule, the following settings can
be changed.
n Select the charging mode

One of the two following charging
modes can be selected.
 “Start”

Starts charging at the set time and
finishes charging when fully
charged.
 “Start and stop”

AC charging is performed according to the set start time and stop
time.
n Repeated setting

The periodic charging schedule can
be set by selecting your desired
day of the week. Select one or
more day of the week to do the
charging schedule.

2

Electric Vehicle system

2 Select “YES” and press “OK” to stop
charging.
If the DC charging connector is removed
and immediately reinserted while the
charging indicator is flashing in green,
charging cannot be stopped using “Stop
charging”. To stop charging, remove the
DC charging connector.

126

2-2. Charging

n Turning “Charge now” on and

off
To start charging without changing
the charging schedule setting, turn
“Charge now” on to temporarily
cancel the charging schedule and
enable charging after connecting
the AC charging connector.*
*: If the AC charging connector is

removed while the charging schedule
is registered and “Charge now” is on,
“Charge now” turns off.

n “Next charging event”

Of the registered charging schedules, the closest charging schedule
after the current time is called the
“Next charging event”.
For charging schedule, AC charging will be performed according to
the Next Event.

Registering the charging
schedule
The Charging Schedule can be registered on the multimedia.
Only “Charge Now” can be set on
the multi-information display.
 Multi-information display operation: P.127
 Multimedia operation: P.128

n Charging schedule function
l The charging schedule cannot be set
while driving.

l A maximum of 15 charging schedules

can be registered.
If the charging mode is set to
“Start-stop” and the start time and end
time are set to the same time, charging
will be performed for 24 hours from the
start time.
The charging schedule function can not
be used when using DC charging.

n To make sure that the charging

schedule function operates correctly
Check the following items.

l The multimedia screen displays the

correct time and day of week
For details, refer to the “Multimedia
owner’s manual”.

l Check that the power switch is turned
off

l After registering the charging sched-

ule, connect the AC charging connector
The charging start time is determined
based on the charging schedule at the
time that the AC charging connector
was connected.

l Connect the AC charging connector

before the start time
When the charging mode is set to
“Start”, if you connect the AC charging
connector after the set start time, the

2-2. Charging

127

next charging schedule will be referenced.

l When turning My Room Mode on

When the charging mode is “Start and
stop”, if you connect the AC charging
connector after the start time, charging
will start immediately and charging will
be performed until the stop time.

l When turning “Charge now” on

l After connecting the AC charging con-

(P.109)/Traction battery cooler
(P.109)
Depending on the temperature of the
traction battery, the traction battery
heater or traction battery cooler may be
activated and the charging indicator may
light up while the charging schedule is
waiting for charging.

nector, check that the charging indicator of the charging port flashes
(P.105)

l Do not use an socket that has a power

n When the AC charging connector

(P.127, 131)

l When an operation that temporarily
cancel charging using the charging
schedule (P.116)

n Traction battery heater

Setting operations on
multi-information display
When operating charging schedule,
use the meter control switches.

remains connected to the vehicle

l When the charging mode is set to

“Start”, even if multiple consecutive
charging schedules are registered,
the next charge will not be carried out
according to the charging schedule
until the AC charging connector is
removed and reconnected after
charging completes. Also, when the
traction battery is fully charged, charging according to the charging schedule will not be carried out.

l If the charging stop time is reached

before the traction battery is fully
charged and the charging mode is set
to “Start and stop”, the nearest charging schedule after the stop time is
updated as the next charging schedule, and charging is repeated until the
battery is fully charged.

n When charging schedules are

ignored
When the following operations are performed while the charging schedule is
on standby, charging schedule is temporarily canceled and charging is started.

A Meter control switches (P.160)
B Multi-information display
n Setting “Charge Now” to on

1 Turn the power switch off.
The “Closing Display” screen will be
displayed on the multi-information display.
(If the door is opened while waiting for
charging schedule, the same screen
will be displayed.)

2

Electric Vehicle system

cut off function (including a charging
schedule function)
Use an socket that constantly supplies
electricity. For sockets where the power
is cut off due to a charging schedule
function, etc., charging may not be carried out according to plan if the power is
cut off during the set time.

(P.136)

128

2-2. Charging

2 Press

to set “Charge Now”

to on.
Each time “OK” is pressed, “Charge
Now” switches between on and off.
After setting operations are complete,
charging starts when the AC charging
connector is connected. (P.115)*
*
: If the AC charging connector is
removed while the charging schedule
is registered and “Charge Now” is on,
“Charge Now” turns off.

If “Charge Now” cannot be set to on
even when performing the operations above, remove the AC charging connector while the charging
indicator is flashing at the normal
speed and then immediately reconnect it.
If this operation is performed, the
setting of charging current and
charging limit will be temporarily initialized. (P.117)

Setting operations on multimedia
For details on how to operate the
multimedia screen, refer to “Multimedia owner’s manual”.
Setting operations related to the
charging schedule are performed
on the “Charging schedule” screen.
n Displaying the “Charging

schedule” screen
1 Turn the power switch to ON.
It is not possible to control the Charging
Schedule settings in Accessory Mode.

2 Select
and “Charging
schedule”, in that order.
The “Charging schedule” screen will be
displayed.

2-2. Charging

129

n How to read the “Charging schedule” screen

2

Displays the week-long registered charging schedule in a list using icons.

B “Add” button
Press to add a new item to the charging schedule. (P.129)

C “Edit” button
Press to change or delete registered items on the charging schedule. (P.130)

“Charge now” button
Each time the button is pressed, “Charge now” switches between on and off.
(P.131)

Return button
Press to close the “Charging schedule” screen.

n Registering the charging

schedule
1 Display the “Charging schedule” screen. (P.128)
2 Press “Add”.
The “Add event” screen will be displayed on the screen.

3 Select the charging mode.
Select the button in the row of the “Start
at set time” or “Start and stop at set

times”.

Electric Vehicle system

A Charging schedules

130

2-2. Charging

4 Operate “Start at set time”
screen and select desired time,
and then select

.

When the charging mode is “Start at set
time”, set the charging start time.
When the charging mode is “Start and
stop at set times”, also set the charging
stop time.

5 When activating the repeated
settings, select the desired day,
and then select

.

Each time the day is selected, the
repeated setting for the selected day
switches between on and off.
When turned on, the check box is highlighted and the charging schedule is
repeated on that day. It is possible to
turn more than one day on.

6 After setting operations are
complete. Select “Save”.

n Changing the registered

charging schedules
1 Display the “Charging schedule” screen. (P.128)
2 Press “Edit”.
The “Events” screen will be displayed
on the screen.

3 Press “Edit” on the “Events”
screen.

The charging schedule is added to the
list and an icon is added to the “Charging schedule” screen.

n Switching charging schedules

between on and off
1 Display the “Charging schedule” screen. (P.128)
2 Press “Edit”.
The “Events” screen will be displayed
on the screen.

3 From the items displayed on the
screen, press on or off in the
row of the charging schedule
you wish to change.
If the charging schedule you wish to
change is not displayed on the screen,
scroll the list up and down to display it.
Each time the button is pressed, the
charging schedule switches between
on and off.

4 From the items displayed on the
screen, press “Edit” in the row of
the charging schedule you wish
to change.
 Changing registered items:
Change the desired settings as
described starting from step 3 of the
“Registering the charging schedule”
procedure. (P.129)
When a setting is changed, its icon on
the “Charging schedule” screen also
changes.

2-2. Charging

131

 Deleting registered items:
Press “Delete”.
A deletion confirmation message will be
displayed.
Press “Delete” to delete the selected
charging schedule.
When a charging schedule is deleted,
its icon is also deleted from the
“Charging schedule” screen.

n Turning “Charge now” on

2 Press “Charge now”.
Each time the button is pressed,
“Charge now” switches between on
and off.
After setting operations are complete, charging starts when the AC
charging connector is connected.
(P.115)
If “Charge now” cannot be set to on
even when performing the operations above, remove the AC charging connector while the charging
indicator is flashing at the normal
speed and then immediately reconnect it.
If this operation is performed, the
setting of charging current and
charging limit will be temporarily initialized. (P.117)
n Displaying Next Event

Turn the power switch off.
Next event will be displayed according
to the charging schedule settings.*

: If the multimedia customize content
“ACC customise” is not set to OFF,
the ending screen will not be displayed. If it is this case, check the
settings of the multimedia.

When press “OK”, close Next charging
event screen.
When press “Charge now”, charge now
is turned on.

n When all charging schedules are

turned off
The icon is not displayed on the “Charging schedule” screen.
The icon will be displayed by turning it
ON on the “Events” screen.

n When charging schedule setting

operations are canceled
When the vehicle is in the following conditions, charging schedule setting operations are canceled.

l The power switch is turned off before
the settings are confirmed

l The vehicle starts off
l A display with a higher priority than

that of the charging schedule setting
is shown

n When charging schedule are

changed while charging
If the charging schedule is changed,
Next Event will be updated and charging
may stop. After changing the charging
schedule, please check Next Event.
If you want to continue charging, turn on

2

Electric Vehicle system

1 Display the “Charging schedule” screen. (P.128)

*
