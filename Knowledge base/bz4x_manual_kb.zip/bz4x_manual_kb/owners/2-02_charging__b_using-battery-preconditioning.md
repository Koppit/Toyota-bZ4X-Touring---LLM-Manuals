# 2-2. Charging (part 2: Using Battery Preconditioning, …)

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 2: Electric Vehicle system, pages 132–151
> Topics in this part: Using Battery Preconditioning; Using My Room Mode; When charging cannot be carried out

132

2-2. Charging

“Charge now”.

NOTICE
n While performing the setting

operation
When performing the setting operation while the EV system is stopped,
be careful that the 12-volt battery will
not be discharged.

Using Battery Preconditioning
By setting battery preconditioning in advance before DC
charging, the temperature of
the traction battery is adjusted
to the optimal state for charging. Charging time can be
shortened by bringing the traction battery to the optimal temperature for charging.
 The cruising distance may be
shortened as electric power is
used to adjust the temperature
of the traction battery.
 Battery preconditioning may
not be available when the traction battery charge level is low.

What can be done with battery preconditioning settings.
Battery preconditioning settings
allow you to configure the following
features:
Battery preconditioning can be
setup via the Multimedia.
 “Battery preconditioning”

(P.133)
When turned ON, “Battery preconditioning” starts and adjusts the
temperature of the traction battery.
 “Battery preconditioning linked

with navigation” (P.133)
When a DC charging station is set

2-2. Charging

5 Select “Battery preconditioning”.

“Battery preconditioning” switches
between ON and OFF with each touch
of the button.

 “Scheduled battery precondition-

ing” (P.134)
By setting the departure time, the
temperature of the drive battery will
be adjusted in advance according
to the departure time.
This feature helps allow the battery
to be ready to accept faster charging speeds.

Switching “Battery preconditioning” ON-OFF

Switching “Battery preconditioning linked with navigation” ON-OFF
1 Turn the power switch to ON.
2 Select

.

3 Select “Battery preconditioning”.
4 Select “General”.
5 Select “Battery preconditioning
linked with navigation”.

1 Turn the power switch to ON.
2 Select

.

3 Select “Battery preconditioning”.
4 Select “General”.

“Battery preconditioning linked with
navigation” switches between ON and
OFF with each touch of the button.
When “Battery preconditioning linked
with navigation service” is set to ON
and a DC charging station is set as a
destination in the navigation system,

2

Electric Vehicle system

as a destination in the navigation
system, “Battery preconditioning” is
automatically turned on according
to the estimated arrival time.
• It may not work depending on
how the destination on the navigation system or the quick charging station is set.
• Depending on traffic conditions
and driving style, temperature
adjustment may not be completed by the arrival time.

133

134

2-2. Charging

“Battery preconditioning” will automatically be set to ON.

5 Select “Add”.

Setting “Scheduled battery
preconditioning”
n Schedule Setup

Departure preconditioning, will be
performed according to the date
and time displayed in the multimedia.
When attempting to set up departure preconditioning, make sure to
check the schedule settings to
make sure it is set to the correct
date and correct them if it is incorrect.

6 Operate the screen to set the
desired time and touch “OK”.

If the schedule contents are incorrect, departure preconditioning will
not work properly.
For details on how to operate the
multimedia screen, refer to “Multimedia owner’s manual”

7 Select the desired day of the
week to enable the repeat setting and touch “OK”.

n Registering “Scheduled bat-

tery preconditioning”
1 Turn the power switch to ON.
2 Select

.

3 Select “Battery preconditioning”.
4 Select “Schedule”.
Each time the check box is selected,
the repeat setting for the selected day
of the week will be turned on or off.

8 When all settings are complete,
touch “Save”.

2-2. Charging

n Switching the settings of

135

5 Select “Edit”.

“Scheduled battery preconditioning”
1 Turn the power switch ON.
2 Select

.

3 Select “Battery preconditioning”.
4 Select “Schedule”.

If the preconditioning setting desired to
turn ON/OFF is not displayed on the
screen, scroll the list display up or down
to display the preconditioning setting.
Each time the button is selected, the
preconditioning setting will switch
between ON and OFF.

n Changing the registered con-

tents of “Scheduled battery
preconditioning”
1 Turn the power switch to ON.
2 Select

.

3 Select “Battery preconditioning”.
4 Select “Schedule”.

6 From the list displayed on the
screen, touch the preconditioning settings in which it is desired
to change the registered contents.

 When changing the registered
contents:
Change the settings to the desired settings by following the steps from step 5
of “Registering “Scheduled battery preconditioning””.

 When deleting the registered
contents:
Touch “Delete”
A message appears to confirm the
deletion.
Touch “Delete” to delete the selected
charging schedule.

2

Electric Vehicle system

5 From the displayed list, touch
the button for the preconditioning setting desired to turn
ON/OFF.

136

2-2. Charging

Using My Room Mode
When the charging cable is
connected to the vehicle, electrical components such as the
air conditioning system and
audio system can be used by
the power supply from an
external power source.

Starting My Room Mode
1 Connect the charge cable to the
vehicle to start charging.
AC Charging: P.115
DC Charging: P.120
2 Turn the power switch to ON
while charging.
My Room Mode settings is automatically displayed on the multimedia.

3 Select the “Yes”.
My Room Mode is started and it is possible to use the air conditioning system,
audio system, etc.
Select “No” when My Room Mode is not
being used.
To disable My Room Mode, turn the
power switch off.
My Room Mode will automatically be off
when DC charging is completed.

n When a door is unlocked while

using My Room Mode
The charging connector unlocks, charging stops and My Room Mode stops. In
order to use My Room Mode again, lock
the doors or reconnect the AC charging
cable and start My Room Mode.
(P.136)
When using My Room Mode with public
charging station, operation to start
charging using the charger may be

required again before starting My Room
Mode.

n Meter display while charging
After turning the power switch to ON
while charging, the power switch automatically turns off if My Room Mode is
not selected within approximately 100
seconds.

n When using My Room Mode the following may occur

l When the remaining charge of the

traction battery drops to the lower
limit, the air conditioning system automatically stops. In that case, the air
conditioning system, audio system,
etc., can not operate until the remaining charge of the traction battery
increases. Turn off the power switch
once, then use My Room Mode after
the remaining charge of the traction
battery increases.

l If the doors are unlocked while using

My Room mode, the AC charging connector will be unlocked and My Room
mode will be stopped. To use My
Room mode again, perform the operation to start it. (P.136)
In addition, when using AC charger at
the public charging station, it is necessary to perform the operation to start
the charger before using My Room
mode.

l The charging time of the traction battery gets longer.

l Noise may be heard from the radio

depending on conditions of the radio
wave.

l The surrounding area of the onboard
traction battery charger in the motor
compartment may become hot.

l The electric power steering system

warning light (yellow) may turn on, but
this is not a malfunction.

l When charging the battery in normal

mode, the amount of charge is controlled so that the battery is not fully
recharged in order to maintain the My
Room Mode.

2-2. Charging

n Using My Room Mode during DC
charging

l When using My Room mode during

DC charging, the amount of charge at
the time of charge completion will be
lower than when not using it. In addition, when DC charging during low
outdoor temperatures and a high
humidity environment, the windows
may fog up. Turning on the cooling
and dehumidification functions
(P.136) will dehumidify the vehicle
interior and remove fogging from the
windows. In this case, the tempera-

137

ture control of the traction battery will
be stopped and the amount of charge
may decrease.

l When the battery is fully charged, the
system will exit the My Room Mode.

n When My Room Mode is used while

the traction battery is fully charged
When My Room Mode is used while the
traction battery is fully charged, the electric power of the traction battery may be
consumed. In this case, charging may
be performed again.

When trying to start My Room Mode or My Room Mode is being used, if a message
is displayed on the multi-information display, refer to the corresponding table and
perform the appropriate correction procedures.
Message

Correction procedure

“Traction battery is too low
for “My Room Mode”.”

There is no remaining charge of the traction battery to
start My Room Mode. Wait until the remaining charge
of the traction battery increases, start My Room Mode.

““My Room Mode” has
The remaining charge of the traction battery is insuffistoppedd ue to low traction cient. Stop using My Room Mode and charge the tracbattery.”
tion battery.
When My Room mode electricity consumption
exceeds the charge amount, the traction battery
““My Room Mode” will stop charge level becomes too low.*
when traction battery is too  If the electricity consumption of the vehicle can not
low. Reduce power usage
be improved, My Room Mode will be off.
to continue using “My Room  When My Room Mode continuation is desired, turn
Mode”.”
off the air conditioning system, audio system, etc.,
to increase the remaining charge of the traction battery.
*: During My Room Mode, the information for electric power balance can be checked

on the multimedia.

Electric Vehicle system

n Warning message display

2

138

2-2. Charging

WARNING
n Warnings for using My Room

Mode
Observe the following precautions.
Failure to do so may result in death or
a serious health hazard.
l Do not leave children, people who
need care, or pets inside the vehicle. The temperature inside the
vehicle may become high or low
due to features such as the automatic shut-off. The children, people
who need care, or pets left inside
the vehicle may suffer heatstroke
dehydration or hypothermia. Also,
since the wipers, etc., can be operated, there may be accidental operation, possibly leading to an
accident.

l Use the mode after sufficiently

checking the vicinity of the vehicle
for safety hazards.

2-2. Charging

139

When charging cannot be carried out
When charging does not start, even though the normal procedure is
followed, check each of the following items.
If a message is shown on the multi-information display, also refer to
P.146.

When charging cannot be carried out

n Charging indicator of the charging port does not illuminate, even

though AC charging connector is connected.
Likely cause

AC charging connector is not securely
connected to AC charging inlet

Traction battery is already fully charged

Correction procedure
Check the connection status of the
charging connector.
 When connecting the AC charging
connector, insert the AC charging connector securely.
 After connecting the AC charging connector, check that the charging indicator of the charging port is turned on.
If the charging indicator of the charging
port does not illuminate, even though the
AC charging connector is securely connected, there may be a malfunction in the
system. Immediately stop charging and
contact any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.
When the traction battery is fully
charged, charging is not performed.

The remaining charge of the traction bat- Change to a higher upper limit setting
tery exceeds the set upper limit of the
than the current remaining charge capaccharge capacity
ity and perform charging again.
The AC charger does not operate

Please contact the facility manager when
there is a problem with AC charger.

2

Electric Vehicle system

Refer to the following table and carry out the appropriate correction procedure.

140

2-2. Charging

n Charging indicator of the charging port flashes and charging can-

not be carried out.
Likely cause

Correction procedure

When you wish to charge according to
When charging indicator of the charging the charging schedule, wait until the set
port flashes normally*: Charging sched- time.
ule is registered

To start charging, set “Charge Now” to
on. (P.127, 131)

When a door is opened while the power
switch is off, a message will be displayed
port rapidly flashes*: Malfunction
on the multi-information display. Follow
occurred in an external power source or
the instructions displayed on the
the vehicle
multi-information display.
When charging indicator of the charging

*: Refer to P.105for details regarding charging indicator of the charging port illumina-

tion and flashing.

2-2. Charging

141

When DC charging cannot be performed normally
n DC charging does not start
Likely cause

Correction procedure

The DC charging connector is not properly connected to the vehicle.

Check the connection status of the DC
charging connector and be sure that it is
locked.

2

Electric Vehicle system

The DC charging connector is not
securely locked.

If the DC charging does not start, even
though the DC charging connector is
securely connected, there may be a malfunction with the DC charger or charging
system.
 If there is a malfunction with the DC
charger, contact the charging station
manager.
 If there is not a malfunction with the
DC charger, there may be a malfunction in the system. Contact any authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
 If there is an error in the connection
status due to the weight of the connector, disconnect the connector and then
reconnect it. Lift and hold the connector in place for about 3 seconds after
reinserting it until it locks. If the connector still does not lock, check if it can
be charged with another DC charger.

142

2-2. Charging
Likely cause

Correction procedure

Error is detected by the DC charger or
vehicle’s system check.

There may be a malfunction with the DC
charger or charging system.
 If there is a malfunction with the DC
charger, contact the charging station
manager.
 If there is not a malfunction with the
DC charger, there may be a malfunction in the system. Contact any authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
 If the EV system can not be started,
contact any authorized Toyota retailer
or Toyota authorized repairer, or any
reliable repairer.

The DC charger power goes off.

Contact the charging station manager
and check the power status.

Traction battery is already fully charged

When the traction battery is fully
charged, DC charging cannot be performed.

The EV system is started.

When the EV system is started, DC
charging cannot be started.
Also, if the shift position is not in P, DC
charging cannot be performed.

Set the upper limit of the charge capacity
The upper limit of the charge capacity is to a value higher than the current remaining charge of the traction battery, and
lower than the remaining charge of the
then perform the charging procedure
traction battery
again.
DC charging was repeatedly performed

After waiting a few minutes after starting
the EV system, stop the EV system and
perform charging again.

2-2. Charging

143

n When DC charging is interrupted
Likely cause

Correction procedure

The timer for the DC charger operates.

Depending on the type of the DC
charger, the timer may be set to stop
charging after a certain time. Check with
the charging station manager.

The power for the DC charger is off.

Check the power status of the DC
charger. If there are uncertainties with
the power status, contact the charging
station manager.

Error is detected by the DC charger or
vehicle’s system check.

There may be a malfunction with the DC
charger or charging system.
 If there is a malfunction with the DC
charger, contact the facility manager.
 If there is not a malfunction with the
DC charger, there may be a malfunction in the system. Contact any authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
 If the EV system can not be started,
contact any authorized Toyota retailer
or Toyota authorized repairer, or any
reliable repairer.

High temperature of charging related
parts

If the temperature of charging related
parts is high, DC charging may not be
possible. Wait for a while and then
charge again.

The electrical components such as the
air conditioning system stop operating
while the traction battery is approximately fully charged.

Keep the electrical components such as
the air conditioning system in the OFF
state, and then perform the DC charging
procedure again.

Electric Vehicle system

DC charging may not be performed in
extremely high or extremely low temperThe temperature of the traction battery is
ature environments. Charge the traction
extremely high or low.
battery after the temperature has been
stabilized.

2

144

2-2. Charging

n EV system does not start after DC charging
Likely cause

Correction procedure

Do a system check following the procedures on P.124. If the system check can
not be completed properly even after
Charging system check is not completed
these procedures are performed, conproperly after DC charging.
tact any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.

The DC charging connector is still connected.

For safety, the EV system can not be
started when the DC charging connector
is connected. (P.112)
Remove the DC charging connector
immediately after the charging is completed.

 Depending on the type of malfunction,
the EV system can be started after the
charging system check is completed.
(P.124)
The DC charging system is malfunction If the EV system can not be started,
ing
contact any authorized Toyota retailer
or Toyota authorized repairer, or any
reliable repairer.

When charging schedule function does not operate normally
Refer to the following table and carry out the appropriate correction procedure.
n Charging does not start at desired time
Likely cause

Correction procedure
Check the calendar setting and set it to

The vehicle day and time is not set correctly.

the correct date.*
Check the clock setting and set to the
proper time.*

2-2. Charging
Likely cause

145

Correction procedure

AC charging connector is not connected Before using the charging schedule, conto vehicle
nect the AC charging connector.
Connect the AC charging connector
before the time set in “Start”.
AC charging connector was connected
after set time

When the charging mode is set to “Start
and stop”, the traction battery will charge
even if the start time has passed, if the
AC charging connector is connected
before the stop time.

2

*: For details on setting the clock, refer to the separate “Multimedia owner’s man-

n Charging starts, even though charging schedule is registered
Likely cause

Correction procedure

“Charge Now” is set to on

When charging according to the charging
schedule, set “Charge Now” to off.
(P.127, 131)

Charging schedule is set to off

Check that charging schedule is not set
to off. (P.130)

The charging mode is set to “Start and
stop” and the AC charging connector
was connected between the start time
and stop time

When the charging mode is “Start and
stop”, connecting the AC charging connector after the start time will perform
charging until the stop time. Check the
charging schedule.

Electric Vehicle system

ual”.

146

2-2. Charging
Likely cause

Correction procedure

If the AC charging connector is removed
and reinserted while the charging indicaAC charging connector was removed
tor is flashing, the charging schedule is
and reinserted while charging indicator of
canceled (P.116). Temporarily remove
the charging port was flashing
the AC charging connector, and then
reconnect it.

Outside temperature is low and traction
battery warming control (P.109) operated

 When traction battery warming control
operates, the charging schedules are
ignored and charging starts. In order to
protect the traction battery, allow
charging to continue.
 After the 12-volt battery is removed
and reconnected, the charging schedule setting may be disabled due to the
initial setting of the temperature control
system for the drive battery, even when
the outside temperature is not low. In
this case, after driving a few times, the
system initial settings will be completed and the charging schedule settings will be enabled when the outside
temperature is not low.

When charging-related message is displayed
When a door is opened with the power switch off, after charging, a message is displayed in the multi-information display.
When this occurs, follow the instructions displayed on the screen.

2-2. Charging

147

n If “Charging Stopped Due to Pulled Charging Connector” is shown
Likely cause

Correction procedure

AC charging connector is removed while
AC charging

When the AC charging connector is
After the traction battery is fully charged,
removed while AC charging, charging
the AC charging connector is removed
stops. If you want to fully charge the tracwhile the traction battery is being
tion battery, reconnect the AC charging
recharged again because electricity-conconnector.
suming functions* have been used and
the remaining charge is now reduced.
When the AC charging connector is
unlocked while AC charging, charging
stops. To continue charging, reconnect
the AC charging connector.

*: Electricity is consumed when operating traction battery heater (P.109)

n If “Charging complete Limited charge due to battery temp” is

shown
Likely cause

Correction procedure

Allow the traction battery to cool down
Charging was stopped to protect the
and perform charging again if the chargtraction battery as it continued to remain
ing amount has not reached the desired
hot for a certain period of time.
amount.

Electric Vehicle system

AC charging connector was unlocked
while AC charging

2

148

2-2. Charging

n If “Charging Stopped Check Charging Source” is shown
Likely cause

Correction procedure
Check the following items.
 The plug is securely inserted.
 Extension cord or multi-socket is not used.
 The remote switch is not off.
 Connected to a dedicated power line.
 Power outage has occurred or not.
 The circuit breakers have not tripped.

Problem in power supply from If all of the above conditions are met, the electrical
socket may be malfunctioning. Contact an electriexternal power source
cian and request an inspection.
If charging cannot be performed, even though
there is no problem with the power source path,
there may be a malfunction in the system. Have the
vehicle inspected by any authorized Toyota retailer
or Toyota authorized repairer, or any reliable
repairer.
Depending on the specifications of AC charger,
charging may be canceled by an interruption of
power supply. Charging may be stopped by the following.
Refer to AC charger handling methods.
 The charging stop button of charger is pressed.
 AC charger with off charging schedule function
canceled charging
AC charging is stopped by AC
 AC charger that is not compatible with the chargcharger
ing schedule function of the vehicle
 Check if it can be charged with another AC
charger.
If charging cannot be carried out even when using
another AC charger, contact any authorized
Toyota retailer or Toyota authorized repairer, or
any reliable repairer.
Check if it can be charged with another AC
charger. If charging cannot be carried out even
The AC charger is not compatiwhen using another AC charger, contact any
ble with the vehicle
authorized Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

2-2. Charging
Likely cause

149

Correction procedure

The DC charger is malfunction- If the message above is displayed when DC charging.
ing has not stopped operations, the DC charger
may be damaged, so do not use that DC charger.
Check if it is possible to charge with another DC
charger.
The DC charger is not compat- If the message is still displayed and charging canible with the vehicle.
not be performed even though another DC charger
is used, drive the vehicle for several kilometers and
then charge the traction battery with different DC
charger.

shown
Likely cause

Power is being consumed by electrical
components of vehicle

Correction procedure
Check the following items, and then carry
out charging again.
 If the headlights and audio are turned
on, turn them off.
 Turn the power switch off.
If charging cannot be carried out, even
after performing the above, the 12-volt
battery may not be sufficiently charged.
Operate the EV system for approximately
15 minutes or more to charge the 12-volt
battery.

n If “Charging system malfunction See Owner's Manual” is shown
Likely cause

Correction procedure

Have the vehicle inspected by any
authorized Toyota retailer or Toyota
Malfunction occurred in charging system
authorized repairer, or any reliable
repairer.

Electric Vehicle system

n If “Charging stopped High energy use See Owner's Manual” is

2

150

2-2. Charging

n If “Traction battery temp is low System has prioritised charging to

preserve battery condition” is shown
Likely cause

The traction battery warming control is
operated (P.109)

Correction procedure
When the traction battery warming control operates, the charging schedule is
not used and charging is performed.
This is a control to protect the traction
battery, and not a malfunction.

n If “Charging Stopped Time Limit Reached” is shown
Likely cause

Correction procedure
 Depending on the type of DC charger,
the timer may be set to stop charging
after a certain time. Check with the
charging station manager.

Depending on the condition of the vehicle, the charging time may become
longer than normal, and the DC charging
The DC charging is not completed within may not be completed within the
restricted time.
the restricted time with DC charger.
 When the A/C, headlights, audio system, etc., are turned on, the electricity
consumption of the vehicle will be
increased. Perform the DC charging
after turning off all of the above.
 The temperature of the traction battery
may be low. Perform the DC charging
after warming up the traction battery.

n If “Charging Stopped Check Charging Source or Vehicle” is shown
Likely cause
Malfunction occurred in connector locking system.

Correction procedure
Have the vehicle inspected by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

Vehicle status information
and indicators

151

3

3-1. Instrument cluster
.

Warning lights and indicators
.......................................152
Gauges and meters ..........156
Multi-information display ...159
Displayed content .............160
Electricity consumption .....164
3

Vehicle status information and indicators
