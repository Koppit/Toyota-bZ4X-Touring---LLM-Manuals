# 4-3. Adjusting the seats

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 4: Before driving, pages 196–202

196

4-3. Adjusting the seats

Front seats

4-3.Adjusting the seats

 Manual seat (passenger seat)

The seats can be adjusted (longitudinally, vertically, etc.).
Adjust the seat to ensure the
correct driving posture.

Adjustment procedure
 Power seat (driver and passen-

ger seat)

A Seat position adjustment lever
B Seatback angle adjustment
lever
C Vertical height adjustment lever
n When adjusting the seat
l Make sure that any surrounding pas-

sengers or objects are not contact the
seat.

l Take care when adjusting the seat so

A Seat position adjustment switch
B Seat cushion (front) angle
adjustment switch
C Seatback angle adjustment
switch

Vertical height adjustment
switch
Lumbar support adjustment
switch (driver seat only)

that the head restraint does not touch
the ceiling and sun visor.

n Power easy access system (if

equipped)
The driver’s seat move in accordance
with power switch mode and the driver’s
seat belt condition. (P.221)

WARNING
n When adjusting the seat position
l Take care when adjusting the seat

position to ensure that other passengers are not injured by the moving seat.

4-3. Adjusting the seats

WARNING

197

Rear seats

l Do not put your hands under the

seat or near the moving parts to
avoid injury. Fingers or hands may
become jammed in the seat mechanism.

Reclining adjustments and
folding the seatbacks can be
done with lever operation.

l Make sure to leave enough space
around the feet so they do not get
stuck.

l Manual seat only: After adjusting

the seat, make sure that the seat is
locked in position.

n Seat adjustment

Pull the seatback angle adjustment
lever A , and adjust the seatback
angle.

4

WARNING
n When operating the rear

seatback
Observe the following precautions.
Failure to do so may result in death or
serious injury.

l Keep other passengers from being
hit by the rear seatback.

l Do not put your hands between the

seats or near the moving parts, or
let any part of your body get caught.

Before driving

To reduce the risk of sliding under the
lap belt during a collision, do not
recline the seat more than necessary.
If the seat is too reclined, the lap belt
may slide past the hips and apply
restraint forces directly to the abdomen, or your neck may contact the
shoulder belt, increasing the risk of
death or serious injury in the event of
an accident.
Adjustments should not be made
while driving as the seat may unexpectedly move and cause the driver to
lose control of the vehicle.

Adjustment procedure

198

4-3. Adjusting the seats

WARNING
l After adjusting the seat, make sure

that the seat is locked in position. If
the seatback is not securely locked,
the red marking will be visible.
Make sure that the red marking is
not visible.

n Folding down the rear

seatbacks
 Using the seatback angle adjust-

ment lever
While pulling the seatback angle
adjustment lever A , fold the
seatback down.

Folding down the rear
seatbacks
n Before folding down the rear

seatbacks
1 Park the vehicle in a safe place.
Apply the parking brake firmly (P.254)
and shift the shift position to P.
(P.248)

 Using the rear seat remote con-

trol lever
While pulling the rear seat remote
control lever, fold the seatback
down.

2 Adjust the position of the front
seat and the angle of the
seatback. (P.196)
Depending on the position of the front
seat, if the seatback is folded
back-ward, it may interfere with the
operation of the rear seat.

3 Lower the head restraint of the
rear seat. (P.200)
4 Stow the armrest of the rear
seat if it is pulled out. (P.552)
This step is not necessary when
oper-ating the left side seat only.

n Returning the rear seatbacks

To avoid trapping the seat belt
between the seat and the inside of
the vehicle, pass the seat belt outside the seat belt guide A and then
return the seatback securely to the
locked position.

4-3. Adjusting the seats

199

l Make sure that the seatback is

securely locked in position by lightly
pushing it back and forth. If the
seatback is not securely locked, the
red marking will be visible on the
seatback lock release lever. Make
sure that the red marking is not
visi-ble.

WARNING
n When folding the rear seatbacks

down
Observe the following precautions.
Failure to do so may result in death or
serious injury.

l Do not attempt to fold the

seatbacks down while driving.
set the parking brake and shift the
shift position to P.

l Do not allow anyone to sit on a

folded seatback or in the luggage
compartment while driving.

l Do not allow children to enter the
luggage compartment.

l Do not operate the rear seat if it is
occupied.

l Be careful not to get feet or hands

caught in the moving parts or joints
of the seats during operation.

l Do not allow children to operate the
seat.

n After returning the rear seatback

to the upright position
Observe the following precautions.
Failure to do so may result in death or
serious injury.

twisted or caught in the seatback.
4

Before driving

l Stop the vehicle on level ground,

l Check that the seat belts are not

200

4-3. Adjusting the seats

Head restraints

Push the head restraint down while

Head restraints are provided
for all seats.

n Rear center seat

pressing the lock release button A .

WARNING
n Head restraint precautions
Observe the following precautions
regarding the head restraints. Failure
to do so may result in death or serious
injury.
l Use the head restraints designed
for each respective seat.

l Adjust the head restraints to the
correct position at all times.

l After adjusting the head restraints,

push down on them and make sure
they are locked in position.

l Do not drive with the head
restraints removed.

1 Up
Pull the head restraints up.

2 Down
Push the head restraint down while
pressing the lock release button A .

n Rear outer seats

Head restraints cannot be adjusted.

l Make sure the rear outer seats

head restraints are locked by pushing them up and down before using
the head restraints.

n Adjusting the height of the head
restraints (front seats)

Adjusting a head restraint
vertically
n Front seats

Make sure that the head restraints are
adjusted so that the center of the head
restraint is closest to the top of your
ears.

n Adjusting the rear center seat head

restraints
Always raise the head restraint one level
from the stowed position when using.

1 Up
Pull the head restraints up.

2 Down

4-3. Adjusting the seats

Removing the head
restraints

201

position where the head
restraints can be removed.

n Front seats

Pull the head restraint up while
pressing the lock release button A .
If the head restraint touches the
ceiling, making the removal difficult,
change the seat height or angle.
(P.196)
2 Pull the head restraint up while
pressing the lock release button
.
4

Before driving

n Rear center seat

Pull the head restraint up while
pressing the lock release button A .

Installing the head restraints
n Front seats

Align the head restraint with the
installation holes and push it down
to the lock position.
Press and hold the lock release
n Rear outer seats

1 Pull the seatback lock release
lever A and fold down the
seatback until it reaches the

button A when lowering the head
restraint.

202

4-3. Adjusting the seats

sition where the head restraints
can be installed.

n Rear center seat

Align the head restraint with the
installation holes and push it down
to the lock position.
Press and hold the lock release
button A when lowering the head
restraint.

n Rear outer seats

1 Pull the seatback lock release
lever A and fold down the
seatback until it reaches thepo-

2 Align the head restraint with
installation holes and push it
down to the lock position.
