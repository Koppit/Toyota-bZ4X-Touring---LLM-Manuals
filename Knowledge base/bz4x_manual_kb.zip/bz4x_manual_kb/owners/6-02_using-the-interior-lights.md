# 6-2. Using the interior lights

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 6: Interior features, pages 528–530

528

6-2. Using the interior lights

Interior lights list

6-2.Using the interior lights

Location of the interior lights

A Outer foot lights (if equipped)
B Inside door handle lights
C Rear interior light (P.529)

Footwell lights
Front interior lights/personal lights (P.529)
Shift lights
Instrument panel ornament lights (P.530)
Center console light
Console box light
Door trim ornament lights
n Personal lights/interior lights automatic on/off

l Illuminated entry system: The lights

automatically turn on/off according to
power switch mode, the presence of

the electronic key, whether the doors
are locked/unlocked, and whether the
doors are opened/closed.

l If the interior lights remain on when

the power switch is turned off, the
lights will go off automatically after 20

6-2. Using the interior lights
minutes.

n Automatic illumination of the inte-

rior lights
If any of the SRS airbags deploy (inflate)
or in the event of a strong rear impact,
the interior lights will turn on automatically. The interior lights will turn off automatically after approximately 20
minutes.
The interior lights can be turned off manually. However, in order to help prevent
further collisions, it is recommended that
they be left on until safety can be
ensured. (The interior lights may not
turn on automatically depending on the
force of the impact and conditions of the
collision.)

529

1 Turns the door-linked function
off
2 Turns the door-linked functionon
(door position)
The lights turn on/off according to the
opening/closing of the doors.

3 Turns the lights on/off
Press the switch to turn on/off the front
interior lights/personal lights and rear
interior lights.

n Rear interior light

n Customization
Setting (e.g. the time elapsed before the
lights turn off) can be changed.
(Customizable features: P.688)

NOTICE
n To prevent 12-volt battery dis-

charge
Do not leave the lights on longer than
necessary when the EV system is off.

n Front interior lights

The light turns on/off according to the
opening/closing of the doors. The rear
interior light turn on/off together the
front interior light.

Operating personal lights
Turns the lights on/off

6

Interior features

Operating interior lights

1 Turns the light on
2 Turns the door-linked functionon
(door position)

530

6-2. Using the interior lights

Changing the illumination
color
Using the multimedia display, the
color and brightness of the interior
lights in the vehicle can be
changed.
 Inside door handle lights
 Instrument panel ornament lights
1 Select

.

2 Select “Vehicle customise”.
3 Select “Illumination”.
4 Select the desired color.
