# 5-2. Driving procedures

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 243–259

5-2. Driving procedures

Power (ignition) switch

5-2.Driving procedures

243

power switch mode.

Performing the following operations when carrying the electronic key on your person
starts the EV system or
changes power switch modes.

Starting the EV system
1 Check that the charging cable is
disconnected. (P.115, 120)
2 Pull the parking brake switch to
check that the parking brake is
set. (P.254)
The parking brake indicator will come
on.

3 Firmly depress the brake pedal.

5 Check that the “READY” indicator is illuminated.
The vehicle cannot be driven if the
“READY” indicator is off.

n Power switch illumination
In the following situations, the power
switch is illuminated.
l When the driver’s or passenger’s door
is opened.

changed from ACC or ON to off.
Also, in the following situation, the
power switch flashes.

4 Press the power switch shortly
and firmly.

n If the EV system does not start
l The immobilizer system may not have

ON.

l When the power switch mode is

l When depressing the brake pedal
while carrying the electronic key.

been deactivated. (P.83)
Contact any authorized Toyota retailer
or Toyota authorized repairer, or any
reliable repairer.

l The charging cable may be connected
to the vehicle. (P.112)

l If a message related to start-up is

shown on the multi-information display, read the message and follow the
instructions.

l The smart entry & start system may
not be operating properly. (P.192)

l If the door is unlocked with the

Driving

and a message will be displayed
on the multi-information display.
If it is not displayed, the EV system
cannot be started.
When the shift position is N, the EV
system cannot start. Shift the shift position to P when starting the EV system.
(P.248)

When operating the power switch, one
short, firm press is enough.
It is not necessary to press and hold the
switch.
If the “READY” indicator turns on, the
EV system will operate normally.
Continue depressing the brake pedal
until the “READY” indicator is illuminated.
The EV system can be started from any

5

l When the power switch is in ACC or

244

5-2. Driving procedures

mechanical key, the EV system cannot be started using the smart entry &
start system. Refer to P.657to start the
EV system. However, if the electronic
key is carried inside the vehicle and
the doors are locked (P.176), the EV
system can be started.

n When the ambient temperature is

low, such as during winter driving
conditions

l When the steering lock cannot be

released, “Push POWER Switch while
Turning the Steering Wheel in Either
Direction” will be displayed on the
multi-information display.
Check that the shift position is in P.
Press the power switch shortly and
firmly while turning the steering wheel
left and right.

l When starting the EV system, the

flashing time of the “READY” indicator
may be long. Leave the vehicle as it is
until the “READY” indicator is steady
on, as steady means the vehicle is
able to move.

l When the traction battery is extremely

cold (below approximately -30°C
[-22°F]) under the influence of the outside temperature, it may not be possible to start the EV system. In this
case, try to start the EV system again
after the temperature of the traction
battery increases due to the outside
temperature increase, etc.

n Sounds and vibrations specific to

an electric vehicle
P.92

n If the 12-volt battery is discharged
The EV system cannot be started using
the smart entry & start system. Refer to
P.659 to restart the EV system.
n Electronic key battery depletion
P.168
n Conditions affecting operation
P.192
n Note for the entry function
P.193
n Steering lock function (for

right-hand drive vehicles only)

l After turning the power switch off and
opening and closing the doors, the
steering wheel will be locked due to
the steering lock function. Operating
the power switch again automatically
cancels the steering lock.

l To prevent the steering lock motor

from overheating, operation of the
motor may be suspended if the EV
system is turned on and off repeatedly
in a short period of time. In this case,
refrain from operating the EV system.
After about 10 seconds, the steering
lock motor will resume functioning.

n If the “READY” indicator does not

come on
In the event that the “READY” indicator
does not come on even after performing
the proper procedures for starting the
vehicle, contact any authorized Toyota
retailer or Toyota authorized repairer, or
any reliable repairer immediately.

n If the EV system is malfunctioning
P.98
n Electronic key battery
P.604
n Operation of the power switch
l If the switch is not pressed shortly and

firmly, the power switch mode may not
change or the EV system may not
start.

l If attempting to restart the EV system
immediately after turning the power
switch off, the EV system may not
start in some cases. After turning the
power switch off, please wait a few

5-2. Driving procedures
seconds before restarting the EV system.

245

Stopping the EV system

n Customization

1 Stop the vehicle completely.

If the smart entry & start system has
been deactivated in a customized setting, refer to P.656.

2 Set the parking brake. (P.254)

WARNING
n When starting the EV system
Always start the EV system while sitting in the driver’s seat. Do not
depress the accelerator pedal while
starting the EV system under any circumstances.
Doing so may cause an accident
resulting in death or serious injury.

n Caution while driving (vehicles

NOTICE
n When starting the EV system
If the EV system becomes difficult to
start, have your vehicle checked by
any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer immediately.
n Symptoms indicating a malfunc-

tion with the power switch
If the power switch seems to be operating somewhat differently than usual,
such as the switch sticking slightly,
there may be a malfunction. Contact
any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer immediately.

Check that the shift position indicator
shows P and the parking brake indicator is illuminated.

4 Press the power switch.
The EV system will stop, and the meter
display will be extinguished (the shift
position indicator will be extinguished a
few seconds after the meter display).

5 Release the brake pedal and
check that “ACCESSORY” or
“POWER ON” is not shown on
the meter.
5

n When the shift control system mal-

functions
If the shift control system is malfunctioning, when attempting to turn the power
switch off, it may not be able to be
turned off. In this situation, it may be
possible to turn the power switch off by
applying the parking brake and then
operating the power switch.
If there is a malfunction in the system,
have the vehicle inspected by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer immediately.

n Automatic P position selection

function
P.250

Driving

with steering lock function)
If EV system failure occurs while the
vehicle is moving, do not lock or open
the doors until the vehicle reaches a
safe and complete stop. Otherwise,
the steering lock function will activate
and this may lead to an accident,
resulting in death or serious injury.

3 Press the P position switch.
(P.248)

246

5-2. Driving procedures

WARNING
n Stopping the EV system in an
emergency

l If you want to stop the EV system in
an emergency while driving the
vehicle, press and hold the power
switch for more than 2 seconds, or
press it briefly 3 times or more in
succession. (P.610)
However, do not touch the power
switch while driving except in an
emergency. Turning the EV system
off while driving will not cause loss
of steering or braking control, however, power assist to the steering
will be lost. This will make it more
difficult to steer smoothly, so you
should pull over and stop the vehicle as soon as it is safe to do so.

l If the power switch is operated

while the vehicle is running, a warning message will be shown on the
multi-information display and a
buzzer sounds.

l When restarting the EV system

after an emergency shutdown,
press the power switch shortly and
firmly.

Changing power switch
modes
Modes can be changed by pressing
the power switch with the brake
pedal released. (The mode
changes each time the switch is
pressed.)

A “ACCESSORY”
B “POWER ON”

1 OFF
The emergency flashers can be used.

2 ACC*
Some electrical components such as
the audio system can be used.
“ACCESSORY” will be displayed on the
meter.

3 ON
All electrical components can be used.
“POWER ON” will be displayed on the
multi-information display.
*: ACC mode can be enabled/disabled

on the customize menu. (P.680)

n When ACC customization is in off
l With the power switch is turned off,

the multimedia system can still be
used for a certain time until the battery
saving function starts operating.

l When the safe exit assist is operating,
a buzzer will sound and a voice guidance will be given.

n Auto power off function
If the vehicle is left in ACC for more than
20 minutes or ON (the EV system is not
operating) for more than 20 minutes with

5-2. Driving procedures
the shift position in P, the power switch
will automatically turn off. However, this
function cannot entirely prevent the
12-volt battery discharge. Do not leave
the vehicle with the power switch in ACC
or ON for long periods of time when the
EV system is not operating.

NOTICE
n To prevent 12-volt battery discharge

l Do not leave the power switch in

247

Shift position
Select the shift position
depending on your purpose
and situation.

Shift position purpose and
functions

ACC or ON for long periods of time
without the EV system on.

Shift position

Objective or function

l If “ACCESSORY” or “POWER ON”

P

Parking the vehicle/starting the EV system

R

Reversing

N

Neutral
(Condition in which the
power is not transmitted)

is displayed on the multi-information display while the EV system is
not operating, the power switch is
not OFF. Exit the vehicle after turning the power switch off.

D

Normal driving

(Drive-Start Control)
P.234

n If a message about a shift operation

is shown
To prevent the shift position from being
selected incorrectly or the vehicle from
moving unexpectedly, the shift position
may be changed automatically or operating the shifting operation may be
required. In this case, change the shift
position following the messages on the
multi-information display.

n After recharging/reconnecting the

Driving

n Restraining sudden start

12-volt battery
P.661

5

248

5-2. Driving procedures

WARNING
n When driving on slippery road

surfaces
Be careful of sudden acceleration, as
this could result in the vehicle skidding to the side or spinning.

Shift position display and
how to change the shift
position

NOTICE
n Situations where shift control

system malfunctions are possible
If any of the following situations
occurs, shift control system malfunctions are possible. Immediately stop
the vehicle in a safe place on level
ground, apply the parking brake, and
then contact any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer.
l When the warning message indicating the shift control system appears
on the multi-information display.
(P.627)

l The display indicates that no shift

position is selected for more than a
few seconds.

A Rotary shifter
Operate the rotary shifter slowly and
securely.
To switch to N, hold down the rotary
shifter and hold it for a while.
To switch to R or D, hold down the
rotary shifter and turn left or right
according to the arrow on the shift position indicator.
Release the rotary shifter after each
shifting operation to allow it to return to
its regular position.
When shifting from P to N, D or R, from
N, D or R to P, from D to R, or from R to
D, ensure that the brake pedal is being
depressed and the vehicle is stationary.

B Shift position indicator
Meter display:
The current shift position is illuminated.

5-2. Driving procedures
Rotary shifter display:
The current shift position is illuminated.
When selecting the shift position, make
sure that the shift position has been
changed to the desired position by
checking the shift position indicator provided on the instrument cluster.

C P position switch
Fully stop the vehicle and set the parking brake, and then press the P position
switch.
When the shift position is changed to P,
the switch illuminates.
Check that the shift position indicator
shows P.

n Changing the shift position in each
power switch mode

l The shift position cannot be changed

249

been changed to the desired position
by checking the shift position indicator
provided on the instrument cluster.

n The shift position cannot be

changed when
In the following situations, a buzzer will
sound to inform you that the shift position cannot be changed. Use the appropriate operation to attempt to change
the shift position again.

l When attempting to change the shift
position from P with the brake pedal
not depressed

l When attempting to change the shift
position from P with the accelerator
pedal depressed

l When attempting to change the shift

position from N while stopped or driving at an extremely low speed with the
brake pedal not depressed

l When attempting to change the shift

position from N while stopped or driving at an extremely low speed with the
accelerator pedal depressed

l When the power switch is in ON, if the

l When the P position switch is pressed

l When the “READY” indicator is illumi-

When driving at an extremely low
speed, the shift position may change to
P.

“READY” indicator is not illuminated,
the shift position can only be changed
to N.
nated, the shift position can be
changed from P to D, N, or R.

l When the “READY” indicator is flash-

ing, the shift position cannot be
changed from P to any other position,
even if the rotary shifter is operated.
Operate the rotary shifter again after
the “READY” indicator changes from
flashing to illuminated.

n Shifting the shift position from P to
other positions

l While depressing the brake pedal

firmly, operate the rotary shifter. If the
rotary shifter is operated without
depressing the brake pedal, the
buzzer will sound and the shifting
operation will be disabled.

l When selecting the shift position,

make sure that the shift position has

while driving

n The shift position automatically

changes to N when
In the following situations, a buzzer will
sound to inform you that the shift position has been changed to N. Use the
appropriate operation to attempt to
change the shift position again.

l When attempting to change the shift

position to R while the vehicle is moving forward
When driving at a low speed, the shift
position may change to R.

l When attempting to change the shift

position to D while the vehicle is moving backward
When driving at a low speed, the shift
position may change to D.

5

Driving

when the power switch is in ACC or
off.

250

5-2. Driving procedures

n If the N shift position is selected

while driving
If the rotary shifter is moved to N while
driving above a certain speed, the shift
position will change to N without holding
the rotary shifter in the N position. In this
situation, a buzzer will sound and a
message will be displayed on the
multi-information display to inform you
that the shift position has been changed
to N.

n Reverse warning buzzer
When shifting into R, a buzzer will sound
to inform the driver that the shift position
is in R.
n Automatic P position selection

function
In the following situations, the shift position is automatically changed to P.

l When pressing the power switch with
the vehicle stopped while the power
switch is in ON and the shift position is
in a position other than P (after the
shift position has changed to P, the
power switch will turn off)*

l If the driver’s door is opened and all of

the following conditions are met, while
the shift position is in a position other
than P:
• The power switch is in ON.
• The driver is not wearing the seat belt.
• The brake pedal is not depressed.
To start off the vehicle after the shift
position is changed to P, operate the
rotary shifter again.

l When the vehicle is stopped after the
EV system has been stopped in an
emergency while driving.

l When voltage of the 12-volt battery

drops while the shift position is in a
position other than P.
*: When the power switch is pressed
while driving at extremely slow
speeds, such as immediately before
stopping the vehicle, the shift position
may automatically change to P. Make
sure that the vehicle is completely

stopped before pressing the power
switch.

n If the shift position cannot be

shifted from P
There is a possibility that the 12-volt battery is discharged. Check the 12-volt
battery in this situation. (P.658)

n Customization
Some functions can be customized.
(P.680)

WARNING
n For the rotary shifter
l Do not remove the rotary shifter

knob or use anything but a genuine
Toyota rotary shifter knob. Also, do
not hang anything on the rotary
shifter. Doing so could prevent the
rotary shifter from returning to position, causing unexpected accidents
to occur when the vehicle is in
motion.

l In order to prevent the shift position

from accidentally being changed,
do not touch the rotary shifter when
not using them.

n P position switch
l Do not press the P position switch

while the vehicle is moving.
If the P position switch is pressed
when driving at very low speeds (for
example, directly before stopping
the vehicle), the vehicle may stop
suddenly when the shift position
switches to P, which could lead to
an accident.

l In order to prevent the shift position
from accidentally being changed,
do not touch the P position switch
when not using them.

5-2. Driving procedures

NOTICE
n When exiting the vehicle (driver’s

seat only)
Check that the shift position indicator
shows P and that the parking brake
indicator is illuminated before opening
the door and exiting the vehicle.

Keeping the shift position in
N without activating the
automatic P position
selection function
 By performing the following operation, the shift position can be
held in N until the shift position
switches to P without activating
the automatic P position
selection function.
1 Stop the vehicle completely.

3 Press and hold the parking
brake switch until a message is
shown on the multi-information
display. (Turn automatic mode
off)
4 Operate the rotary shifter and
change the shift position to N
when the EV system is operating.
5 Return the rotary shifter to its
regular position.
6 Operate the rotary shifter to N
and hold it there until the buzzer
sounds.

7 Press the power switch within 5
seconds after the buzzer
sounds.
The EV system stops with the shift
position in N*.
Make sure to check that the buzzer
sounds and “Holding N Push P Switch
When Done” is displayed on the
multi-information display.

 In order to shift to a position
other than N, first press the P
position switch to change the
shift position to P.
*: To keep this state, do not operate the

power switch. If the power switch is
operated repeatedly, the power
switch will turn off after the shift position has automatically changed to P.

Selecting the drive mode
n Snow mode (2WD models)

P.497
n “X-MODE” (AWD models)

P.497

Selecting Eco mode
It is suited for driving that suppress
vehicle driving power and improves
electricity consumption.
Press the switch to switch over to
Eco mode.
Press the switch again to return to
Normal driving mode.
The Eco mode ON state is memorized even if the power switch is
turned off.

5

Driving

2 Turn off the brake hold system.
(P.257)

251

252

5-2. Driving procedures

becomes strong as the number of
the arrows

of

(regener-

ative braking power indicator) on
the multi-information display
increases.

n Eco mode drive automatic cancel-

lation
Eco mode is automatically canceled
when snow mode or “X-MODE” is
selected and the vehicle returns to normal mode. (if equipped)

n When Eco mode is not available
Eco mode cannot be activated when
“X-MODE” is selected. (if equipped)

How to operation the regenerative braking force
selection mode
By setting the shift position to D
and operating the paddle shift
switches, the vehicle can drive with
the regenerative braking force fixed
when the accelerator pedal is
released.
Regenerative braking force can be
selected among 4 levels:
By operating the “-” side of the paddle shift switch, the regenerative
braking force can be made stronger
than the current one.
By operating the “+” side of the
paddle shift switch, the regenerative braking force can be made
weaker than the current one.
The regenerative braking power

A Paddle shift switch “-”
B Paddle shift switch “+”
C Indicator
n How to cancel the regenerative

braking force selection mode
In the following conditions, the regenerative braking force selection mode is
canceled.

l The shift position is shifted to a position other than D

l The “+” paddle shift switch is pressed
and held

l When “X-MODE” is activated (If
equipped)

n Using regenerative brake
l When driving at a high speed, the

feeling of deceleration with regenerative braking is less than that on conventional vehicles.

l If “Regenerative Braking Limited

Press Brake to Decelerate” appears
on the multi-information display, firmly
depress the brake pedal to decelerate
the vehicle.

5-2. Driving procedures

Turn signal lever
Operating instructions

253

n If the turn signals stop flashing

before a lane change has been performed
Operate the lever again.

5

The right hand signals will flash 3 times.

3 Lane change to the left (move
the lever partway and release it)
The left hand signals will flash 3 times.

4 Left turn
n Turn signals can be operated when
The power switch is in ON.
n If the indicator flashes faster than

usual
Have the vehicle inspected by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

Driving

1 Right turn
2 Lane change to the right (move
the lever partway and release it)

254

5-2. Driving procedures

Parking brake
The parking brake can be set
or released automatically or
manually.
In automatic mode, the parking
brake can be set or released
automatically.
Also, even in automatic mode,
the parking brake can be set or
released manually.

Operating instructions
n Using the manual mode

The parking brake can be set and
released manually.

driving.

2 Press the switch to release the
parking brake.
• Operate the parking brake switch
while depressing the brake pedal.
• Using the parking brake automatic
release function, the parking brake
can be released by depressing the
accelerator pedal. When using this
function, slowly depress the accelerator pedal. (P.255)
Make sure that the parking brake indicator light turn off.
If the parking brake indicator light flash,
operate the switch again. (P.625)

n Turning the automatic mode

on
While the vehicle is stopped, pull
and hold the parking brake switch
until a buzzer sounds and a message is shown on the multi-information display.
When the automatic mode is turned
on, the parking brake operates as
follows.
 When the shift position is shifted
from P, the parking brake will be
released, and the parking brake
indicator light will turn off.

A Parking brake indicator light

1 Pull the switch to set the parking
brake.
The parking brake indicator light will
turn on.
Pull and hold the parking brake switch if
an emergency occurs and it is necessary to operate the parking brake while

 When the shift position is shifted
to P, the parking brake will be
set, and the parking brake indicator light will turn on.
Operate the shift position and P
position switch with the vehicle
stopped and the brake pedal
depressed.
The auto function may not operate if the
shift position is moved extremely

5-2. Driving procedures

255

quickly or the brake pedal is not firmly
depressed. In this situation, apply the
parking brake manually. (P.254)

l Automatic mode ON
l The brake system warning light (Yel-

n Turning the automatic mode

n Parking brake automatic lock func-

off
While the vehicle is stopped and
depressing the brake pedal, press
and hold the parking brake switch
until a buzzer sounds and a message is shown on the multi-information display.

low) are not illuminated

tion when exiting the vehicle
The parking brake will be set automatically under the following conditions:

l The brake pedal is not depressed
l The driver’s door is open
l The driver’s seat belt is not fastened
l The brake system warning light (Yellow) are not illuminated

n When the parking brake is not auto-

n Parking brake operation
l When the power switch is not in ON,

the parking brake cannot be released
using the parking brake switch.

l When the power switch is not in ON,

automatic mode (automatic brake setting and releasing) is not available.

n Parking brake automatic release

l The driver’s door is closed
l The driver is wearing the seat belt
l The shift position is in a forward driv-

ing position or reverse driving position

l The brake system warning light (Yel-

low) is not illuminated.
When depressing the accelerator pedal,
depress it slowly.
If the parking brake is not released when
the accelerator pedal is depressed,
release the parking brake manually.
When the shift position is shifted from P,
the parking brake will be released automatically.

n Parking brake automatic lock func-

tion when EV system is off
The parking brake will be set automatically under the following conditions:

l The EV system is off

l The shift position other than N
l The parking brake switch is pulled
l The EV system is turned off and then
started again

5

Driving

function
When all of the following conditions are
met, the parking brake can be released
by depressing the accelerator pedal.

matically set in the shift position N,
such as when using car wash.
“Parking brake automatic lock function
when exiting the vehicle” will be disabled by doing the following:
1 Stop the vehicle.
2 Turn off the brake hold system.
3 Press and hold the parking brake
switch until a buzzer sounds and a
message is shown on the multi-information display.
4 The shift position to N
5 Press and hold the parking brake
switch until a buzzer sounds and a
message is shown on the multi-information display.
The parking brake indicator light will
flash.
6 Disable the automatic P position
selection function. Refer to P.251
When any of the following conditions are
met, the vehicle will return to automatic
mode ON.
The parking brake indicator light will turn
off or light up.

256

5-2. Driving procedures

n If “Parking Brake Temporarily Una-

vailable” is displayed on the
multi-information display
If the parking brake is operated repeatedly over a short period of time, the system may restrict operation to prevent
overheating. If this happens, refrain from
operating the parking brake. Normal
operation will return after about 1 minute.

n If “Parking Brake Unavailable” is

displayed on the multi-information
display
Operate the parking brake switch. If the
message does not disappear after operating the switch several times, the system may be malfunctioning. Have the
vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

n Parking brake operation sound
When the parking brake operates, a
motor sound (whirring sound) may be
heard. This does not indicate a malfunction.
n Parking brake indicator light
l Depending on the power switch mode,
the parking brake indicator light will
turn on and stay on as described
below:
ON: Comes on until the parking brake
is released.
Not in ON: Stays on for approximately
15 seconds.

l When the power switch is turned off

with the parking brake set, the parking
brake indicator light will stay on for
about 15 seconds. This does not indicate a malfunction.

n When the parking brake switch

malfunctions
Automatic mode (automatic brake setting and releasing) will be turned on
automatically.

n Parking the vehicle
P.229

n Parking brake engaged warning

buzzer
A buzzer will sound if the vehicle is
driven with the parking brake engaged.
“Parking Brake ON” is displayed on the
multi-information display (with the vehicle reaching a speed of 5 km/h [3 mph]).

n If the brake system warning light

(Yellow) comes on
P.619

n Usage in winter time
P.509

WARNING
n When parking the vehicle
Do not leave a child in the vehicle
alone. The parking brake may be
released unintentionally by a child
and there is the danger of the vehicle
moving that may lead to an accident
resulting in death or serious injury.
n Parking brake switch
Do not set any objects near the parking brake switch. Objects may interfere with the switch and may lead the
parking brake to unexpectedly operate.
n Parking brake automatic lock

function
Never use the automatic parking
brake engagement function in place
of normal parking brake operation.
This function is designed to reduce
the risk of a collision due to the driver
forgetting to engage the parking
brake. Over-reliance on this function
to park the vehicle safely may lead to
an accident resulting in death or serious injury.

5-2. Driving procedures

NOTICE
n When parking the vehicle
Before you leave the vehicle, shift the
shift position to P, set the parking
brake and make sure that the vehicle
does not move.
n When the system malfunctions
Stop the vehicle in a safe place and
check the warning messages.
n When the vehicle 12-volt battery

is discharged
The parking brake system cannot be
activated. (P.658)

n When the parking brake cannot

Brake Hold
The brake hold system keeps
the brake applied when the
shift position is in D, N or P
with the system on and the
brake pedal has been
depressed to stop the vehicle.
The system releases the brake
when the accelerator pedal is
depressed with the shift position in D to allow smooth start
off.

Enabling the system
Turns the brake hold system on
The brake hold standby indicator
(green)
comes on. While the system
is holding the brake, the brake hold
operated indicator (yellow)
on.

comes

n Brake hold system operating con-

ditions
The brake hold system cannot be turned
on in the following conditions:

l The driver’s door is not closed.
l The driver is not wearing the seat belt.
l “Parking Brake Unavailable” or “Parking Brake Malfunction Visit Your

5

Driving

be released due to a malfunction
Driving the vehicle with the parking
brake set will lead to brake components overheating, which may affect
braking performance and increase
brake wear. Have the vehicle
inspected by any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer immediately if
this occurs.

257

258

5-2. Driving procedures

Dealer” is displayed on the multi-information display.
If any of the conditions above are
detected when the brake hold system is
enabled, the system will turn off and the
brake hold standby indicator light will go
off. In addition, if any of the conditions
are detected while the system is holding
the brake, a warning buzzer will sound
and a message will be shown on the
multi-information display. The parking
brake will then be set automatically.

n Brake hold function
l If the brake pedal is left released for a

period of about 3 minutes after the
system has started holding the brake,
the parking brake will be set automatically. In this case, a warning buzzer
sounds and a message is shown on
the multi-information display.

l To turn the system off while the system is holding the brake, firmly
depress the brake pedal and press
the button again.

l The brake hold function may not hold

the vehicle when the vehicle is on a
steep incline. In this situation, it may
be necessary for the driver to apply
the brakes. A warning buzzer will
sound and the multi-information display will inform the driver of this situation. If a warning message is shown
on the multi-information display, read
the message and follow the instructions.

l When do not wish for the parking

brake to operate automatically, press
and hold the brake hold switch until
the standby indicator (green) turns off,
and then turn the power switch off.

n When the parking brake is set auto-

matically while the system is holding the brakes
Perform any of the following operations
to release the parking brake.

l Depress the accelerator pedal. (The

parking brake will not be released
automatically if the seat belt is not fastened.)

l Operate the parking brake switch with

the brake pedal depressed.
Make sure that the parking brake indicator light goes off. (P.254)

n When an inspection at any author-

ized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer is necessary
When the brake hold standby indicator
(green) does not illuminate even when
the brake hold switch is pressed with the
brake hold system operating conditions
met, the system may be malfunctioning.
Have the vehicle inspected at any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

n If “Brake Hold Malfunction Press

Brake to Deactivate Visit Your
Dealer” or “Brake Hold Malfunction
Visit Your Dealer” is displayed on
the multi-information display
The system may be malfunctioning.
Have the vehicle inspected by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer immediately.

n Warning messages and buzzers
Warning messages and buzzers are
used to indicate a system malfunction or
to inform the driver of the need for caution. If a warning message is shown on
the multi-information display, read the
message and follow the instructions.
n If the brake hold operated indicator

flashes
P.625

WARNING
n When the vehicle is on a steep

incline
Take care when using the brake hold
system on a steep incline, exercise
caution. The brake hold function may
not hold brakes in such situations.
Also, the system may not activate
depending on the angle of the slope.

5-2. Driving procedures

259

WARNING
n When stopped on a slippery road
The system cannot stop the vehicle
when the gripping ability of the tires
has been exceeded. Do not use the
system when stopped on a slippery
road.

NOTICE
n When parking the vehicle
The brake hold system is not
designed for use when parking the
vehicle for a long period of time. Turning the power switch off while the system is holding the brake may release
the brake, which would cause the
vehicle to move. When operating the
power switch, depress the brake
pedal, shift the shift position to P and
set the parking brake.
5

Driving
