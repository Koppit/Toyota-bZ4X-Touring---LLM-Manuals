# 5-4. Using the driving support systems (part 1: Toyota Safety Sense software update, …)

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 276–303
> Topics in this part: Toyota Safety Sense software update; Toyota Safety Sense; Driver monitor; PCS (Pre-Collision System); LTA (Lane Tracing Assist)

276

5-4. Using the driving support systems

Toyota Safety Sense
software update*

5-4.Using the driving support systems

*: If equipped

It is necessary to enter a connected services contract, provided by Toyota, to use these
functions. For details, contact
any authorized Toyota retailer
or Toyota authorized repairer,
or any reliable repairer.
WARNING
n For safe use
When the Toyota Safety Sense software is updated, the operating methods of functions may change. Using
this system without knowing the correct operating methods may lead to
an accident resulting in death or serious injury.

l Make sure to read the Digital

Owner’s Manual which corresponds
to the software version of the system, available at the Owner’s Manual website, before using this
system.

Content of the Toyota Safety
Sense Owner’s Manual
This Owner’s Manual contains
information for Ver. 3. For the latest
information about the controls, use,
warnings/precautions, etc. of each
function of Toyota Safety Sense,

refer to the Digital Owner’s Manual
at the Owner’s Manual website.
Before using this system, be sure to
read the Owner’s Manual which
corresponds to the software version
of the system.
n Precautions for use
l Be aware that some functions may

temporarily be disabled if a legal or
safety related issue occurs.

l If a connected services contract has

not been entered or has expired, software updates will not be able to be
performed wirelessly.

Checking your vehicle’s
Toyota Safety Sense version
To access the appropriate Owner’s
Manual, it is necessary to check the
software version of the system and
then visit the Owner’s Manual
website.
Checking the current software version on the multimedia display* or smartphone
The current software version can
be checked from the driving assist
function update notification.
*: The display may not appear depend-

ing on the type of multimedia display.

Selecting your vehicle’s Toyota Safety Sense version
1 Access the following URL using a computer or smartphone:

5-4. Using the driving support systems

Language

URL

277

QR code

English

https://www.toyota-europe.com/manual?
parameter=om9ad75e.bz4x-touring.2601.bev.vh

French

https://www.toyota-europe.com/manual?
parameter=om42j95k.bz4x-touring.2601.bev.vh

Spanish

https://www.toyota-europe.com/manual?
parameter=om9ad77s.bz4x-touring.2601.bev.vh

Russian

https://www.toyota-europe.com/manual?
parameter=om42j99r.bz4x-touring.2601.bev.vh

2 Select the file which includes the previously checked system version.

If a software update is available, a
notification will be displayed on the
multimedia display. Follow the
instructions displayed on the
screen.
When the software is updated, the
way functions are used may
change and functions may be
added.
For details about changes or additions, check the Owner’s Manual
website.
n Software update precautions
l After a software update has been performed, it will not be possible to revert
to a previous version.

l Depending on the communication

environment and the content of an
update, a software update may take
several hours. Although an update will
be suspended when the power switch
is turned off, it will resume when the
power switch is changed back to ON.

l Toyota Safety Sense can still be used
while a software update is being performed.

l In the following situations, a software

update may be performed automatically:
• When a possible system issue or
other safety related issue is corrected*
• When a legal issue is corrected*
• When small corrections which do not
affect system operation or performance are made
*: All available updates may be installed
and the software updated to the most
current version.

Driving

Updating the software

5

278

5-4. Using the driving support systems

Toyota Safety Sense*

n Checking the driving assist func-

tion update notification
The following items can be checked or
performed.

l Software version, update details, precautions, use methods, etc.

l A link to display the software update
history

l Software update

*

: If equipped

The Toyota Safety Sense consists of the driving assist systems and contributes to a safe
and comfortable driving experience:
WARNING
n Toyota Safety Sense
The Toyota Safety Sense operates
under the assumption that the driver
will drive safely, and is designed to
help reduce the impact to the occupants in a collision and assist the
driver under normal driving conditions.
As there is a limit to the degree of recognition accuracy and control performance that this system can provide,
do not overly rely on this system. The
driver is solely responsible for paying
attention to the vehicle’s surroundings
and driving safely.
n For safe use
l Do not overly rely on this system.

The driver is solely responsible for
paying attention to the vehicle’s
surroundings and driving safely.
This system may not operate in all
situations and provided assistance
is limited. Over-reliance on this system to drive the vehicle safely may
lead to an accident resulting in
death or serious injury.

l Do not attempt to test the operation

of the system, as it may not operate
properly, possibly leading to an
accident.

5-4. Using the driving support systems

WARNING
l If attention is necessary while per-

forming driving operations or a system malfunction occurs, a warning
message or warning buzzer will be
operated. If a warning message is
displayed on the display, follow the
instructions displayed.

l Depending on external noise, the

volume of the audio system, etc. it
may be difficult to hear the warning
buzzer. Also, depending on the
road conditions, it may be difficult to
recognize the operation of the system.

n When it is necessary to disable

the system
In the following situations, make sure
to disable the system.
Failure to do so may lead to the system not operating properly, possibly
leading to an accident resulting in
death or serious injury.
being overloaded or having a flat
tire

l When driving at extremely high
speeds

l When a sensor is misaligned or

deformed due to a strong impact
being applied to the sensor or the
area around the sensor

l When accessories which obstruct a
sensor or light are temporarily
installed to the vehicle

l When a compact spare tire or tire

chains are installed to the vehicle or
an emergency tire puncture repair
kit has been used

l When the tires are excessively

worn or the inflation pressure of the
tires is low

l When tires other than the manufacturer specified size are installed

l When the vehicle cannot be driven
stably, due to a collision, malfunction, etc.

Driving assist systems
n AHS (Adaptive High-beam

System)
P.264
n AHB (Automatic High Beam)

l When towing another vehicle

P.268

l When the vehicle is being trans-

n PCS (Pre-Collision System)

ported by a truck, ship, train, etc.

l When the vehicle is raised on a lift
and the tires are allowed to rotate
freely

l When inspecting the vehicle using

a drum tester such as a chassis
dynamometer or speedometer
tester, or when using an on vehicle
wheel balancer

l When the vehicle is driven in a
sporty manner or off-road

l When using an automatic car wash

P.288
n LTA (Lane Tracing Assist)

P.299
n LDA (Lane Departure Alert)

P.307
n LCA (Lane Change Assist)*

P.304
*: If equipped

5

Driving

l When the vehicle is tilted due to

279

280

5-4. Using the driving support systems

n FCTA (Front Crossing Traffic

Alert)*
P.317
*

n Sensors which detect the sur-

rounding conditions
 Front

: If equipped

n PDA (Proactive driving assist)*

P.312
*: If equipped

n RSA (Road Sign Assist)*

P.320
*: If equipped

n Dynamic radar cruise control

A Front radar sensor

P.324

B Front camera

n Cruise control

C Front side radar sensors*

P.335

*: If equipped

n Speed limiter*

 Rear

P.343
*: If equipped

n Emergency Driving Stop Sys-

tem
P.346
n Driver monitor*

P.286
*

: If equipped

A Rear side radar sensors*
*: If equipped

Sensors used by Toyota
Safety Sense
Various sensors are used to obtain
the necessary information for system operation.

5-4. Using the driving support systems

n Sensors which detect the

driver condition

A Driver monitor camera*
*: If equipped

WARNING
n To prevent malfunction of the

281

l Vehicles with front side radar sen-

sors: Keep the surrounding area of
the front side radar sensors on the
front bumper clean at all times.

l Do not attach accessories, stickers

(including transparent stickers), aluminum tape, etc. to a radar sensor
or radar sensor cover and their surrounding area.

l Do not subject a radar sensor or its

surrounding area to impact.
If a radar sensor, the front grille, or
front bumper has been subjected to
a impact, have the vehicle
inspected by any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.

l Keep the radar sensors and radar

l Do not disassemble the radar sen-

sensor covers clean at all times.
Clean the front of a radar sensor or
the front or back of a radar sensor
cover if it is dirty or covered with water
droplets, snow, etc.
When cleaning the radar sensor and
radar sensor cover, use a soft cloth to
remove dirt so as to not damage
them.

sors.

l Do not modify or paint the radar

sensors or radar sensor cover, or
replace them with anything other
than Toyota genuine parts.

l In the following situations, recalibra-

tion of the radar sensors will be
necessary. For details, contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.
• When a radar sensor is removed
and installed, or replaced
• When the front bumper or the front
grille has been replaced

A Radar sensor
B Radar sensor cover

5

Driving

radar sensors
Observe the following precautions.
Failure to do so may lead to a radar
sensor not operating properly, possibly leading to an accident resulting in
death or serious injury.

282

5-4. Using the driving support systems

WARNING
n To prevent malfunction of the

front camera
Observe the following precautions.
Failure to do so may lead to the front
camera not operating properly, possibly leading to an accident resulting in
death or serious injury.

l Always keep the windshield clean.
• If the windshield is dirty or covered
with an oily film, water droplets,
snow, etc., clean the windshield.
• Even if a glass coating agent is
applied to the windshield, it will still
be necessary to use the windshield
wipers to remove water droplets,
etc. from the area of the windshield
in front of the front camera.
• If the inner side of the windshield
where the front camera is installed
is dirty, contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

l Do not attach stickers (including

transparent stickers) or other items
to the area of the windshield in front
of the front camera (shaded area in
the illustration).

l If water droplets cannot be properly

removed from the area of the windshield in front of the front camera by
the windshield wipers, replace the
wiper insert or wiper blade.

l Do not attach window tint to the
windshield.

l Replace the windshield if it is dam-

aged or cracked.
If the windshield has been
replaced, recalibration of the front
camera will be necessary. For
details, contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

l Do not allow liquids to contact the
front camera.

l Do not allow bright lights to shine
into the front camera.

l Do not damage the lens of the front
camera or allow it to become dirty.
When cleaning the inside of the
windshield, do not allow glass
cleaner to contact the lens of the
front camera. Do not touch the lens
of the front camera.
If the lens of the front camera is
dirty or damaged, contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

l Do not subject the front camera to a
strong impact.

l Do not change the position or orientation of the front camera or remove
it.

A Approximately 4 cm (1.6 in.)
B Approximately 4 cm (1.6 in.)
l If the part of the windshield in front
of the front camera is fogged up or
covered with condensation or ice,
use the windshield defogger to
remove the fog, condensation, or
ice.

l Do not disassemble the front camera.

l Do not modify any parts around the
front camera, such as the inside
rear view mirror or ceiling.

5-4. Using the driving support systems

WARNING
l Do not attach accessories which

may obstruct the front camera to
the hood, front grille, or front
bumper. For details, contact any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

l If a surfboard or other long object is
to be mounted on the roof, make
sure that it will not obstruct the front
camera.

l Do not modify or change the headlights and other lights.

n Front camera installation area on

n Precautions for the driver moni-

tor camera (if equipped)
Observe the following precautions.
Failure to do so may lead to malfunction of the driver monitor camera and
the systems not operating properly,
possibly leading to an accident resulting in death or serious injury.

l Do not subject the driver monitor

camera or its surrounding area to
strong impact.
If subjected to a strong impact, the
driver monitor camera may move out
of alignment and the driver may no
longer be detected correctly. In this
case, have the vehicle inspected by
any authorized Toyota retailer or
Toyota authorized repairer, or any reliable repairer.

l Do not disassemble or modify the
driver monitor camera.

l Do not attach accessories, stickers

(including transparent stickers), etc.
to the driver monitor camera or its
surrounding area.

l Do not allow the driver monitor

camera or its surrounding area to
get wet.

l Do not cover the driver monitor

camera or place anything in front of
it.

l Keep the lens of the driver monitor
camera free from damage.

l Do not touch the lens of the driver

monitor camera or allow it to
become dirty.
When there is dirt or fingerprints on
the camera lens, clean it with a dry,
soft cloth so as to not mark or damage it.

l When cleaning the lens, do not use
detergents or organic solvents that
may damage plastic.

5

n Situations in which the sensors

Driving

the windshield
If the system determines that the
windshield may be fogged up, it will
automatically operate the heater to
defog the part of the windshield
around the front camera. When cleaning, etc., be careful not to touch the
area around the front camera until the
windshield has cooled sufficiently, as
touching it may cause burns.

283

and the systems may not operate
properly

l When the height or inclination of the
vehicle has been changed due to
modifications

l When the windshield is dirty, fogged
up, cracked or damaged

l When the ambient temperature is high
or low

l When mud, water, snow, dead

insects, foreign matter, etc., is
attached to the front of the sensor

l When in inclement weather such as

heavy rain, fog, snow, or a sandstorm

l When water, snow, dust, etc. is thrown

up in front of the vehicle, or when driving through mist or smoke

l When the headlights are not illumi-

nated while driving in the dark, such
as at night or when in a tunnel

284

5-4. Using the driving support systems

l When the lens of a headlight is dirty
and illumination is weak

l When the headlights are misaligned
l When a headlight is malfunctioning
l When the headlights of another vehicle, sunlight, or reflected light shines
directly into the front camera

l When the brightness of the surrounding area changes suddenly

l When driving near a TV tower, broad-

casting station, electric power plant,
radar equipped vehicles, etc., or other
location where strong radio waves or
electrical noise may be present

l When a wiper blade is blocking the
front camera

l When in a location or near objects

which strongly reflect radio waves,
such as the following:
• Tunnels
• Truss bridges
• Gravel roads
• Rutted, snow-covered roads
• Walls
• Large trucks
• Manhole covers
• Guardrail
• Metal plates

l When near a step or protrusion
l When a detectable vehicle is narrow,
such as a small mobility vehicle

l When a detectable vehicle has a

small front or rear end, such as an
unloaded truck

l When a detectable vehicle has a low
front or rear end, such as a low bed
trailer

l When a detectable vehicle is carrying
a load which protrudes from its cargo
area

l When a detectable vehicle has little

exposed metal, such as a vehicle
which is partially covered with cloth,
etc.

l When a detectable vehicle is irregu-

larly shaped, such as a tractor, sidecar, etc.

l When the distance between the vehicle and a detectable vehicle has
become extremely short

l When a detectable vehicle is at an
angle

l When snow, mud, etc. is attached to a
detectable vehicle

l When driving on the following kinds of

roads:
• Roads with sharp curves or winding
roads
• Roads with changes in grade, such as
sudden inclines or declines
• Roads which is sloped to the left or
right
• Roads with deep ruts
• Roads which are rough and unmaintained
• Roads which frequently undulate or
are bumpy

l When the steering wheel is being
operated frequently or suddenly

l When the vehicle is not in a constant
position within a lane

l When parts related to this system, the
brakes, etc. are cold or extremely hot,
wet, etc.

l When a detectable vehicle has

extremely high ground clearance

l When the wheels are misaligned
l When driving on slick road surfaces,

5-4. Using the driving support systems

285

such as when it is covered with ice,
snow, gravel, etc.

n Changes in brake operation sound

l When the course of the vehicle differs

l When the brakes have been operated,

from the shape of a curve

l When the vehicle speed is excessively high when entering a curve

l When entering/exiting a parking lot,
garage, car elevator, etc.

l When driving in a parking lot
l When driving through an area where

there are obstructions which may contact your vehicle, such as tall grass,
tree branches, a curtain, etc.

l When driving in strong wind
n Situations in which the lane may
not be detected

l When the lane is extremely wide or
narrow

l Immediately after changing lanes or
passing through an intersection

l When driving in a temporary lane or
lane regulated by construction

and pedal response

brake operation sounds may be heard
and the brake pedal response may
change, but this does not indicate a
malfunction.

l When the system is operating, the

brake pedal may feel stiffer than
expected or sink. In either situation
the brake pedal can be depressed further. Further depress the brake pedal
as necessary.

n Situations in which the driver moni-

tor may not operate properly (if
equipped)
In situations such as the following, the
driver monitor camera may not be able
to detect the driver’s face, and the function may not operate properly.

l When the inside of the vehicle is hot,
such as after the vehicle has been
parked in the sun

sun or the headlights of following vehicle, shines onto the driver monitor
camera

l When there are multiple white lines for

l When the brightness inside the vehi-

a lane line

l When the lane lines are not clear or
driving on a wet road surface

l When a lane line is on a curb
l When driving on a bright, reflective

cle changes frequently due to the
shadows of surrounding structures,
etc.

l When a very bright light, such as the

road surface, such as concrete

sun or the headlights of an oncoming
vehicle, is shining onto the driver’s
face

n Situations in which some or all of

l When light, either inside or outside of

l When a malfunction is detected in this

l When there are multiple faces in the

the functions of the system cannot
operate
system or a related system, such as
the brakes, steering, etc.

l When the VSC, TRC, or other safety
related system is operating

l When the VSC, TRC, or other safety
related system is off

the vehicle, is being reflected from the
lenses of eyeglasses or sunglasses
detection range of the driver monitor
camera, such as when a front or rear
passenger is leaning toward the
driver’s seat

l When the driver’s face is outside of

the detection range of the driver monitor camera, such as when leaned forward or when their head is outside of
the window

Driving

l When there are structures, patterns,
shadows which are similar to lane
lines in the surrounding

5

l When a very bright light, such as the

286

5-4. Using the driving support systems

Driver monitor*

l When the driver monitor camera is

being blocked by the steering wheel, a
hand holding the steering wheel, an
arm, etc.

l When the driver is wearing a hat
l When the driver is wearing an eyepatch

l When the driver is wearing eye-

glasses or sunglasses that do not
easily transmit infrared rays

l When the driver is wearing contact
lenses

l When the driver is wearing a face
mask

l When the driver is laughing or the

driver’s eyes are only slightly open

l When the driver’s eyes, nose, mouth,
or shape of their face is blocked

l When the driver is wearing makeup

which makes it difficult to detect their
eyes, nose, mouth, or shape of their
face

l When the driver’s eyes are blocked by
the frame of eyeglasses, sunglasses,
hair, etc.

l When there is a device inside the

vehicle that radiates near infrared
rays, such as a non-genuine driver
monitoring system.

n Certification
P.710

*

: If equipped

Basic functions
During controlled driving, the driver
monitor camera detects the position
and direction the driver is facing,
and whether their eyes are opened
or closed. Through this, the system
determines if the driver is checking
their surroundings and if the driver
can perform driving operations.
In order to operate properly, the
driver monitor camera requires an
unobstructed view of the driver’s
face. If the steering column or seat
position is either too high or too low,
or if any other condition is present
that obstructs the driver monitor
camera’s view of the driver’s face,
some driving support systems may
not operate properly, or a warning
message may be displayed.

n Warning function

In situations such as the following,
a buzzer will sound and a message
will be displayed to warn the driver.
 When the system determines

5-4. Using the driving support systems

that the driver is not paying
attention to the road or their eyes
are closed
 When the driver’s face cannot be
detected or the system determines that the driver has poor
driving posture

If the alarm continues even after
making the recommended adjustments, contact any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.
n Face identification

The driver monitor is used as a
device to identify faces in order to
identify an individual.
For information about how to use
the face identification function, priorities among other devices of individual identification, and linked
vehicle settings, see “My Settings”.
(P.224)

WARNING
n For safe use
l The driver monitor is not designed

to prevent the driver from driving
carelessly or having a poor driving
posture. Pay careful attention to the
surrounding conditions in order to
ensure safe driving.

l The driver monitor cannot reduce

drowsiness. If you feel unable to
concentrate or drowsy, take a break
and sleep as necessary in order to
ensure safe driving.

n Warning function
These functions may not operate when
the vehicle speed is low.
n Face identification
Face identification starts when the door
is opened then closed.
In face identification, facial traits are digitized and stored in a built-in computer,
to be used for identification in My Settings.

l Face image or video are not stored.
Voice is not stored either.

l Digitized face information is not used
for any purpose other than identification in My Settings. Additionally, face
information cannot be decoded and
will not be disclosed or provided to a
third party.

l Face information can be deleted by
yourself.

l For the handling of face information,

please consent to the following before
using it:
• Face identification does not guarantee
a complete identity authentication,
collation, or identification.
• When face information registration
fails frequently or face identification
fails frequently, the driver cameras
should be cleaned or face information
should be registered again.
• Face information stored in the vehicle

5

Driving

When the position of the steering
wheel/driver’s seat is too high or
too low, the driver monitor camera
may not be able to recognize the
whole face of the driver which can
limit feature functionality and possibly trigger an alarm. Adjust the
steering wheel/seat position to
achieve a proper seating position
where the whole meter is visible.
Confirm proper seat belt routing,
head restraint positioning, and
appropriate distance from the steering wheel and frontal airbag as
described in this manual.

287

288

5-4. Using the driving support systems

computer cannot be decoded or
moved to another media. Therefore, it
is necessary to register face information again once it is deleted or relevant parts are replaced.
• Once deleted, face information cannot
be restored. It is necessary to register
face information again.

n Situations where face identifica-

tion may not be performed correctly
This system is designed for use to identify facial traits. In the following situations, face information may not be able
to be registered or identified correctly:

l When a part of the driver’s face (eyebrows, eyes, nose, or mouth) is not
visible

l When the driver is wearing

glasses/sun glasses, a face mask,
muffler, etc.

l When the driver is not facing front
l When part of driver’s face is covered

with hair, beard, a hand, clothes, jewelry, etc.

l When the driver is closing eyes
l When a non-registered driver is a

twin, etc. with a registered driver,
whose face looks quite alike with each
other

n Situations in which the driver monitor may not operate properly
P.285

PCS (Pre-Collision System)
The pre-collision system uses
sensors to detect objects
(P.289) in the path of the
vehicle. When the system
determines that the possibility
of a frontal collision with a
detectable object is high, a
warning operates to urge the
driver to take evasive action
and the potential brake pressure is increased to help the
driver avoid the collision. If the
system determines that the
possibility of a collision is
extremely high, the brakes are
automatically applied to help
avoid the collision or help
reduce the impact of the collision.
The pre-collision system can
be disabled/enabled and the
warning timing can be
changed. (P.298)
WARNING

Changing Driver monitor
settings
The Warning function of Driver
monitor can be enabled/disabled
through the customize setting.
(P.675)
Each time the power switch is
turned to ON, the Warning function
is enabled.

n For safe use
l Driving safely is solely the responsi-

bility of the driver. Pay careful attention to the surrounding conditions in
order to ensure safe driving.
Never use the pre-collision system in
place of normal braking operations.
This system cannot help avoid or
reduce the impact of a collision in
every situation. Over-reliance on this
system to drive the vehicle safely may
lead to an accident resulting in death
or serious injury.

5-4. Using the driving support systems

WARNING
l Although the pre-collision system is

designed to help avoid or help
reduce the impact of a collision, its
effectiveness may change according to various conditions. Therefore,
it may not always be able to
achieve the same level of performance.
Read the following items carefully.
Do not overly rely on this system
and always drive carefully.
• For safe use: P.278

289

urge the driver to take evasive
action.
If the detectable object is a vehicle,
there may be cases where moderate braking will be performed with
the warning.

n When to disable the pre-collision system

l When it is necessary to disable the
system: P.279

Detectable objects

If the system determines that the
accelerator pedal is strongly
depressed, the following icon and
message will be displayed on the
multi-information display.

 Vehicles
 Bicycles*
 Pedestrians
 Motorcycles*
 Walls
*: Detected as a detectable object only

when being ridden.

System functions
n Pre-collision warning

When the system determines that
the possibility of a collision is high,
a buzzer will sound and an icon and
warning message will be displayed
on the multi-information display to

A “Accelerator Pedal is Pressed”
n Pre-collision brake assist

If the system determines that the
possibility of a collision is high and
the brake operation by the driver is
insufficient, the braking power will
be increased.

5

Driving

The system can detect the following as detectable objects. (Detectable objects differ depending on the
function.)

A “Pre-Collision System”

290

5-4. Using the driving support systems

n Pre-collision brake control

If the system determines that the
possibility of a collision is extremely
high, the brakes are automatically
applied to help avoid the collision or
reduce the impact of the collision.
n Emergency steering assist

If the system determines that the
following conditions are met, assistance will be provided to help
enhance vehicle stability and prevent lane departure. During assistance, in addition to the
pre-collision warning, the following
icon will be displayed on the
multi-information display.
 The possibility of a collision is
high
 There is sufficient space within
the lane to perform evasive
steering maneuvers
 The driver is operating the steering wheel

n Intersection collision avoid-

ance support (left/right turn)
In situations such as the following,
if the system determines that the
possibility of a collision is high, the
pre-collision warning and pre-collision braking will operate.
Depending on the intersection,
assistance may not operate correctly.
 When turning left/right at an
intersection and crossing the
path of an oncoming vehicle/motorcycle

Vehicles with active steering function: The brakes and steering are
controlled to help avoid a collision
or reduce the impact of a collision,
regardless of the evasive steering
maneuvers performed by the driver.
During assistance, the pre-collision
warning will operate and a message will be displayed to warn the
driver.

 When turning left/right and a
pedestrian or bicycle is detected

5-4. Using the driving support systems

291

tion. During operation, a buzzer will
sound and a warning indicator and
message will be displayed on the
multi-information display.

n Intersection collision avoid-

ance support (crossing vehicles)
At an intersection, etc., if the system determines that the possibility
of a collision with an approaching
vehicle or motorcycle is high, the
pre-collision warning and pre-collision braking will operate.

WARNING
n Pre-collision braking
l When the pre-collision braking

function is operating, a large
amount of braking force will be
applied.

l The pre-collision braking function is

not designed to hold the vehicle
stopped. If the vehicle is stopped by
pre-collision brake control, the
driver should operate the brakes
immediately as necessary.

l The pre-collision braking function

n Acceleration Suppression at

Low Speed
When driving at a low speed, if the
accelerator pedal is strongly
depressed and the system determines that there is a possibility of a
collision, EV system output will be
restrained or the brakes will be
applied weakly to restrict accelera-

may not operate if certain operations are performed by the driver. If
the accelerator pedal is being
depressed strongly or the steering
wheel is being turned, the system
may determine that the driver is taking evasive action and possibly prevent the pre-collision braking
function from operating.

l If the brake pedal is being

depressed, the system may determine that the driver is taking evasive action and possibly delay the
operation timing of the pre-collision
brake control.

5

Driving

Depending on the intersection,
assistance may not operate correctly.

A “Accelerator Pedal is Pressed”

292

5-4. Using the driving support systems

WARNING
n Acceleration Suppression at Low

Speed
If the steering wheel is being turned,
the system may determine that the
driver is taking evasive action and
possibly prevent the Acceleration
Suppression at Low Speed function
from operating or possibly causing its
operation to be canceled.

n Emergency steering assist
l The emergency steering assist will

be canceled when the system
determines that lane departure prevention control has completed.

l Depending on operations per-

formed by the driver, emergency
steering assist may not operate or
operation may be canceled.
• If the accelerator pedal is
depressed strongly, the steering
wheel is turned heavily, the brake
pedal is depressed, or the turn signal lever is operated, the system
may determine that the driver is taking evasive action and the emergency steering assist may not
operate.
• While the emergency steering
assist is operating, if the accelerator pedal is depressed strongly, the
steering wheel is turned heavily, or
the brake pedal is depressed, the
system may determine that the
driver is taking evasive action and
emergency steering assist operation may be canceled.
• While the emergency steering
assist is operating, if the steering
wheel is held or turned in the opposite direction of system operation,
emergency steering assist operation will be canceled.

n Operating conditions of each function of the pre-collision system
The pre-collision system is enabled and the system determines that the possibility of

5-4. Using the driving support systems

293

a frontal collision with a detected object is high.
However, the system will not operate in the following situations:

l When the vehicle has not been driven a certain amount after a terminal of the
12-volt battery has been disconnected and reconnected

l When the shift position is in R
l When the VSC OFF indicator is illuminated (only the pre-collision warning function

will be operational)
The following are the operational speeds and cancelation conditions of each function:

l Pre-collision warning
Detectable objects

Vehicle speed

Relative speed between
your vehicle and object

Preceding vehicles,
stopped vehicles

Approximately 5 to 180
km/h (3 to 110 mph)

Approximately 5 to 180
km/h (3 to 110 mph)

Oncoming vehicles

Approximately 30 to 180
km/h (20 to 110 mph)

Approximately 80 to 220
km/h (50 to 130 mph)

Bicycles

Approximately 5 to 80
km/h (3 to 50 mph)

Approximately 5 to 80
km/h (3 to 50 mph)

Pedestrians

Approximately 5 to 80
km/h (3 to 50 mph)

Approximately 5 to 80
km/h (3 to 50 mph)

5

Preceding motorcycles,
stopped motorcycles

Approximately 5 to 180
km/h (3 to 110 mph)

Approximately 5 to 80
km/h (3 to 50 mph)

Driving

Oncoming motorcycles

Approximately 30 to 180
km/h (20 to 110 mph)

Approximately 30 to 180
km/h (20 to 110 mph)

While the pre-collision warning is operating, if the steering wheel is operated heavily
or suddenly, the pre-collision warning may be canceled.

l Pre-collision brake assist
Detectable objects

Vehicle speed

Relative speed between
your vehicle and object

Preceding vehicles,
stopped vehicles

Approximately 30 to 180
km/h (20 to 110 mph)

Approximately 10 to 180
km/h (7 to 110 mph)

Bicycles

Approximately 30 to 80
km/h (20 to 50 mph)

Approximately 30 to 80
km/h (20 to 50 mph)

Pedestrians

Approximately 30 to 80
km/h (20 to 50 mph)

Approximately 30 to 80
km/h (20 to 50 mph)

Preceding motorcycles,
stopped motorcycles

Approximately 30 to 180
km/h (20 to 110 mph)

Approximately 10 to 80
km/h (7 to 50 mph)

294

5-4. Using the driving support systems

l Pre-collision braking
Detectable objects

Vehicle speed

Relative speed between
your vehicle and object

Preceding vehicles,
stopped vehicles

Approximately 5 to 180
km/h (3 to 110 mph)

Approximately 5 to 180
km/h (3 to 110 mph)

Oncoming vehicles

Approximately 30 to 180
km/h (20 to 110 mph)

Approximately 80 to 220
km/h (50 to 130 mph)

Bicycles

Approximately 5 to 80
km/h (3 to 50 mph)

Approximately 5 to 80
km/h (3 to 50 mph)

Pedestrians

Approximately 5 to 80
km/h (3 to 50 mph)

Approximately 5 to 80
km/h (3 to 50 mph)

Preceding motorcycles,
stopped motorcycles

Approximately 5 to 180
km/h (3 to 110 mph)

Approximately 5 to 80
km/h (3 to 50 mph)

Oncoming motorcycles

Approximately 30 to 180
km/h (20 to 110 mph)

Approximately 30 to 180
km/h (20 to 110 mph)

If either of the following occur while the pre-collision braking function is operating, it
will be canceled:
• The accelerator pedal is strongly depressed
• The steering wheel is operated heavily or suddenly

l Emergency steering assist
The emergency steering assist will not operate when the turn signal lights are flashing.
Vehicle speed

Relative speed between
your vehicle and object

Approximately 40 to 80
km/h (25 to 50 mph)

Approximately 40 to 80
km/h (25 to 50 mph)

Active steering function: *

Active steering function: *

to 80 km/h (* to 50 mph)

to 80 km/h (* to 50 mph)

Detectable objects

Preceding vehicles,
stopped vehicles, bicycles,
pedestrians, motorcycles
*

: Minimum vehicle speed: Vehicle speed at which evasion using pre-collision brake
control is difficult

While the emergency steering assist is operating, if any of the following are performed, emergency steering assist operation may be canceled:
• The accelerator pedal is strongly depressed
• The steering wheel is operated heavily or suddenly
• The brake pedal is depressed

l Intersection collision avoidance support (left/right turn)
The intersection collision avoidance support (for left/right turning vehicles) will not

5-4. Using the driving support systems

295

operate when the turn signal lights are not flashing.
Relative speed
between your vehicle and object

Detectable objects

Vehicle speed

Oncoming vehicle
speed

Oncoming vehicles

Approximately 5 to
40 km/h (3 to 25
mph)

Approximately 5 to Approximately 10 to
75 km/h (3 to 45
115 km/h (7 to 70
mph)
mph)

Pedestrians

Approximately 5 to
30 km/h (3 to 20
mph)



Approximately 5 to
40 km/h (3 to 25
mph)

Bicycles

Approximately 5 to
30 km/h (3 to 20
mph)



Approximately 5 to
50 km/h (3 to 30
mph)

Oncoming motorcycles

Approximately 5 to
40 km/h (3 to 25
mph)

Approximately 5 to Approximately 10 to
75 km/h (3 to 45
115 km/h (7 to 70
mph)
mph)

l Intersection collision avoidance support (crossing vehicles)
 Vehicles without front side radars

5

Vehicle speed

Vehicles, Motorcycles (side)

 Your vehicle
speed or less
Approximately 5 to
60 km/h (3 to 38  Approximately 40
km/h or less (25
mph)
mph or less)

Approximately 5 to
60 km/h (3 to 38
mph)

The system operates only when the crossing vehicle speed is same as or less than
the vehicle speed.
When driving at approximately 40 km/h (25 mph) or more, this system will only operate when the speed of the other vehicle is approximately 40 km/h (25 mph) or less.
 Vehicles with front side radars

Detectable objects

Vehicle speed

Crossing vehicle
speed

Relative speed
between your vehicle and object

Vehicles, Motorcycles (side)

Approximately 5 to
60 km/h (3 to 38
mph)

Approximately 50
km/h or less (31
mph or less)

Approximately 5 to
60 km/h (3 to 38
mph)

l Acceleration Suppression at Low Speed

Driving

Crossing vehicle
speed

Detectable objects

Relative speed
between your vehicle and object

296

5-4. Using the driving support systems

The Acceleration Suppression at Low Speed function will not operate when the turn
signal lights are flashing.
Detectable objects
Preceding vehicles,
stopped vehicles, Pedestrians, Bicycles, Wall

Relative speed between
your vehicle and object

Vehicle speed
Approximately 0 to 15
km/h (0 to 9 mph)

Approximately 0 to 15
km/h (0 to 9 mph)

While the Acceleration Suppression at Low Speed function is operating, if any of the
following are performed, the low speed sudden acceleration suppression function
operation will be canceled:
• The accelerator pedal is released.
• The steering wheel is operated heavily or suddenly

n Detection of detectable objects
Objects are detected based on their
size, shape, and movement.
Depending on the ambient brightness,
movement, posture and direction of a
detectable object, it may not be detected
and the system may not operate properly.
The system detects shapes, such as the
following, as detectable objects.

walls, etc.
• When there is a detectable object or
other object by the roadside of a curve

• When there are patterns or a painting
ahead of the vehicle that may be mistaken for a detectable object
• When passing a detectable object that
is changing lanes or turning left/right

n Situations in which the system may
operate even though the possibility
of a collision is not high

l In certain situations, such as the fol-

lowing, the system may determine
that the possibility of a collision is high
and operate:
• When passing a detectable object
• When changing lanes while overtaking a detectable object
• When suddenly approaching a detectable object
• When approaching a detectable
object or other object on the roadside,
such as guardrails, utility poles, trees,

• When passing a detectable object
which is stopped to make a left/right
turn

5-4. Using the driving support systems

297

• When the steering wheel is operated
toward the path of an oncoming vehicle
• When there is an object moving above
or under the road

• When a detectable object stops immediately before entering the path of the
vehicle
• When passing through a location with
a structure above the road (traffic
sign, billboard, etc.)

n Situations in which the system may
not operate properly

l In certain situations, such as the fol-

5

Driving

• When approaching an electric toll gate
barrier, parking lot barrier, or other
barrier that opens and closes
• When turning left/right and an oncoming vehicle, oncoming motorcycle,
pedestrian or bicycle crosses in front
of the vehicle
• When attempting to turn left/right in
front of an oncoming vehicle, oncoming motorcycle, pedestrian or bicycle
• When turning left/right and an oncoming vehicle, oncoming motorcycle,
pedestrian or bicycle stops or
changes course immediately before
entering the path of the vehicle
• When turning left/right and an oncoming vehicle/motorcycle turns left/right
in front of the vehicle

lowing, a detectable object may not be
detected by the front sensors, and the
system may not operate properly:
• When a detectable object is
approaching your vehicle
• When your vehicle or a detectable
object is wandering
• When a detectable object makes an
abrupt maneuver (such as sudden
swerving, acceleration or deceleration)
• When suddenly approaching a detectable object
• When the detectable object is near a
wall, fence, guardrail, manhole cover,
steel plate on the road surface, or
another vehicle
• When there is a structure above a
detectable object
• When part of a detectable object is
hidden by another object (large luggage, umbrella, guardrail, etc.)
• When multiple detectable objects are
overlapping
• When a bright light, such as the sun,
is reflecting off of a detectable object
• When a detectable object is white and
looks extremely bright
• When the color or brightness of a
detectable object causes it to blend in
with its surroundings
• When a detectable object cuts in front
of or suddenly emerges in front of
your vehicle
• When approaching a vehicle which is

298

5-4. Using the driving support systems

diagonal
• If a bicycle is a child sized bicycle, is
carrying a large load, is carrying an
extra passenger, is carrying a forward
leaning rider, or has an unusual shape
(bicycles equipped with a child seat,
tandem bicycles, etc.)
• If a pedestrian or bicycle is shorter
than approximately 1 m (3.2 ft.) or
taller than approximately 2 m (6.5 ft.).
• When the silhouette of a pedestrian or
bicycle is unclear (such as when they
are wearing a raincoat, long skirt, etc.)
• When a pedestrian is bending forward
or squatting
• When a pedestrian or bicycle is moving at high speed
• When a pedestrian is pushing a
stroller, wheelchair, bicycle or other
vehicle
• When a detectable object blends in
with the surrounding area, such as
when it is dim (at dawn or dusk) or
dark (at night or in a tunnel)
• When the vehicle has not been driven
for a certain amount of time after the
EV system was started
• While turning left/right or a few seconds after turning left/right
• While driving around a curve and a
few seconds after driving around a
curve
• When turning left/right and an oncoming vehicle/motorcycle is driving in a
lane 3 or more lanes from the vehicle
• When turning left/right and the direction of the vehicle differs greatly from
the direction traffic flows in the
oncoming lane

• When at an intersection, the
approaching crossing vehicle is long
in overall length, such as a large truck,
towing trailer, etc.

l In addition to the preceding, in certain

situations, such as the following, the
emergency steering assist may not
operate properly:
• When a detectable object is too close
to the vehicle
• When there is insufficient space to
perform evasive steering maneuvers
or an obstruction exists in the evasion
direction
• When there is an oncoming vehicle

l In addition to the preceding, in certain

situations, such as the following, walls
may not be detected as a target object
and the Acceleration Suppression at
Low Speed function may not operate
properly:
• When scenery behind the wall is visible, such as a glass door, grid fence,
etc.
• When the wall is slanted or low
• When the wall is narrow, such as a
pole, etc.
• When the wall is made of plants, such
as a hedge, etc.
• When the road, etc. is reflected on the
wall
• When the vehicle is approaching the
wall at an angle

Changing the pre-collision
setting
• When turning left/right, a pedestrian or
bicycle behind the vehicle comes in
front of it as if it overtakes the vehicle

 The pre-collision system can be
enabled/disabled through a customize setting. (P.675)

5-4. Using the driving support systems
The system is enabled each time the
power switch is turned to ON.

 When the system is disabled, the
PCS warning light will illuminate
and a message will be displayed
on the multi-information display.
 The pre-collision setting can be
changed on the customize settings. (P.681)
 When the pre-collision warning
timing is changed, the emergency steering assist timing will
also be changed.
Vehicles without front side radar sensors: When “Later” is selected, the
emergency steering assist will not operate in most cases.

 Vehicles with a driver monitor
camera: When the system determines that the driver is not facing
forward, the pre-collision warning
and emergency steering assist
will operate at the “Earlier” timing, regardless of the user setting.
 When the dynamic radar cruise
control is operating, the pre-collision warning will operate at the
“Earlier” timing, regardless of the
user setting.

LTA (Lane Tracing
Assist)*
*: If equipped

LTA functions
 When driving on a road with
clear lane lines with the dynamic
radar cruise control operating,
lane lines and preceding and
surrounding vehicles are
detected using the front camera
and radar sensor, and the steering wheel is operated to maintain
the vehicle’s lane position.
Use the this function only on highways
and expressways.
If the dynamic radar cruise control is
not operating, the function will not operate.
In situations where the lane lines are
difficult to see or are not visible, such as
when in a traffic jam, support will be
provided using the path of preceding
and surrounding vehicles.
If the system determines that the steering wheel has not been operated for a
certain amount of time or the steering
wheel is not being firmly gripped, the
driver will be alerted and this function
will be temporarily canceled.
If the steering wheel is firmly gripped,
the function will begin operating again.

5

Driving

Vehicles with front side radar sensors:
When “Later” is selected, the emergency steering assist (excluding the
active steering function) will not operate
in most cases.

299

300

5-4. Using the driving support systems

 When the function is operating, if
the vehicle is likely to depart from
its lane, the driver will be alerted
via a display and buzzer.
When the buzzer sounds, check the
area around the vehicle and carefully
operate the steering wheel to move the
vehicle back to the center of the lane.

WARNING
n Before using the LTA system
l Do not overly rely on the LTA sys-

tem. The LTA system is not a system which provides automated
assistance in driving and it is not a
system which reduces the amount
of attention necessary for safe driving. The driver is solely responsible
for paying attention to their
surroundings and operating the
steering wheel as necessary to
ensure safety. Also, the driver is
responsible for taking adequate
breaks when fatigued, such as
when driving for a long time.

l Failure to perform appropriate driving operations and pay careful
attention may lead to an accident.

l When not using the LTA system,
turn it off using the LTA switch.

n Operating conditions of function
This function is operable when all of the
following conditions are met:

l The LTA system detects lane lines or

5-4. Using the driving support systems
the path of preceding or surrounding
vehicles.

l The dynamic radar cruise control is
operating.

l The lane width is approximately 3 to 4
m (10 to 13 ft.).

l The turn signal lever is not being operated.

l The vehicle is not being driven around
a sharp curve.

l The vehicle is not accelerating or
decelerating more than a certain
amount.

l The steering wheel is not being turned
with a large force.

301

lane and the warning will not operate.

n Hands off steering wheel warning
operation

l When the system determines the

driver is not holding the steering
wheel, a message urging the driver to
grip the steering wheel and the icon
shown in the illustration will be displayed on the multi-information display to warn the driver. If the system
detects that the steering wheel is held,
the warning will be canceled. When
using the system, make sure to grip
the steering wheel firmly, regardless
of whether the warning is operating or
not.

l The hands off steering wheel warning
(P.301) is not operating.

l The vehicle is being driven in the
center of a lane.

n Temporary cancelation of functions
l When the operating conditions are no

l If the operating conditions of a func-

tion are no longer met while the function is operating, a buzzer may sound
to indicate that the function has been
temporarily canceled.

l The steering assist operation of the

function can be overridden by the
steering wheel operation of the driver.

5

l If no operations are detected for a certain amount of time, the warning will
operate and the function will be temporarily canceled. This warning may
also operate if the driver only operates
steering wheel a small amount continuously.

n Situations in which the hands off
steering wheel warning may not
operate properly

l Depending on the condition of the

n Lane departure warning function

vehicle, handle control condition and
road surface, the warning function
may not operate.

l Even if the LDA warning method is

l Vehicles with LCA: In the following sit-

when the LTA is operating

changed to vibration of the steering
wheel, if the vehicle deviates from the
lane while the LTA is operating, the
warning buzzer will sound to alert the
driver.

l If steering wheel operation equivalent

to that necessary for a lane change is
detected, the system will determine
the vehicle is not deviating from the

uations, the system may not be able
to detect when the driver’s hands are
off the steering wheel.
• When a steering wheel cover is
installed
• When the driver is wearing gloves
• When foreign matter is attached to the
steering wheel
• When the driver is gripping the wood
trim, seam of the leather, spokes, or

Driving

longer met, a function may be temporarily canceled. However, when the
operation conditions are met again,
operation of the function will automatically be restored. (P.300)

302

5-4. Using the driving support systems

other part of the steering wheel that
does not have sensors

l Vehicles with LCA: In the following sit-

uations, the hands off steering wheel
warning may not operate and the LTA
function may continue operating even
though the driver’s hands are off the
steering wheel:
• When something other than a hand is
contacting the steering wheel
• When a wide object or arms are held
across the steering wheel

l When a preceding or surrounding

vehicle changes lanes (Your vehicle
may follow the preceding or surrounding vehicle and also change
lanes)

Enabling/disabling the system

l When a preceding or surrounding

The LTA will change between
ON/OFF each time the LTA switch
is pressed.

l When a preceding or surrounding

When the LTA is ON, the LTA indicator
will illuminate.

vehicle is swaying (Your vehicle
may sway accordingly and depart
from the lane)

vehicle departs from a lane (Your
vehicle may follow the preceding or
surrounding vehicle and also depart
from the lane)

l When a preceding or surrounding

vehicle is being driven extremely
close to the left/right lane line (Your
vehicle may follow the preceding or
surrounding vehicle accordingly
and depart from the lane)

l When there are moving objects or

WARNING
n Situations in which the func-

tions may not operate properly
In the following situations, the functions may not operate properly and
the vehicle may depart from its lane.
Do not overly rely on these functions.
The driver is solely responsible for
paying attention to their surroundings
and operating the steering wheel as
necessary to ensure safety.

structures in the surrounding area
(Depending on the position of the
moving object or structure relative
to your vehicle, your vehicle may
sway)

l When the vehicle is struck by a

crosswind or the turbulence of other
nearby vehicles

l Situations in which the sensors may
not operate properly: P.283

l Situations in which the lane may not
be detected: P.285

l When it is necessary to disable the
system: P.279

5-4. Using the driving support systems

303

Operation display of steering wheel operation support
The operating state of the LTA system is indicated.
Indicator

Lane display Steering icon

Situation
LTA is on standby

White

Gray/White

Gray

Green

Green

Green

LTA is operating

Yellow

Yellow

Flashing

Flashing

Green

The vehicle is departing the lane toward
the side which the lane display is flashing

5

Driving
