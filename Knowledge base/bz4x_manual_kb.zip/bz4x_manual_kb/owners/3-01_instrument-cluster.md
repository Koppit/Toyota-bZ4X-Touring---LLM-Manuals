# 3-1. Instrument cluster

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 3: Vehicle status information and indicators, pages 152–167

152

3-1. Instrument cluster

Warning lights and indicators

3-1.Instrument cluster

The warning lights and indicators on the instrument cluster, outside
rear view mirrors and overhead console inform the driver of the status of the vehicle’s various systems.

Warning lights and indicators displayed on the instrument
cluster
For the purpose of explanation, the following illustrations display all warning
lights and indicators illuminated.

EV system malfunction indi-

Warning lights

cator lamp*1 (P.620)

Warning lights inform the driver of
malfunctions in the indicated vehicle’s systems.

SRS warning light*1 (P.620)

Brake system warning light*1
(P.619)

Inappropriate pedal operation

(Red)

(Yellow)

Brake system warning light*1
(P.619)

ABS warning light*1 (P.620)
warning light*2 (P.620)
Electric power steering sys(Red)

Charging system warning

tem warning light*1 (P.621)
Electric power steering sys-

light*2 (P.619)
(Yellow)

tem warning light*1 (P.621)

3-1. Instrument cluster

(Yellow)

Traction battery charge warning light (P.621)
Driver’s and front passenger’s seat belt reminder light
(P.621)
Rear passengers’ seat belt
reminder light (P.621)
Tire pressure warning light*1
(P.622)
PCS warning light*1 (if
equipped) (P.622)

(Yellow)

(Yellow)

power switch is turned to ON to indicate that a system check is being
performed. They will turn off after the
EV system is started, or after a few
seconds. There may be a malfunction in a system if the lights do not
come on, or turn off. Have the vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.
*2: This light illuminates on the

multi-information display.

WARNING
n If a safety system warning light

LDA indicator (if equipped)
(P.623)
PDA indicator (if equipped)
(P.623)

Dynamic radar cruise control
indicator (if equipped)
(Yellow) (P.623)

(Yellow)

*1: These lights come on when the

Cruise control indicator
(P.623)
Driving assist information
indicator*1 (if equipped)
(P.624)
Toyota parking assist-sensor
OFF indicator*1 (if equipped)
(P.624)
Slip indicator*1 (P.625)

does not come on
Should a safety system light such as
the ABS and SRS warning light not
come on when you start the EV system, this could mean that these systems are not available to help protect
you in an accident, which could result
in death or serious injury. Have the
vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer
immediately if this occurs.

Indicators
The indicators inform the driver of
the operating state of the vehicle’s
various systems.
Turn signal indicator
(P.253)
Tail light indicator (P.260)

Brake hold operated indica(Flashes)

(Flashes)

tor*1 (P.625)
Parking brake indicator
(P.625)

Headlight high beam indicator (P.263)

3

Vehicle status information and indicators

(Yellow)

LTA indicator (if equipped)
(P.622)

153

154

3-1. Instrument cluster
AHS indicator (if equipped)
(P.264)
AHB indicator (if equipped)
(P.268)
Rear fog light indicator
(P.271)
PCS warning light*1, 2 (if
equipped) (P.288)

(Green)

LTA indicator (if equipped)
(P.303)

(Green)

(White)

cators*3 (if equipped)
(P.348, 361, 375)
Driving assist information

LTA indicator (if equipped)

indicator*1, 2 (if equipped)
(P.348, 361, 375, 380, 384)
Toyota parking assist-sensor

LTA indicator (if equipped)
(P.303)

OFF indicator*1, 2 (if
equipped) (P.366)
Toyota parking assist-sensor

LDA indicator (if equipped)

detection indicator*8 (if
equipped) (P.366)

(Yellow (P.311)
[Flashing])

(Green)

(Yellow)

(Green)

(White)

LDA indicator (if equipped)
(P.311)
LDA OFF indicator*2
(P.311)
PDA indicator (if equipped)
(P.316)
PDA indicator (if equipped)
(P.316)

Dynamic radar cruise control
indicator (if equipped)
(Green) (P.333)
Dynamic radar cruise control
indicator (if equipped)
(White) (P.333)

Cruise control indicator
(P.337, 341)

Speed limiter indicator (if
(Green or equipped) (P.343)
White)
Outside rear view mirror indi-

(Yellow (P.303)
[Flashing])

(White)

Cruise control indicator
(P.337, 341)

Slip indicator*1 (P.503)
(Flashes)
VSC OFF indicator*1, 2
(P.503)
Brake hold standby indicator*1 (P.257)
Brake hold operated indicator*1 (P.257)
Smart entry & start system
indicator*4 (P.243)
Charging cable indicator
(P.116)
“READY” indicator (P.243)
Parking brake indicator
(P.254)
Low outside temperature indicator*5 (P.156)

3-1. Instrument cluster
Security indicator (P.83,
85)
“PASSENGER AIR
BAG” indicator*1, 6
(P.44)
Eco mode indicator (P.251)
Snow mode indicator (if
equipped) (P.497)
Downhill assist control system indicator (if equipped)
(P.497)
Grip Control indicator (if
equipped) (P.497)

(*7)

(*7)

SNOW/DIRT mode indicator
(if equipped) (P.497)
D.SNOW/MUD mode indicator (if equipped) (P.497)
Stop light indicator
(P.155)

*1: These lights come on when the

power switch is turned to ON to indicate that a system check is being
performed. They will turn off after the
EV system is started, or after a few
seconds. There may be a malfunction in a system if the lights do not
come on, or turn off. Have the vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.
*2: This light comes on when the system

is turned off.
*3: This light illuminates on the outside

rear view mirrors.
*4: This light illuminates on the

multi-information display with a mes-

sage.
*5: When the outside temperature is

approximately 3°C (37°F) or lower,
this indicator will flash for approximately 10 seconds, then stay on.
*6: This light illuminates on the over-

head console.
*7: Depending on the operating condi-

tion, the color of the light change.
*8: Vehicles without multimedia display

or rear camera

n Stop light indicator
This light comes on when the stop lights
are illuminated by the operation of the
brake pedal or the driving assist system.

n Toyota parking assist-sensor OFF

indicator (if equipped)
Vehicles without multimedia display:
The indicators turn off when the shift
position is changed to R regardless of
whether the Toyota parking assist-sensor function is turned on or off.

3

Vehicle status information and indicators

Grip Control set speed indicator (if equipped) (P.497)

155

156

3-1. Instrument cluster

Gauges and meters
The meters display various drive information.

Meter display
n Locations of gauges and meters

The units of measure may differ depending on the intended destination of the vehicle.

A Multi-information display
Presents the driver with a variety of vehicle data. (P.159)
Displays warning messages if a malfunction occurs. (P.627)
Display/hide for the multi-information display can be changed. (P.627)

B Outside temperature
Displays the outside temperature within the range of -40°C (-40°F) to 60°C (140°F).

C Power meter (P.157)
Displays EV system output or regeneration level.

Speedometer
Displays the vehicle speed.

Clock
Automatically adjusts the time by using the GPS time information (GPS clock). For
details, refer to the “Multimedia owner’s manual”.

Shift position indicator/regenerative braking power indicator (P.247)
SOC (State of Charge) gauge

3-1. Instrument cluster

157

Displays the amount of charge remaining in the traction battery.

Driving range
Displays driving range with remaining charge. (P.247)
When the air conditioning system is operating,

and the driving range with the

air conditioning system on are displayed.

Odometer and trip meter display (P.158)

*1: The meaning of “Regeneration” here

A Charge area
*1 status.

Shows regeneration

Regenerated energy will be used to
charge the EV battery (traction battery).

B Power area
Displays the EV system output (acceleration force) while driving.

C Regeneration*1 restrictions reference display*2
In the following situations, regenerative
braking is restricted, and the references
for those restrictions are displayed in the
charge area.
• When the traction battery has a large
amount of charge and can no longer
be regenerated
• When the temperature of the traction
battery is extremely high or extremely
low
Output restrictions reference display*2
In the following situations, the output is

means converting kinetic energy into
electrical energy.
*2: This is a reference display, so it may

differ from the actual restriction
depending on the vehicle condition.

n Outside temperature display
l In the following situations, the correct

outside temperature may not be displayed, or the display may take longer
than normal to change:
• When stopped, or driving at low
speeds (less than 25 km/h [16 mph])
• When the outside temperature has
changed suddenly (at the
entrance/exit of a garage, tunnel, etc.)

l When “--” is displayed, the system

may be malfunctioning. Take your
vehicle to any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer.

l When the outside temperature is
approximately 3°C (37°F) or lower, the
indicator
will flash for approximately 10 seconds, then stay on.

3

Vehicle status information and indicators

restricted, and the references for those
restrictions are displayed in the power
area.
• When the traction battery has a low
amount of charge and can no longer
output power
• When the temperature of the traction
battery is extremely high or extremely
low

n Power meter

158

3-1. Instrument cluster

n Liquid crystal display
P.160

WARNING
n The information display at low

temperatures
Allow the interior of the vehicle to
warm up before using the liquid crystal information display. At extremely
low temperatures, the information display monitor may respond slowly, and
display changes may be delayed.
For example, there is a lag between
the driver’s shifting and the regenerative braking power appearing on the
display. This lag could cause the
driver to downshift again, causing
rapid and excessive regenerative
braking and possibly an accident
resulting in death or injury.

 Trip meter A/Trip meter B
Displays the distance the vehicle has
been driven since the meter was last
reset. Trip meters A and B can be used
to record and display different distances
independently.

n Switching the display

The display switches each time the
switch is pressed. Also, when the
switch is continuously pressed during the trip meter display, the driving distance can be changed to “0”.

Switching the meter display
The multi-information display can
be switched between display and
hidden.

Adjusting the instrument
panel light control
The brightness of the instrument
panel lights can be adjusted.

Odometer and trip meter
display
n Display items

 Odometer
Displays the total distance the vehicle
has been driven.

1 Darker
2 Brighter

3-1. Instrument cluster

n Instrument panel illumination

adjustment
The brightness level can be adjusted
when the surroundings are bright (daytime, etc.) or dark (nighttime, etc.).

159

Multi-information display
Display and menu icons
n Display

3

Displays an image when the following
systems are operating and a menu icon
other than

is selected:

• LDA (Lane Departure Alert) (if
equipped) (P.307)
• LTA (Lane Tracing Assist) (if
equipped) (P.299)
• LCA (Lane Change Assist) (if
equipped) (P.304)
• RSA (Road Sign Assist) (if equipped)
(P.320)
• Dynamic radar cruise control (if
equipped) (P.324)
• Cruise control (P.335, 339)
• PDA (Proactive driving assist) (if
equipped) (P.312)

B Content display area
By selecting menu icons on the
multi-information display, a variety of
driving-related information can be displayed. The multi-information display
can also be used to change display settings and other vehicle settings.
Warning or advice pop-up displays are

Vehicle status information and indicators

A Driving support system status
display area

160

3-1. Instrument cluster

also displayed in certain situations.

n Menu icons

The menu icons will be displayed
by pressing the
control switch.

or

meter

Driving information display
(P.161)

Displayed content
Changing the meter display
The multi-information display is
operated using the meter control
switches.

Driving support system
information display
(P.161)
Audio system-linked display (P.162)
Vehicle information display
(P.162)
Warning message display
(P.627)

n Liquid crystal display
Small spots or light spots may appear
on the display. This phenomenon is
characteristic of liquid crystal displays,
and there is no problem continuing to
use the display.

WARNING
n Caution for use while driving
l When operating the multi-informa-

tion display while driving, pay extra
attention to the safety of the area
around the vehicle.

l Do not look continuously at the

multi-information display while driving as you may fail to see pedestrians, objects on the road, etc.,
ahead of the vehicle.

n The information display at low

temperatures
P.158

A

/
: Select menu icons,
scroll the screen and move the
cursor
/
: Change displayed content, scroll the screen and move
the cursor

B Press: Enter/Set
Press and hold: Reset/Display
customizable items
C Return to the previous screen

Call sending/receiving and history display
Linked with the hands-free system,
sending or receiving call is displayed.
For details regarding the hands-free
system, refer to the “Multimedia
owner’s manual”.

Display of drive information
Driving related information is displayed on the following displays.

3-1. Instrument cluster

 Multi-information display
 Multimedia display
The items displayed will differ depending on the display.

Content of driving information

161

n Trip average (Average electric-

ity consumption [after start])
Displays the average electricity
consumption since EV system start.
Use the displayed values as a reference only.

n Display items

 Total average (Average electricity consumption [after reset])
 Trip average (Average electricity
consumption [after start])

3

tricity consumption [after
reset])
Displays the average electricity
consumption since the vehicle was
reset.
Use the displayed values as a reference only.

A Current electricity consumption
Displays instantaneous current electricity consumption.

B Trip Average
To reset the average electricity consumption display, press and hold the
meter control switch.

n Electricity consumption
It is a numerical value that represents
the electricity consumption rate and corresponds to the fuel consumption rate of
gasoline engine vehicles. In this car, the
number of kilometers traveled (km/kWh)
per kilowatt hour of electricity (1 kWh) is
displayed on each screen as “electricity
cost”.

A Current electricity consumption
Displays instantaneous current electricity consumption.

B Total Average
To reset the average electricity consumption display, press and hold the
meter control switch.

Driving support system
information display
n Driving support system infor-

mation
Select to display the operational
status of the following systems:

Vehicle status information and indicators

n Total average (Average elec-

162

3-1. Instrument cluster

 LDA (Lane Departure Alert) (if
equipped) (P.307)
 LTA (Lane Tracing Assist) (if
equipped) (P.299)

n Driving information

Use the displayed information as a
reference only.

 LCA (Lane Change Assist) (if
equipped) (P.304)

 “Average Speed”: Displays the
average vehicle speed since the
display was reset

 RSA (Road Sign Assist) (if
equipped) (P.320)

 “Total Time”: Displays elapsed
time since the display was reset

 Dynamic radar cruise control (if
equipped) (P.324)

n Battery status display

 Cruise control (P.335, 339)

Displays the traction battery degradation status.

 PDA (Proactive driving assist) (if
equipped) (P.312)
n Navigation system-linked dis-

play
Select to display the following navigation system-linked information:
 Route guidance to destination
 Compass display (heading-up
display)

Audio system-linked display
The operating conditions of the
audio system can be displayed on
the multi-information display.

Vehicle information display
n Display items

The following items can be displayed on the multi-information display.
 Driving information
 Battery status display

A “State of certified energy”
The current health of the traction battery displayed as the measured charge
capacity compared to the initial full
charge capacity.

B “Distance travelled since last
update”
At vehicle delivery or after repair at the
dealer, “Distance travelled since last
update” may display its default value
(65535 km/40727 miles).
This value will be reset after the “State
of certified energy” is updated.

AWD/4WD operation status
display (AWD/4WD models)
AWD/4WD operation status display

3-1. Instrument cluster

can be displayed on the Multimedia
display.
n Displaying AWD/4WD opera-

tion status display on the Multimedia display
1 Select

on the main menu.

2 Select “All wheel drive”.
n AWD/4WD operation status

163

n Tire inflation pressure
P.673

Suggestion function
Displays suggestions to the driver
in the following situations. To select
a response to a displayed suggestion, use the meter control
switches.
n Suggestion to enable the

power back door
If the power back door system is

The illustration used is intended as
an example, and may differ from
the image that is actually displayed
on the multi-information display or
Multimedia display.

After enabling the power back door
system, press the power back door
switch again to open or close the
power back door.
n Suggestion to close the power

Tire pressure
The tire pressure detected by the
tire pressure warning system can
be displayed on the Multimedia display.
n Displaying the tire pressure on

the Multimedia display
1 Select

on the main menu.

2 Select “Tyre pressure”.

windows (linked to windshield
wiper operation)
If the windshield wipers are operated with a power window open, a
suggestion message will be displayed asking if you wish close the
power windows.
To close all of the power windows,
select “Yes”.

Vehicle status information and indicators

Torque distribution display: Displays the drive status of each wheel
in 6 steps from 0 to 5.

disabled (setting on
set to off)
and the power back door switch on
the instrument panel is operated, a
suggestion message will be displayed asking if you wish to enable
the power back door system. To
enable the power back door system, select “Yes”.

3

164

3-1. Instrument cluster

n Suggestion to close the power

windows (Driving at high
speeds)
If the vehicle speed exceeds a certain speed with a power window
open, a suggestion message will be
displayed asking if you wish to
close the power windows.
To close all of the power windows,
select “Yes”.
n Suggestion to turn on the

headlights
If the headlight switch is in other
than
or
, and the vehicle
speed is 5 km/h (3 mph) or higher
for a certain amount of time when
the surroundings are dark, a suggestion message will be displayed.
n Suggestion to turn off the

headlights
If the headlights are left on for a
certain amount of time after the
power switch has been turned off, a
suggestion message will be displayed.

Electricity consumption
Electricity consumption information can be displayed on
the multimedia system.

Consumption
n Display procedure

1 Select

on the main menu.

2 Select the “Trip information”.
n Current electricity consump-

tion screen
If a screen other than current electricity consumption screen is displayed, touch “Current”.
Use the displayed average electricity consumption as a reference.
The image is an example only, and
may vary slightly from actual conditions.

n Customization
The suggestion function can be turned
on/off. (Customizable features: P.676)

A Resetting the consumption data
B Electricity consumption in the
past 15 minutes
C Current electricity consumption

Average vehicle speed since the
EV system was started.

3-1. Instrument cluster

Trip range
Elapsed time since the EV system was started.
Use the displayed average electricity consumption as a reference.
n History screen

If a screen other than history
screen is displayed, press “History”.

165

n Resetting the data
The electricity consumption data can be
deleted by selecting “Clear data”.
n Cruising range
Displays the estimated maximum distance that can be driven with the quantity of electricity remaining.
This distance is computed based on
your average electricity consumption.
As a result, the actual distance that can
be driven may differ from that displayed.

Use the displayed average electricity consumption as a reference.

A Latest electricity consumption
B Best recorded electricity consumption
C Previous electricity consumption
record

Resetting the history data
Updating the latest average
electricity consumption data
n Updating the history data
Update the latest electricity consumption by selecting “Update” to measure
the current electricity consumption
again.

3

Vehicle status information and indicators

The image is an example only, and
may vary slightly from actual conditions.

166

3-1. Instrument cluster

167

Before driving

4

4-1. Key information
.

Keys..................................168
Digital Key ........................171
4-2. Opening, closing and locking
the doors
Side doors ........................173
Power back door...............178
Smart entry & start system
.......................................191
4-3. Adjusting the seats
Front seats........................196

4

Rear seats ........................197

Steering wheel ..................203
Inside rear view mirror ......204
Digital Rear-view Mirror ....205
Outside rear view mirrors
.......................................214
4-5. Opening, closing the windows
Power windows.................218
4-6. Favorite settings
Driving position memory ...221
My Settings .......................224

Before driving

Head restraints .................200
4-4. Adjusting the steering wheel
and mirrors
