# Reading this manual

> Source: Toyota bZ4X Touring — Owner's Manual, Front/back matter, pages 11–12

11
Reading this manual

Symbols

Indicates the action (pushing, turning, etc.) used to
operate switches and
other devices.

Explains symbols used in this
manual

Indicates the outcome of
an operation (e.g. a lid
opens).

Symbols in this manual
Symbols

Meanings

Meanings
WARNING:
Explains something that, if
not obeyed, could cause
death or serious injury to
people.
NOTICE:
Explains something that, if
not obeyed, could cause
damage to or a malfunction in the vehicle or its
equipment.
Indicates operating or
working procedures. Follow the steps in numerical
order.

Symbols in illustrations

Symbols

Meanings
Indicates the component
or position being
explained.
Means Do not, Do not do
this, or Do not let this
happen.

12
How to search
n Searching by name

 Alphabetical index: P.697

n Searching by installation posi-

tion
 Pictorial index: P.13

n Searching by symptom or

sound
 What to do if... (Troubleshooting): P.694

n Searching by title

 Table of contents: P.2
