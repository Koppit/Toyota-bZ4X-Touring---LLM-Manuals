# 6-1. Using the air conditioning system and defogger

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 6: Interior features, pages 516–527

516

6-1. Using the air conditioning system and defogger

ALL AUTO (ECO) control

6-1.Using the air conditioning system and defogger

The seat heaters/radiant heaters (if equipped), seat ventilators (if equipped) and heated
steering wheel are each automatically controlled according
to the set temperature of the
air conditioning system, the
outside and cabin temperature,
etc. ALL AUTO (ECO) controls
the electricity consumption in
order to both extend the cruising range and maintain comfortable conditions.

Turning on ALL AUTO (ECO)
control
Select the “AUTO” switch.
The indicator on the AUTO switch illuminates, and the automatic air conditioning system, seat heaters/radiant
heaters (if equipped), seat ventilators (if
equipped) and heated steering wheel
operate in automatic mode.
If the fan speed control switch or airflow
mode control switch is operated, the
indicator turns off. However, all other
functions continue to operate in automatic mode.
Even if ALL AUTO (ECO) control is
turned off, the air conditioner, seat heaters and heated steering wheel will not
be turned off.
Also, during ALL AUTO (ECO) control
operation, pressing the ECO switch
turns off the eco air conditioning control.

If the front window glass becomes
cloudy due to a drop in the outside air
temperature while the ALL AUTO
(ECO) control is operating, you can
remove the cloudiness by selecting the
“A/C” switch or windshield defogger
switch on the multimedia display.

Operation of each system
n Automatic air conditioning

system (P.518)
The temperature can be adjusted
independently for each seat.
n Seat heaters/radiant heaters (if

equipped) and seat ventilators (if equipped) (P.525)
Heating or ventilation is automatically selected according to the set
temperature of the air conditioning
system, the outside temperature,
etc. Also, heating and ventilation
may turn off.
n Heated steering wheel

(P.526)
Heated steering wheel operates
automatically according to the set
temperature of the air conditioning
system, the outside temperature,
etc.
n Passenger detection functions
When a passenger is detected in the
front passenger seat, the seat
heater/radiant heater (if equipped) and
seat ventilator (if equipped) will operate
automatically.

6-1. Using the air conditioning system and defogger

517

n Seat heaters/radiant heaters (if

equipped) and seat ventilators (if
equipped) operation
If the passenger side seat heaters/radiant heaters (if equipped) or seat ventilator (if equipped) is operating under ALL
AUTO (ECO) control when the power
switch is turned off, the seat heater/radiant heaters (if equipped) or seat ventilator (if equipped) will automatically turn
on the next time the power switch is
turned on. To detect the occupant again,
select the “AUTO” switch.

n Rear seat heaters operation (if

equipped)
The rear seat heaters are not controlled
by the ALL AUTO (ECO) control.

6

Interior features

518

6-1. Using the air conditioning system and defogger

Automatic air conditioning system
When the “AUTO” switch is on, the air outlets and fan speed will
automatically be changed according to the set temperature.
The button positions and shapes will differ for right-hand drive vehicles. Also, the display and button positions will differ depending on
the type of the system.

Air conditioning controls

A Left-hand side temperature control switch
B Airflow mode control switch
C Option screen switch

Shortcut screen switch
Select to display shortcut icons for various functions.

“SYNC” switch
Right-hand side temperature control switch
“A/C” switch
Outside/recirculated air mode switch
Fan speed control switch
“OFF” switch
“AUTO” switch
n Adjusting the temperature

to decreases the temperature.

Turn temperature control dial clockwise to increases the temperature
and turn the dial counterclockwise

When the indicator on the “SYNC”
switch is illuminated, the temperature setting for the front passen-

6-1. Using the air conditioning system and defogger

519

ger’s side will match the setting for
the driver’s side.

The airflow mode changes each time
the switch is selected.

When the indicator on the “SYNC”
switch is off, turning the “SYNC”
switch on will illuminate the “SYNC”
switch indicator and the temperature setting for the front passenger’s side will become the same as
that for the driver’s side.

The air outlets and air volume changes
according to the selected air flow mode.

When the front passenger’s side
temperature control switch is operated, the indicator on the “SYNC”
switch will turn off and the temperature setting for the front passenger’s side will be able to be
adjusted.

: Air flows to the upper
body
: Air flows to the upper
body and feet
: Air flows to the feet

: Air flows to the feet and
the windshield defogger operates

n Setting the fan speed

n Switching between outside air

To increase the fan speed, select
the “+” fan speed adjustment switch
or slide the icon of the fan speed
adjustment switch right. To
decrease the fan speed, select the
“-” fan speed adjustment switch or
slide the icon of the fan speed
adjustment switch left.

Temporarily changing the air mode
to recirculated air mode is recommended to prevent dirty air from
entering the vehicle, such as when
in a tunnel or heavy traffic, and to
help cool the interior when the outside air temperature is high.

Select the “OFF” switch to turn the fan
off.

Select the outside/recirculated air
mode switch.

The fan can also be stopped by touching and holding the “-” fan speed adjustment switch or sliding the icon of the
fan speed adjustment switch to the leftmost position and holding it.

n Changing the air flow mode

Select the airflow mode control
switch.

and recirculated air modes

The mode switches between outside air
mode (the indicator is off) and recirculated air mode (the indicator is on) each
time the switch is selected.
The air mode may change automatically depending on the temperature setting, temperature inside the vehicle,
etc.

6

Interior features

If the “A/C” indicator is turned off, the
system will blow ambient temperature
air or heated air.

520

6-1. Using the air conditioning system and defogger

n Set cooling and dehumidifica-

tion function
Select the “A/C” switch.

the settings of the air conditioning
system will be changed immediately.

When the function is on, the indicator illuminates on the “A/C” switch.

1 Select the shortcut screen
switch. (P.518)

n Eco air conditioning mode

2 Select the “Max heat” switch.

The air conditioning is controlled
with low electricity consumption
efficiency prioritized such as reducing fan speed, etc.

 The driver’s side temperature
setting of the air conditioning
system will be set to “Hi” and the
“AUTO” switch will be turned on.

1 Select the option screen switch.
(P.518)

 Driver’s side seat heater/radiant
heater (if equipped) will be set to
Hi.

2 Select the “Eco Heat/Cool”
switch.
 In Eco drive mode, the air conditioning system is controlled as
follows to prioritize electricity
consumption efficiency. To
improve air conditioning performance, turn off Eco air conditioning mode.
• Electric motor speed and compressor
operation controlled to restrict heating/cooling capacity.
• Fan speed restricted when automatic
mode is selected.

 When the driving mode is set to
Eco driving mode, the Eco air
conditioning mode will be turned
on automatically. Even in this
case, the Eco air conditioning
mode can be turned off by
selecting the “Eco Heat/Cool”.
n Warming the interior quickly

(Max heat)
When “Max heat” is turned on, in
order to warm the interior quickly,

 Heated steering wheel will be set
to Hi.
 When the system determines
that a passenger is in the front
passenger seat, the front passenger’s side seat heater/radiant
heater (if equipped), seat ventilator (if equipped) will be set to
“AUTO”.
 When the indicator on the “Sync”
switch is illuminated, the temperature setting for the front passenger’s side will also be set to “Hi”.
n Defogging the windshield

Defoggers are used to defog the
windshield and front side windows.
Press the windshield defogger
switch.

6-1. Using the air conditioning system and defogger

The dehumidification function will operate and the air flow will increase.
Set the outside/recirculated air mode
button to outside air mode if the recirculated air mode is used. (It may switch
automatically.)
To defog the windshield and the side
windows early, turn the air flow and
temperature up.
To return to the previous mode, press
the windshield defogger switch again
when the windshield is defogged.
When the windshield defogger switch is
on, the indicator illuminates on the
windshield defogger switch.

and outside rear view mirrors
Defoggers are used to defog the
rear window, and to remove raindrops, dew and frost from the outside rear view mirrors.
Press the rear window and outside
rear view mirror defoggers switch.

The rear window defogger and outside
rear view mirror defoggers will operate
and defog the rear window and outside
rear view mirrors.
When the rear window and outside rear
view mirror defoggers switch is on, the
indicator illuminates on the rear window
and outside rear view mirror defoggers
switch.
The defoggers will automatically turn off
after a period of time.

n Windshield wiper de-icer (if

equipped)
Use the windshield wiper de-icer to
help prevent the windshield wiper
blades from freezing to the windshield.
1 Select the option screen switch.
(P.518)
2 Select the “De-icer” switch.
The windshield wiper de-icer will automatically turn off after a period of time.

n Fogging up of the windows
l The windows will easily fog up when

the humidity in the vehicle is
high.Turning “A/C” switch on will
dehumidify the air from the outlets and
defogthe windshield effectively.

l If you turn “A/C” off, the windows may
fog up more easily.

6

Interior features

n Defogging the rear window

521

522

6-1. Using the air conditioning system and defogger

l The windows may fog up if the recir-

l Each function can also be adjusted to

n When driving on dusty roads

n Ventilation and air conditioning

culated air mode is used.

Close all windows. If dust thrown up by
the vehicle is still drawn into the vehicle
after closing the windows, it is recommended that the air intake mode be set
to outside air mode and the fan speed to
any setting except off.

n Outside/recirculated air mode
l Setting to the recirculated air mode

temporarily is recommended in preventing dirty air from entering the
vehicle interior and helping to cool the
vehicle when the outside air temperature is high.

l Outside/recirculated air mode may

automatically switch depending on the
temperature setting or the inside temperature.

n When the outside temperature

exceeds 24°C (75°F) and the air
conditioning system is on

l In order to reduce the air conditioning

power consumption, the air conditioning system may switch to recirculated
air mode automatically. This may also
reduce electricity consumption.

l Recirculated air mode is selected as a
default mode when the power switch
is turned to ON.

the desired setting.
odors

l To let fresh air in, set the air conditioning system to the outside air mode.

l During use, various odors from inside

and outside the vehicle may enter into
and accumulate in the air conditioning
system. This may then cause odor to
be emitted from the vents.

l To reduce potential odors from occur-

ring:
• It is recommended that the air conditioning system be set to outside air
mode prior to turning the vehicle off.
• The start timing of the blower may be
delayed for a short period of time
immediately after the air conditioning
system is started in automatic mode.

l When parking, the system automati-

cally switches to outside air mode to
encourage better air circulation
throughout the vehicle, helping to
reduce odors that occur when starting
the vehicle.

n Air conditioning filter
P.602
n Customization
Some functions can be customized.
(Customizable features: P.675)

l It is possible to switch to outside air

mode at any time by pressing the outside/recirculated air mode switch.

n When the outside temperature is

low
The dehumidification function may not
operate even when “A/C” is selected.

n “Max heat”
l The “Max heat” switch cannot be used
to turn the setting off.

l After the “Max heat” switch has been

operated, the temperature setting can
be adjusted using the temperature
control switches of the air conditioning
system.

WARNING
n To prevent the windshield defog-

ger from operating improperly
l Do not use the windshield defogger
in extremely humid areas when the
air conditioning system is set to a
low temperature. The difference
between the temperature of the outside air and that of the windshield
can cause the outer surface of the
windshield to fog up, blocking your
vision.

6-1. Using the air conditioning system and defogger

WARNING
l Do not place anything on the instrument panel which may cover the air
outlets. Otherwise, air flow may be
obstructed, preventing the windshield defoggers from defogging.

n To prevent burns
l Do not touch the rear view mirrors

urfaces when the outside rear view
mirror defoggers are on.

l Vehicles with windshield wiper

deicer: Do not touch the glass at
lower part of the windshield or to
the side of the front pillars when the
windshield wiper de-icer is on.

NOTICE
charge
Do not leave the air conditioning system on longer than necessary when
the EV system is off.

Using automatic mode
1 Select the “AUTO” switch.
(P.518)
2 Adjust the temperature setting.
3 To stop the operation, select the
“OFF” switch.
If the fan speed setting or airflow
modes are operated, the automatic
mode indicator goes off. However,

automatic mode for functions other
than that operated is maintained.
n Using automatic mode
Fan speed is adjusted automatically
according to the temperature setting and
the ambient conditions.
Therefore, the fan may stop for a while
until warm or cool air is ready to flow
immediately after the automatic mode
switch is selected.
Cool air may blow around the upper
body even when the heater is on due to
sunlight.

Front seat concentrated airflow mode (S-FLOW)
This function automatically controls
the air conditioning airflow so that
priority is given to the front seats.
Unnecessary air conditioning is
suppressed, contributing to
increased electricity consumption
efficiency.
Front seat concentrated airflow
mode operates in the following situations.
 No passengers are detectedin
the rear seats
 The windshield defogger is not
operating
The “S-Flow” switch is
(ON) on the option screen.
In front seat concentrated airflow
mode, directing airflow to the front
seats only and to allseats can be
switched via switch operation.
When the mode has been switched
manually, automatic airflow control

6

Interior features

n To prevent 12-volt battery dis-

523

524

6-1. Using the air conditioning system and defogger

stops operating.
1 Select the option screenswitch.
(P.518)
2 Select the “S-Flow” switch.
 Indicator illuminated: Airflow to
the front seats only
 Indicator off: Airflow to all the
seats
n Operation of automatic airflow control

l In order to maintain a comfortable

interior, airflow may be directed to
seats without passengers immediately
after the EV system is started and at
other times depending on the outside
temperature.

n Adjusting the position of and

opening and closing the air
outlets
To adjust the position of and opening and closing the air outlets, perform the following operations:
 Front

l After the EV system is started, if pas-

sengers move around inside or
enter/exit the vehicle, the system cannot accurately detect the presence of
passengers and automatic airflow
control will not operate.

n Operation of manual airflow control
Even if the function is manually switched
to directing airflow to only the front
seats, when a rear seat is occupied, it
may automatically direct airflow to all
seats.
n To return to automatic airflow con-

trol
1 With the indicator off, turn the power
switch off.
2 After 60 minutes or more elapse,
turn the power switch to ON.

Direct air flow to the left or right, up or
down

Move the knob fully to the inside to
close the vent.

Air outlet layout and operations
n Location of air outlets

The air outlets and air volume
change according to the selected
air flow mode.

Direct air flow to the left or right, upor
down

6-1. Using the air conditioning system and defogger

Move the knob fully to the outside
to close the vent.

525

Heated steering
wheel/seat heaters/seat
ventilators*/radiant heaters*

 Rear

*

: If equipped

 Heated steering wheel
Warms up the grip of the steering
wheel
 Seat heaters
Warm up the seat upholstery
1 Direct air flow to the left or right,
up or down
2 Turn the knob to open or close
the vent

 Seat ventilators
Maintain good airflow on the seat
upholstery by sucking air into the
seats
 Radiant heaters
Warm up the feet of the front
seats
WARNING

6

n To prevent minor burn injuries

l Babies, small children, the elderly,
the sick and the physically challenged

l Persons with sensitive skin
l Persons who are fatigued
l Persons who have taken alcohol or
drugs that induce sleep (sleeping
drugs, cold remedies, etc.)

Interior features

Care should be taken if anyone in the
following categories comes in contact
with the steering wheel or seats when
the heater is on:

526

6-1. Using the air conditioning system and defogger
operation condition changes as follows.

NOTICE
n To prevent damage to the seat

heaters/radiant heaters and seat
ventilators
Do not put heavy objects that have an
uneven surface on the seat and do
not stick sharp objects (needles,
nails, etc.) into the seat.

n To prevent 12-volt battery dis-

charge
Do not use the functions when the EV
system is off.

Heated steering wheel
Select
play.

on the multimedia dis-

AUTOHi (3 segments lit)Mid (2
segments lit)Lo (1 segment lit)Off

The level indicator (red) lights up
during operation. “AUTO” indicator
lights up during automatic operation.
n Rear (outboard rear seats) (if

equipped)
Each time the switch is pressed,
the operation condition changes as
follows.
Hi (3 segments lit)Mid (2 segments
lit)Lo (1 segment lit)Off
When not in use, put the switch in the

Each time the switch is selected, the
operation condition changes as follows.

neutral position. The indicator
turn off.

will

AUTO (lit)Hi (2 segments lit)Lo(1
segment lit)Off
The level indicator (red) lights up during
operation. “AUTO” indicator lights up
during automatic operation.

n The heated steering wheel can be

used when
The power switch is in ON.

n The seat heaters can be used when

Seat heaters

The power switch is in ON.

n Front

Vehicles without radiant heaters:
Select
display.

or

on the multimedia

Vehicles with radiant heaters:
Select
display.

or

on the multimedia

Each time the switch is selected, the

WARNING
n To prevent overheating and

minor burn injuries
Observe the following precautions
when using the seat heaters.

l Do not cover the seat with a blanket
or cushion when using the seat
heater.

6-1. Using the air conditioning system and defogger

WARNING
l Do not use seat heater more than

A Front passenger’s side radiant
heater

necessary.

B Driver’s side radiant heater

Seat ventilators (front seats)

Select
display.

Select
or
dia display.

on the multime-

Each time the switch is pressed, the
operation condition changes as follows.
AUTOHi (3 segments lit)Mid (2
segments lit)Lo (1 segment lit)Off
The level indicator (blue) lights up during operation. “AUTO” indicator lights
up during automatic operation.

n The seat ventilators can be used

when
The power switch is in ON.

n Air conditioning system-linked

Radiant heaters

or

on the multimedia

Each time the switch is selected, the
operation condition changes as follows.
AUTOHi (3 segments lit)Mid (2
segments lit)Lo (1 segment lit)Off

The level indicator (red) lights up
during operation. “AUTO” indicator
lights up during automatic operation.
WARNING
n To prevent causes of overheating

and minor burn injuries
Observe the following precautions
when using a radiant heater:

l Do not use radiant heaters more
than necessary.

6

l Do not let blankets, cushions, luggage, etc., to touch the radiant
heaters.

n Use while driving
Do not touch the radiant heater or
hold your hand or foot over it by
releasing a hand from the handle or a
foot from the pedal.
Doing so may cause the driver to mishandle the vehicle and cause an accident, resulting in death or serious
injury.

NOTICE
n To prevent damage to the radiant

heaters
Do not pierce with uneven objects or
sharp objects such as wires or needles.

Interior features

control mode
When a seat ventilator is set to Hi, the
fan speed of the seat ventilator may
increase according to the fan speed of
the air conditioning system.

527
