# 5-4. Using the driving support systems (part 4: Toyota parking assist-sensor, …)

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 366–393
> Topics in this part: Toyota parking assist-sensor; RCTA (Rear crossing traffic alert) function; RCD (Rear camera detection); PKSB (Parking Support Brake); the vehicle/static objects around the vehicle); (moving vehicles rear of the vehicle)

366

5-4. Using the driving support systems

• When a vehicle or bicycle approaches
from behind a vehicle stopped in an
adjacent lane

Toyota parking
assist-sensor
The Toyota parking assist-sensor function detects the
approximate distance from the
vehicle and an object such as a
wall using ultrasonic sensors
and informs the driver with the
multimedia display distance
display and buzzer.

System components
n Type of sensors

A Front corner sensors
B Front center sensors
C Rear corner sensors

Rear center sensors
Front side sensors (vehicles
with Advanced Park)
Rear side sensors (vehicles with
Advanced Park)
n Display

When the sensors detect an object,
such as a wall, a graphic is shown
on the multimedia display depending on the position and distance to

5-4. Using the driving support systems

the object.
Vehicles without multimedia display
or rear camera: When detecting a
stationary object, the Toyota parking assist-sensor detection indicator illuminates. (P.153)
The illustration is an example for
explanation and may differ depending on the specifications.
 Multimedia display

367

customize setting (P.675).
(It remains off even if the power
switch is turned to ON again after
the power switch has been turned
off.)
Vehicles without the multimedia display or rear camera: However, the
system will automatically turn on
(enabled) and the Toyota parking
assist-sensor OFF indicator wil
lturn off if the shift position is
changed to R.
When the shift position is R, the
Toyota parking assist-sensor cannot be turned on or off.
The setting of Toyota parking
assist-sensor itself will not change.
WARNING

5

n Cautions regarding the use of

The Toyota parking assist-sensor
function can be enabled/disabled
through a customize setting.
(P.675)
When the Toyota parking
assist-sensor function is disabled,
the Toyota parking assist-sensor
OFF indicator (P.153) illuminates
on the multi-information display.
If the system switches to OFF (disabled) and the Toyota parking
assist-sensor is stopped, the
Toyota parking assist-sensor will
not be re-enabled until ON (enabled) is selected again from the

the system
There is a limit to the degree of recognition accuracy and control performance that this system can provide,
do not overly rely on this system. The
driver is always responsible for paying
attention to the vehicle’s surroundings
and driving safely.

n To ensure the system can oper-

ate properly
Make sure to observe the following
precautions. The system may not
operate properly and may lead to an
unexpected accident. When these
precautions cannot be observed, turn
the system off.

l Do not damage the sensors, and
always keep them clean.

l Do not attach a sticker or install a

component, such as a backlit
license plate (especially fluorescent
type), fog lights, fender pole or wireless antenna near a radar sensor.

Driving

Turning the Toyota parking
assist-sensor function
ON/OFF

368

5-4. Using the driving support systems

WARNING
l Do not subject the surrounding area
of the sensor to a strong impact. If
subjected to an impact, have the
vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer. If
the front or rear bumper needs to
be removed/installed or replaced,
contact any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.

l Do not modify, disassemble or paint
the sensors.

l Do not attach a license plate cover.
l Keep your tires properly inflated.
l Do not install a suspension other
than a genuine suspension.

n Notes when washing the vehicle
l When using a high pressure

washer to wash the vehicle, do not
spray the sensors directly, as doing
so may cause a sensor to malfunction.

l When using steam to clean the

vehicle, do not direct steam too
close to the sensors, as doing so
may cause a sensor to malfunction.

n The system can be operated when
l The power switch is in ON.
l The Toyota parking assist-sensor is
on.

l The vehicle speed is less than about
10 km/h (6 mph).

l Front corner sensors:
The shift position is in a position other
than P.

l Front center sensors:
The shift position is in a position other
than P or R.

l Rear corner and rear center sensors:
• The shift position is in R.

l Side sensors: (vehicles with

Advanced Park)
• The vehicle is moving about 7 m (23.0
ft.) after the EV system was started.
• The vehicle is moving about 7 m (23.0
ft.) after the shift position was
changed from R to D.
• The shift position is in R.
•

switch has been pressed and the
multimedia display is displayed.
• The front or rear sensor detects a stationary object.

l Vehicles without the multimedia dis-

play or rear camera: The system will
automatically turn on (enabled) and
the Toyota parking assist-sensor OFF
indicator will turn off if the shift position is changed to R.
The setting of Toyota parking
assist-sensor itself will not change.

n Sensor detection information
l The sensor’s detection areas are limited to the areas around the vehicle’s
front and rear bumpers.

l Certain vehicle conditions and the surrounding environment may affect the
ability of a sensor to correctly detect
an object.

l Objects may not be detected if they
are too close to the sensor.

l There will be a short delay between

object detection and display.
Even at low speeds, there is a possibility that the object will come within
the sensor’s detection areas before
the display is shown and the warning
beep sounds.

l It might be difficult to hear the buzzer

due to the volume of the audio system
or air flow noise of the air conditioning
system.

l It may be difficult to hear the sound of
this system due to the buzzers of
other systems.

l If the meter malfunctions, the buzzer
may not sound.

5-4. Using the driving support systems

n Objects which the system may not

be properly detected
The shape of the object may prevent the
sensor from detecting it. Pay particular
attention to the following objects:

l Wires, fences, ropes, etc.
l Cotton, snow and other materials that
absorb sound waves

l Sharply-angled objects
l Low objects
l Tall objects with upper sections pro-

jecting outwards in the direction of
your vehicle
People may not be detected if they are
wearing certain types of clothing.

n Situations in which the system may

l There is dirt, snow, water drops or ice
on a sensor. (Cleaning the sensors
will resolve this problem.)

l A sensor is frozen. (Thawing the area

will resolve this problem.)
In especially cold weather, if a sensor
is frozen the sensor display may be
displayed abnormally, or objects, such
as a wall, may not be detected.

l When a sensor or the area around a
sensor is extremely hot or cold.

other vehicles or other devices which
produce ultrasonic waves are near the
vehicle

l A sensor is coated with a sheet of
spray or heavy rain

l If objects draw too close to the sensor.
l When a pedestrian is wearing clothing
that does not reflect ultrasonic waves
(ex. skirts with gathers or frills).

l When objects that are not perpendicular to the ground, not perpendicular to
the vehicle traveling direction, uneven, or waving are in the detection
range.

l When strong winds are blowing
l When driving in inclement weather
such as fog, snow or a sandstorm

l When an object that cannot be

detected is between the vehicle and a
detected object

l If an object such as a vehicle, motorcycle, bicycle or pedestrian cuts in
front of the vehicle or runs out from
the side of the vehicle

5

l If the orientation of a sensor has been

Driving

not operate properly
Certain vehicle conditions and the surrounding environment may affect the
ability of a sensor to correctly detect
objects. Particular instances where this
may occur are listed below.

369

changed due to a collision or other
impact

l When equipment such as a towing

eyelet, transport hook, bumper protector, bumper trim, bicycle carrier or
snow-removal device (snow plow) is
installed near the sensor

l If the front of the vehicle is raised or
lowered due to the carried load

l If the vehicle cannot be driven in a

stable manner, such as when the
vehicle has been in an accident or is
malfunctioning

l When tire chains, compact spare tire
or an emergency tire puncture repair
kit are used

l On an extremely bumpy road, on an
incline, on gravel, or on grass.

l When vehicle horns, vehicle detec-

tors, motorcycle engines, air brakes of
large vehicles, the clearance sonar of

l When towing with the vehicle
n Situations in which the system may

operate even if there is no possibility of a collision
In some situations, such as the follow-

370

5-4. Using the driving support systems

ing, the system may operate even
though there is no possibility of a collision.

l When driving on a narrow road

produce ultrasonic waves are near the
vehicle

l If the front of the vehicle is raised or
lowered due to the carried load

l If the orientation of a sensor has been
changed due to a collision or other
impact

l The vehicle is approaching a tall or
curved curb

l Driving close to columns (H-shaped

steel beams, etc.) in multi-story parking garages, construction sites, etc.

l When driving toward a banner, flag,

l If the vehicle cannot be driven in a

low-hanging branch or boom barrier
(such as those used at railroad crossings, toll gates and parking lots)

stable manner, such as when the
vehicle has been in an accident or is
malfunctioning

l When there is a rut or hole in the sur-

l On an extremely bumpy road, on an

face of the road

incline, on gravel, or on grass

l When driving on a metal cover (grat-

ing), such as those used for drainage
ditches

l When driving up or down a steep
slope

l If a sensor is hit by a large amount of
water, such as when driving on a
flooded road

l There is dirt, snow, water drops or ice

l When tire chains, compact spare tire

l A sensor is coated with a sheet of

l When towing with the vehicle

on a sensor. (Cleaning the sensors
will resolve this problem.)
spray or heavy rain

l When driving in inclement weather
such as fog, snow or a sandstorm

l When strong winds are blowing

l When vehicle horns, vehicle detec-

tors, motorcycle engines, air brakes of
large vehicles, the clearance sonar of
other vehicles or other devices which

or an emergency tire puncture repair
kit are used

5-4. Using the driving support systems

Sensor detection display,
object distance

371

The range of the sensors may change
depending on the shape of the object,
etc.
 Vehicles with Advanced Park

A Approximately 100 cm (3.3 ft.)

A Approximately 200 cm (6.6 ft.)

B Approximately 150 cm (4.9 ft.)

The diagram shows the detection range
of the sensors. Note that the sensors
cannot detect objects that are
extremely close to the vehicle.

C Approximately 60 cm (2.0 ft.)
The diagram shows the detection range
of the sensors. Note that the sensors
cannot detect objects that are
extremely close to the vehicle.

The range of the sensors may change
depending on the shape of the object,
etc.

n The distance and buzzer
 Vehicles without Advanced Park

Approximate distance to obstacle

Buzzer

Front center sensor:
Approximately 100 cm (3.3 ft.) to 60 cm
(2.0 ft.)*
Rear center sensor:

Slow

Approximately 150 cm (4.9 ft.) to 60 cm
(2.0 ft.)*
Approximately 60 cm (2.0 ft.) to 45 cm
(1.5 ft.)*

Medium

5

Driving

 Vehicles without Advanced Park

372

5-4. Using the driving support systems
Approximate distance to obstacle

Buzzer

Approximately 45 cm (1.5 ft.) to 30 cm

Fast

(1.0 ft.)*
Approximately less than 30 cm (1.0 ft.)
*

Continuous

: Automatic buzzer mute function is enabled. (P.372)

 Vehicles with Advanced Park

Approximate distance to obstacle

Buzzer

Front center sensor:
Approximately 200 cm (6.6 ft.) to 100 cm
(3.3 ft.)
Rear center sensor:
Approximately 200 cm (6.6 ft.) to 150 cm
(4.9 ft.)

Does not sound (Display only)

Corner sensor:
Approximately 200 cm (6.6 ft.) to 60 cm
(2.0 ft.)
Front center sensor:
Approximately 100 cm (3.3 ft.) to 60 cm
(2.0 ft.)*

Slow

Rear center sensor:
Approximately 150 cm (4.9 ft.) to 60 cm
(2.0 ft.)*
Front/Rear center sensor and Corner
sensor:

Medium

Approximately 60 cm (2.0 ft.) to 45 cm
(1.5 ft.)*
Front/Rear center sensor and Corner
sensor:

Fast

Approximately 45 cm (1.5 ft.) to 30 cm
(1.0 ft.)*
Approximately less than 30 cm (1.0 ft.)

Continuous

*: Automatic buzzer mute function is enabled. (P.372)

n Toyota parking assist-sensor

buzzer

A buzzer sounds when the sensors
are operating.

5-4. Using the driving support systems

 The buzzer beeps faster as the
vehicle approaches a static
object. When the vehicle comes
within the approximately 30 cm
(1.0 ft.) of the object, the buzzer
will sound continuously.
 When 2 or more sensors simultaneously detect a static object,
the buzzer sounds for the nearest object.
 After an intermittent buzzer
begins sounding, if the distance
between the vehicle and the
detected static object does not
become shorter, the buzzer will
be muted automatically. (automatic buzzer mute function)
n Adjusting the buzzer volume

373

• When the shift position is changed.
• When the vehicle speed exceeds a
certain speed.
• When there is a malfunction in a sensor or the system is temporarily unavailable.
• When the operating function is disabled manually.
• When the power switch is turned off.

Toyota parking assist-sensor object warning function
(vehicles with Advanced
Park)
The object warning function informs
the driver of the existence of
objects along the side of the vehicle, using a display and buzzer, if
the objects are within the estimated
path of the vehicle.

n Muting a buzzer
When the temporary mute switch is displayed on the multimedia display, this
switch can be pressed to temporarily
mute the buzzer.
Select the switch to mute a buzzer of the
Toyota parking assist-sensor, RCTA and
RCD all together.
l Mute will be automatically canceled in

Driving

The buzzer volume of the Toyota parking assist-sensor, RCTA and RCD can
all be changed at once from the customize settings. (P.675)

5

A Object
B Calculated vehicle route

the following situations:

When the vehicle is moving, the side sensors or side cameras can detect
objects. While the vehicle is moving, if a detected object can no longer be
detected by the side sensors or side cameras, the location of the object relative to the vehicle is estimated. If the object is determined to be in the estimated path of the vehicle, the object warning function will operate.

374

5-4. Using the driving support systems

A Object detected by side sensors or side cameras

1 The vehicle is stopped and objects along the sides of the vehicle are not
detected.
2 Objects are detected as the vehicle is moving.
3 Even though the objects are outside of the detection area of the side
sensors or side cameras, a warning is displayed and a buzzer sounds.
n Object warning function operating
conditions

l The vehicle moves about 7 m (23.0 ft.)
after the EV system is started.

l After the D shift position has been

selected, the vehicle has moved 7 m
(23.0 ft.) or less.

l The R shift position is selected.
l

switch has been pressed and the
multimedia display is displayed.

l The front or rear sensor detects a stationary object.

n Detection of objects along the
sides of the vehicle

l Objects along the sides of the vehicle

are not instantaneously detected. The
location of objects in relation to the
vehicle is estimated after they are first
detected by the front or rear side sensors, or side cameras. Therefore, after
the power switch is changed to ON,
even if an object is along the side of
the vehicle, it may not be detected
until the vehicle has been driven a
small amount and the side sensors or
side cameras completely scan the
areas along the sides of the vehicle.

l If a vehicle, person, animal, etc., is

detected by a side sensors or side
cameras, but then leaves the detection area of the side sensors or side
cameras, the system will assume the
object has not moved.

WARNING
n Side sensors and side cameras
In situations such as the following, the
function may not operate correctly,
possibly leading to an accident. Proceed carefully.

5-4. Using the driving support systems

WARNING
l When starting off shortly after the

power switch is turned to ON and a
small vehicle or other object which
cannot be detected by a front side
sensor is next to the vehicle.
In the situation shown in the following illustration, even if the vehicle
starts off, the vehicle on the left will
not be detected and the object
warning function will not operate.

375

RCTA (Rear crossing
traffic alert) function*
*: If equipped

The RCTA function uses the
BSM rear side radar sensors
installed behind the rear
bumper. This function is
intended to assist the driver in
checking areas that are not
easily visible when backing up.
WARNING
n Cautions regarding the use of

l When an object or person is in a

position which cannot be detected
by the side sensors or side cameras.
object approaches the side of the
vehicle after the side sensors have
completed scanning the areas
along the sides of the vehicle.

l When the outside rear view mirror
is folded.

l If the 12-volt battery was dis-

charged or has been removed and
installed, fold and extend the outside rear view mirrors.

n To ensure the system can oper-

ate properly
P.349

5

Driving

l When a vehicle, person, or other

the system
The driver is solely responsible for
safe driving. Always drive safely, taking care to observe your
surroundings. The RCTA function is
only a supplementary function which
alerts the driver that a vehicle is
approaching from the right or left at
the rear of the vehicle. As the RCTA
function may not function correctly
under certain conditions, the driver’s
own visual confirmation of safety is
necessary. Over reliance on this function may lead to an accident resulting
death or serious injury.

376

5-4. Using the driving support systems

System components

Turning the RCTA function
on/off
The RCTA can be enabled/disabled
through a customize setting.
(P.675)
When the RCTA function is off, the
driving assist information indicator
(P.153) will illuminate and a message will be displayed on the
multi-information display. Each time
the power switch is turned to ON,
the RCTA function is enabled.

A Multimedia display
Turning the RCTA function on/off in
multimedia display. If a vehicle
approaching from the right or left at the
rear of the vehicle is detected, the
RCTA icon (P.377) for the detected
side will be displayed on the multimedia
display. This illustration* shows an
example of a vehicle approaching from
both sides of the vehicle.
*: Depending on the vehicle grade and

equipped options, the actual screen
may be different from this illustration.

B Outside rear view mirror indicators
If a vehicle is detected as approaching
from the left or right behind the vehicle,
both outside rear view mirror indicators
(P.153) will blink and a buzzer will
sound.

C Driving assist information indicator
Illuminates when the RCTA is turned
off. At this time, a message will be displayed on the multi-information display.

n Outside rear view mirror indicator

visibility
In strong sunlight, the outside rear view
mirror indicator may be difficult to see.

n Hearing the RCTA buzzer
The RCTA buzzer may be difficult to
hear over loud noises, such as if the
audio system volume is high.
n Rear side radar sensors
P.349

RCTA function
n Operation of the RCTA func-

tion
The RCTA function uses rear side
radar sensors to detect vehicles
approaching from the right or left at
the rear of the vehicle and alerts
the driver of the presence of such
vehicles by flashing the outside
rear view mirror indicators and
sounding a buzzer.

5-4. Using the driving support systems

A Approaching vehicles
B Detection areas of approaching
vehicles
n RCTA icon display

When a vehicle approaching from
the right or left at the rear of the
vehicle is detected, the following
will be displayed on the multimedia
display.

The buzzer can alert the driver of
faster vehicles approaching from
farther away.
Example:
Approaching vehicle speed

A Approximate

56 km/h (34 mph)
(fast)

30 m (98 ft.)

8 km/h (5 mph)
(slow)

4 m (13 ft.)

alert distance

n The RCTA function is operational

when
The RCTA function operates when all of
the following conditions are met:

l The power switch is ON.
l The RCTA function is on.
l The shift position is in R.
l The vehicle speed is less than

approximately 15 km/h (9 mph).

n RCTA function detection areas

The areas that vehicles can be
detected in are outlined below.

l The approaching vehicle speed is
between approximately 8 km/h (5
mph) and 56 km/h (34 mph).

n Setting the buzzer volume
The buzzer volume of the RCTA, Toyota
parking assist-sensor, and RCD can be
adjusted all together through a customize setting. (P.675)
n Muting a buzzer temporarily
When an object is detected, the temporary mute switch is displayed on the
multimedia display. Select the switch to

5

Driving

Example: Vehicles are approaching
from both sides of the vehicle

377

378

5-4. Using the driving support systems

mute the buzzer of the Toyota parking
assist-sensor, RCTA, and RCD all
together.
Mute will be canceled automatically in
the following situations:

l When the shift position is shifted.
l When the vehicle speed exceeds a
certain speed.

l When there is a malfunction in a sensor or the system is temporarily unavailable.

l When the operating function is disabled manually.

l When the power switch is turned off.
n Conditions under which the system

will not detect a vehicle
The RCTA function is not designed to
detect the following types of vehicles
and/or objects:

tion of a vehicle and/or object may
occur.

n Situations in which the system may

not operate properly
The RCTA function may not detect vehicles correctly in the following situations:

l When the sensor is misaligned due to
a strong impact to the sensor or its
surrounding area

l When mud, snow, ice, a sticker, etc. is
covering the sensor or surrounding
area on the rear bumper

l When driving on a wet road surface,

such as in a puddle, while in inclement
weather, such as heavy rain, snow,
fog, etc.

l When multiple vehicles are approaching with only a small gap between
each vehicle

l Vehicles approaching from directly

l When a vehicle is approaching at high

l Vehicles backing up in a parking

l When equipment that may obstruct a

behind

space next to your vehicle

l Vehicles that the sensors cannot
detect due to obstructions

speed

sensor is installed, such as a towing
eyelet, bumper protector (an additional trim strip, etc.), bicycle carrier,
or snow plow

l When backing up on a slope with a
sharp change in grade

l Guardrails, walls, signs, parked vehicles and similar stationary objects*

l Small motorcycles, bicycles, pedestrians, etc.*

l Vehicles moving away from your vehicle

l Vehicles approaching from the parking spaces next to your vehicle*

l The distance between the sensor and
approaching vehicle gets too close
*: Depending on the conditions, detec-

l When backing out of a sharp angle
parking spot

5-4. Using the driving support systems

379

n Situations in which the system may

operate even if there is no possibility of a collision
Instances of the RCTA function unnecessarily detecting a vehicle and/or
object may increase in the following situations:

l When the parking space faces a street
l Immediately after the RCTA function
is turned on

and vehicles are being driven on the
street

l Immediately after the EV system is
started with the RCTA function on

l When the sensors cannot detect a
vehicle due to obstructions

l When towing with the vehicle
l When there is a significant difference
in height between your vehicle and
the vehicle that enters the detection
area

l When a sensor or the area around a
sensor is extremely hot or cold

l If the suspension has been modified

l When the distance between your vehicle and metal objects, such as a
guardrail, wall, sign, or parked vehicle,
which may reflect electrical waves
toward the rear of the vehicle, is short

l If the front of the vehicle is raised or
lowered due to the carried load

l When turning while backing up

l When equipment that may obstruct a
sensor is installed, such as a towing
eyelet, bumper protector (an additional trim strip, etc.), bicycle carrier,
or snow plow

l When a vehicle turns into the detection area

5

Driving

or tires of a size other than specified
are installed

l When a vehicle passes by the side of
your vehicle

l When a detected vehicle turns while

380

5-4. Using the driving support systems

approaching the vehicle

RCD (Rear camera
detection)*
*: If equipped

l When there are spinning objects near
your vehicle such as the fan of an air
conditioning unit

l When water is splashed or sprayed

toward the rear bumper, such as from
a sprinkler

l Moving objects (flags, exhaust fumes,
large rain droplets or snowflakes, rain
water on the road surface, etc.)

l When the distance between your vehicle and a guardrail, wall, etc., that
enters the detection area is short

l Gratings and gutters
l When a sensor or the area around a
sensor is extremely hot or cold

l If the suspension has been modified

or tires of a size other than specified
are installed

l If the front of the vehicle is raised or
lowered due to the carried load

l When towing with the vehicle

When the vehicle is backing
up, the rear camera detection
function can detect pedestrians in the detection area
behind the vehicle. If a pedestrian is detected, a buzzer will
sound and an icon will be displayed on the multimedia display to inform the driver of the
pedestrian.
WARNING
n Cautions regarding the use of

the system
The recognition and control capabilities for this system are limited.
The driver should always drive safely
by always being responsible without
over relying on the system and have a
understanding of the surrounding situations.

n To ensure the system can oper-

ate properly
Observe the following, otherwise
there is the danger that could lead to
an accident.

l Always clean the camera without
damaging it.

l Do not install market parts (such as

Illuminated license plate, fog lamps,
etc.) in the camera vicinity.

l Do not subject the camera vicinity

to strong impacts. If the vicinity is
subjected to a strong impact, have
the vehicle inspected by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer.

5-4. Using the driving support systems

WARNING

381

RCD display

l Do not disassemble, remodel or
paint the camera.

l Do not attach accessories or stickers to the camera.

l Do not install market protection

parts (bumper trim, etc.) to the rear
bumper.

l Maintain suitable tire air pressure.
l Make sure the back door is completely closed.

n When to disable the RCD func-

tion
In the following situations, disable the
system. The RCD function may not
operate properly, possibly leading to
an accident.

l The contents mentioned above are
not observed.

l Suspensions other than the genu-

System component
Location of the rear camera

Turning the RCD function
on/off
The RCD function can be enabled/disabled through a customize
setting. (P.675)
When the RCD function is disabled,
the driving assist information indicator (P.153) illuminates, and a
message is displayed on the
multi-information display.
Each time the power switch is
turned off then changed to ON, the
RCD function will be enabled automatically.

When a pedestrian is
detected
If a pedestrian is in the area behind
the vehicle or if the rear camera
detected that a pedestrian is
approaching the vehicle from

5

Driving

ine parts are installed.

A Pedestrian detection icon
Displayed automatically when a
pedestrian is detected behind
the vehicle.

382

5-4. Using the driving support systems

behind, the system urges caution
from the driver by sounding the
buzzer and displaying the detection
of a pedestrian on the multimedia
display as follows:

Blinks
n The rear camera detection function
is operational when

l The power switch is in ON.
l RCD function is on.
l The shift position is in R.
l Advanced Park is not operating (if
equipped)

n Setting the buzzer volume
The buzzer volume of the Toyota parking assist-sensor, RCTA and RCD can
all be changed at once from the customize settings. (P.675)

A If a pedestrian is detected in

area
Buzzer: Sounds repeatedly
Pedestrian detection icon:
Blinks
B If a pedestrian is detected in

area
Buzzer (When the vehicle is stationary): Sounds 3 times
Buzzer (When the vehicle is
backing up, when a pedestrian
approaches the rear of the vehicle): Sounds repeatedly
Pedestrian detection icon:
Blinks
C If the system determines that
your vehicle may collide with a

pedestrian in area
Buzzer: Sounds repeatedly
Pedestrian detection icon:

n Muting a buzzer temporarily
When an object is detected, the temporary mute switch is displayed on the
multimedia display.
Select the switch to mute a buzzer of the
Toyota parking assist-sensor, RCTA and
RCD all together.
Mute will be automatically canceled in
the following situations:
l When the shift position is changed.
l When the vehicle speed exceeds a
certain speed.

l When there is a malfunction in a sensor or the system is temporarily unavailable.

l When the operating function is disabled manually.

l When the power switch is turned off.
n Situations in which the system may
not operate properly

l Some pedestrians, such as the follow-

ing, may not be detected by the rear
camera detection function, preventing
the function from operating properly:
• Pedestrians who are bending forward
or squatting
• Pedestrians who are lying down
• Pedestrians who are running
• Pedestrians who suddenly appear
from the shadow of the vehicle or a
building

5-4. Using the driving support systems
• Pedestrians who are riding moving
objects such as a bicycle or skateboard
• Pedestrians wearing oversized clothing such as a rain coat, long skirt, etc.,
making their silhouette obscure
• Pedestrians whose body is partially
hidden by an object, such as a cart or
umbrella
• Pedestrians which are obscured by
darkness, such as at night

l In some situations, such as the follow-

n Situations in which the system may
operate unexpectedly

l Even though there are no pedestrians

in the detection area, some objects,
such as the following, may be
detected, possibly causing the rear
camera detection function to operate.
• Three dimensional objects, such as a
pole, traffic cone, fence, or parked
vehicle
• Moving objects, such as a car or
motorcycle
• Objects moving toward your vehicle
when backing up, such as flags or
puddles (or airborne matter, such as
smoke, steam, rain, or snow)
• Cobblestone or gravel roads, tram
rails, road repairs, white lines, pedestrian crossings or fallen leaves on the
road
• Metal covers (gratings), such as those
used for drainage ditches
• Objects reflected in a puddle or on a
wet road surface
• Shadows on the road

5

l In some situations, such as the follow-

ing, the rear camera detection function may operate even though there
are no pedestrians in the detection
area.
• When backing up toward the roadside
or a bump on the road
• When backing up toward an
incline/decline
• When the vehicle height is extremely
changed (nose up, nose down, etc.)
• When an aftermarket part (backlit
license plate, fog light, etc.) is
installed near the rear camera
• If a bumper protector, such as an
additional trim strip, is installed to the
rear bumper
• If the orientation of the rear camera
has been changed due to a collision
or other impact, or removal and installation
• If a towing eyelet is installed to the
rear of the vehicle
• When water is flowing over the rear
camera lens
• The lens is dirty (by dirt or snow-melting agent, etc.)

Driving

ing, pedestrians may not be detected
by the rear camera detection function,
preventing the function from operating
properly:
• When backing up in inclement
weather (rain, snow, fog, etc.)
• The lens is dirty (by dirt or snow-melting agent, etc.) or scratched
• When a very bright light, such as the
sun, or the headlights of another vehicle, shines directly into the rear camera
• When backing up in a place where the
surrounding brightness changes suddenly, such as at the entrance or exit
of a garage or underground parking
lot
• When backing up in a dim environment such as during dusk or in an
underground parking lot
• When the camera position and direction are deviated
• When a towing hook is attached
• When water droplets are flowing on
the camera lens
• When the vehicle height is extremely
changed (nose up, nose down, etc.)
• When tire chains or an emergency tire
puncture repair kit are used
• When the suspension has been lowered or tires that have a different size
than the genuine tires are installed
• When an aftermarket part (backlit
license plate, fog light, etc.) is
installed near the rear camera
• If a bumper protector, such as an
additional trim strip, is installed to the
rear bumper

383

384

5-4. Using the driving support systems

• If there is a flashing light in the detection area, such as the emergency
flashers of another vehicle
• When tire chains or an emergency tire
puncture repair kit are used

l Situations in which the rear camera

detection function may be difficult to
notice
• The buzzer may be difficult to hear if
the surrounding area is noisy or the
audio system volume is high.
• If the temperature in the cabin is
extremely high or low, the multimedia
display may not operate correctly.

PKSB (Parking Support
Brake)*
*: If equipped

The PKSB (Parking Support
Brake) is a system that issues
warnings and automatically
performs braking to help
reduce collision damage with
operation targets that were
detected when traveling at a
low speed such as when parking.

PKSB (Parking Support
Brake) system
The system has detected the following as operation targets. (The
operation targets vary depending
on the function.)
 Parking Support Brake function
(static objects front and rear of
the vehicle):
P.389

 Parking Support Brake function
(moving vehicles rear of the vehicle):
P.393

 Parking Support Brake function
(pedestrians rear of the vehicle):
P.394

 Parking Support Brake function
(static objects around the vehicle) (vehicles with the Advanced
Park):
P.389

5-4. Using the driving support systems

WARNING
n Cautions regarding the use of

l When loading the vehicle onto a

boat, truck or other transport vessel

the system
Do not overly rely on the system, as
doing so may lead to an accident.
Always drive while checking the
safety of the surroundings of the vehicle.
Depending on the vehicle and road
conditions, weather, etc., the system
may not operate.
The detection capabilities of sensors
and radars are limited. Always drive
while checking the safety of the
surroundings of the vehicle.

l If the suspension has been modi-

l The driver is solely responsible for

l If the vehicle cannot be driven in a

safe driving. Always drive carefully,
taking care to observe your
surroundings. The Parking Support
Brake system is designed to provide support to lessen the severity
of collisions. However, it may not
operate in some situations.
is not designed to stop the vehicle
completely. Additionally, even if the
system has stopped the vehicle, it
is necessary to depress the brake
pedal immediately as brake control
will be canceled after approximately
2 seconds.

l It is extremely dangerous to check

the system operations by intentionally driving the vehicle into the
direction of a wall, etc. Never
attempt such actions.

n When to disable the Parking Sup-

port Brake
In the following situations, disable the
Parking Support Brake as the system
may operate even though there is no
possibility of a collision.

l When inspecting the vehicle using

a chassis roller, chassis dynamo or
free roller

fied or tires of a size other than
specified are installed

l If the front of the vehicle is raised or
lowered due to the carried load

l When equipment such as a towing
hook, transport hook, bumper protector, bumper trim, bicycle carrier
or snow-removal device (snow
plow) is installed near the sensor

l When using automatic car washing
devices

stable manner, such as when the
vehicle has been in an accident or
is malfunctioning

l When the vehicle is driven in a
sporty manner or off-road

5

l When the tires are not properly
inflated

l When the tires are very worn
l When tire chains, a compact spare
tire or an emergency tire puncture
repair kit are used.

l When towing with the vehicle
n Precautions for the suspension
Do not modify the suspension of the
vehicle. If the height or tilt of the vehicle is changed, the sensors may not
be able to detect detectable objects
and the system may not operate correctly, possibly leading to an accident.

Enabling/Disabling the Parking Support Brake
The Parking Support Brake function
can be enabled/disabled through a
customize setting. (P.675)

Driving

l The Parking Support Brake system

385

386

5-4. Using the driving support systems

When the PKSB (Parking Support
Brake) is disabled, the driving
assist information indicator
(P.153) illuminates, and a message is displayed on the multi-information display.
If the PKSB (Parking Support
Brake) is switched to OFF (disabled), the system will not be re-enabled until ON (enabled) is selected
again from the customize setting
(P.687).
(It remains off even if the power
switch is turned to ON again after
the power switch has been turned
off.)

Display and buzzer for EV
system output restriction
control and brake control
If the EV system output restriction
control or brake control operates, a
buzzer will sound and a message
that indicates limited acceleration
or prompts the driver to brake will
be displayed on the multimedia display and multi-information display,
to alert the driver.

played
Message example on the multi-information display: “Object Detected Ahead
Speed Reduced”
Driving assist information indicator: Not
illuminated
Buzzer: Does not sound

 EV system output restriction control is operating (output restricted
as much as possible)
The system has determined that stronger-than-normal brake operation is necessary.
Message example on the multimedia
display (vehicles with a panoramic view
monitor or parking assist monitor with
RCD [Rear Camera Detection])*:
“BRAKE!”
Message example on the multi-information display: “BRAKE!”
Driving assist information indicator: Not
illuminated
Buzzer: Short beep

 Brake control is operating
The system determined that emergency braking is necessary.
Message example on the multimedia
display (vehicles with a panoramic view
monitor or parking assist monitor with

Depending on the situation, output
restriction control operates to either
limit acceleration or restrict output as
much as possible.

RCD [Rear Camera Detection])*:
“BRAKE!”

 EV system output restriction control is operating (acceleration
restriction)

Driving assist information indicator: Not
illuminated

Acceleration greater than a certain
amount is restricted by the system.

 Vehicle stopped by system operation

Multimedia display: No warning dis-

The vehicle has been stopped by brake

Message example on the multi-information display: “BRAKE!”

Buzzer: Short beep

5-4. Using the driving support systems

387

control operation.
Message example on the multimedia
display (vehicles with a panoramic view
monitor or parking assist monitor with
RCD [Rear Camera Detection])*:
“Switch to brake”
Message example on the multi-information display: “Accelerator Pedal is
Pressed Press Brake Pedal”, “Press
Brake Pedal”
Driving assist information indicator: Illuminated
Buzzer: Sounds repeatedly
*: This may not be displayed depending

on the specification of the panoramic
view monitor.

A EV system output
B Braking force
C Time

 Figure 2: When EV system output restriction control operates

System overview

Additionally, if the accelerator pedal
continues to be depressed, the
brakes will be applied automatically
to reduce the vehicle speed. (Brake
control: See figure 3.)
 Figure 1: When the PKSB (Parking Support Brake) is not operating

5

Driving

If the Parking Support Brake determines that a collision with a
detected object or pedestrian is
possible, the EV system output will
be restricted to restrain any
increase in the vehicle speed. (EV
system output restriction control:
See figure 2 below.)

A EV system output
B Braking force
C Time

EV system output restriction
control begins operating (System determines that possibility
of collision with detected object
is high)
 Figure 3: When EV system output restriction control and brake
control operates

388

5-4. Using the driving support systems
the PKSB (Parking Support Brake),
either enable the system again, or turn
the power switch off and then back to
ON.
Additionally, if any of the following conditions are met, the system will be re-enabled automatically and the driving assist
information indicator will turn off
(P.153):

A EV system output
B Braking force
C Time

EV system output restriction
control begins operating (System determines that possibility
of collision with detected object
is high)
Brake control begins operating
(System determines that possibility of collision with detected
object is extremely high)
n If the Parking Support Brake has

operated
If the vehicle is stopped due to operation
of the Parking Support Brake, the Parking Support Brake will be disabled and
the driving assist information indicator
will illuminate.
In addition, even when the PKSB (Parking Support Brake) operates, the brake
control is canceled after approximately 2
seconds to start off.
Furthermore, the brake control also can
be canceled by depressing the brake
pedal. Depressing the accelerator pedal
again after that allows the vehicle to
start off.

n Re-enabling the Parking Support

Brake
To re-enable the Parking Support Brake
when it is disabled due to operation of

l The P shift position is selected
l Drive with no operation targets in the
traveling direction of the vehicle

l Change the traveling direction of the
vehicle

n Buzzer
Regardless of whether the Toyota parking assist-sensor is enabled or not
(P.367), if the PKSB (Parking Support
Brake) system is enabled (P.385), the
buzzer will sound to notify the driver of
the approximate distance to the object
when the brake control and the EV system output restriction control are operated.

5-4. Using the driving support systems

Parking Support Brake
function (static objects
front and rear of the
vehicle/static objects
around the vehicle)

Examples of function operation (static objects front and
rear of the vehicle)
This function will operate in situations such as the following if an
object is detected in the traveling
direction of the vehicle.

n When traveling at a low speed

and the brake pedal is not
depressed, or is depressed
late

n When the accelerator pedal is

depressed excessively

5

Driving

If the sensors detect a static
object, such as a wall, in the
traveling direction of the vehicle and the system determines
that a collision may occur due
to the vehicle suddenly moving
forward due to an accidental
accelerator pedal operation,
the vehicle moving the unintended direction due to the
wrong shift position being
selected, or while parking or
traveling at low speeds, the
system will operate to lessen
the impact with the detected
static object and reduce the
resulting damage.

389

390

5-4. Using the driving support systems

n When the vehicle moves for-

ward due to the incorrect shift
position being selected

Examples of function operation (static objects around
the vehicle) (vehicles with
Advanced Park)

n When moving forward and a

collision with a stationary
object on the inner side of a
turn is likely

n When reversing and a colli-

sion with a stationary object
on the outer side of a turn is
likely

The system will operate in the following situations when a stationary
object is detected in the surrounding area.

Types of sensors
P.366

5-4. Using the driving support systems

WARNING
n To ensure the system can oper-

ate properly
P.367

n If the Parking Support Brake

function operates unnecessarily,
such as at a railroad crossing
P.388

n Notes when washing the vehicle
P.368

n Side sensors and side cameras

(vehicles with Advanced Park)
In situations such as the following,
Parking Support Brake function (static
objects around the vehicle) may not
operate correctly, possibly leading to
an accident. Proceed carefully.

l When starting off shortly after the

l When the outside rear view mirror
is closed.

l If the 12-volt battery was dis-

charged or has been removed and
installed, fold and extend the outside rear view mirrors.

n The Parking Support Brake func-

tion (static objects front and rear of
the vehicle) will operate when
The function will operate when the driving assist information indicator is not illuminated (P.152) and all of the
following conditions are met:

l EV system output restriction control
• The Parking Support Brake is enabled.
• The vehicle speed is approximately 15
km/h (9 mph) or less.
• There is a static object in the traveling
direction of the vehicle and approximately 2 to 4 m (6 to 13 ft.) away.
• The Parking Support Brake determines that a stronger-than-normal
brake operation is necessary to avoid
a collision.
l Brake control
• EV system output restriction control is
operating.
• The Parking Support Brake determines that an immediate brake operation is necessary to avoid a collision.
n The Parking Support Brake func-

l When an object or person is in a

position which cannot be detected
by the side sensors or side cameras.

l When a vehicle, person, or other

object approaches the side of the
vehicle after the side sensors have
completed scanning the areas
along the sides of the vehicle.

tion (static objects around the vehicle) will operate when (vehicles
with Advanced Park)
This function is operable when any of
the following conditions is met in addition to the operating conditions for static
objects in front and rear of the vehicle.

l After the EV system has been started,
the vehicle has moved approximately
7 m (23.0 ft.) or less

l The R shift position is selected
l After the shift position has been

changed from R to D, the vehicle has
moved approximately 7 m (23.0 ft.) or

5

Driving

power switch is turned to ON and a
small vehicle or other object which
cannot be detected by a front side
sensor is next to the vehicle.
In the situation shown in the following illustration, even if the vehicle
starts off, the vehicle on the left will
not be detected and the object
warning function will not operate.

391

392

5-4. Using the driving support systems

less

n The Parking Support Brake func-

tion (static objects front and rear of
the vehicle/static objects around
the vehicle) will stop operating
when
The function will stop operating if any of
the following conditions are met:

n Situations in which the system may

not operate properly
P.369

n Situations in which the system may

operate even if there is no possibility of a collision
P.369

n Situations in which the system may

l EV system output restriction control

• The Parking Support Brake is disabled.
• The system determines that the collision has become avoidable with normal brake operation.
• The static object is no longer approximately 2 to 4 m (6 to 13 ft.) away from
the vehicle or in the traveling direction
of the vehicle.

operate even though there is no
possibility of a collision (static
objects around the vehicle) (vehicles with Advanced Park)
In addition to the situations in which
static objects in front and rear of the
vehicle (P.391) may not be detected,
objects may not be detected by the sensors in the following situations:

l Brake control

l When moving sideways, such as

• The Parking Support Brake is disabled.
• Approximately 2 seconds have
elapsed since the vehicle was
stopped by brake control.
• The brake pedal is depressed after
the vehicle is stopped by brake control.
• The static object is no longer approximately 2 to 4 m (6 to 13 ft.) away from
the vehicle or in the traveling direction
of the vehicle.

n Detection range of the Parking Sup-

port Brake function (static objects
front and rear of the vehicle/static
objects around the vehicle)
The detection range of the Parking Support Brake function (static objects front
and rear of the vehicle/static objects
around the vehicle) differs from the
detection range of the Toyota parking
assist-sensor (P.371). Therefore,
even if the Toyota parking assist-sensor
detects an object and provides a warning, the Parking Support Brake function
(static objects front and rear of the vehicle/static objects around the vehicle)
may not start operating.

when parallel parking (P.413)

n Detection of objects along the

sides of the vehicle (static objects
around the vehicle) (vehicles with
Advanced Park)

l Objects along the sides of the vehicle

are not instantaneously detected. The
location of objects in relation to the
vehicle is estimated after they are first
detected by the front or rear side sensors, or side cameras. Therefore, after
the power switch is changed to ON,
even if an object is along the side of
the vehicle, it may not be detected
until the vehicle has been driven a
small amount and the side sensors or
side cameras completely scan the
areas along the sides of the vehicle.

l If a vehicle, person, animal, etc., is

detected by a side sensors or side
cameras, but then leaves the detection area of the side sensors or side
cameras, the system will assume the
object has not moved.

5-4. Using the driving support systems

Parking Support Brake
function (moving vehicles rear of the vehicle)*
*: If equipped

If a rear radar sensor detects a
vehicle approaching from the
right or left at the rear of the
vehicle and the system determines that the possibility of a
collision is high, this function
will perform brake control to
reduce the likelihood of an
impact with the approaching
vehicle.

Examples of the function
operation

n When reversing, a vehicle is

approaching and the brake
pedal is not depressed, or is
depressed late

Types of sensors
P.349
WARNING
n To ensure the system can oper-

ate properly
P.349

n The Parking Support Brake func-

tion (moving vehicles rear of the
vehicle) will operate when
The function will operate when the driving assist infomation indicator is not illuminated (P.152) and all of the
following conditions are met:

l EV system output restriction control
• The Parking Support Brake is enabled.
• The vehicle speed is approximately 15
km/h (9 mph) or less.
• Vehicles are approaching from the
right or left at the rear of the vehicle at
a traveling speed of approximately 8
km/h (5 mph) or more.
• The shift position is in R.
• The Parking Support Brake determines that a stronger than normal
brake operation is necessary to avoid
a collision with an approaching vehicle.
l Brake control
• EV system output restriction control is
operating.
• The Parking Support Brake determined that an emergency brake operation was necessary to avoid a
collision with a vehicle approaching
from the rear.
n The Parking Support Brake func-

tion (moving vehicles rear of the
vehicle) will stop operating when
The function will stop operating if any of
the following conditions are met:

l EV system output restriction control
• The Parking Support Brake is disabled.

5

Driving

This function will operate in situations such as the following if a vehicle is detected in the traveling
direction of the vehicle.

393
