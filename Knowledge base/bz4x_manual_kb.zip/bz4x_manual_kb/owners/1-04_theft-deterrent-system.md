# 1-4. Theft deterrent system

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 1: For safety and security, pages 83–89

1-4. Theft deterrent system

Immobilizer system

83

1-4.Theft deterrent system

The vehicle’s keys have
built-in transponder chips that
prevent the EV system from
starting if a key has not been
previously registered in the
vehicle’s on-board computer.

This system is designed to
help prevent vehicle theft but
does not guarantee absolute
security against all vehicle
thefts.

Operating the system
The indicator light flashes after the
power switch has been turned off to
indicate that the system is operating.
The indicator light stops flashing
after the power switch has been
turned to ACC or ON to indicate
that the system has been canceled.

n Conditions that may cause the system to malfunction

l If the grip portion of the key is in contact with a metallic object

l If the key is in close proximity to or

touching a key registered to the security system (key with a built-in
transponder chip) of another vehicle

NOTICE
n To ensure the system operates

correctly
Do not modify or remove the system.
If modified or removed, the proper
operation of the system cannot be
guaranteed.

1

For safety and security

Never leave the keys inside the
vehicle when you leave the
vehicle.

n System maintenance
The vehicle has a maintenance-free
type immobilizer system.

84

1-4. Theft deterrent system

Double locking system*
*

: If equipped

Unauthorized access to the
vehicle is prevented by
disabling the door unlocking
function from both the interior
and exterior of the vehicle.
Vehicles employing this system have labels on the side
window of both front doors.

Setting/canceling the double
locking system
n Setting

Turn the power switch off, have all
the passengers exit the vehicle and
ensure that all the doors are closed.
Using the entry function: Touch the
sensor area on the outside door
handle twice within 5 seconds.
Using the wireless remote control:
Press

twice within 5 seconds.

n Canceling

Using the entry function: Hold the
outside door handle, press the
power back door switch or move

your foot under the center of the
rear bumper (vehicles with Hands
Free Power Back Door)
Using the wireless remote control:
Press

.
WARNING

n Double locking system precau-

tion
Never activate the double locking system when there are people in the
vehicle because all the doors cannot
be opened from inside the vehicle.

1-4. Theft deterrent system

Alarm*
*

: If equipped

n Setting

Close the doors, back door and
hood, and lock all doors using the
entry function or wireless remote
control. The system will be set
automatically after 30 seconds.
The indicator light changes from being
on to flashing when the system is set.

 A locked door or back door is
unlocked or opened in any way
other than using the entry
function or wireless remote
control. (The doors will lock
again automatically.)
 The hood is opened.
 The intrusion sensor detects
something moving inside the
vehicle. (Example: an intruder
breaks a window and gets into
the vehicle.)
 The tilt sensor detects a
change of vehicle inclination.

Setting/deactivating/stopping the alarm system
n Items to check before locking

the vehicle
To prevent unexpected triggering of
the alarm and vehicle theft, make
sure of the following:
 Nobody is in the vehicle.
 The windows are closed before
the alarm is set.
 No valuables or other personal
items are left in the vehicle.

1

For safety and security

The alarm uses light and
sound to give an alert when an
intrusion is detected.
The alarm is triggered in the
following situations when the
alarm is set:

85

n Deactivating or stopping

Do one of the following to deactivate or stop the alarms:
 Unlock the doors or open the
back door using the entry function or wireless remote control.
 Start the EV system. (The alarm
will be deactivated or stopped
after a few seconds.)
n Setting the alarm
The alarm can be set if all the doors are
closed even with the hood open.
n System maintenance
The vehicle has a maintenance-free
type alarm system.
n Triggering of the alarm
The alarm may be triggered in the following situations:
(Stopping the alarm deactivates the
alarm system.)
l The doors are unlocked using the
mechanical key.

86

1-4. Theft deterrent system

NOTICE
n To ensure the system operates

correctly
Do not modify or remove the system.
If modified or removed, the proper
operation of the system cannot be
guaranteed.

l A person inside the vehicle opens a
door, the back door or hood, or
unlocks the vehicle.

Intrusion sensor and tilt
sensor (if equipped)
n The intrusion sensor and tilt

sensor detection
 The intrusion sensor detects
intruders or movement in the
vehicle.
l The 12-volt battery is recharged or

replaced when the vehicle is locked.
(P.661)

 The tilt sensor detects changes
in vehicle inclination, such as
when the vehicle is towed away.
This system is designed to deter
and prevent vehicle theft but does
not guarantee absolute security
against all intrusions.
n Setting the intrusion sensor

and tilt sensor
n Alarm-operated door lock
In the following cases, depending on the
situation, the door may automatically
lock to prevent improper entry into the
vehicle:
l When a person remaining in the vehicle unlocks the door and the alarm is
activated.

l While the alarm is activated, a person
remaining in the vehicle unlocks the
door.

l When recharging or replacing the
12-volt battery

n Customization
Some functions can be customized.
(P.676)

The intrusion sensor and tilt sensor
will be set automatically when the
alarm is set. (P.85)
n Canceling the intrusion sensor

and tilt sensor
If you are leaving pets or other
moving things inside the vehicle,
make sure to disable the intrusion
sensor and tilt sensor before setting
the alarm, as they will respond to
movement inside the vehicle.
1 Turn the power switch off.

1-4. Theft deterrent system

87

2 Press the intrusion sensor and
tilt sensor cancel switch.

l A window is open.
In this case, the sensor may detect the
following:
• Wind or the movement of objects such
as leaves and insects inside the vehicle
• Ultrasonic waves emitted from
devices such as the intrusion sensors
of other vehicles
• The movement of people outside the
vehicle

n Canceling and automatic re-ena-

bling of the intrusion sensor and
tilt sensor

l The alarm will still be set even when

the intrusion sensor and tilt sensor are
canceled.

l After the intrusion sensor and tilt sensor are canceled, pressing the power
switch or unlocking the doors using
the entry function or wireless remote
control will re-enable the intrusion
sensor and tilt sensor.

l The intrusion sensor and tilt sensor

will automatically be re-enabled when
the alarm system is deactivated.

l Small insects such as moths or flies
are in the vehicle.

l Unstable items, such as dangling

accessories or clothes hanging on the
coat hooks, are in the vehicle.

l The vehicle is parked in a place where
extreme vibrations or noises occur,
such as in a parking garage.

n Intrusion sensor detection consid-

erations
The sensor may trigger the alarm in the
following situations:

l People or pets are in the vehicle.

l Ice or snow is removed from the vehicle, causing the vehicle to receive
repeated impacts or vibrations.

1

For safety and security

Press the switch again to re-enable the
intrusion sensor and tilt sensor.
A message will be shown on the
multi-information display in the instrument cluster.
The intrusion sensor and tilt sensor will
revert to on each time the power switch
is turned to ON.

88

1-4. Theft deterrent system

NOTICE
n To ensure the intrusion sensor
function correctly

l To ensure that the sensors operate
properly, do not touch or cover
them.

l The vehicle is inside an automatic or
high-pressure car wash.

l The vehicle experiences impacts,

such as hail, lightning strikes, and
other kinds of repeated impacts or
vibrations.

n Tilt sensor detection considera-

tions
The sensor may trigger the alarm in the
following situations:

l Do not spray air fresheners or other
products directly into the sensor
holes.

l The vehicle is transported by a ferry,
trailer, train, etc.

l The vehicle is parked in a parking
garage.

l The vehicle is inside a car wash that
moves the vehicle.

l Any of the tires loses air pressure.
l The vehicle is jacked up.
l An earthquake occurs or the road
caves in.

l Cargo is loaded onto or unloaded
from the roof luggage carrier.

l Installing accessories other than

genuine Toyota parts or leaving
objects between the driver’s seat
and front passenger’s seat may
reduce the detection performance.

89

Electric Vehicle system

2

2-1. Electric vehicle system
.

Electric Vehicle system features ................................. 90
Electric Vehicle system precautions .................................. 94
Battery Electric Vehicle driving
tips .................................... 99

2

Driving range ....................101

Electric Vehicle system

2-2. Charging
Charging equipment .........103
Locking and unlocking the AC
charging connector .........106
Charging methods ............108
Charging tips ....................110
Things to know before charging
.......................................112
How to use AC charging ...115
How to use DC charging...120
Using the charging schedule
function ...........................125
Using Battery Preconditioning
.......................................132
Using My Room Mode ......136
When charging cannot be carried out ...........................139
