# 5-4. Using the driving support systems (part 6: Multi-terrain Monitor, …)

> Source: Toyota bZ4X Touring — Owner's Manual, Chapter 5: Driving, pages 433–496
> Topics in this part: Multi-terrain Monitor

5-4. Using the driving support systems

Multi-terrain Monitor*
*

: If equipped

The Multi-terrain Monitor helps
the driver to check the vehicle
surroundings. It assists in
determining the conditions
around the driver in a variety
of situations, such as when
judging conditions during
off-road driving or checking
for obstacles when parking.
l The screen illustrations used in this

text are intended as examples, and
may differ from the image that is actually displayed on the screen.

WARNING
n When using the Multi-terrain

l Never drive while looking only at

the screen as the image on the
screen is different from actual conditions. If you are driving while looking only at the screen, you may hit a
person or an object, resulting in an
accident. When driving, be sure to
check the vehicle’s surroundings
with your own eyes and the vehicle’s mirrors.

l The position of the guide lines dis-

played on the screen may change
due to factors such as number of
passengers, load capacity, and
road gradient. Always make sure to
visually check behind you and your
surroundings while you are driving.

l In low temperatures, the screen

When the camera malfunctions, the
screen may be displayed as follows:

l Due to the characteristics of the

l When the shift position is in any

l Always make sure to visually check
behind you and your surroundings
while you are driving.

l If you replace your tires, the posi-

tion of the guide lines displayed on
the screen may be incorrect.

NOTICE
n Multi-terrain Monitor

position other than R, the camera
image continue to be displayed

l When the shift position is in R, part
or all of the screen may appear
black

l When the shift position is in R, the

screen may not change to the camera image

5

Driving

may darken or the images may
become faint.
Images of moving objects in particular may distort or disappear
from the screen. Therefore, make
sure to drive carefully while directly
visually confirming the safety of
your surroundings.

Monitor system
Observe the following precautions to
avoid an accident that could result in
death or serious injuries.
l Never rely solely on the Multi-terrain Monitor.
As with unequipped vehicles, drive
carefully while directly confirming
the safety of your surroundings and
the area to the rear of the vehicle.
Take particular care to avoid parked
cars and other obstacles.
camera lens, the actual position
and distance of people and other
obstacles will differ from those
shown on the Multi-terrain Monitor
screen. Directly confirm the safety
of your surroundings before driving.

433

434

5-4. Using the driving support systems

NOTICE
l The guide lines are not displayed

on the camera image, and attention
symbols and caution notices are
displayed

Multi-terrain Monitor
screens
The following screens can be
selected according to driving conditions.
• Screens that can be selected
vary depending on conditions
such as shift position and vehicle
speed. (P.437)
• Depending on the displayed
screen, the display can be
switched from normal to full
screen display.

P.442

 When checking the condition of
the road surface under the vehicle
 Under vehicle terrain view & dual

side views

n Screens when the “X-MODE”

switch is in on.
 When checking the area to the
front and sides of the vehicle

P.445

 Front view & dual side views

 Under vehicle terrain view (magni-

P.442
 Front view (magnified)

fied)

P.445
 Under vehicle terrain view (rear

wheel) & dual side views

5-4. Using the driving support systems

435

P.448

P.452

 Under vehicle terrain view (rear

 Under vehicle terrain view (rear side)

wheel) (magnified)

& dual side views

5
P.455

 When checking the area to the
rear of the vehicle

 Under vehicle terrain view (rear side)

(magnified)

 Rear view & dual side views

P.455
P.452
 Wide rear view & dual side views

n Screens when the “X-MODE”

switch is in off.
 When checking the area to the
around of the vehicle
 Moving view

Driving

P.448

436

5-4. Using the driving support systems

P.458

P.460

 See-through view

 Cornering View & panoramic view

P.458

P.460

 When checking the area to the
front of the vehicle

 When checking the area to the
rear of the vehicle

 Wide front view & panoramic view

 Rear view & panoramic view

P.460

P.468

 Side Clearance View & panoramic

 Wide rear view & panoramic view

view

5-4. Using the driving support systems

437

P.476
 Side view & Wide rear view

P.468

 When folding the outside rear
view mirrors

P.476

 Side view & Wide front view

Camera switch
The camera switch is located as
shown in the illustration.
5

 Side view & Rear view

How to switch the screen
When you press the camera switch while the power switch is in ON, the
monitor display operates.
The monitor displays various views of the position of the vehicle. (The following is an example)

Driving

P.476

438

5-4. Using the driving support systems

“X-MODE” switch is in on
n When the shift position is in the P, D or N position

A Audio screen, etc.
B Front view & dual side views
C Under vehicle terrain view & dual side views

Front view (magnified)
Under vehicle terrain view (magnified)
Under vehicle terrain view (rear wheel) (magnified)
Under vehicle terrain view (rear wheel) & dual side views
Press the camera switch
Select the Multi-terrain Monitor screen
Select the under vehicle terrain view (rear wheel) button
Select the return button
Select the display mode button

5-4. Using the driving support systems

439

n When the shift position is in the R position

A Rear view & dual side views
C Under vehicle terrain view (rear side) & dual side views

Under vehicle terrain view (rear side) (magnified)
Select the under vehicle terrain view (rear side) button
Select the return button
Select the Multi-terrain Monitor screen
Select the display mode button

Driving

B Wide rear view & dual side views

5

440

5-4. Using the driving support systems

“X-MODE” switch is in off
n When the shift position is in the P position

A Navigation screen, audio screen, etc.
B Pressing the camera switch
C Moving view

See-through view
Touch the display mode switching button

5-4. Using the driving support systems

441

n When the shift position is in the D or N position

A Navigation screen, audio screen, etc.
C Side clearance view & panoramic view

Cornering view & panoramic view
Pressing the camera switch
Touch the display mode switching button
When the steering wheel is turned by 180 degrees or more from the
center (straight-line) position
n When the shift position is in the R position

A Rear view & panoramic view

Driving

B Wide front view & panoramic view

5

442

5-4. Using the driving support systems

B Wide rear view & panoramic view
C Touch the display mode switching button
n Multi-terrain Monitor screen display
l The amount of time that the Multi-terrain Monitor screen is displayed
changes as follows according to the
vehicle speed at the time the camera
switch was pressed.

l The Multi-terrain Monitor screen is

displayed if the vehicle speed is
approximately 20 km/h (12 mph) or
less when the camera switch is
pressed.

l If the vehicle speed exceeds approximately 20 km/h (12 mph), the
Multi-terrain Monitor display is
canceled.

l The guide lines mode and other display settings can be saved by registering the user profile.

l The voice control system can be used
to display the panoramic view monitor
screen, change the screen mode and
for other operations*.
*: This function is not available in some
countries or areas.

Screen display and functions
When the “X-MODE” switch is in
on, the various screens display
information to support several different driving situations, such as
when checking for obstacles when
moving forward or in reverse, or
when judging road surface conditions during off-road driving.

Front view & dual side views
Front view & dual side views can be

used to check the area around the
front of the vehicle.
To display the screen, press the
camera switch when the shift position is in the P, D or N position.
 In addition to an image of the
front of the vehicle, guide lines
are displayed in a composite
view to provide reference for
when deciding a direction to
move forward in.
 If the front view display is
selected while the screen is displayed, the screen switches from
normal to magnified display.
(Selecting the display again
returns the screen to the normal
display)
 If the steering wheel is turned
270° or more, guide lines and
other features to support turning
are automatically displayed.

5-4. Using the driving support systems

443

Screen display

A If the steering wheel is turned 270° or more
B Selecting the display
C 0.5 m (1.5 ft.) distance guide line (red)

1 m (3 ft.) distance guide line (blue)
Items C to

indicate the estimated distance from the front end of the vehicle.

Front tire course line (yellow)
Indicates the estimated course of the front tires according to steering wheel position.

Vehicle width lines (blue)
Indicate the width of the vehicle including the outside rear view mirrors.

Front tire contact line (blue)
Rear tire contact line (blue)
Items

and

indicate estimated tire positions on the image.

Rear tire course line (yellow)
Indicates the estimated course of the rear tires.

Forward movement guide line (blue)
Indicates the estimated tire course of the tightest possible turn.

Toyota parking assist-sensor/slip display (if equipped)
Indicates tire spinning by changing color and flashing the tire displayed. If the

Driving

2 m (6 ft.) distance guide line (blue)

5

444

5-4. Using the driving support systems

Toyota parking assist-sensor detects a static object when the system is enabled, the
indicator is displayed on the screen. (P.444)

Display off button
Changes the screen back to the previously displayed screen, such as the audio
screen.

Display mode switching button
Switches display mode every time touch the button.

Under vehicle terrain view (rear wheel) selection button
Switch the under vehicle terrain view (rear wheel) & dual side views (P.448)

Automatic display mode selection button
P.445

Setting button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

Tilt meter
Displays the vehicle’s estimated degree of incline. (P.444)

n Tilt meter

Tilt meter displays the vehicle inclination to the front, rear, left and
right within a range of 0° to approximately 30°.

Indicates the vehicle inclination in
degrees in the left and right directions.

C Pointer
Indicates the degree of the vehicle inclination in comparison to a parallel line.

n Toyota parking assist-sensor

(if equipped) /slip display
Indicates the tire that is spinning
when tire spinning is detected.

A Degree markers of incline to the
front and rear
Indicates the vehicle inclination in
degrees in the front and rear directions.

B Degree markers of incline to the
left and right

A Tire icon
The tire that is spinning flashes in

5-4. Using the driving support systems
orange.

B Toyota parking assist-sensor
pop-up display
Displayed if an obstacle is detected
while the Toyota parking assist-sensor
is enabled.

Automatic display mode

445

n Front view & dual side views dis-

play
The screen can be displayed when the
shift position is in P, D or N.

n Tilt meter display
l The display indicates the incline of the

vehicle in degrees shown by the
movement of the pointer and the rotation of the vehicle image.

In addition to screen switching by
operating the camera switch, automatic display mode is available. In
this mode, the screen is switched
automatically in response to vehicle
speed.

l The color of the degree markers of

In automatic display mode, the
monitor will automatically display
images in the following situations:

l The degree of incline showed on the

 Touching the automatic display
turns on auto display

 Turning on auto display mode
automatically displays the views
in the following situations:
 When the shift position is in D or
N
 The vehicle decelerates to less
than 10 km/h (6 mph) (the shift
position is in any position other
than R)

l After the power switch is turned to

ON, the degree of incline is not displayed until such information is determined
tilt meter is only an approximate indication, and may differ from the degree
of incline measured using other equipment.

5

l When the degree of incline is larger

than 30°, the pointer will be displayed
beyond 30°.

l If the system malfunctions, the vehicle
image and pointer are not displayed.
In this case, have the vehicle
inspected by any authorized Toyota
retailer or Toyota authorized repairer,
or any reliable repairer.

n Slip display
If the system malfunctions, the tire icon
is not displayed. In this case, have the
vehicle inspected by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.

Under vehicle terrain view & dual side views
Lines indicating current vehicle and tire position are displayed in a composite view on an image taken behind the current vehicle position and assists
the driver to check conditions underneath the vehicle or determine the position of the front tires.
To display the screen, press the camera switch when the shift position is in

Driving

button
mode.

incline to the front, rear, left and right
changes according to the current
incline of the vehicle.

446

5-4. Using the driving support systems

the P, D or N position.
 It is necessary to drive a certain distance or more for the image to be displayed.
 If the under vehicle terrain view display is selected while the screen is
displayed, the screen switches from normal to magnified display. (Selecting the display again returns the screen to the normal display)
Screen display

A Current vehicle position
B Image displayed in the under vehicle terrain view (image taken behind
the current vehicle position)
C Vehicle position at the time the image was taken (behind the current
vehicle position)

Selecting the display
Vehicle width lines (blue)
Indicate the width of the vehicle including the outside rear view mirrors.

Front tire contact line (blue)
Rear tire contact line (blue)
Items

and

indicate estimated tire positions on the image.

0.5 m (1.5 ft.) distance guide line (red, black)
Indicate the estimated distance from the front end of the vehicle.

Rear tire course line (yellow)

5-4. Using the driving support systems

447

Indicates the estimated course of the rear tires.

Tire position indicator lines (black, white)
Indicates the estimated position of the front tires.

Vehicle position indicator lines (blue)
Indicates the estimated position of the vehicle.

Toyota parking assist-sensor/slip display (if equipped)
Indicates tire spinning by changing color and flashing the tire displayed. If the
Toyota parking assist-sensor detects a static object when the system is enabled, the
indicator is displayed on the screen. (P.444)

Display off button
Changes the screen back to the previously displayed screen, such as the audio
screen.

Display mode switching button
Switches display mode every time touch the button.

Under vehicle terrain view (rear wheel) selection button
Switch the under vehicle terrain view (rear wheel) & dual side views (P.448)
5

Automatic display mode selection button
P.447
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

Tilt meter
Displays the vehicle’s estimated degree of incline. (P.444)

Automatic display mode
In addition to screen switching by
operating the camera switch, automatic display mode is available. In
this mode, the screen is switched
automatically in response to vehicle
speed.
In automatic display mode, the
monitor will automatically display
images in the following situations:

 Touching the automatic display
button
mode.

turns on auto display

 Turning on auto display mode
automatically displays the views
in the following situations:
• When the shift position is in D or N
• The vehicle decelerates to less than
10 km/h (6 mph) (the shift position is
in any position other than R)

Driving

Setting button

448

5-4. Using the driving support systems

n Under vehicle terrain view & dual
side views

l The screen can be displayed when
the shift position is in P, D or N.

l In the following situations, under vehi-

cle terrain view will disappear.
• When the vehicle is driven with the
steering wheel turned almost all the
way to one side
• After the EV system starts or the system returns to normal, a fixed distance
or more has not yet been driven
• When the tires are slipping or spinning
• ABS is activated
• When there is a malfunction in the
system

l If the outside rear view mirrors are

folded while the under vehicle terrain
view is being displayed, a separate
screen is displayed.

l If the vehicle is driven with the steer-

ing wheel turned to a certain steering
angle or greater, a part of the screen
may disappear. However, this is not a
malfunction.

l In the following situations, the system

may not operate normally.
• The road is covered with snow
• When there are shadows due to light
sources such as sunlight or illumination
• When driving on slippery roads or
tires are spinning
• Dirt or foreign matter is adhering to
the camera lens
• There is water in front of the vehicle (a
river, puddle, sea water, etc.)
• Optional equipment has been
installed
• When the camera is covered or there
is an object in the image capture
range
• Tires have been replaced
• When the back door is open

• When the steering wheel is operated
at or more than a specified steering
angle
• On roads that are not flat, such as
slopes

l As vision that was captured in the past

is being displayed, the screen and the
actual situation may differ in the following cases:
• An obstacle appears or moves after
vision is captured.
• Sand or snow crumbles and moves
after vision is captured.
• Mud or puddles are in the display
range.
• When the vehicle slips.

WARNING
n Guide lines
The tire position indicator lines and
vehicle position indicator lines may
differ from actual vehicle positions
depending on the number of passengers, cargo weight, road grade, road
surface conditions, brightness of the
surrounding environment, whether
tires or suspension parts other than
those specified are equipped, etc.
Always drive the vehicle while confirming the safety of your
surroundings.
n Under vehicle terrain view dis-

play
The image displayed is one that was
previously taken at a point behind the
current vehicle position. In cases
such as when objects move after the
image is taken, the image displayed
on the screen may differ from the
actual state. In addition, when driving
in the dark such as at night, there are
cases when obstacles cannot be confirmed from the image.

Under vehicle terrain view (rear wheel) & dual side views
Lines indicating current vehicle and tire position are displayed in a composite view on an image taken behind the current vehicle position and assists

5-4. Using the driving support systems

449

the driver to check conditions underneath the vehicle or determine the position of the rear tires.
To display the screen, press the camera switch when the shift position is in
the P, D or N position, select the under vehicle terrain view (rear wheel)
selection switch.
 It is necessary to drive a certain distance or more for the image to be displayed.
 If the under vehicle terrain view display is selected while the screen is
displayed, the screen switches from normal to magnified display. (Selecting the display again returns the screen to the normal display)
Screen display

5

Driving

A Current vehicle position
B Image displayed in the under vehicle terrain view (rear wheel) (image
taken behind the current vehicle position)
C Vehicle position at the time the image was taken (behind the current
vehicle position)

Selecting the display
Tire position indicator lines (black, white)
Indicates the estimated position of the rear tires.

Vehicle position indicator lines (blue)
Indicates the estimated position of the vehicle.

0.5 m (1.5 ft.) distance guide line (red, black)

450

5-4. Using the driving support systems

Indicate the estimated distance from the front end of the vehicle.

Front tire contact line (blue)
Indicate estimated tire positions on the image.

Vehicle width lines (blue)
Indicate the width of the vehicle including the outside rear view mirrors.

Rear tire contact line (blue)
Indicate estimated tire positions on the image.

Toyota parking assist-sensor/slip display (if equipped)
Indicates tire spinning by changing color and flashing the tire displayed. If the
Toyota parking assist-sensor detects a static object when the system is enabled, the
indicator is displayed on the screen. (P.444)

Display off button
Changes the screen back to the previously displayed screen, such as the audio
screen.

Return button
Return to the previous screen

Automatic display mode selection button
P.450

Setting button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

Tilt meter
Displays the vehicle’s estimated degree of incline. (P.444)

Automatic display mode
In addition to screen switching by
operating the camera switch, automatic display mode is available. In
this mode, the screen is switched
automatically in response to vehicle
speed. In automatic display mode,
the monitor will automatically display images in the following situations:
 Touching the automatic display

button
mode.

turns on auto display

 Turning on auto display mode
automatically displays the views
in the following situations:
• When the shift position is in D or N
• The vehicle decelerates to less than
10 km/h (6 mph) (the shift position is
in any position other than R)

5-4. Using the driving support systems

n Under vehicle terrain view (rear
wheel)

l The screen can be displayed when
the shift position is in P, D or N.

l In the following situations, the display

of the under vehicle terrain view (rear
wheel) ends and the screen automatically returns to the most recently used
camera screen. In addition, the under
vehicle terrain view (rear wheel)
selection switch cannot be operated
until the next screen can be displayed.
• When vehicle speed reaches or
exceeds approximately 5 km/h (3
mph)
• When the vehicle is driven with the
steering wheel turned almost all the
way to one side
• When the tires are slipping or spinning
• ABS is activated
• When there is a malfunction in the
system
• When the steering wheel is operated
at or more than a specified steering
angle
folded while the under vehicle terrain
view (rear wheel) is being displayed, a
separate screen is displayed.

l If the vehicle is driven with the steer-

ing wheel turned to a certain steering
angle or greater, a part of the screen
may disappear. However, this is not a
malfunction.

l In the following situations, the system

may not operate normally or may not
be able to switch to the under vehicle
terrain view (rear wheel). In addition,
the under vehicle terrain view (rear
wheel) selection switch cannot be
operated until the next screen can be
displayed.
• The road is covered with snow
• When there are shadows due to light
sources such as sunlight or illumination
• When driving on slippery roads or
tires are spinning
• Dirt or foreign matter is adhering to
the camera lens

• There is water in front of the vehicle (a
river, puddle, sea water, etc.)
• Optional equipment has been
installed
• When the camera is covered or there
is an object in the image capture
range
• Tires have been replaced
• When the back door is open
• When the steering wheel is operated
at or more than a specified steering
angle
• On roads that are not flat, such as
slopes

l As vision that was captured in the past

is being displayed, the screen and the
actual situation may differ in the following cases:
• An obstacle appears or moves after
vision is captured.
• Sand or snow crumbles and moves
after vision is captured.
• Mud or puddles are in the display
range.
• When the vehicle slips.

WARNING
n Guide lines
The tire position indicator lines and
vehicle position indicator lines may
differ from actual vehicle positions
depending on the number of passengers, cargo weight, road grade, road
surface conditions, brightness of the
surrounding environment, whether
tires or suspension parts other than
those specified are equipped, etc.
Always drive the vehicle while confirming the safety of your
surroundings.

5

Driving

l If the outside rear view mirrors are

451

452

5-4. Using the driving support systems

WARNING
n Under vehicle terrain view (rear

wheel) display
The image displayed is one that was
previously taken at a point behind the
current vehicle position. In cases
such as when objects move after the
image is taken, the image displayed
on the screen may differ from the
actual state. In addition, when driving
in the dark such as at night, there are
cases when obstacles cannot be confirmed from the image.

Rear view & dual side views/wide rear view & dual side views
The rear view & dual side views and the wide rear view & dual side views
screen provide support when checking the areas of behind the vehicle and
around the vehicle while backing up, for example while parking.
The screens will be displayed when the shift position is in the R position.
Screen display

A Display mode switching button
Each time the display mode switching button is selected, the mode will change
between the rear view & dual side views mode and the wide rear view & dual side
views mode.

B Front tire contact line (blue)
C Rear tire contact line (blue)
Items B and C indicate estimated tire positions on the image.

Vehicle width extension guide line (blue)

5-4. Using the driving support systems

453

Indicates the estimated vehicle width including the outside rear view mirrors.

Projected course lines (yellow)
Indicate the estimated course of the vehicle according to steering operations.

Distance guide line
Shows the distance behind the vehicle when the steering wheel is turned.
• The guide lines move in conjunction with the estimated course lines.
• The guide lines display points approximately 0.5 m (1.5 ft.) (red) and approximately 1 m (3 ft.) (yellow) from the center of the edge of the bumper.

Rear Camera Detection (if equipped)
Displayed automatically when a pedestrian is detected.

Rear Crossing Traffic Alert/Rear Camera Detection (if equipped)
The indicator is displayed on the screen in the following situations.
• When the rear radar detects an approaching vehicle or obstacle from the rear
• When the rear camera detects a pedestrian to the rear

Toyota parking assist-sensor/slip display (if equipped)
Indicates tire spinning by changing color and flashing the tire displayed. If the
Toyota parking assist-sensor detects a static object when the system is enabled, the
indicator is displayed on the screen. (P.444)

5

Under vehicle terrain view (rear side) selection button
PKSB (Parking Support Brake) (if equipped)
When the system determines that the possibility of a collision with detected target
objects is high, a warning message is displayed. (P.386)

Setting button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

Guide line switching button
Each time the guide line switching button is selected, the mode will change between
the estimated course line mode and the vehicle center estimated course line mode.

Vehicle center estimated course line
Shows a vehicle center estimated course when the steering wheel is turned.

Tilt meter
Displays the vehicle’s estimated degree of incline. (P.444)

Driving

Switch the under vehicle terrain view (rear side) & dual side views (P.455)

454

5-4. Using the driving support systems

n Rear view & dual side views/wide rear view & dual side views
l The monitor is canceled when the shift position is shifted into any position other
than the R position.

l For details about the Toyota parking assist-sensor (P.366), Rear Crossing Traffic
Alert function (P.375) and Parking Support Brake function (P.384). (if
equipped)

l The display position of the Toyota parking assist-sensor and the position of obstacles displayed in the camera image do not match. (if equipped)

n Guide lines
If the back door is not closed, guide lines will not be displayed. If the guide lines do
not display even when the back door is closed, have the vehicle inspected at any
authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

WARNING
n Toyota parking assist-sensor display (if equipped)
When a sensor indicator on the Toyota parking assist-sensor display illuminates in
red or a buzzer sounds continuously, be sure to check the area around the vehicle
immediately and do not proceed any further until safety has been ensured, otherwise an unexpected accident may occur.
n Rear view & dual side views/wide rear view & dual side views display

(vehicles with Toyota parking assist-sensor and Rear Crossing Traffic
Alert)
As the Toyota parking assist-sensor display and Rear Crossing Traffic Alert display are displayed over the camera view, it may be difficult to see the Toyota parking assist-sensor display and Rear Crossing Traffic Alert display depending on the
color and brightness of the surrounding area.

Parking
When parking in a space which is in
the reverse direction to the space
described in the procedure below,
the steering directions will be
reversed.
1 Shift the shift position to the R
position.
2 Turn the steering wheel so that
the estimated course lines are

5-4. Using the driving support systems

within the parking space, and
back up slowly.

455

dividing lines of the parking
space.

5

A Estimated course lines

B Estimated course lines

4 Once the estimated course lines
and the parking space lines are
parallel, straighten the steering
wheel and back up slowly until
the vehicle has completely
entered the parking space.

3 When the rear position of the
vehicle has entered the parking
space, turn the steering wheel
so that the vehicle width guide
lines are within the left and right

5 Stop the vehicle in an appropriate place, and finish parking.

Under vehicle terrain view (rear side) & dual side views
Lines indicating current vehicle and tire position are displayed in a composite view on an image taken in front of the current vehicle position and
assists the driver to check conditions underneath the vehicle or determine
the position of the rear tires.
To display the screen, when the shift position is in the R position, select the
under vehicle terrain view (rear side) selection switch.
 It is necessary to drive a certain distance or more for the image to be dis-

Driving

A Parking space

456

5-4. Using the driving support systems

played.
 If the under vehicle terrain view display is selected while the screen is
displayed, the screen switches from normal to magnified display. (Selecting the display again returns the screen to the normal display)
Screen display

A Current vehicle position
B Image displayed in the under vehicle terrain view (rear side) (image
taken in front of the current vehicle position)
C Vehicle position at the time the image was taken (in front of the current
vehicle position)

Front tire contact line (blue)
Indicate estimated tire positions on the image.

Vehicle width lines (blue)
Indicate the width of the vehicle including the outside rear view mirrors.

Rear tire contact line (blue)
Indicate estimated tire positions on the image.

Tire position indicator lines (black, white)
Indicates the estimated position of the rear tires.

Vehicle position indicator lines (blue)
Indicates the estimated position of the vehicle.

Toyota parking assist-sensor/slip display (if equipped)
Indicates tire spinning by changing color and flashing the tire displayed. If the

5-4. Using the driving support systems

457

Toyota parking assist-sensor detects a static object when the system is enabled, the
indicator is displayed on the screen. (P.444)

Return switch
Return to the previous screen

Selecting the display
Setting button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

Tilt meter
Displays the vehicle’s estimated degree of incline. (P.444)

n Under vehicle terrain view (rear
side)

l The screen can be displayed when
the shift position is in R.

l While the under vehicle terrain view

l In the following situations, the display

of the under vehicle terrain view (rear
side) ends and the screen automatically returns to the most recently used
camera screen. In addition, the under
vehicle terrain view (rear side)
selection switch cannot be operated
until the next screen can be displayed.
• When the tires are slipping or spinning
• ABS is activated
• When there is a malfunction in the
system
• Rear Crossing Traffic Alert, Rear
Camera Detection or Parking Support
Brake is activated (if equipped)
• When the back door is open

l If the outside rear view mirrors are

folded while the under vehicle terrain
view (rear side) is being displayed, a
separate screen is displayed.

l If the vehicle is driven with the steer-

ing wheel turned to a certain steering
angle or greater, a part of the screen

l In the following situations, the system

may not operate normally or may not
be able to switch to the under vehicle
terrain view (rear side). In addition,
the under vehicle terrain view (rear
side) selection switch cannot be operated until the next screen can be displayed.
• The road is covered with snow
• When there are shadows due to light
sources such as sunlight or illumination
• When driving on slippery roads or
tires are spinning
• Dirt or foreign matter is adhering to
the camera lens
• There is water in front of the vehicle (a
river, puddle, sea water, etc.)
• Optional equipment has been
installed
• When the camera is covered or there
is an object in the image capture
range
• Tires have been replaced
• When the back door is open
• When the steering wheel is operated
at or more than a specified steering
angle
• On roads that are not flat, such as
slopes

5

Driving

(rear side) is displayed, if the vehicle
speed reaches or exceeds approximately 5 km/h (3 mph), the screen
automatically returns to the previous
display.

may disappear. However, this is not a
malfunction.

458

5-4. Using the driving support systems

WARNING
n Guide lines
The tire position indicator lines and
vehicle position indicator lines may
differ from actual vehicle positions
depending on the number of passengers, cargo weight, road grade, road
surface conditions, brightness of the
surrounding environment, whether
tires or suspension parts other than
those specified are equipped, etc.
Always drive the vehicle while confirming the safety of your
surroundings.

n Under vehicle terrain view (rear
side) display

l The image displayed is one that

l The area covered by the camera is
limited. When driving, be sure to
check the vehicle’s surroundings
with your own eyes and the vehicle’s mirrors.

Screen display and functions
When the “X-MODE” switch is in
off, the various screens display
information to support several different driving situations, such as
when checking for obstacles when
moving forward

was previously taken at a point in
front of the current vehicle position.
In cases such as when objects
move after the image is taken, the
image displayed on the screen may
differ from the actual state. In addition, when driving in the dark such
as at night, there are cases when
obstacles cannot be confirmed from
the image.

Display mode when the shift position is in P
This is a mode that displays images combined from the cameras to enable
you to check obstacles around the vehicle. Images are displayed as if seen
from the driver’s seat and on an angle from above the vehicle.
Screen display
1 Shift the shift position to P.
2 Press the camera switch.
 The mode changes every time the display mode switching button is

5-4. Using the driving support systems

459

touched.
 Pressing the camera switch again returns the display to the previous
screen, such as the navigation screen.
 Moving view

A Screen off button
Turns off the camera screen and returns the previous screen, such as the audio
screen.

B Display mode switching button
Switches between see-through view and moving view.

5

C Rotation pause/resume button

Customize settings button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

Voice recognition icon*
This icon is displayed when the voice control system is in operation.
*: This function is not available in some countries or areas.

 See-through view

Driving

Pauses and resumes the rotation of the display.

460

5-4. Using the driving support systems

A Screen off button
Turns off the camera screen and returns the previous screen, such as the audio
screen.

B Display mode switching button
Switches between see-through view and moving view.

C Rotation pause/resume button
Pauses and resumes the rotation of the display.

Customize settings button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

Voice recognition icon*
This icon is displayed when the voice control system is in operation.
*: This function is not available in some countries or areas.

l When the Toyota parking assist-sensor (P.366) is turned on, you can display
see-through view or moving view. (if equipped)

l You can also pause and resume the rotation of the see-through view and moving
view screen by touching any point on the screen.

Display mode when the shift position is in D or N
You can check for nearby pedestrians, bicycles, and vehicles at intersections with poor visibility and T-junctions by displaying vision of your
surroundings on the screen. This mode also provides support to check both
sides of the vehicle for safety, avoid collisions on narrow roads, and pulling
over to the side of the road.
Screen display
1 Shift the shift position to D or N.
2 Press the camera switch.
 The mode changes every time you press the camera switch.
 If the cornering view mode is on and you turn the steering wheel more
than 180 degrees from the straight position, the display will change from
side clearance view & panoramic view to cornering view & panoramic
view.

5-4. Using the driving support systems

461

 Wide front view & panoramic view

A Front distance guide lines
Displays about 1 m (3 ft.) in front of the vehicle.

B Forward estimated course lines
Displays course lines that are linked to operation of the steering wheel. (Yellow)
These lines are displayed when the steering wheel is turned more than 90 degrees
from the straight position.

FCTA (Front Crossing Traffic Alert) (if equipped)
If FCTA detects nearby vehicles and/or obstacles from the front or side of the vehicle, an indicator is displayed on the screen.

Screen off button
Turns off the camera screen and returns the previous screen, such as the navigation.

Display mode switching button
Switches display mode every time you touch the button.

Guide line switching button
Switches guide line mode every time you touch the button. (P.465)

Automatic display button
Turns the auto display mode on or off. When the shift position is in D or N, wide front
view & panoramic view or side clearance view/cornering view & panoramic view will
be automatically displayed in accordance with the vehicle speed. (P.466)

Driving

C Toyota parking assist-sensor (if equipped)
Displays an indicator on the screen and sounds a buzzer when an object is detected
by a sensor.

5

462

5-4. Using the driving support systems

Customize settings button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

Camera dirt detection icon
This icon is displayed when dirt is detected on the camera.

PKSB (Parking Support Brake) (if equipped)
If an obstacle that you may collide with is detected, a message is displayed on the
screen. (P.386)

Voice recognition icon*
This icon is displayed when the voice control system is in operation.

Toyota parking assist-sensor mute button (if equipped)
This button temporarily mutes the Toyota parking assist-sensor sound.
*: This function is not available in some countries or areas.

 Side clearance view & panoramic view

A Forward estimated course lines
Displays course lines that are linked to operation of the steering wheel. (Yellow)
These lines are displayed when the steering wheel is turned more than 90 degrees
from the straight position.

B Vehicle width guide lines
Shows guide lines of the vehicle’s width including the outside rear view mirrors.

C Front distance guide lines
Displays about 1 m (3 ft.) in front of the vehicle.

5-4. Using the driving support systems

463

Toyota parking assist-sensor (if equipped)
Displays an indicator on the screen and sounds a buzzer when an object is detected
by a sensor.

Front tire guide lines
Displays the position of the front tires.

FCTA (Front Crossing Traffic Alert) (if equipped)
If FCTA detects nearby vehicles and/or obstacles from the front or side of the vehicle, an indicator is displayed on the screen.

Screen off button
Turns off the camera screen and returns the previous screen, such as the navigation.

Display mode switching button
Switches display mode every time you touch the button.

Guide line switching button
Switches guide line mode every time you touch the button. (P.465)

Automatic display button

Customize settings button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

Camera dirt detection icon
This icon is displayed when dirt is detected on the camera.

PKSB (Parking Support Brake) (if equipped)
If an obstacle that you may collide with is detected, a message is displayed on the
screen. (P.386)

Voice recognition icon*
This icon is displayed when the voice control system is in operation.

Toyota parking assist-sensor mute button (if equipped)
This button temporarily mutes the Toyota parking assist-sensor sound.
*: This function is not available in some countries or areas.

5

Driving

Turns the auto display mode on or off. When the shift position is in D or N, wide front
view & panoramic view or side clearance view/cornering view & panoramic view will
be automatically displayed in accordance with the vehicle speed.

464

5-4. Using the driving support systems

 Cornering view & panoramic view

A Forward estimated course lines
Displays course lines that are linked to operation of the steering wheel. (Yellow)
These lines are displayed when the steering wheel is turned more than 90 degrees
from the straight position.

B Vehicle width guide lines
Shows guide lines of the vehicle’s width including the outside rear view mirrors.

C Front distance guide lines
Displays about 1 m (3 ft.) in front of the vehicle.

Toyota parking assist-sensor (if equipped)
Displays an indicator on the screen and sounds a buzzer when an object is detected
by a sensor.

Front tire guide lines
Displays the position of the front tires.

FCTA (Front Crossing Traffic Alert) (if equipped)
If FCTA detects nearby vehicles and/or obstacles from the front or side of the vehicle, an indicator is displayed on the screen.

Screen off button
Turns off the camera screen and returns the previous screen, such as the navigation.

Display mode switching button
Switches display mode every time you touch the button.

Guide line switching button
Switches guide line mode every time you touch the button. (P.465)

5-4. Using the driving support systems

465

Automatic display button
Turns the auto display mode on or off. When the shift position is in D or N, wide front
view & panoramic view or side clearance view/cornering view & panoramic view will
be automatically displayed in accordance with the vehicle speed.

Customize settings button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

Camera dirt detection icon
This icon is displayed when dirt is detected on the camera.

PKSB (Parking Support Brake) (if equipped)
If an obstacle that you may collide with is detected, a message is displayed on the
screen. (P.386)

Voice recognition icon*
This icon is displayed when the voice control system is in operation.

Toyota parking assist-sensor mute button (if equipped)
This button temporarily mutes the Toyota parking assist-sensor sound.
*: This function is not available in some countries or areas.

view display (vehicles with Toyota parking assist-sensor)

l When the Toyota parking assist-sensor (P.366) is turned on, you can display
side clearance view & panoramic view/cornering view.

l The display position of the Toyota parking assist-sensor may not match the position of the obstacle displayed in the camera image.

WARNING
n Guide line
The position of the guide lines displayed on the screen may change due to factors
such as number of passengers, load weight, and road gradient. Always make sure
to visually check behind you and your surroundings while you are driving.
n Toyota parking assist-sensor and FCTA (Front Crossing Traffic Alert) dis-

play (if equipped)
The Toyota parking assist-sensor and Front Crossing Traffic Alert (FCTA) displays
are superimposed on the camera image, so it may be difficult to see depending on
the brightness of the surroundings and colors.

Changing the guide line display
mode

The guide line display mode
changes every time the guide line

Driving

n Side Clearance View & panoramic view screen/Cornering View & panoramic

5

466

5-4. Using the driving support systems

display mode button is touched.
 Distance guide lines mode

button
mode.

turns on auto display

 Turning on auto display mode
automatically displays the views
in the following situations:
• When the shift position is in D or N
• The vehicle decelerates to less than
10 km/h (6 mph) (the shift position is
in any position other than R)

Displays about 1 m (3 ft.) in front of the
vehicle. (blue)
 Estimated course lines mode

Cornering view auto display
You can set the cornering view auto
display mode to automatically display cornering view & panoramic
view in accordance with the operation of the steering wheel.
 Turning on cornering view auto
display mode automatically displays cornering view in the following situations:
• When the shift position is in D or N

Displays course lines that are linked to
operation of the steering wheel. (Yellow) These lines are displayed when
the steering wheel is turned more than
90 degrees from the straight position.

Auto display mode
Although you can display wide front
view & panoramic view and side
clearance view & panoramic
view/cornering view by pressing the
camera switch, you can also set
auto display mode to display the
views automatically in accordance
with the vehicle speed.
 Touching the automatic display

• The vehicle decelerates to less than
12 km/h (7 mph)
• When the steering wheel is turned by
180 degrees or more from the center
(straight-line) position

n Cornering view auto display
You can change cornering view auto
mode in the custom settings.

Toyota parking assist-sensor
linked display (if equipped)
Depending on the Toyota parking
assist-sensor detection state, wide
front view & panoramic view/Side
clearance view/Cornering view &
panoramic view will be displayed.

5-4. Using the driving support systems

467

 The views are displayed automatically when the Toyota parking assist-sensor detects an
obstacle (when the shift position
is in D or N).
 The display returns to the previous screen automatically when
the Toyota parking assist-sensor
stops detecting an obstacle.
n Toyota parking assist-sensor linked
display

l You can also return to the previous

screen by pressing the camera switch
displayed on the screen.

l If the panoramic view monitor screen

is canceled when an obstacle is
detected, the panoramic view monitor
screen can be displayed again by
touching the Toyota parking
assist-sensor mark shown on the multimedia system screen.

n Side Clearance View & pano-

ramic view
 Check the positional relationship
between the vehicle width guide
lines and an obstacle.
 Turn the steering wheel and
drive forward so that the vehicle
width guide lines do not overlap
the actual obstacle.

 Pull the vehicle over so that the
vehicle width guide lines do not
overlap the obstacle as shown in
the figure.
 By driving with the vehicle width
guide lines parallel to the object,
you can park alongside the
object.

5

Driving

Using the vehicle width guide lines

 Check the positional relationship
between the vehicle width guide
lines and an object such as
curbs on the shoulder of a road.

468

5-4. Using the driving support systems

between the forward estimated
course lines and an obstacle.
 Turn the steering wheel and
drive forward so that the forward
estimated course lines do not
overlap the actual obstacle.

Using the forward estimated
course lines
n Cornering View & panoramic

view
 Check the positional relationship

Display mode when the shift position is in R
To check for safety when parking the vehicle, an image is displayed from
above the vehicle and from the rear camera.
Screen display
1 Shift the shift position to R.
The mode changes every time you touch the display mode switching button.

5-4. Using the driving support systems

469

 Rear view & panoramic view

A Camera dirt detection icon
This icon is displayed when dirt is detected on the camera.

B Toyota parking assist-sensor (if equipped)
Displays an indicator on the screen and sounds a buzzer when an object is detected
by a sensor.
Switches display mode every time you touch the button.

Guide line switching button
Switches guide line mode every time you touch the button. (P.471)

RCTA (Rear Crossing Traffic Alert)/RCD (Rear Camera Detection) (if
equipped)
The indicator is displayed on the screen in the following situations.
• When the rear radar detects an approaching vehicle or obstacle from the rear
• When the rear camera detects a pedestrian to the rear

Customize settings button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

RCD (Rear Camera Detection) (if equipped)
If the rear camera detects a pedestrian behind the vehicle, an indicator is displayed
on the screen.

PKSB (Parking Support Brake) (if equipped)
If an obstacle that you may collide with is detected, a message is displayed on the

Driving

C Display mode switching button

5

470

5-4. Using the driving support systems

screen. (P.386)

Voice recognition icon*
This icon is displayed when the voice control system is in operation.

Toyota parking assist-sensor/RCTA (Rear Crossing Traffic Alert)/RCD
(Rear Camera Detection) mute button (if equipped)
This button temporarily mutes the Toyota parking assist-sensor, RCTA (Rear Crossing Traffic Alert) and RCD (Rear Camera Detection) buzzer sound. Operating the
shift automatically cancels mute.
*: This function is not available in some countries or areas.

 Wide rear view & panoramic view

A Camera dirt detection icon
This icon is displayed when dirt is detected on the camera.

B Toyota parking assist-sensor (if equipped)
Displays an indicator on the screen and sounds a buzzer when an object is detected
by a sensor.

C Display mode switching button
Switches display mode every time you touch the button.

Guide line switching button
Switches guide line mode every time you touch the button. (P.471)

RCTA (Rear Crossing Traffic Alert)/RCD (Rear Camera Detection) (if
equipped)
The indicator is displayed on the screen in the following situations.
• When the rear radar detects an approaching vehicle or obstacle from the rear
• When the rear camera detects a pedestrian to the rear

5-4. Using the driving support systems

471

Customize settings button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance (if equipped).
(P.480)

RCD (Rear Camera Detection) (if equipped)
If the rear camera detects a pedestrian behind the vehicle, an indicator is displayed
on the screen.

PKSB (Parking Support Brake) (if equipped)
If an obstacle that you may collide with is detected, a message is displayed on the
screen. (P.386)

Voice recognition icon*
This icon is displayed when the voice control system is in operation.

Toyota parking assist-sensor/RCTA (Rear Crossing Traffic Alert)/RCD
(Rear Camera Detection) mute button (if equipped)
This button temporarily mutes the Toyota parking assist-sensor, RCTA (Rear Crossing Traffic Alert) and RCD (Rear Camera Detection) buzzer sound. Operating the
shift automatically cancels mute.
*: This function is not available in some countries or areas.

5

n Rear view & panoramic view/wide rear view & panoramic view display
l Pressing the camera switch when the shift position is in R enables you to change

Driving

to panoramic view & wide front view.

l The display position of the Toyota parking assist-sensor (P.366) may not match
the position of the obstacle displayed in the camera image. (if equipped)

WARNING
n Guide line
The position of the guide lines displayed on the screen may change due to factors
such as number of passengers, load weight, and road gradient. Always make sure
to visually check behind you and your surroundings while you are driving.

n Toyota parking assist-sensor, RCTA (Rear Crossing Traffic Alert) and RCD

(Rear Camera Detection) display (if equipped)
The Toyota parking assist-sensor, RCTA (Rear Crossing Traffic Alert) and RCD
(Rear Camera Detection) displays are overlapped and displayed on the camera
image, so it may be difficult to see depending on the brightness of the
surroundings and colors.

Changing the guide line display mode
The guide line display mode changes every time you touch the guide line

472

5-4. Using the driving support systems

switching button.
 Estimated course lines mode

This mode displays estimated course lines that move in accordance with
the operation of the steering wheel.

A Front distance guide lines
Displays about 1 m (3 ft.) (blue) in front of the vehicle.

B Side estimated course lines
Displays course lines (yellow) that are linked to operation of the steering wheel.

C Reverse estimated course lines
Displays course lines (yellow) that are linked to operation of the steering wheel.

Rear distance guide lines
Displays the distance behind the vehicle.
• The distance guide line is linked to the estimated course lines.
• Displays about 0.5 m (1.5 ft.) (red) and 1 m (3 ft.) (yellow) from the center end of
the rear bumper.

Rear distance guide line
Displays about 0.5 m (1.5 ft.) (blue) from the end of the rear bumper.

Vehicle width guide lines
Displays course lines when the vehicle is being reversed in a straight line.
• The lines are wider than the actual width of the vehicle.
• When the vehicle is straight, the guide lines will overlap with the estimated course
lines.

Vehicle center guide line
Displays the center of the vehicle width guide lines.
 Parking assist guide lines mode

This mode displays the steering wheel return points (parking assist guide
lines). This mode is recommended for those who have a sense of the vehicle and can park the vehicle without the aid of the estimated course lines.

5-4. Using the driving support systems

473

A Front distance guide lines
Displays about 1 m (3 ft.) (blue) in front of the vehicle.

B Rear distance guide lines
Displays the distance behind the vehicle.
• Displays about 0.5 m (1.5 ft.) (red) from the center end of the rear bumper.

C Vehicle center guide line
Displays the center of the vehicle width guide lines.

Vehicle width guide lines
Displays course lines when the vehicle is being reversed in a straight line.
• The lines are wider than the actual width of the vehicle.
Displays the course lines of the smallest turn possible behind the vehicle.
• Use the position of operating the steering wheel when parking as a guide.
 Distance guide lines mode

This mode only displays the distance guide lines. It is recommended for
those who do not need the guide lines.

A Front distance guide lines
Displays about 1 m (3 ft.) (blue) in front of the vehicle.

B Rear distance guide lines

Driving

Parking assist guide lines

5

474

5-4. Using the driving support systems

Displays the distance behind the vehicle.
• Displays about 0.5 m (1.5 ft.) (red) from the center end of the rear bumper.
 Estimated course center line mode

This mode displays estimated course lines and a vehicle center guide line
that move in accordance with the operation of the steering wheel.
Use this mode when approaching a signpost or pole with the center of the
rear bumper.

A Front distance guide lines
Displays about 1 m (3 ft.) (blue) in front of the vehicle.

B Side estimated course lines
Displays course lines (yellow) that are linked to operation of the steering wheel.

C Rear distance guide lines
Displays the distance behind the vehicle.
• The distance guide line is linked to the estimated course lines.
• Displays about 0.5 m (1.5 ft.) (red) and 1 m (3 ft.) (yellow) from the center end of
the rear bumper.

Reverse estimated course lines
Displays course lines (yellow) that are linked to operation of the steering wheel.

Estimated course center line
Displays the vehicle center guide line (green) that is linked to operation of the steering wheel.

n Guide line display mode
The guide lines will not be displayed if the back door is not closed. If the back door is
closed but the guide lines are still not displayed, have the vehicle inspected by any
authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

5-4. Using the driving support systems

475

WARNING
n Guide line display mode
The rear vehicle width guide lines are wider than the actual width of the vehicle.
Always make sure to visually check behind you and your surroundings when you
are reversing.

Parking using the estimated
course lines mode

within the left and right dividing
lines of the parking space.

1 Shift the shift position to R.
2 Turn the steering wheel so that
the estimated course lines are
within the parking space and
then reverse slowly.

5

Driving

A Vehicle width guide lines

A Parking space
B Estimated course lines

3 When the rear of the vehicle has
entered the parking space, turn
the steering wheel so that the
vehicle width guide lines are

4 Once the vehicle width guide
lines and the parking space
lines are parallel, straighten the
steering wheel and reverse
slowly until the vehicle has completely entered the parking
space.
5 Stop the vehicle in an appropriate place to finish parking.

476

5-4. Using the driving support systems

Parking using the parking
assist guide lines mode
1 Shift the shift position to R.
2 Reverse until the parking assist
guide lines align with the
right-hand dividing line of the
parking space.

A Parking assist guide lines
B Parking space dividing lines

3 Turn the steering wheel all the
way to the left, and reverse
slowly.
4 Once the vehicle is parallel with
the parking space, straighten
the steering wheel and reverse
slowly until the vehicle has completely entered the parking
space.
5 Stop the vehicle in an appropriate place to finish parking.

The screen when the outside rear view mirrors are folded
When the outside rear view mirrors are folded, an image from the side cameras rather than panoramic view will be displayed. This can assist you in
confirming that the vicinity of the vehicle is safe when you are parking in a
narrow place.

5-4. Using the driving support systems

477

Screen display
 Side view & Wide front view

A Side views
B Toyota parking assist-sensor (if equipped)
Displays an indicator on the screen and sounds a buzzer when an object is detected
by a sensor.

C Wide front view
 Side view & Rear view

5

Driving

A Side views
B Toyota parking assist-sensor (if equipped)
Displays an indicator on the screen and sounds a buzzer when an object is detected
by a sensor.

C Rear view

478

5-4. Using the driving support systems

 Side view & Wide rear view

A Side views
B Toyota parking assist-sensor (if equipped)
Displays an indicator on the screen and sounds a buzzer when an object is detected
by a sensor.

C Wide rear view
n Toyota parking assist-sensor display (if equipped)
The display position of the Toyota parking assist-sensor (P.366) may not match the
position of the obstacle displayed in the camera image. (if equipped)

Zooming in on the screen
Zooming in on the screen can be done if the image on the screen is too
small and hard to see.
Touch the area that you want to zoom in on the panoramic view.
Screen display

 The selected area is zoomed in on.
 You can zoom in on either the area in front of the vehicle or the area
behind it in panoramic view.

5-4. Using the driving support systems

479

 To cancel the zoom, touch the screen again.
n Zooming in on the screen
l The zoom feature is enabled when all of the following conditions are met:

• The vehicle speed is below 12 km/h (7 mph)
• The Toyota parking assist-sensor (P.366) is turned on (if equipped)

l In any of the following situations, the zoom feature will be canceled automatically:
• The vehicle speed is above 12 km/h (7 mph)
• The Toyota parking assist-sensor is turned off (if equipped)
l The guide lines will not be displayed when the panoramic view is zoomed.

Displaying transparent underfloor vision
A composite of camera vision captured in the past from the current vehicle
position to assist understanding of the situation under the vehicle, tire positions, and so on can be displayed. The vision is displayed in panoramic
view, side clearance view, or cornering view.
Screen display
5

Driving

A Tire tracks
Displays the tire position guides linked to the steering wheel.

B Vehicle guide lines
Displays the exterior of the vehicle.

n Transparent underfloor vision
l Transparent underfloor vision is displayed when the setting on the customized setting screen is turned on and the vehicle is moving forward or backward.

l Transparent underfloor vision is not displayed in the following cases:

• The vehicle speed is above 20 km/h (12 mph)
• The vehicle stops and a certain amount of time passes.
• If the vehicle does not move a certain distance after it is started.
• The side mirrors are folded.

480

5-4. Using the driving support systems

• ABS is operating.
• The system is not functioning correctly.

l The system may not function correctly in the following situations:
• Snow covered roads.
• There are shadows from lights and so forth.
• There is dirt or a foreign object on the camera lens.
• Water (river, sea, etc.).
• Optional equipment has been installed.
• There is an obstacle in front of the camera.
• The tires were replaced.
• The back door is open and the camera is not in the correct position.
• The road surface is slippery or the wheels slip.
• The vehicle is on a hill or other steep roads.
l As vision that was captured in the past is being displayed, the screen and the

actual situation may differ in the following cases:
• An obstacle appears or moves after vision is captured.
• Sand or snow crumbles and moves after vision is captured.
• Mud or puddles are in the display range.
• When the vehicle slips.

l Part or all of the transparent underfloor vision may appear black in the following

cases:
• The vehicle starts moving with no captured vision.
• The steering wheel is turned more than a certain angle.
• The vehicle stops and a certain amount of time passes.

WARNING
n Transparent underfloor vision
l The tire and vehicle guide lines may not align correctly with the actual vehicle

position due to the number of passengers, vehicle load, road gradient, road surface conditions, brightness of the surroundings, optional equipment, tire
replacements, and other reasons. Always make sure to check your
surroundings while you are driving.

l Displayed vision is vision that was captured in the past. Therefore, if obstacles
and other objects move after being captured, the transparent underfloor vision
and the actual situation may not always match.

Changing the Multi-terrain
Monitor settings
Settings related to Multi-terrain
Monitor such as the cornering view
auto display and vehicle body color
can be changed.

5-4. Using the driving support systems

1 Touch the

.

481

n Suspension of the settings display
For safety purposes, you cannot display
the custom settings screen while the
vehicle is moving.

When using the Multi-terrain Monitor

2 Select the desired item.
 Cornering view
Automatically display the cornering
view.

Observe the following precautions.
Failure to do so may result in an
unexpected accident. Also, when
driving, make sure to directly confirm the safety of your surroundings
and the area to the rear of the vehicle.

 View Under Vehicle

WARNING
n Conditions under which the

Multi-terrain Monitor should not
be used
Do not use the Multi-terrain Monitor in
the following situations. The system
may not operate properly, resulting in
an unexpected accident.

l On icy or slick road surfaces, or in
snow

l When using tire chains or emergency tires

 Toyota Park Assist 3D Display (if
equipped)

l When the front door(s) or back door

Show or hide the Toyota parking
assist-sensor 3D display.

l On roads that are not flat, such as

 Toyota Park Assist Distance (if
equipped)

l If the tires of a size other than spec-

Change the distance that the Toyota
parking assist-sensor starts detecting
obstacles.

 Vehicle Body Color
Change the vehicle body color displayed on the screen.

are not closed completely
hills

ified by Toyota are installed

l If the suspension has been modified

l If a non-Toyota product is installed

on the area displayed on the screen

5

Driving

Turn the transparent underfloor vision
display setting on or off. Setting it to on
and moving the vehicle forward or
backwards displays a composite of
camera vision captured in the past from
the current vehicle position to assist
understanding of the situation under the
vehicle, front tire positions, and so on.
The vision is displayed in panoramic
view, side clearance view, or cornering
view.

482

5-4. Using the driving support systems

WARNING
n Guide lines
The tire position indicator lines and
vehicle position indicator lines may
differ from actual vehicle positions
depending on the number of passengers, cargo weight, road grade, road
surface conditions, brightness of the
surrounding environment, etc. Always
drive the vehicle while confirming the
safety of your surroundings.

NOTICE
n Panoramic view
l See-through view, moving view,

panoramic view, side clearance
view, and cornering view produce
an image that is a composite of
images captured by the front camera, rear camera, and side cameras. As there is a limit to the
displayable range and content,
make sure you fully understand the
features of the panoramic view
monitor before you use it.

l The four corners of the see-through

view, moving view, panoramic view,
side clearance view, and cornering
view have a video composition processing region centered on borders of the cameras, and image
clarity may decline. However this is
not a fault.

l Depending on lighting conditions

near each camera, bright and dark
patches may appear on the
see-through view, moving view,
panoramic view, side clearance
view, and cornering view.

l See-through view, moving view,

panoramic view, side clearance
view, and cornering view does not
extend higher than the installation
position and image capture range
of each camera.

l There are blind spots around the

vehicle and as such there are
regions not displayed on the panoramic view monitor.

l Three-dimensional objects dis-

played in wide front view, rear view,
wide rear view or side view may not
be displayed in see-through view,
moving view, panoramic view, side
clearance view, and cornering view.

l People and other three-dimensional
obstacles may appear differently
when displayed on the panoramic
view monitor. (These differences
include cases in which displayed
objects appear to have fallen over,
disappear near image processing
regions, appear from video composition processing areas, or when
the actual distance to an object differs from the displayed position.)

l When the back door, which is

equipped with the rear camera, or
front doors, which are equipped
with side mirrors that have the
built-in side cameras, are open,
images will not be displayed properly on the panoramic view monitor.

l The vehicle icon displayed in

see-through view, moving view,
panoramic view, side clearance
view, and cornering view is a computer generated image, so the
color, shape and size will differ from
the actual vehicle. Therefore,
nearby three-dimensional objects
may appear to be touching the vehicle, and actual distances to
three-dimensional objects may differ from those displayed.

5-4. Using the driving support systems

483

Area displayed on the screen
There are blind spots around the vehicle and as such there are regions not
displayed on the screen. Even if nothing around the vehicle is displayed on
the screen, there may actually be obstacles on the road, which you may
collide with. Always make sure to visually check your surroundings.

5

A Area displayed on the screen
Objects in the black areas do not appear on the screen.

A Area displayed on the screen
B Parts of objects not displayed on the screen
Parts higher than the road do not appear on the screen.

Driving

B Objects not displayed on the screen

484

5-4. Using the driving support systems

n Area displayed on screen
l The black parts around the vehicle

icon are not displayed by the camera.
Visually check those areas.

l As the images are obtained from four

cameras are processed and displayed
on the standard of a flat road surface,
see-through view, moving view, panoramic view (including zoomed display), side clearance view, and
cornering view may be displayed as
follows:
• Objects may look collapsed; thinner or
bigger than usual.
• An object with a higher position than
the road surface may look further
away than it actually is or may not
appear at all.
• Tall objects may appear protruding
from the non-displayed areas of the
image.

n Wide front view

l Variations in the brightness of the

image may appear for every camera
due to lighting conditions.

l The displayed image may be mis-

aligned due to inclination of the vehicle body or change in vehicle height
caused by the number of passengers,
vehicle load.

l If the doors are not completely closed,
the image and the guide lines may not
be displayed correctly.

l The positional relationship of the road
surface and objects with the vehicle
icon displayed on see-through view,
moving view, panoramic view (including zoomed display), side clearance
view, and cornering view may differ to
the actual positions.

A Area displayed on the screen
B Objects not displayed on the
screen
Areas close to both corners of the
bumpers will not appear on the screen.

l Light from a back-lit license plate may
appear on the screen.

l Images indicated by

in the figure
are a composite, and hence some
areas may be difficult to see.

n Display range
l The area covered by the camera is

limited. Objects that are close to either
corner of the bumper or under the
bumper cannot be displayed on the
screen.

l The depth perception of the image

displayed on the screen differs to the

5-4. Using the driving support systems
actual distance.

485

 Rear view

l The wide front view camera uses a

special lens, so the depth perception
of the image displayed on the screen
differs to the actual distance.

 Side view & Rear view (when the

side mirrors are folded)

A Area displayed on the screen

Areas close to both corners of the
bumpers will not appear on the screen.

A Area displayed on the screen
n Display range
l The range that is displayed on the

screen may differ due to the state of
the vehicle and road surface.

l The area covered by the camera is

limited. Objects that are close to the
bumper on the passenger’s side or
under the bumper cannot be displayed on the screen.

l The depth perception of the image

displayed on the screen differs to the
actual distance.

l The cameras on side view & rear view
use a special lens, so the depth perception of the image displayed on the
screen differs to the actual distance.

Driving

B Objects not displayed on the
screen

5

486

5-4. Using the driving support systems

 Wide rear view

camera may not appear in the monitor.

l Light from a back-lit license plate may
appear on the screen.

Camera position
The Multi-terrain Monitor cameras
are in the locations shown in the
figures.
n Front camera

A Area displayed on the screen
B Objects not displayed on the
screen

n Side cameras

Areas close to both corners of the
bumpers will not appear on the screen.

n Display range
l The range that is displayed on the

screen may differ due to the state of
the vehicle and road surface.

l The area covered by the camera is

limited. Objects that are close to either
corner of the bumper or under the
bumper cannot be displayed on the
screen.

l The depth perception of the image

displayed on the screen differs to the
actual distance.

l The rear view and wide rear view

cameras use a special lens, so the
depth perception of the image displayed on the screen differs to the
actual distance.

l Objects that are higher than the rear

n Rear camera

5-4. Using the driving support systems

Cleaning the camera
If dirt or foreign matter, such as
water droplets, snow, or mud, has
stuck to the camera, you will not be
able to see the image clearly. If that
happens, splash the camera with a
large amount of water and then
wipe the camera lens clean with a
soft, damp cloth.

487

• If you wash the vehicle with a high
pressure car washer, do not point
the hose directly at the camera or
camera area. Applying strong water
pressure may result in the camera
malfunctioning.

l If the camera is hit, it may cause a

camera malfunction. If this happens, have the vehicle inspected by
any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer as soon as possible.

NOTICE
n How to use the cameras
l The Multi-terrain Monitor may stop

functioning correctly. Take note of
the following items:
• Do not hit or apply a forceful impact
on the camera. Doing so may
change the position and mounting
angle of the camera.

Parking assist lights
The parking assist lights of the
Multi-terrain Monitor system are
installed in the locations shown in
the figure.
5

• When washing the camera lens,
splash the camera with a large
amount of water and then wipe the
camera lens clean with a soft, damp
cloth. Rubbing the camera lens forcibly may scratch the camera lens
and you may no longer be able to
see images clearly.
• The camera cover is made of resin.
Do not allow an organic solvent, car
wax, window cleaner, or glass coating to adhere to the camera. If this
happens, wipe it off immediately.
• Do not pour hot water on the vehicle in cold weather or apply other
rapid changes of temperature.

Driving

• The camera is designed to be
waterproof. Do not detach, disassemble, or modify it.

NOTICE
n Parking assist lights
l Make sure to observe the following

precautions, otherwise the
Multi-terrain Monitor system may
not operate correctly:
• Do not apply excessive force to a
light or subject it to a strong impact.
Doing so may cause the position or
installation angle of the light to deviate.
• Do not remove, disassemble, or
modify the lights as they have a
waterproof construction.

488

5-4. Using the driving support systems

NOTICE
• When cleaning the lights, wash
them with a large amount of water,
and then wipe them with a soft wet
cloth.
• Do not apply organic solvents,
waxes, oil removing solvents, glass
coatings, etc. to the covers of the
lights, as they are made of resin. If
such is applied, remove it immediately.

actual distance. Thus, objects on
up-slopes will appear to be farther
away than they actually are. In the
same way, there will be a margin of
error between the guidelines and
the actual distance and course on
the road.

• Do not expose the lights to sudden
temperature changes, such as
applying hot water to them when it
is cold.
• When washing the vehicle with a
high-pressure washer, do not spray
water directly on the lights or their
surrounding area. High-pressure
water can damage the lights and
cause them to not operate correctly.

l If a light has been subjected to a

strong impact, it may be damaged.
Have the vehicle inspected by any
authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer as soon as possible.

Difference between the
screen and the actual road

When the ground behind the vehicle slopes down sharply

The composite images on the
Multi-terrain Monitor and guide
lines give a distance guide for flat
road surfaces. Therefore, there is a
margin of error between the guide
lines on the screen and the actual
distance and course on the road.

The distance guide lines will appear
to be further from the vehicle than
the actual distance. Thus, objects
on down-slopes will appear to be
closer than they actually are. In the
same way, there will be a margin of
error between the guidelines and
the actual distance and course on
the road.

When the ground behind the vehicle slopes up sharply
The distance guide lines will appear
to be closer to the vehicle than the

5-4. Using the driving support systems

489

A Margin of error

Estimated course center line
As the guide lines are shown midair
near the rear bumper, there are
times that they may look like they
are off-center.
When any part of the vehicle sags

Differences between the screen and actual 3D objects
Since the guide lines displayed on the screen are for a flat road surface, it is
not possible to determine the position of three-dimensional objects. When
approaching a three-dimensional object that extends outward (such as the
flatbed of a truck), take note of the following cautions.
WARNING
n Toyota parking assist-sensor pop-up display (if equipped)
When the Toyota parking assist-sensor display is red, make sure to visually check
before moving the vehicle any further. There is the danger that you may collide
with another vehicle or have some other unforeseen accident.

5

Driving

When any part of the vehicle sags
due to the number of passengers or
the distribution of the load, there is
a margin of error between the guide
lines on the screen and the actual
distance and course on the road.

490

5-4. Using the driving support systems

Displaying panoramic view (including zoom display)
On the screen, it appears that there is a gap between the vehicle’s bumper
and another object or vehicle, and it does not look as if the vehicle will collide with the object or vehicle. However, the vehicle is over the course lines,
so the vehicle may collide with the object or vehicle. Make sure to visually
check your surroundings.

Estimated course lines
 On the screen, it appears that
the vehicle’s bumper is outside
of the estimated course lines,
and it does not look as if the
vehicle will collide with the object
or vehicle. However, the vehicle
is over the course lines, so the
vehicle may collide with the
object or vehicle. Make sure to
visually check your
surroundings.

A Estimated course lines

 Three-dimensional objects in

5-4. Using the driving support systems

491

high positions (such as the overhang of a wall or loading platform
of a truck) may not appear on the
screen. Make sure to visually
check your surroundings.

A Estimated course lines
5

Distance guide lines

 On the screen, a truck flatbed
may appear to be outside of the
estimated course lines and the
vehicle does not look as if it will
collide with the truck. However,
the flatbed may actually cross
over the estimated course lines
and if you reverse as guided by
the estimated course lines, the
vehicle may hit the truck. Make
sure to visually check your
surroundings.

at point B . However, in reality if
you reverse to point A , you will
collide with the truck. On the
screen, it appears that point A is
closest followed by points B and
C . However, in reality, the distance

to points A and C is the same,
and point B is farther than A and
C . Make sure to visually check
behind you and your surroundings.

The distance to point D is about 1
m (3 ft.).

Driving

A Overhang of a wall

On the screen, the distance guide
lines shows that a truck is parking

492

5-4. Using the driving support systems

Overhang of a diagonal beam

Magnifying function

In panoramic view, a diagonal
beam may appear straight and
seems likely not to be struck, however, since the top part of the beam
is actually overhanging, the vehicle
may hit it. Make sure to visually
check the rear and surroundings.

Unlike the normal panoramic view,
the panoramic view magnifying
function zooms in on the vehicle
icon. Therefore, white lines on the
road, walls, and other objects may
look bent.

5-4. Using the driving support systems

493

n Using under vehicle terrain view
l The images displayed were previously

taken behind the current vehicle position.
Therefore, actual conditions may differ from those shown on the screen in
the following situations.
• When conditions changed such as
when an object moved or entered the
frame after the image was taken.
• Loose material like sand or snow has
crumbled or shifted
• An obstacle has moved
• There is a puddle, tract of mud, etc.,
within the display range
• The vehicle slips

l In the following situations, actual tire

Under vehicle terrain view

WARNING
n Guide lines
The displayed guide lines are composed with the image that was previously taken and may differ from the
actual state. Always drive the vehicle
while confirming the safety of your
surroundings.

Things you should know
If you notice any symptoms
If you notice or are troubled by any of the symptoms below, check the issue
again referring to the likely cause and solution.
If the symptom is not resolved by the solution, have the vehicle inspected
by any authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

5

Driving

The tire position indicator lines and
vehicle position indicator lines may
differ from actual vehicle positions
depending on the number of passengers, weight of the load, road
grade, road surface conditions,
brightness of the surrounding environment, etc. Always drive the vehicle while directly confirming the
safety of your surroundings

positions and vehicle position may differ from those indicated by the tire
position indicator lines and vehicle
position indicator lines.
• Tires have been replaced
• Optional equipment has been
installed

494

5-4. Using the driving support systems
Symptom

The screen is difficult to
see

Likely cause

Solution

 The vehicle is in a dark
area or it is night.
 The temperature around Visually check the vehithe lens is either high or cle’s surroundings while
low
you are driving.
 The outside temperaUse the Multi-terrain Moniture is low
tor again once the camera
 There are water dropand conditions have
lets on the camera
improved.
 It is raining or humid
The procedure for adjust Foreign matter (mud,
etc.) is stuck to the cam- ing the picture quality of
the Multi-terrain Monitor
era
system is the same as the
 Sunlight or headlights
are shining directly into procedure for adjusting the
screen display. Refer to
the camera
 The vehicle is under flu- the “Multimedia owner’s
orescent lights, sodium manual”.
lights, mercury lights,
etc.

The image is blurry

The screen is misaligned

Splash the camera with a
Dirt or foreign matter, such
large amount of water and
as water droplets, snow, or
then wipe the camera lens
mud, has stuck to the camclean with a soft, damp
era lens.
cloth.

The camera has received
a strong impact.

Have the vehicle inspected
by any authorized Toyota
retailer or Toyota authorized repairer, or any reliable repairer.

5-4. Using the driving support systems
Symptom

Likely cause

The camera position is
misaligned.

495

Solution
Have the vehicle inspected
by any authorized Toyota
retailer or Toyota authorized repairer, or any reliable repairer.

The guide lines are signifi-  The vehicle is tilted.
cantly misaligned
(There is a heavy load
on the vehicle, tire pres- Visually check the vehisure is low due to a tire cle’s surroundings while
puncture, etc.)
you are driving.
 The vehicle is on an
incline.
The estimated course lines
Have the vehicle inspected
move even though the
by any authorized Toyota
There is a malfunction in
steering wheel is straight
the signals being output by retailer or Toyota author(the vehicle width guide
ized repairer, or any reliathe steering sensor.
lines and estimated course
ble repairer.
lines are out of alignment).
Close the back door.

The panoramic view display cannot be enlarged.

Follow the correction proThe Toyota parking
cedures for malfunctions of
The see-through
assist-sensor (if equipped)
the Toyota parking
view/moving view, side
may be malfunctioning or
assist-sensor. (if equipped)
clearance view, and cordirty.
(P.366)
nering view cannot be displayed.

Driving

The guide lines are not disThe back door is open.
played

If this does not resolve the
symptom, have the vehicle inspected by any
authorized Toyota retailer
or Toyota authorized
repairer, or any reliable
repairer.

5

496

5-4. Using the driving support systems
Symptom

Likely cause

Solution

Rinse the camera with a
Foreign matters (such as
large quantity of water,
water droplets, mud, snow
wipe it clean with a soft
and snow melting agents.)
cloth dampened with
Rear camera image is diffi- is on the camera lens.
water.
cult to see.
Foreign matters (such as
Ice, snow and mud) is
Remove foreign matters.
attached to surrounding
parts of the camera lens.
