# For your information

> Source: Toyota bZ4X Touring — Owner's Manual, Front/back matter, pages 6–10

6
For your information
Main Owner’s Manual
Please note that this manual
applies to all models and explains
all equipment, including options.
Therefore, you may find some
explanations for equipment not
installed on your vehicle.
All specifications provided in this
manual are current at the time of
printing. However, because of the
Toyota policy of continual product
improvement, we reserve the right
to make changes at any time without notice.
Depending on specifications, the
vehicle shown in the illustrations
may differ from your vehicle in
terms of color and equipment.
For Eurasian Economic Union: The
information on the procedure for
the safe use of the vehicle and its
systems, presented on the manufacturer’s labels on the body in
English, is intended only for service
workers.

Accessories, spare parts
and modification of your
Toyota
Both genuine Toyota and a wide
variety of other spare parts and
accessories for Toyota vehicles are
currently available in the market.
Should it be determined that any of

the genuine Toyota parts or accessories supplied with the vehicle
need to be replaced, Toyota recommends that genuine Toyota parts or
accessories, be used to replace
them. Other parts or accessories of
matching quality can also be used.
Toyota cannot accept any liability or
guarantee spare parts and accessories which are not genuine
Toyota products, nor for replacement or installation involving such
parts. In addition, damage or performance problems resulting from
the use of non-genuine Toyota
spare parts or accessories may not
be covered under warranty.
Also, remodeling like this will have
an effect on advanced safety equipment such as Toyota Safety Sense
and there is a danger that it will not
work properly or the danger that it
may work in situations where it
should not be working.

Cyber Attack Risk
Installing electronic devices and
radios increases the risk of cyber
attacks through the installed parts,
which may lead to unexpected accidents and leakage of personal
information.
Toyota does not make any guarantees for problems caused by installing non-genuine Toyota products.

7
Installation of an RF-transmitter system

reception of the radio frequency
transmitter (RF-transmitter).

The installation of an RF-transmitter system in your vehicle could
affect electronic systems such as:

Vehicle data recording (vehicles with Toyota Safety
Sense)

 EV system
 Toyota Safety Sense (if
equipped)
 Cruise control system
 Anti-lock brake system
 SRS airbag system
 Seat belt pretensioner system
Be sure to check with any authorized Toyota retailer or Toyota
authorized repairer, or any reliable
repairer for precautionary measures or special instructions regarding installation of an RF-transmitter
system.
Further information regarding frequency bands, power levels,
antenna positions and installation
provisions for the installation of
RF-transmitters, is available on
request at any authorized Toyota
retailer or Toyota authorized
repairer, or any reliable repairer.
High voltage parts and cables on
the battery electric vehicles emit
approximately the same amount of
electromagnetic waves as the conventional gasoline powered vehicles or home electronic appliances
despite of their electromagnetic
shielding.
Unwanted noise may occur in the

This vehicle is equipped with
sophisticated computers that
record certain data regarding vehicle controls and operations.
n Data recorded by the comput-

ers
Certain data, such as the following,
is recorded depending on the operation timing and status of each
function.
• Engine speed/Electric motor
speed (traction motor speed)
• Accelerator status
• Brake status
• Vehicle speed
• Operation status of the driving
assist systems
• Images from the cameras
Your vehicle is equipped with cameras.
Contact any authorized Toyota retailer
or Toyota authorized repairer, or any
reliable repairer for the location of
recording cameras.

The recorded data varies according
to the vehicle grade level, options
and destinations with which it is
equipped.
These computers do not record
conversations or sounds, and only
record images outside of the vehicle in certain situations.

8
n Data usage
Toyota may use the data recorded in
this computer to diagnose malfunctions, conduct research and development, and improve quality.
Toyota will not disclose the recorded
data to a third party except:

• With the consent of the vehicle
owner or with the consent of the
lessee if the vehicle is leased
• In response to an official request
by the police, a court of law or a
government agency
• For use by Toyota in a lawsuit
• For research purposes where
the data is not tied to a specific
vehicle or vehicle owner
Image information recorded by the vehicle can be erased by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer.
The image recording function can be
disabled. However, if the function is disabled, data from when systems operate
will not be available.
If you wish to stop the collection of
Toyota Safety Sense data by the Toyota
servers for the purpose of research and
development and provision to individual
services, contact any authorized Toyota
retailer or Toyota authorized repairer, or
any reliable repairer.

Vehicle data recording (vehicles without Toyota Safety
Sense)
The vehicle is equipped with
sophisticated computers that will
record certain data, such as:
• Engine speed/Electric motor
speed (traction motor speed)

•
•
•
•

Accelerator status
Brake status
Vehicle speed
Operation status of the driving
assist systems

The recorded data varies according
to the vehicle grade level, options
and destinations with which it is
equipped.
n Data usage
Toyota may use the data recorded in
this computer to diagnose malfunctions, conduct research and development, and improve quality.
Toyota will not disclose the recorded
data to a third party except:

• With the consent of the vehicle
owner or with the consent of the
lessee if the vehicle is leased
• In response to an official request
by the police, a court of law or a
government agency
• For use by Toyota in a lawsuit
• For research purposes where
the data is not tied to a specific
vehicle or vehicle owner

Event data recorder
This vehicle is equipped with an
event data recorder (EDR). The
main purpose of an EDR is to
record, in certain crash or near
crash-like situations, such as an
airbag deployment or hitting a road
obstacle, data that will assist in
understanding how a vehicle’s systems performed. The EDR is
designed to record data related to

9
vehicle dynamics and safety systems for a short period of time, typically 30 seconds or less. However,
data may not be recorded depending on the severity and type of a
crash.
The EDR in this vehicle is designed
to record such data as:
• How various systems in your
vehicle were operating;
• How far (if at all) the driver was
depressing the accelerator
and/or brake pedal; and,
• How fast the vehicle was
traveling.
These data can help provide a better understanding of the circumstances in which crashes and
injuries occur.
NOTE: EDR data are recorded by
your vehicle only if a non-trivial
crash situation occurs; no data are
recorded by the EDR under normal
driving conditions and no personal
data (e.g., name, gender, age, and
crash location) are recorded. However, other parties, such as law
enforcement, could combine the
EDR data with the type of personally identifying data routinely
acquired during a crash investigation.
To read data recorded by an EDR,
special equipment is required, and
access to the vehicle or the EDR is
needed. In addition to the vehicle
manufacturer, other parties, such
as law enforcement, that have the

special equipment, can read the
information if they have access to
the vehicle or the EDR.
 Disclosure of the EDR data
Toyota will not disclose the data
recorded in an EDR to a third party
except when:
• An agreement from the vehicle’s
owner (or the lessee for a leased
vehicle) is obtained
• In response to an official request by
the police, a court of law or a government agency
• For use by Toyota in a lawsuit
However, if necessary, Toyota may:
• Use the data for research on vehicle
safety performance
• Disclose the data to a third party for
research purposes without disclosing information about the specific
vehicle or vehicle owner

Scrapping of your Toyota
The SRS airbag and seat belt
pretensioner devices in your Toyota
contain explosive chemicals. If the
vehicle is scrapped with the airbags
and seat belt pretensioners left as
they are, this may cause an accident such as fire. Be sure to have
the systems of the SRS airbag and
seat belt pretensioner removed and
disposed of by any authorized
Toyota retailer or Toyota authorized
repairer, or any reliable repairer
before you scrap your vehicle.

10
“QR Code”

WARNING

The word “QR Code” is registered
trademark of DENSO WAVE
INCORPORATED in Japan and
other countries.

Caution symbols attached to
the high voltage components
High voltage components, such as
the power control unit, may have
labels attached indicating care
required.
Each caution symbol indicates the
following:
Symbols

Meanings

Indicates danger

Indicates high voltage
part

Indicates not to touch

Indicates high temperature part

n General precautions while driv-

ing
Driving under the influence: Never
drive your vehicle when under the
influence of alcohol or drugs that have
impaired your ability to operate your
vehicle. Alcohol and certain drugs
delay reaction time, impair judgment
and reduce coordination, which could
lead to an accident that could result in
death or serious injury.
Defensive driving: Always drive
defensively. Anticipate mistakes that
other drivers or pedestrians might
make and be ready to avoid accidents.
Driver distraction: Always give your
full attention to driving. Anything that
distracts the driver, such as adjusting
controls, talking on a cellular phone or
reading can result in a collision with
resulting death or serious injury to
you, your occupants or others.

n General precaution regarding

children’s safety
Never leave children unattended in
the vehicle, and never allow children
to have or use the key.
Children may be able to start the vehicle or shift the vehicle into neutral.
There is also a danger that children
may injure themselves by playing with
the windows, or other features of the
vehicle. In addition, heat build-up or
extremely cold temperatures inside
the vehicle can be fatal to children.

Toyota Motor Europe NV/SA, Avenue du Bourget 60 - 1140 Brussels,
Belgium
www.toyota-europe.com
Toyota (GB) PLC Great Burgh,
Burgh Heath, Epsom, Surrey, KT18
5UX, UK
