# 8-2. Panoramic view monitor

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 8 Parking assist system, pages 277–324

monitor

view

Panoramic

8-2. Panoramic view monitor

Panoramic view monitor functions*
The panoramic view monitor is a device that assists you in driving at low
speeds by displaying seamless vision from above the vehicle on the screen
that is a composite of images from the front, side, and rear cameras installed on the vehicle.
INFORMATION
The illustrations of screens used in the descriptions are examples and may differ
to the actual vision from the camera due to vehicle glare and such like.

WARNING
● The panoramic view monitor is a device that assists you in checking around the

vehicle. Always make sure to visually check your surroundings while you are
driving.

● Due to the characteristics of the camera lens, the actual position and distance

of people and obstacles differ from what appears on the screen.

Camera switch
Displays the panoramic view monitor
and switches the display mode.
8

When you press the camera switch or shift the shift position to "R" while the
power switch is in ON, the panoramic view monitor operates.

* : If equipped

277

Parking assist system

Displaying the panoramic view monitor screen

8-2. Panoramic view monitor

■ Display mode when the shift position is in “P”

A Navigation screen, audio screen, etc.
B Pressing the camera switch
C Moving view
D See-through view
E Touch the display mode switching button

■ Display mode when the shift position is in “D” or “N”

A Navigation screen, audio screen, etc.
B Wide front view & panoramic view

278

8-2. Panoramic view monitor
C Side clearance view & panoramic view
D Cornering view & panoramic view
E Pressing the camera switch
F Touch the display mode switching button
G When the steering wheel is turned by 180 degrees or more from the

center (straight-line) position
■ Display mode when the shift position is in “R”

A Rear view & panoramic view
B Wide rear view & panoramic view
C Touch the display mode switching button

INFORMATION
● If you press the camera switch when the vehicle is moving at about 20 km/h (12

● Display settings, such as the guide line modes, can be saved as My Setting by

registering to user profiles. They can be recalled when the driver is recognized.

● The voice control system can be used to display the panoramic view monitor

screen, change the screen mode and for other operations.*1

Related Links
Registering a user profile(P. 50)
Starting voice control(P. 42)

*1 : This function is not available in some countries or areas.

279

Parking assist system

mph) or less, the panoramic view monitor screen will be displayed. When the
vehicle exceeds about 20 km/h (12 mph), the panoramic view monitor screen
will disappear and the previous screen will be displayed.

8

8-2. Panoramic view monitor

Display mode when the shift position is in "P"
This is a mode that displays images combined from the cameras to enable
you to check obstacles around the vehicle. Images are displayed as if seen
from the driver’s seat and on an angle from above the vehicle.
1. Shift the shift position to "P".
2. Press the camera switch.
● The mode changes every time the display mode switching button is
touched.
● Pressing the camera switch again returns the display to the previous
screen, such as the navigation screen.
■ See-through view

■ Moving view

A Screen off button
Turns off the camera screen and returns the previous screen, such as the
navigation.
B Display mode switching button
Switches between see-through view and moving view.
C Rotation pause/resume button
Pauses and resumes the rotation of the display.
D Customize settings button

280

8-2. Panoramic view monitor
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance.
E Voice recognition icon*1
This icon is displayed when the voice control system is in operation.

INFORMATION
● When the Toyota parking assist-sensor is turned on, you can display see-

through view or moving view. (For details about the Toyota parking assist-sensor, see the vehicle "Owner's manual".)

● You can also pause and resume the rotation of the see-through view and

moving view screen by touching any point on the screen.

Related Links
Changing the panoramic view monitor settings(P. 304)

8

Parking assist system

*1 : This function is not available in some countries or areas.

281

8-2. Panoramic view monitor

Display mode when the shift position is in "D" or "N"
You can check for nearby pedestrians, bicycles, and vehicles at intersections with poor visibility and T-junctions by displaying vision of your surroundings on the screen. This mode also provides support to check both
sides of the vehicle for safety, avoid collisions on narrow roads, and pulling
over to the side of the road.
1. Shift the shift position to "D" or "N".
2. Press the camera switch.
● The mode changes every time you press the camera switch.
● If the cornering view mode is on and you turn the steering wheel

more than 180 degrees from the straight position, the display will
change from side clearance view & panoramic view to cornering view
& panoramic view.

■ Wide front view & panoramic view

A Front distance guide lines
Displays about 1 m (3 ft.) in front of the vehicle.
B Forward estimated course lines
Displays course lines that are linked to operation of the steering wheel. (Yellow)
These lines are displayed when the steering wheel is turned more than 90
degrees from the straight position.
C Toyota parking assist-sensor
Displays an indicator on the screen and sounds a buzzer when an object is
detected by a sensor. (For details about the Toyota parking assist-sensor, see
the vehicle "Owner's manual".)
D FCTA (Front Crossing Traffic Alert)*//Moving objects alert*
* : If equipped

282

8-2. Panoramic view monitor
In the following situations, an indicator is displayed on the screen.
● When FCTA (Front Crossing Traffic Alert) detects a vehicle that is approach-

ing from the front or an object.

● If moving objects alert detects nearby vehicles and/or obstacles from the

front or rear of the vehicle.

E Screen off button
Turns off the camera screen and returns the previous screen, such as the
navigation.
F Display mode switching button
Switches display mode every time touch the button.
G Guide line switching button
Switches guide line mode every time touch the button.
H Automatic display button
Turns auto display mode on or off. When the shift position is in "D" or "N", wide
front view & panoramic view or side clearance view/cornering view & panoramic
view will be automatically displayed in accordance with the vehicle speed.
I Customize settings button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance.
J Camera dirt detection icon
This icon is displayed when dirt is detected on the camera.
K Moving objects alert*

8

L Voice recognition icon*1
This icon is displayed when the voice control system is in operation.
M PKSB (Parking Support Brake)
If an obstacle that you may collide with is detected, a message is displayed on
the screen. (For details about PKSB (Parking Support Brake), see the vehicle
"Owner's manual".)
N Mute button
This button temporarily mutes the Toyota parking assist-sensor/moving objects
alert sound.

* : If equipped
*1 : This function is not available in some countries or areas.

283

Parking assist system

When the moving objects alert detects an approaching vehicle or object from
the front or side of the vehicle, an indicator will be displayed on the screen.

8-2. Panoramic view monitor

■ Side clearance view & panoramic view

■ Cornering view & panoramic view

A Forward estimated course lines
Displays course lines that are linked to operation of the steering wheel. (Yellow)
These lines are displayed when the steering wheel is turned more than 90
degrees from the straight position.
B Vehicle width guide lines
Shows guide lines of the vehicle’s width including the outside rear view mirrors.
C Front distance guide lines
Displays about 1 m (3 ft.) in front of the vehicle.
D Toyota parking assist-sensor
Displays an indicator on the screen and sounds a buzzer when an object is
detected by a sensor. (For details about the Toyota parking assist-sensor, see
the vehicle "Owner's manual".)

284

8-2. Panoramic view monitor
E FCTA (Front Crossing Traffic Alert)*//Moving objects alert*
In the following situations, an indicator is displayed on the screen.
● When FCTA (Front Crossing Traffic Alert) detects a vehicle that is approach-

ing from the front or an object.

● If moving objects alert detects nearby vehicles and/or obstacles from the

front or rear of the vehicle.

F Screen off button
Turns off the camera screen and returns the previous screen, such as the
navigation.
G Display mode switching button
Switches display mode every time touch the button.
H Guide line switching button
Switches guide line mode every time touch the button.
I Automatic display button
Turns the auto display mode on or off. When the shift position is in "D" or
"N", wide front view & panoramic view or side clearance view/cornering view &
panoramic view will be automatically displayed in accordance with the vehicle
speed.
J Customize settings button
Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance.
K Moving objects alert*

8

L Camera dirt detection icon
This icon is displayed when dirt is detected on the camera.
M Front tire guide lines
Displays the position of the front tires.
N Voice recognition icon*1
This icon is displayed when the voice control system is in operation.
O PKSB (Parking Support Brake)
If an obstacle that you may collide with is detected, a message is displayed on
the screen. (For details about PKSB (Parking Support Brake), see the vehicle
"Owner's manual".)
P Mute button
This button temporarily mutes the Toyota parking assist-sensor/moving objects
alert sound.
* : If equipped
*1 : This function is not available in some countries or areas.

285

Parking assist system

When the moving objects alert detects an approaching vehicle or object from
the front or side of the vehicle, an indicator will be displayed on the screen.

8-2. Panoramic view monitor

INFORMATION
● When the Toyota parking assist-sensor is turned on, you can display side

clearance view & panoramic view/cornering view. (For details about the Toyota
parking assist-sensor, see the vehicle "Owner's manual")

● The display position of the Toyota parking assist-sensor may not match the

position of the obstacle displayed in the camera image.

WARNING
● The position of the guide lines displayed on the screen may change due to

factors such as number of passengers, load weight, and road gradient. Always
make sure to visually check behind you and your surroundings while you are
driving.

● The Toyota parking assist-sensor, FCTA (Front Crossing Traffic Alert) and mov-

ing objects alert displays are overlapped and displayed on the camera image,
so it may be difficult to see depending on the brightness of the surroundings
and colors.

Related Links
Changing the guide line display mode(P. 286)
Auto display mode(P. 287)
Changing the panoramic view monitor settings(P. 304)

Changing the guide line display mode
The guide line display mode changes every time the guide line display
mode button is touched.
■ Distance guide lines mode

Displays about 1 m (3 ft.) in front of
the vehicle. (blue)

286

8-2. Panoramic view monitor

■ Estimated course lines mode

Displays course lines that are linked
to operation of the steering wheel.
(Yellow) These lines are displayed
when the steering wheel is turned
more than 90 degrees from the
straight position.

Auto display mode
Although you can display wide front view & panoramic view and side clearance view & panoramic view/cornering view by pressing the camera switch,
you can also set auto display mode to display the views automatically in
accordance with the vehicle speed.
● Touching the automatic display button [

] turns on auto display mode.
● Turning on auto display mode automatically displays the views in the
following situations:
• When the shift position is in "D" or "N"
• The vehicle decelerates to less than 10 km/h (6 mph) (the shift position is in

any position other than “R”)

You can set the cornering view auto display mode to automatically display
cornering view & panoramic view in accordance with the operation of the
steering wheel.
● Turning on cornering view auto display mode automatically displays cornering view in the following situations:
• When the shift position is in "D" or "N"
• The vehicle decelerates to less than 12 km/h (7 mph)
• When the steering wheel is turned by 180 degrees or more from the center

(straight-line) position

INFORMATION
You can change cornering view auto mode in the custom settings.

Related Links
Changing the panoramic view monitor settings(P. 304)

287

Parking assist system

Cornering view auto display

8

8-2. Panoramic view monitor

Toyota parking assist-sensor linked display
Depending on the Toyota parking assist-sensor detection state, wide front
view & panoramic view/Side clearance view/Cornering view & panoramic
view will be displayed.
● The views are displayed automatically when the Toyota parking assistsensor detects an obstacle (when the shift position is in “D” or “N”).
● The display returns to the previous screen automatically when the Toyota
parking assist-sensor stops detecting an obstacle.
INFORMATION
● You can also return to the previous screen by pressing the camera switch

displayed on the screen.

● If the panoramic view monitor screen is canceled when an obstacle is detected,

the panoramic view monitor screen can be displayed again by touching the
Toyota parking assist-sensor mark shown on the multimedia system screen.

Using the vehicle width guide lines
■ Side clearance view & panoramic view
● Check the positional relationship

between the vehicle width guide
lines and an obstacle.
● Turn the steering wheel and drive
forward so that the vehicle width
guide lines do not overlap the actual obstacle.

288

8-2. Panoramic view monitor
● Check the positional relationship

between the vehicle width guide
lines and an object such as curbs
on the shoulder of a road.
● Pull the vehicle over so that the vehicle width guide lines do not overlap the obstacle as shown in the
figure.
● By driving with the vehicle width
guide lines parallel to the object,
you can park alongside the object.

Using the forward estimated course lines
■ Cornering view & panoramic view
● Check the positional relationship

between the forward estimated
course lines and an obstacle.
● Turn the steering wheel and drive
forward so that the forward estimated course lines do not overlap the
actual obstacle.

8

Parking assist system

289

8-2. Panoramic view monitor

Display mode when the shift position is in "R"
To check for safety when parking the vehicle, an image is displayed from
above the vehicle and from the rear camera.
1. Shift the shift position to "R".
● The mode changes every time you touch the display mode switching

button.

■ Rear view & panoramic view

■ Wide rear view & panoramic view

A Camera dirt detection icon
This icon is displayed when dirt is detected on the camera.
B Moving objects alert*

* : If equipped

290

8-2. Panoramic view monitor
If moving objects alert detects nearby vehicles and/or obstacles from the side of
the vehicle, an indicator is displayed on the screen.
C Display mode switching button
Switches display mode every time touch the button.
D Guide line switching button
Switches guide line mode every time touch the button.
E RCTA(Rear Crossing Traffic Alert) / RCD (Rear Camera Detection) /

Moving objects alert*
An indicator is displayed on the screen in the following situations.
● When the rear radar detects an obstacle or a vehicle approaching

from the rear
● If the rear camera detects a pedestrian behind the vehicle
(For details about RCTA(Rear Crossing Traffic Alert) / RCD (Rear
Camera Detection), see the vehicle "Owner's manual".)
● If the rear camera detects a moving object
F Customize settings button

Changes settings, such as the automatically display cornering view, the vehicle
body color, the Toyota parking assist-sensor detection distance.
G Toyota parking assist-sensor
Displays an indicator on the screen and sounds a buzzer when an object is
detected by a sensor. (For details about the Toyota parking assist-sensor, see
the vehicle "Owner's manual")

8

H RCD (Rear Camera Detection) / Moving objects alert*

I Voice recognition icon*1
This icon is displayed when the voice control system is in operation.
J PKSB (Parking Support Brake)
If an obstacle that you may collide with is detected, a message is displayed on
the screen. (For details about PKSB (Parking Support Brake), see the vehicle
"Owner's manual".)
K Mute button
Mute the Toyota parking assist-sensor / RCTA(Rear Crossing Traffic Alert) /
RCD (Rear Camera Detection) / moving objects alert sound.
Operating the shift automatically cancels mute.

* : If equipped
*1 : This function is not available in some countries or areas.

291

Parking assist system

If the rear camera detects a pedestrian or a moving object behind the vehicle,
an indicator is displayed on the screen. (For details about RCD (Rear Camera
Detection), see the vehicle "Owner's manual".)

8-2. Panoramic view monitor

INFORMATION
● When rear view is displayed, touch the display to change to wide rear view.

● The display position of the Toyota parking assist-sensor may not match the

position of the obstacle displayed in the camera image.

WARNING
● The position of the guide lines displayed on the screen may change due to

factors such as number of passengers, load weight, and road gradient. Always
make sure to visually check behind you and your surroundings while you are
driving.

● The Toyota parking assist-sensor, RCTA (Rear Crossing Traffic Alert), RCD

(Rear Camera Detection), and the moving objects alert displays are overlapped
and displayed on the camera image, so it may be difficult to see depending on
the brightness of the surroundings and colors.

Related Links
Changing the guide line display mode(P. 292)
Changing the panoramic view monitor settings(P. 304)

Changing the guide line display mode
The guide line display mode changes every time you touch the guide line
switching button.
■ Estimated course lines mode

This mode displays estimated course lines that move in accordance with
the operation of the steering wheel.

A Front distance guide lines
Displays about 1 m (3 ft.) (blue) in front of the vehicle.
B Side estimated course lines
Displays course lines (yellow) that are linked to operation of the steering wheel.
C Reverse estimated course lines

292

8-2. Panoramic view monitor
Displays course lines (yellow) that are linked to operation of the steering wheel.
D Rear distance guide lines
Displays the distance behind the vehicle.
● The distance guide line is linked to the estimated course lines.

● Displays about 0.5 m (1.5 ft.) (red) and 1 m (3 ft.) (yellow) from the center of

the end of the rear bumper.

E Rear distance guide line
Displays about 0.5 m (1.5 ft.) (blue) from the end of the rear bumper.
F Vehicle width guide lines
Displays course lines when the vehicle is being reversed in a straight line.
● The lines are wider than the actual width of the vehicle.

● When the vehicle is straight, the guide lines will overlap with the estimated

course lines.

G Vehicle center guide line
Displays the center of the vehicle width guide lines.

■ Parking assist guide lines mode

This mode displays the steering wheel return points (parking assist guide
lines). This mode is recommended for those who have a sense of the
vehicle and can park the vehicle without the aid of the estimated course
lines.
8

Parking assist system

A Front distance guide lines
Displays about 1 m (3 ft.) (blue) in front of the vehicle.
B Rear distance guide lines
Displays the distance behind the vehicle.
● Displays about 0.5 m (1.5 ft.) (red) from the center of the end of the rear

bumper.

C Displays the distance behind the vehicle.
Displays the center of the vehicle width guide lines.
D Vehicle width guide lines
Displays course lines when the vehicle is being reversed in a straight line.

293

8-2. Panoramic view monitor
● The lines are wider than the actual width of the vehicle.

E Parking assist guide lines

Displays the course lines of the smallest turn possible behind the vehicle.
● Use the position of operating the steering wheel when parking as a guide.

■ Distance guide lines mode

This mode only displays the distance guide lines. It is recommended for
those who do not need the guide lines.

A Front distance guide lines
Displays about 1 m (3 ft.) (blue) in front of the vehicle.
B Rear distance guide lines
Displays the distance behind the vehicle.
● Displays about 0.5 m (1.5 ft.) (red) from the center of the end of the rear

bumper.

■ Estimated course center line mode

This mode displays estimated course lines and a vehicle center guide line
that move in accordance with the operation of the steering wheel.
Use this mode when approaching a signpost or pole with the center of the
rear bumper.

A Front distance guide lines
Displays about 1 m (3 ft.) (blue) in front of the vehicle.
B Side estimated course lines

294

8-2. Panoramic view monitor
Displays course lines (yellow) that are linked to operation of the steering wheel.
C Rear distance guide lines
Displays the distance behind the vehicle.
● The distance guide line is linked to the estimated course lines.

● Displays about 0.5 m (1.5 ft.) (red) and 1 m (3 ft.) (yellow) from the center of

the end of the rear bumper.

D Reverse estimated course lines
Displays course lines (yellow) that are linked to operation of the steering wheel.
E Estimated course center line
Displays the vehicle center guide line (green) that is linked to operation of the
steering wheel.

INFORMATION
The guide lines will not be displayed if the back door is not closed. If you close the
back door but the guide lines are still not displayed, have the vehicle inspected by
any Toyota retailer or Toyota authorized repairer, or any reliable repairer.

WARNING
The rear vehicle width guide lines are wider than the actual width of the vehicle.
Always make sure to visually check behind you and your surroundings when you
are reversing.
8

Parking using the estimated course lines mode

Parking assist system

1 Shift the shift position to "R".

295

8-2. Panoramic view monitor

2 Turn the steering wheel so that
the estimated course lines are
within the parking space and
then reverse slowly.
A Parking space
B Estimated course lines

3 When the rear of the vehicle
has entered the parking space,
turn the steering wheel so that
the vehicle width guide lines are
within the left and right dividing
lines of the parking space.
A Vehicle width guide lines

4 Once the vehicle width guide lines and the parking space lines are
parallel, straighten the steering wheel and reverse slowly until the
vehicle has completely entered the parking space.
5 Stop the vehicle in an appropriate place to finish parking.

296

8-2. Panoramic view monitor

Parking using the parking assist guide lines mode
1 Shift the shift position to "R".
2 Reverse until the parking assist
guide lines align with the dividing line of the parking space.
A Parking assist guide lines
B Parking space dividing line

297

8

Parking assist system

3 Turn the steering wheel all the way, and reverse slowly.
4 Once the vehicle is parallel with the parking space, straighten the
steering wheel and reverse slowly until the vehicle has completely
entered the parking space.
5 Stop the vehicle in an appropriate place to finish parking.

8-2. Panoramic view monitor

The screen when the outside rear view mirrors are folded
When the outside rear view mirrors are folded, an image from the side
cameras rather than panoramic view will be displayed. This can assist you
in confirming that the vicinity of the vehicle is safe when you are parking in
a narrow place.

A Side views
B Toyota parking assist-sensor
Displays an indicator on the screen and sounds a buzzer when an object is
detected by a sensor. (For details about the Toyota parking assist-sensor, see
the vehicle "Owner's manual")
C Wide front view/Rear view/Wide rear view

INFORMATION
The display position of the Toyota parking assist-sensor may not match the position of the obstacle displayed in the camera image.

298

8-2. Panoramic view monitor

Zooming in on the screen
Zooming in on the screen can be done if the image on the screen is too
small and hard to see.
Touch the area that you want to zoom in on the panoramic view.

● The selected area is zoomed in on.
● In panoramic view, you can zoom in one of the two places in front or rear

of the vehicle.
● To cancel the zoom, touch the screen again.
INFORMATION

● The zoom feature is enabled when all of the following conditions are met:
• The vehicle speed is below 12 km/h (7 mph)

8

• The Toyota parking assist-sensor is turned on

cally:

• The vehicle speed is above 12 km/h (7 mph)
• The Toyota parking assist-sensor is turned off

● The guide lines will not be displayed when the panoramic view is zoomed.

299

Parking assist system

● In any of the following situations, the zoom feature will be canceled automati-

8-2. Panoramic view monitor

Displaying transparent underfloor vision
A composite of camera vision captured in the past from the current vehicle
position to assist understanding of the situation under the vehicle, tire positions, and so on can be displayed.
Transparent underfloor vision is displayed when the setting on the customized setting screen is turned on and the vehicle is moving forward or backward.

A Tire tracks
Displays the tire position guides linked to the steering wheel.
B Vehicle guide lines
Displays the exterior of the vehicle.

INFORMATION
● Transparent underfloor vision is not displayed in the following cases:
• The vehicle speed is above 20 km/h (12 mph)
• The vehicle stops and a certain amount of time passes
• If the vehicle does not move a certain distance after it is started
• The side mirrors are folded
• ABS is operating
• The system is not functioning correctly

● The system may not function correctly in the following situations:
• Snow covered roads
• There are shadows from lights and so forth
• There is dirt or a foreign object on the camera lens
• Water (river, sea, etc.)
• Optional equipment has been installed
• There is an obstacle in front of the camera
• The tires were replaced

300

8-2. Panoramic view monitor
• The back door is open and the camera is not in the correct position
• The road surface is slippery or the wheels slip
• The vehicle is on a hill or other steep roads

● As vision that was captured in the past is being displayed, the screen and the

actual situation may differ in the following cases:

• An obstacle appears or moves after vision is captured
• Sand or snow crumbles and moves after vision is captured
• Mud or puddles are in the display range
• When the vehicle slips

● Part or all of the transparent underfloor vision may appear black in the following

cases:

• The vehicle starts moving with no captured vision
• If the vehicle does not move a certain distance after it is started
• The steering wheel is turned more than a certain angle
• The vehicle stops and a certain amount of time passes
• The outside rear view mirrors are folded
• ABS is operating
• The system is not functioning correctly

WARNING

8

position due to the number of passengers, vehicle load, road gradient, road
surface conditions, brightness of the surroundings, optional equipment, tire replacements, and other reasons. Always make sure to check your surroundings
while you are driving.

● Displayed vision is vision that was captured in the past. Therefore, if obstacles

and other objects move after being captured, the transparent underfloor vision
and the actual situation may not always match.

Related Links
Changing the panoramic view monitor settings(P. 304)

301

Parking assist system

● The tire and vehicle guide lines may not align correctly with the actual vehicle

8-2. Panoramic view monitor

Moving objects alert*
If a moving object is detected around the vehicle when the panoramic view
is displayed, an alarm will sound and an indicator will be displayed on the
screen.
The moving objects alert is operational when all of the following are met:
● When the "D" or "R" shift position is selected
● When the vehicle speed is approximately 15 km/h (9 mph) or less
● When the outside rear view mirrors are not closed
INFORMATION
● In situations such as the following, the camera sensors may not detect a mov-

ing object correctly:

• When the object is a running person
• When a person suddenly appears from behind the vehicle or a building
• When the object is a person riding a skateboard or self-balancing personal

transporter

• When the object is a person clothed in similar color as the surroundings
• When part of person’s body is hidden behind an object, such as a cart or

luggage

• When it is dark after the sunset
• When in inclement weather, such as rain, snow, fog, etc.
• When a camera lens is dirty with mud, snow melting agent, etc. or damaged
• When water droplets are attached on a camera lens
• When a very bright light shines directly into a camera sensor
• When there is a difference in brightness/darkness, such as near an open

shutter of a garage or underground parking space

● When an object, such as the following, is detected, the system may operate

even though there is no possibility of a collision:

• Moving objects/substance, such as a flag, emission gas, large rain drops,

snow, rainwater on the road, etc.

• Patterns formed on a road, such as white lines, pedestrian crossings, stone

pavement, tram rails, road repair traces, fallen leaves, gravels, puddles, etc.

• Gratings or a road gutter
• A road shoulder or ramp
• Reflections of an object on a puddle or wet road surface
• Shadows
* : If equipped

302

8-2. Panoramic view monitor
• Objects having height/slender length, such as columns, traffic corns, fire

hydrants, etc.

• Pedestrians, bicycles, or vehicles that are standing still

● In situations such as the following, the system may operate even though there

is no possibility of a collision:

• When the vehicle rides on a ramp
• When there is a change in gradient
• When the vehicle is tilted at a steep angle, due to carrying load or sudden

braking

• When tires other than specified are installed
• When the vehicle height has been excessively changed (nose-up, nose-

down)

• When a non-genuine part is installed near the camera sensors
• When a non-genuine bumper protector, such as a bumper trim, is installed
• When an arm is held outside of a window
• When the camera sensors are displaced, due to re-installation or a collision
• When a towing hook is installed
• When a camera lens is dirty with mud, snow melting agent, etc.
• When water droplets are attached on a camera lens
• When there is a flashing light source, such as the emergency flashers

8

Parking assist system

303

8-2. Panoramic view monitor

Changing the panoramic view monitor settings
Settings related to panoramic view monitor such as the cornering view auto
display and vehicle body color can be changed.
1 Touch [

].

2 Select the desired item.
● [Cornering View]

Automatically display the cornering
view.
● [View Under Vehicle]

Turn the transparent underfloor vision display setting on or off. Setting
it to on and moving the vehicle forward or backwards displays a composite of camera vision captured in
the past from the current vehicle position to assist understanding of the situation under the vehicle, front tire positions, and so on. The vision is displayed in
panoramic view, side clearance view, or cornering view.
● [TOYOTA Park Assist 3D Display]

Show or hide the Toyota parking assist-sensor display.
● [TOYOTA Park Assist Distance]

Change the distance that the Toyota parking assist-sensor starts detecting
obstacles.
● [Vehicle Body Colour]

Change the vehicle body color displayed on the screen.
● [Moving object alert]*

Set the moving object alert display on/off.
● [Warnings when auto /display mode enabled]*

Set the moving object alert display on/off when the automatic display mode is
ON.

* : If equipped

304

8-2. Panoramic view monitor

INFORMATION
For safety purposes, you cannot display the custom settings screen while the
vehicle is moving.

Related Links
Changing the Toyota parking assist-sensor detection distance(P. 305)

Changing the body color
Change the vehicle body color displayed on the screen.
1 Touch [Vehicle Body Colour].
2 Select the desired body color.
3 Touch [OK].

Changing the Toyota parking assist-sensor detection distance
Change the distance that the Toyota parking assist-sensor starts detecting
obstacles.
1 Touch [TOYOTA Park Assist Distance].
2 Select the distance at which you
want to start detecting objects.
3 Touch [OK].

8

Parking assist system

305

8-2. Panoramic view monitor

Precautions for the panoramic view monitor
Always make sure to visually check behind you and your surroundings
while driving. If not, collision with other vehicles or an unforeseen accident
may occur. Follow the below precautions when using the panoramic view
monitor.
WARNING
● Never depend on the panoramic view monitor entirely. Always make sure to

visually check behind you and your surroundings as you would when driving
any other vehicle. In particular, be careful not to collide with vehicles parked
nearby or other objects.

● Always make sure to visually check behind you and your surroundings while

you are driving.

● Never drive while looking only at the screen. The image on the screen may

be different to the actual conditions. Moreover, there is a limit to the range of
image that the camera can capture. Never turn or reverse only looking at the
screen. Doing so may result in a collision with another vehicle or some other
unforeseen accident. Be sure to visually check the vehicle’s surroundings and
use the vehicle’s rear-view and side mirrors.

● The position of the guide lines displayed on the screen may change due to

factors such as number of passengers, load weight, and road gradient. Always
make sure to visually check behind you and your surroundings while you are
driving.

● Do not use the panoramic view monitor in the following cases:
• On icy or slick road surfaces, or in snow
• When using tire chains or emergency tires
• When the front door(s) or back door are not closed completely
• On roads that are not flat, such as hills
• If the tires of a size other than specified by Toyota are installed
• If the suspension has been modified
• If a non-Toyota product is installed on the area displayed on the screen

● In low external temperatures, the screen may darken or the image may become

faint. The image could distort when the vehicle is moving, or you may not be
able to see the image on the screen, so always visually check your surroundings while you are driving.

● If you replace your tires, the position of the guide lines displayed on the screen

may be incorrect.

306

8-2. Panoramic view monitor

NOTICE
● See-through view, moving view, panoramic view, side clearance view, and

cornering view produce an image that is a composite of images captured by
the front camera, rear camera, and side cameras. As there is a limit to the
displayable range and content, make sure you fully understand the features of
the panoramic view monitor before you use it.

● The four corners of the see-through view, moving view, panoramic view, side

clearance view, and cornering view have a video composition processing region centered on borders of the cameras, and image clarity may decline. However this is not a fault.

● Depending on lighting conditions near each camera, bright and dark patches

may appear on the see-through view, moving view, panoramic view, side clearance view, and cornering view.

● See-through view, moving view, panoramic view, side clearance view, and cor-

nering view does not extend higher than the installation position and image
capture range of each camera.

● There are blind spots around the vehicle and as such there are regions not

displayed on the panoramic view monitor.

● Three-dimensional objects displayed in wide front view, rear view, wide rear

view or side view may not be displayed in see-through view, moving view,
panoramic view, side clearance view, and cornering view.

● People and other three-dimensional obstacles may appear differently when

● When the back door, which is equipped with the rear camera, or front doors,

which are equipped with side mirrors that have the built-in side cameras, are
open, images will not be displayed properly on the panoramic view monitor.

● The vehicle icon displayed in see-through view, moving view, panoramic view,

side clearance view, and cornering view is a computer generated image, so
the color, shape and size will differ from the actual vehicle. Therefore, nearby
three-dimensional objects may appear to be touching the vehicle, and actual
distances to three-dimensional objects may differ from those displayed.

● The camera may not function correctly and the image may be displayed on the

screen in the following manner:

• When the shift position is in "R", part or all of the screen may appear black
• When the shift position is in "R", the screen may not change to the camera

image

• When a shift position other than "R" is selected, the image from the camera

may remain displayed

• The guide lines are not displayed on the camera image, and attention sym-

bols and caution notices are displayed

307

8

Parking assist system

displayed on the panoramic view monitor. (These differences include cases
in which displayed objects appear to have fallen over, disappear near image
processing regions, appear from video composition processing areas, or when
the actual distance to an object differs from the displayed position.)

8-2. Panoramic view monitor

Area displayed on the screen
There are blind spots around the vehicle and as such there are regions not
displayed on the screen. Even if nothing around the vehicle is displayed on
the screen, there may actually be obstacles on the road, which you may
collide with. Always make sure to visually check your surroundings.

A Area displayed on the screen
B Objects not displayed on the screen
Objects in the black areas do not appear on the screen.

A Area displayed on the screen
B Parts of objects not displayed on the screen
Parts higher than the road do not appear on the screen.

308

8-2. Panoramic view monitor

INFORMATION
● The black parts around the vehicle icon are not displayed by the camera.

Visually check those areas.

● As the images are obtained from four cameras are processed and displayed on

the standard of a flat road surface, see-through view, moving view, panoramic
view (including zoomed display), side clearance view, and cornering view may
be displayed as follows:
• Objects may look collapsed; thinner or bigger than usual.

• An object with a higher position than the road surface may look further away

than it actually is or may not appear at all.

• Tall objects may appear protruding from the non-displayed areas of the

image.

● Variations in the brightness of the image may appear for every camera due to

lighting conditions.

● The displayed image may be misaligned due to inclination of the vehicle body

or change in vehicle height caused by the number of passengers and vehicle
load.

● If the doors are not completely closed, the image and the guide lines may not

be displayed correctly.

● The positional relationship of the road surface and objects with the vehicle

icon displayed on see-through view, moving view, panoramic view (including
zoomed display), side clearance view, and cornering view may differ to the
actual positions.

8

● Light from a back-lit license plate may appear on the screen.

Parking assist system

● Images indicated by [○] in the figure

are a composite, and hence some
areas may be difficult to see.

309

8-2. Panoramic view monitor

■ Wide front view
A Area displayed on the screen
B Objects not displayed on the

screen
Areas close to both corners of the
bumpers will not appear on the
screen.

INFORMATION
● The area covered by the camera is limited. Objects that are close to either

corner of the bumper or under the bumper cannot be displayed on the screen.

● The depth perception of the image displayed on the screen differs to the actual

distance.

● The wide front view camera uses a special lens, so the depth perception of the

image displayed on the screen differs to the actual distance.

310

8-2. Panoramic view monitor

■ Both side views (when the side mirrors are folded)
A Area displayed on the screen

INFORMATION
● The range that is displayed on the screen may differ due to the state of the

vehicle and road surface.

8

● The area covered by the camera is limited. Objects that are close to the bump● The depth perception of the image displayed on the screen differs to the actual

distance.

● The cameras on side view & rear view use a special lens, so the depth percep-

tion of the image displayed on the screen differs to the actual distance.

311

Parking assist system

er on the passenger’s side or under the bumper cannot be displayed on the
screen.

8-2. Panoramic view monitor

■ Rear view
A Area displayed on the screen
B Objects not displayed on the

screen
Areas close to both corners of the
bumpers will not appear on the
screen.

■ Wide rear view
A Area displayed on the screen
B Objects not displayed on the

screen
Areas close to both corners of the
bumpers will not appear on the
screen.

312

8-2. Panoramic view monitor

INFORMATION
● The range that is displayed on the screen may differ due to the state of the

vehicle and road surface.

● The area covered by the camera is limited. Objects that are close to either

corner of the bumper or under the bumper cannot be displayed on the screen.

● The depth perception of the image displayed on the screen differs to the actual

distance.

● The rear view and wide rear view cameras use a special lens, so the depth

perception of the image displayed on the screen differs to the actual distance.

● Objects that are higher than the rear camera may not appear in the monitor.

● Light from a back-lit license plate may appear on the screen.

Camera position
The panoramic view monitor cameras are in the locations shown in the
figures.
■ Front camera

8

Parking assist system

■ Side cameras

313

8-2. Panoramic view monitor

■ Rear camera

Cleaning the camera
If dirt or foreign matter, such as water droplets, snow, or mud, has stuck to
the camera, you will not be able to see the image clearly. If that happens,
splash the camera with a large amount of water and then wipe the camera
lens clean with a soft, damp cloth.
NOTICE
● The panoramic view monitor may stop functioning correctly. Take note of the

following items:

• Do not hit or apply a forceful impact on the camera. Doing so may change

the position and mounting angle of the camera.

• The camera is designed to be waterproof. Do not detach, disassemble, or

modify it.

• When washing the camera lens, splash the camera with a large amount of

water and then wipe the camera lens clean with a soft, damp cloth. Rubbing
the camera lens forcibly may scratch the camera lens and you may no
longer be able to see images clearly.

• The camera cover is made of resin. Do not allow an organic solvent, car

wax, window cleaner, or glass coating to adhere to the camera. If this happens, wipe it off immediately.

• Do not pour hot water on the vehicle in cold weather or apply other rapid

changes of temperature.

• If you wash the vehicle with a high pressure car washer, do not point the

hose directly at the camera or camera area. Applying strong water pressure
may result in the camera malfunctioning.

● If the camera is hit, it may cause a camera malfunction. If this happens, have

the vehicle inspected by any authorized Toyota retailer or Toyota authorized
repairer, or any reliable repairer as soon as possible.

314

8-2. Panoramic view monitor

■ Cleaning the rear camera with washer fluid

Dirt on the rear camera lens can be cleaned by operating the dedicated
camera cleaning washer. For details, refer to "Owner's manual".
● When cleaning the camera, it may be difficult to see the image due to the
washer fluid. When backing up, be sure to visually check all around the
vehicle both directly and using the mirrors before proceeding.
● If washer fluid remains on the camera lens surface after cleaning, the
image may be difficult to see at night due to the height or inclination of
the headlights of the vehicle behind.
● Some dirt may not be removed completely after cleaning. In this case,

rinse the camera lens with a large quantity of water and then wipe it
clean with a soft cloth dampened with water.
● Washer fluid is sprayed onto the camera lens surface. Therefore, the ice,
snow, etc. adhering around the camera cannot be removed.
NOTICE
Do not strike or hit the washer nozzle or subject it to a strong impact, as the
washer nozzle installation position and angle may be changed.

Parking assist lights
The parking assist lights of the panoramic view monitor system are installed in the locations shown in the figure.

8

Parking assist system

NOTICE
● Make sure to observe the following precautions, otherwise the panoramic view

monitor system may not operate correctly:

• Do not apply excessive force to a light or subject it to a strong impact. Doing

so may cause the position or installation angle of the light to deviate.

• Do not remove, disassemble, or modify the lights as they have a waterproof

construction.

• When cleaning the lights, wash them with a large amount of water, and then

wipe them with a soft wet cloth.

315

8-2. Panoramic view monitor

NOTICE
• Do not apply organic solvents, waxes, oil removing solvents, glass coatings,

etc. to the covers of the lights, as they are made of resin. If such is applied,
remove it immediately.

• Do not expose the lights to sudden temperature changes, such as applying

hot water to them when it is cold.

• When washing the vehicle with a high-pressure washer, do not spray water

directly on the lights or their surrounding area. High-pressure water can
damage the lights and cause them to not operate correctly.

● If a light has been subjected to a strong impact, it may be damaged. Have

the vehicle inspected by any authorized Toyota retailer or Toyota authorized
repairer, or any reliable repairer as soon as possible.

Differences between the screen and the actual road
The composite images on the panoramic view monitor and guide lines give
a distance guide for flat road surfaces. Therefore, there is a margin of error
between the guide lines on the screen and the actual distance and course
on the road.
■ When the ground behind the vehicle slopes up sharply

The distance guide lines will appear
to be closer to the vehicle than the
actual distance. Thus, objects on upslopes will appear to be farther away
than they actually are. In the same
way, there will be a margin of error
between the guidelines and the actual
distance and course on the road.

316

8-2. Panoramic view monitor

■ When the ground behind the vehicle slopes down sharply

The distance guide lines will appear
to be further from the vehicle than
the actual distance. Thus, objects on
down-slopes will appear to be closer
than they actually are. In the same
way, there will be a margin of error
between the guidelines and the actual
distance and course on the road.

■ When any part of the vehicle sags

When any part of the vehicle sags
due to the number of passengers or
the distribution of the load, there is
a margin of error between the guide
lines on the screen and the actual distance and course on the road.
A Margin of error

8

Parking assist system

■ Estimated course center line

As the guide lines are shown midair
near the rear bumper, there are times
that they may look like they are offcenter.

317

8-2. Panoramic view monitor

Differences between the screen and actual 3D objects
Since the guide lines and displayed on the screen are displayed for a
flat road surface, it is not possible to determine the position of three-dimensional objects. When approaching a three-dimensional object that extends
outward (such as the flatbed of a truck), take note of the following cautions.
WARNING
When the Toyota parking assist-sensor display is red, make sure to visually check
before moving the vehicle any further. There is the danger that you may collide
with another vehicle or have some other unforeseen accident.

■ Displaying panoramic view (including zoom display)

On the screen, it appears that there is a gap between the vehicle’s bumper
and another object or vehicle, and it does not look as if the vehicle will
collide with the object or vehicle. However, the vehicle is over the course
lines, so the vehicle may collide with the object or vehicle. Make sure to
visually check your surroundings.

318

8-2. Panoramic view monitor

■ Estimated course lines
● On the screen, it appears that the

vehicle’s bumper is outside of the
estimated course lines, and it does
not look as if the vehicle will collide
with the object or vehicle. However,
the vehicle is over the course lines,
so the vehicle may collide with the
object or vehicle. Make sure to visually check your surroundings.
A Estimated course lines

● Three-dimensional objects in high

positions (such as the overhang
of a wall or loading platform of
a truck) may not appear on the
screen. Make sure to visually check
your surroundings.

8

Parking assist system

A Overhang of a wall

319

8-2. Panoramic view monitor
● On the screen, a truck flatbed may

appear to be outside of the estimated course lines and the vehicle
does not look as if it will collide with
the truck. However, the flatbed may
actually cross over the estimated
course lines and if you reverse
as guided by the estimated course
lines, the vehicle may hit the truck.
Make sure to visually check your
surroundings.
A Estimated course lines

■ Distance guide lines

On the screen, the distance guide
lines shows that a truck is parking at
point . However, in reality if you reverse to point , you will collide with
the truck. On the screen, it appears
that point
is closest followed by
points
and . However, in reality, the distance to points
and
is the same, and point
is farther
than
and . Make sure to visually check behind you and your suris
roundings. The distance to point
about 1 m (3 ft.).

320

8-2. Panoramic view monitor

■ Overhang of a diagonal beam

In panoramic view, a diagonal beam
may appear straight and seems likely not to be struck, however, since
the top part of the is actually overhanging, the vehicle may hit it. Make
sure to visually check the rear and
surroundings.

■ Magnifying function

Unlike the normal panoramic view,
the panoramic view magnifying function zooms in on the vehicle icon.
Therefore, white lines on the road,
walls, and other objects may look
bent.

8

Parking assist system

321

8-2. Panoramic view monitor

If you notice any symptoms
If you notice or are troubled by any of the symptoms below, check the issue
again referring to the likely cause and solution.
If the symptom is not resolved by the solution, have the vehicle inspected
by any authorized Toyota retailer or Toyota authorized repairer, or any
reliable repairer.
Symptom

Likely cause

Solution

● The vehicle is in a dark

area or it is night.

● The temperature around

the lens is either high or
low.

● The outside tempera-

Visually check the vehicle’s surroundings while you are driving.

● There are water drop-

Use the panoramic view monitor
again once the camera and conditions have improved.

ture is low.

lets on the camera.

The screen is
difficult to see

● It is raining or humid.

The procedure for adjusting the
etc.) is stuck to the cam- picture quality of the panoramic
view monitor is the same as the
era.
procedure for adjusting the multi● Sunlight or headlights
media screen.
are shining directly into
the camera.
● Foreign matter (mud

● The vehicle is under flu-

orescent lights, sodium
lights, mercury lights,
etc.

The image is
blurry

Splash the camera with a large
amount of water and then wipe
Dirt or foreign matter, such the camera lens clean with a soft,
as water droplets, snow, or damp cloth.
mud, has stuck to the cam- Operate the dedicated camera
era lens.
cleaning washer and clean the
camera lens. For details, refer to
"Owner's manual".

The screen is
misaligned

The camera has received
a strong impact.

322

Have the vehicle inspected by any
authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

8-2. Panoramic view monitor
Symptom

Likely cause
The camera position is
misaligned.

The guide lines
are significantly
misaligned

Solution
Have the vehicle inspected by any
authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

● The vehicle is tilted

(There is a heavy load
on the vehicle, tire presVisually check the vehicle’s sursure is low due to a tire
roundings while you are driving.
puncture, etc.).

● The vehicle is on an in-

cline.

The estimated
course lines
move even
though the
steering wheel is There is a malfunction in
straight (the ve- the signals being output by
hicle width guide the steering sensor.
lines and estimated course
lines are out of
alignment).

Have the vehicle inspected by any
authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

8

Close the back door.
The back door is open.

The panoramic
view display
cannot be enlarged. The seethrough view/
The Toyota parking assistmoving view,
sensor may be malfuncside clearance
tioning or dirty.
view, and cornering view cannot be displayed.

If this does not resolve the issue,
have the vehicle inspected by any
authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

Follow the correction procedures
for malfunctions of the Toyota
parking assist-sensor. (For details
about the Toyota parking assistsensor, see the vehicle "Owner's
manual".)

Related Links
Changing the screen display settings(P. 67)

323

Parking assist system

The guide lines
are not displayed

8-2. Panoramic view monitor

Information about free/open source software
This product contains free/open source software.
You can get information about free/open source software and/or source
codes from the following URL:
https://www.denso.com/global/en/opensource/svss/toyota

324
