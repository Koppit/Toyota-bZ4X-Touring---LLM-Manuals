# 6-8. How to use the message function

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 6 Hands-free calls, pages 243–248

function

message

the

use

to

How

6-8. How to use the message function

Precautions when using the message function
Messages are transferred from the cellular phone connected for hands-free
calls. The multimedia system can be used to check, reply, and send messages. Depending on the cellular phone model being connected, it may not
be possible to transfer messages to the multimedia system. If the cellular
phone does not support messaging, this function cannot be used.
This function can be used with cellular phones that support HFP and MAP.
To check if a cellular phone is compatible with HFP and MAP, check the
user’s manual that came with the cellular phone, or its compatible profiles.
INFORMATION
● You need to enable the message sharing setting from your cellular phone

settings.

● This function cannot be used during emergency calls.

● Depending on the cellular phone model, it may not be possible to use the

e-mail function.

● Depending on the cellular phone model, it may not be possible to use the reply

function is used.

● Depending on the connected cellular phone model, it may be necessary to

perform additional operations on the cellular phone.

● For SMS messages, the subject is not displayed.

● Depending on the cellular phone model, the subject name of a received MMS

may not be displayed.

● If [Auto read messages] is on, messages are read aloud.

● Some information may not be displayed depending on your cellular phone

model and registration status to the multimedia system.

Related Links
Setting Bluetooth® devices(P. 99)
Bluetooth® specifications and compatible profiles(P. 107)

Checking messages
Sent and received messages can be checked.
] from the main menu.
1 Touch [
2 Touch [Messages].
3 Select an account.

243

Hands-free calls

function.

● Cellular phone messages will be automatically transferred when each message

6

6-8. How to use the message function

4 Select the message sender.
5 Select each item as necessary.
[
] : Enlarges or minimizes the
message screen.
[
] : Displays the reply to message
screen.
] : Reads the message aloud.*1

[

To stop the message being read
aloud, touch [

].

] : Calls the message sender by phone.

[

Depending on the contact registration status, the phone number must be selected.
[

] : Displays the contact information of the other party.

INFORMATION
While the message screen is enlarged with an e-mail, touch [Mark Unread] or
[Mark Read] to mark the message as unread or read.

Related Links
Replying to messages(P. 245)
Making calls from the message function(P. 248)
Making calls from contacts(P. 222)

Checking new messages
When an e-mail or an SMS or MMS message is received, a new message
notification is displayed at the top of the screen. While [Voice support] is
on, voice control system starts.
● The following operations can be

performed when a message is
received.

] : Displays the body of the mes[
sage.
[

] : Reads the message aloud.*1

*1 : This function is not available in some languages.

244

6-8. How to use the message function

Related Links
Changing the voice control settings(P. 69)
Replying to messages(P. 245)

Replying to messages
Replies can be sent to received messages.
] from the main menu.
1 Touch [
2 Touch [Messages].
3 Select an account.
4 Select the message sender.
].
5 Touch [
6 Enter each item.
[Template] : Fill in the selected template message.
[

6

] : Enter using the keyboard.

Hands-free calls

7 Touch [Send] to reply.

INFORMATION
Replies can also be sent with templates using voice control system. (SMS only)

Related Links
Operating the system with voice control(P. 40)
Editing templates(P. 246)
Entering letters and numbers(P. 27)
Starting voice control(P. 42)

Sending new messages
New e-mail or SMS messages can be sent. MMS is not supported.
] from the main menu.
1 Touch [
2 Touch [Contacts].
3 Select recipients from your contact list.

245

6-8. How to use the message function

4 Select the desired [
mail address.

] or e-

For email addresses, select the sender
account.

5 Enter each item.
[Template] : Fill in the selected template message.
[

] : Enter using the keyboard.

6 Touch [Send].
INFORMATION
Reply templates can also be sent using the voice control system. (SMS only)

Related Links
Operating the system with voice control(P. 40)
Editing templates(P. 246)
Entering letters and numbers(P. 27)
Starting voice control(P. 42)

Editing templates
Templates can be edited.
1 Touch [
] from the main menu.
2 Touch [Template].
3 Touch [
edit.

] of the template to

4 Enter the template and save.
Touch [Default] to initialize all the template sets.

INFORMATION
● The templates are set separately for each cellular phone.

● Editing some templates may not be possible.

246

6-8. How to use the message function

Related Links
Replying to messages(P. 245)
Sending new messages(P. 245)

6

Hands-free calls

247

6-8. How to use the message function

Making calls from the message function
Hands-free calls can be made using the message function.
● Touch the blue number to make a call.
Consecutive numbers may be recognized as phone numbers. In addition, some
phone numbers, such as phone numbers from other countries, may not be recognized.

Making calls from the e-mail, SMS, or MMS message screen
Email, SMS, and MMS senders can be called.
● For e-mail, a phone number must be registered in the same contact data.
● For MMS, the phone number may need to be registered to the same

contact data.

1
2
3
4

] from the main menu.
Touch [
Touch [Messages].
Select an account.
Select the message sender.

5 Touch [
] or press the [
switch on the steering.

]

Depending on the contact registration
status, the phone number must be selected.

Related Links
Operating with the steering switches(P. 218)

248
