# 2-11. Bluetooth® Settings

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 99–102

Bluetooth®Settings

2-11. Bluetooth® Settings

Setting Bluetooth® devices
How to use the multimedia system and the connected Bluetooth® device
can be set.
2

INFORMATION

● Audio may skip if hands-free calling is selected while playing Bluetooth® audio.
● Depending on the Bluetooth® device model, it may be necessary to perform

operations on the Bluetooth® device.

● A Bluetooth® device cannot be selected during an emergency call.
● Settings cannot be selected while driving.

● Settings may not be selectable depending on the status of the Bluetooth®

device.

1 Touch [
] from the main menu.
2 Touch [Bluetooth & Devices].
3 Touch the Bluetooth® device to configure from the sub menu.
Nothing will display unless at least one Bluetooth® device is registered.

4 Set each item.

Setting
[Use for
phone]

Description
Enables or disables the hands-free call function.*1*2

*1 : Displayed only when the Bluetooth® device can execute this function. Toggling

the function on or off will display or hide related functions, or turn them on or
off. This cannot be used for calls or audio while Apple CarPlay or Android Auto
is set to on. The same also applies in reverse.
*2 : The connection with this function will be disconnected if the button is turned off.
When connected with a device such as by being automatically connected, the
function that turned off will not automatically turn on. The connection with this
function will be started if the button is turned on.

99

Settings and registration

● Settings details are set separately for each individual Bluetooth® device.

2-11. Bluetooth® Settings
Setting
[Use for media]

Description
Enables or disables the audio function.*1*2

[Use for Apple
Enables or disables the Apple CarPlay function.*1*2
CarPlay]
Enables or disables the Android Auto function.*1*2
[Use for Android Auto]

If the [Use for Android Auto] settings are switched OFF
while using Android Auto, [Use for phone] settings will be
switched ON.

[Setup secure The password for the Wireless Android Auto function can be
password]
changed.*3
Sets the device as a secondary device.*3
This setting can be used when a driver has been registered
[Set as secon- and the detected cellular phone has not been set as their
dary device] main device. Once set as a secondary device, the device
will be recognized as such. The priority of the vehicle’s Bluetooth® connection will be in the sequence of main device,
secondary device, and the most recently connected device.
[Remove secondary device Removes the device as a secondary device.*3
setting]
Disconnects a Bluetooth® device from the multimedia system.
[Disconnect]

[Forget]

The connected functions will turn off. The device may not
automatically connect to the function even if the device is
reconnected.
Allows registered Bluetooth® devices to be deleted.

● "Volume"

*1 : Displayed only when the Bluetooth® device can execute this function. Toggling

the function on or off will display or hide related functions, or turn them on or
off. This cannot be used for calls or audio while Apple CarPlay or Android Auto
is set to on. The same also applies in reverse.
*2 : The connection with this function will be disconnected if the button is turned off.
When connected with a device such as by being automatically connected, the
function that turned off will not automatically turn on. The connection with this
function will be started if the button is turned on.
*3 : This function is not available in some countries or areas.

100

2-11. Bluetooth® Settings
Setting

Description
Adjusts the ringtone volume.*1

[Ringtone]

[Received volume] Adjusts the receiver volume.*1
[New message]

2

Adjusts the volume for incoming messages.

Setting

Description
The ringtone for hands-free calling can be set as follows.
• Sets the ringtone set for the cellular phone as the ringtone

[Ringtone]

for the multimedia system.

• Sets the existing ringtone.
• Sets the system to read aloud the name of the party call-

ing.*2

The ringtone for incoming messages can be set as follows.
[Message
tone]

• Set to the existing incoming ringtone.
• Set to mute.
• Set to read aloud the name of the sender.*2

[Sort contacts by]

The display of names registered in your contacts can be
changed as follows.
• Sort contacts by the first name.
• Sort contacts by the last name.

[Auto read
messages]
[Clear call
history]

Enables or disables the automated message read out function.
Deletes hands-free call history data.
Displayed when a cellular phone with [Sync contacts] turned
off is connected.

● "Syncing"

Setting

Description

Enables or disables automatic transfer of contacts, favorites,
and history to the multimedia system.
[Sync
contacts] When the setting is changed from disabled to enabled automatic transfer of the phone book starts.

*1 : Cellular phone and multimedia system speaker volume/ringtone volume may

be synchronized. The speaker volume/ringtone volume with the multimedia
system cannot be synchronized depending on the cellular phone model.
*2 : This function is not available in some languages.

101

Settings and registration

● "General"

2-11. Bluetooth® Settings
Setting

Description

[Sync
Some cellular phone models do not allow favorites to be transcontacts] ferred.
[Display
contact
images]

Enables or disables the contact image display.
The contact image cannot be downloaded to the multimedia
system unless the [Sync contacts] is set to on.

Related Links
Precautions when using Bluetooth® devices(P. 104)
Bluetooth® specifications and compatible profiles(P. 107)
Precautions for hands-free calling(P. 210)
Precautions for Bluetooth® audio playback(P. 202)
Precautions when using Apple CarPlay and Android Auto(P. 123)
Setting a Bluetooth® device as a primary device(P. 116)
Setting a Bluetooth® device as a secondary device(P. 117)
Changing and registering a user profile(P. 58)
Registering a user profile for the first time (Type A)(P. 51)

102
