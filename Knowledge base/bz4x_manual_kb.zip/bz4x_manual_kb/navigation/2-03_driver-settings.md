# 2-3. Driver settings

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 58–63

settings

Driver

2-3. Driver settings

Changing and registering a user profile*1
The user profile can be registered or changed. By registering a user profile,
multimedia settings, and various other individual vehicle settings can be
saved as a profile for each driver.
1 Touch [

] from the main menu.

2 Touch [
] (User profile name or vehicle name) or [
the submenu.
3 Select the desired item.

Setting

"Saved profiles"

][Guest] on

Description
The user profiles registered on the vehicle are displayed in a
list. The profile can be switched by touching the desired profile
and enter the password.
Touching [Edit] enables you to delete a registered user profile.
(not available in guest mode)

[
][ConRegister a new user profile.
nect your
If the driver has already been registered on other vehicle, some
account]/
[Create pro- multimedia settings registered on the vehicle will be reflected.
file]
Change to the guest driver.
By using the guest driver, personal settings can be adjusted
and not saved to another user profile. When handing your vehi[Sign out to
cle off to another person, touching [Sign out to guest mode]/
guest
[Sign out] will hide the personal information of the connected
mode]/[Sign
device. This can be used to protect private information, such as
out]
the search history or personal settings.
Profiles other than the search history or personal settings will
be applied to the guest drivers.

*1 : This function is not available in some countries or areas.

58

2-3. Driver settings

INFORMATION
For safety purposes, these settings cannot be operated while the vehicle is moving.
2

Creating a new user profile (Type A)
] from the main menu.

](User profile name or vehicle name) or [
2 Touch [
the submenu.

][Guest] on

3 To use the Toyota app on a smartphone to register a profile, touch
[Connect your account].
4 Touch [Link].
● If you have not installed the Toyota app, touch [Get the App] and download it

using the QR code on the screen.

5 Open the Toyota app on a smartphone, follow the instructions on
the screen and scan the QR code, or enter the verification code to
register a driver.
6 Touch [I Agree].
Once registration is complete, a message is displayed and your profile is saved.

7 After registering your profile, register a device in order to identify
the driver. To continue with setup, touch [Continue].
You can also register a device at a later time.

8 Register a device on the driver setup screen. By registering a device to identify the driver, your profile will be automatically loaded.
● You can register any desired device, such as a smartphone in your profile.
● You can register multiple devices in your profile.

Creating a new user profile (Type B)
1 Touch [

] from the main menu.

2 Touch [
](User profile name or vehicle name) or [
the submenu.

][Guest] on

3 Touch [

][Create Profile].
4 Enter the user profile name.
5 Enter the desired PIN code.
● Set a PIN code to protect the privacy of the user profile.

● To register a profile without setting a PIN code, touch [Skip].

6 Reenter your PIN code to register your profile.

59

Settings and registration

1 Touch [

2-3. Driver settings
Once registration is complete, a message is displayed and your profile is saved.

7 After registering your profile, register a device in order to identify
the driver. To continue with setup, touch [Continue].
You can also register a device at a later time.

8 Register a device on the driver setup screen. By registering a device to identify the driver, your profile will be automatically loaded.
Related Links
Setting up how to identify a driver(P. 61)

60

2-3. Driver settings

Setting up how to identify a driver*1
Set a device in order to identify a driver. When the power switch is turned to
ACC or ON and a registered device is detected, the profile that the device
is assigned to is automatically loaded. You can select a device such as a
smart key and smartphone as the device to be registered.

Settings and registration

] from the main menu.
1 Touch [
2 Touch [Personal info] on the submenu.
3 Select the desired item.

Setting

User profile name

Description
The name of the user profile is displayed.
Touch [Edit] to change the profile
name.

"Devices linked to your profile"

"Face identification"(1)(2)

Driver identification is performed using
a face and the applicable profile is
loaded. Touch [Set-up face] to register.(→ P.62)
To delete the registered face information, touch [Remove face data].

"PIN"(3)

2

Driver identification is performed using
a PIN code and the applicable profile
is loaded. Touch [Set new PIN] to register.

*1 : This function is not available in some countries or areas.

61

2-3. Driver settings
Setting

[Link key](1)

Description
Place all the desired electronic keys to
be registered in the vehicle and then
perform registration. Key(s) registered
and allocated to other driver(s) cannot
be registered. When the smart entry &
start system is disabled, the key used
to unlock the doors will be assigned to
the driver.
Place all the desired digital keys to
be registered in the vehicle and then
perform registration. Digital key(s) registered and allocated to other driver(s)
cannot be registered.

[Link digital key](1)(2)

As when the vehicle’s electronic key
is detected earlier than a registered
digital key the detection of the digital
key will be stopped, it is recommended to register both the electronic key
and digital key.

"Bluetooth devices"

Driver identification is performed using
a smartphone or other Bluetooth® device and the applicable profile is loaded. Touch [Link devices] to register.
(→ P.116)

[Reset settings]

Some multimedia settings for the selected user profile will be deleted.
The registration for the selected user
profile will be deleted.

[Delete driver]

Deleting the user profile registered for
the owner will delete all users profile
registered in the vehicle.

(1) Refer to the vehicle "Owner's manual".
(2) If equipped
(3) This function is not available in some countries or areas.

Registering face identification
Face identification enables the system to identify the driver.
] on the main menu.
1 Touch [
2 Touch [Personal info] on the submenu.
3 Touch [Set-up face].

62

2-3. Driver settings

4 Carefully read the Terms of Service and touch [Accept].
5 Look directly at the driver monitor camera, ensure only your
face is being displayed, and
then touch [Begin].

2

● Once registration is complete, a message is displayed on the screen.

● If an error message appears, follow the on-screen instructions and try again.

63

Settings and registration

6 The system will start scanning your face.
