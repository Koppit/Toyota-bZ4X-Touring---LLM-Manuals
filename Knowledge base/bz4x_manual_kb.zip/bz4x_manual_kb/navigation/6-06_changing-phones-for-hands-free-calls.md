# 6-6. Changing phones for hands-free calls

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 6 Hands-free calls, pages 235–235

calls

hands-free

for

phones

Changing

6-6. Changing phones for hands-free calls

Switching phones for hands-free calls*1
If two cellular phones are connected as hands-free phones, each cellular
phone can be used. The hands-free system makes it possible to switch
cellular phones. The hands-free phone screen displays the selected cellular
phone data, such as contacts and history. Functions such as incoming calls
can also be used with the unselected cellular phone.
To connect two cellular phones as hands-free phones, it is necessary to
register and set a driver.
] from the main menu.
1 Touch [
2 Touch [Devices].
3 Select the cellular phone you
want to use.
A cellular phone that is on a call, receiving a call, or making a call cannot
be selected.

6

● If making a call from a screen other than the hands-free phone screen, the

call is placed as the primary device.

● If you are on a hands-free call using either one of the devices, calls cannot

be placed from the other device.

● When a hands-free call is being made by any of the hands-free phones and

an incoming call is answered by another hands-free phone, the first call is
disconnected.

● The following functions are also available on the unselected cellular phone.
• Phone incoming call function
• Message receiving and sending functions (when receiving a message)

● The primary device will not necessarily be changed even if the cellular

phone is switched.

Related Links
Registering a user profile(P. 50)
Changing and registering a user profile(P. 58)
Setting a Bluetooth® device as a primary device(P. 116)
*1 : This function is not available in some countries or areas.

235

Hands-free calls

INFORMATION
