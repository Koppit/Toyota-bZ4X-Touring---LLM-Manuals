# 2-7. Vehicle settings

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 71–77

settings

Vehicle

2-7. Vehicle settings

Setting dealer information*1
You can register and delete dealer information. Registering the information
of the dealer at which you get your vehicle serviced enables you to contact
the dealer from the settings screen when you want to reserve a service.

Settings and registration

] from the main menu.
1 Touch [
2 Touch [Dealer info] on the submenu.
3 Select the desired item.

2

Setting

Description

[Add dealer]

Registers the preferred dealer, contact name and phone number.

Dealer name

Displays the stored dealer name. Touching [
change the information.

] enables to

"Contact"

Displays the stored contact name. Touching [
change the information.

] enables to

"Phone"

Displays the stored phone number. Touching [
change the information.

] enables to

[Delete dealer] Deletes the dealer information.

*1 : This function is not available in some countries or areas.

71

2-7. Vehicle settings

Changing the security settings
Settings related to security and privacy can be changed.
] from the main menu.
1 Touch [
2 Touch [Info & Security] on the submenu.
3 Select the desired item.

Setting

Description
Displays the system name (vehicle
name).

[Vehicle name]

This is the device name displayed
when searching for a Bluetooth® device from an external device. The
name can be changed by touching it.

"Digital keys"(1)(2)
[Enable digital keys]

Enable the use of digital keys.
Delete registered digital keys.

[Remove digital keys]

When deleting the digital key, perform
the operation in an area with good
DCM reception. If deleting the digital
key fails, wait about 1 minute and try
again.

"Privacy"

[Activate all data](3)

72

Select to enable/disable data upload
via communication service. When disabled, the communication service is
not available. When enabled, the privacy policy and terms of use will
be displayed on the screen. Touch [I
Agree].

2-7. Vehicle settings
Setting

Description

[Use location data]

Set whether to send location information when using the communication
service. Turning this setting off will disable some services that use location
information.

[Security lock]

Enable the password-protected security lock to protect personal information.
When set ON, entering the password
will be required when the 12-volt battery is replaced or the multimedia system is removed from the vehicle.

[Reset security lock password]

Reset the set security lock password.

[Remote security](3)

The operating status of Remote security is displayed.

[System reset]

Reset all of the system’s data and
restore the settings to the factory defaults.

(1) If equipped
(2) Refer to the vehicle "Owner's manual".
(3) This function is not available in some countries or areas.

INFORMATION
● Communication may be cut off after resetting the system. In that case,

restart the system.

● After initializing all the information, all the data in the multimedia system will

be initialized and returned to the factory default. It cannot be returned to the
state before initialization.

Related Links
Restarting the system(P. 15)

73

2

Settings and registration

[Use voice data](3)

Select to enable/disable voice data
upload via communication service.
When disabled, voice data is not available via communication service. When
enabled, the privacy policy and terms
of use will be displayed on the screen.
Touch [I Agree].

2-7. Vehicle settings

Setting up the security lock
1
2
3
4
5

Touch [
] from the main menu.
Touch [Info & Security] on the submenu.
Touch [Security lock].
Touch [OK].
Set a password that contains between 4 and 15 alphanumeric characters.
6 Reenter your password.
A message will appear and the security lock is enabled.

INFORMATION
● After a password is set, if the system is reset after the 12-volt battery is

replaced or the multimedia system is removed from the vehicle, a password
to operate the multimedia system needs to be entered. Enter the password
that you set.

● If the password is entered incorrectly a certain number of times, access to

enter a password will no longer be granted. If that happens, ask your dealer
to unlock the system.

● To ensure security, do not repeatedly use the same password or a word that

can be found in the dictionary when setting a password.

74

2-7. Vehicle settings

Updating and checking the software information*1
Check and update software information. The software is updated for the
purpose of improving multimedia system functions and operations for more
smoother usability.

Setting

Settings and registration

] from the main menu.
1 Touch [
2 Touch [Software update] on the submenu.
3 Select the desired item.

Description

"Software update"

[Updates available]

Touch [View ] to check software update information. After
checking whether there is an update available and the content of the update, the updated data can be downloaded
and software update can be installed.
If there is no updated data available, [No updates available] will be displayed.

[Model info]
[Update software]

Check the current software version etc.
Updating the software.
This will not be displayed if there is no update data available.
Check software update history.

[History]
[License information]

2

This setting will not be displayed if there is no update history.
Check the software license information.

[Update notificaTurn the notification for software updates on or off.
tion]

Updating the software*1
Use one of the following methods to update the software:
*1 : This function is not available in some countries or areas.

75

2-7. Vehicle settings
● Update the software using Data Communication Module (DCM)
● Update the software using Wi-Fi®

INFORMATION
● Map data cannot be updated using this service.

● Some operations cannot be performed while the software is updating.

● If you have any questions, contact any authorized Toyota retailer or Toyota

authorized repairer, or any reliable repairer.

NOTICE
● Update the software at your own risk.

● The software cannot be restored to the previous version once the software has

been updated.

● The update software can only be used on this system. It cannot be used on any

other device.

● Depending on the content of the software update, some settings may be reset.

If that happens, reconfigure the applicable settings after the software has been
updated.

● Although basic functions are possible during the software update, operation

may be slow. If possible, do not operate the system.

● After the software is updated, the Toyota Motor Corporation distribution server

will be automatically notified that the update has completed. Note that Toyota
Motor Corporation does not use the information it receives for any purpose
other than software updates. You may also be charged for communication fees
depending on your subscription.

Updating the software using DCM or Wi-Fi®
This system regularly accesses the distribution server to check for software
updates.
1. Touch the button in the software update notification.
2. Follow the on-screen instructions to check and agree to the update
content and terms.
● Downloading of the update data will start. Once the data has been
downloaded, installation will begin.
● The time required for download and installation may increase depending on the communications environment. If you turn off the power
switch while the software is installing, installation will resume the next
time the vehicle is started.
● Once the update is complete, a message is displayed on the screen.

76

2-7. Vehicle settings
● If the system needs to be restarted, a message will appear. Touching

[Yes] restarts the system.
● To check the software update history, touch [History] on the software
update history screen.

■ Manually updating the software

] from the main menu.

INFORMATION
● If critical update data is available on the distribution server, a message will be

displayed. Touch [OK] to download the update data.

● If the software update fails, the system will start with the previous version.
● The following conditions must be met to use Wi-Fi® to update the software:
• The Wi-Fi® function is turned on.
• The vehicle must be in a location where it can access Wi-Fi®
• The system must be connected to a Wi-Fi® access point (e.g. home, work,

etc.)

77

Settings and registration

1. Touch [

2. Touch [Software update] on the submenu.
3. Touch [View] of "Updates available".
4. Follow the on-screen instructions to check and agree to the update
content and terms.
● Downloading of the update data will start. Once the data has been
downloaded, installation will begin.
● The time required for download and installation may increase depending on the communications environment. If you turn off the power
switch while the software is installing, installation will resume the next
time the vehicle is started.
● Once the update is complete, a message is displayed on the screen.
● If the system needs to be restarted, a message will appear. Touching
[Yes] restarts the system.
● To check the software update history, touch [History] on the software
update history screen.

2
