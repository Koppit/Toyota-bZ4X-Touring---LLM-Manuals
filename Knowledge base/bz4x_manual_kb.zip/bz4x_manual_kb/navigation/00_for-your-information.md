# For your information

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, Introduction, pages 7–8

Introduction

Introduction

For your information
Multimedia owner’s manual
● This manual describes the operation of the multimedia system. Please

read this manual and the vehicle "Owner's manual" carefully to ensure
proper use.
● Please be aware that the content of this manual may be different
from the system in some cases, such as due to software updates and
changes to specifications.
● This manual contains information related to system software Ver.2230

and earlier. For the latest information, refer to the following URL. Before
using this system, be sure to read the information relating to the latest
software version. For details of the current software version, see “Updating and checking the software information”(→ P.75).
Depending on the country or area, the software update service may not
be available.
Language

URL

English

https://www.toyota-europe.com/
manual?
parameter=om9ad79e.bz4xtouring.260
1.bev.mm

French

https://www.toyota-europe.com/
manual?
parameter=om42k03k.bz4xtouring.260
1.bev.mm

Spanish

https://www.toyota-europe.com/
manual?
parameter=om9ad81s.bz4xtouring.260
1.bev.mm

Russian

https://www.toyota-europe.com/
manual?
parameter=om42k06r.bz4xtouring.260
1.bev.mm

QR code

● The screens shown in this manual may differ from the actual screen of

the system depending on availability of functions, subscription status,
and map data available at the time this manual was produced.
● The company names and products listed in this manual are trademarks
and/or registered trademarks of their respective companies.

7

Introduction

Disclaimer about data compensation
This system saves data onto the internal memory. Data saved in the memory may become corrupted or lost due to system failure, repair, malfunction,
bugs, or other causes.
Please note that Toyota Motor Corporation takes no responsibility whatsoever for direct and/or indirect damage, and offers no compensation for
data if the data that was saved in the internal memory could not be saved
properly.

Removal of the 12-volt battery
When the power switch is turned off, all data is saved in the system. If the
12-volt battery terminal is removed before the data is saved, the data may
not be saved correctly.

8
