# 1-1. Basic operation of multimedia system

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 1 Basic operation, pages 14–27

system

multimedia

of

operation

Basic

1-1. Basic operation of multimedia system

Display and control

A Display
Operate the touch screen by directly touching it.
B [

VOL] knob

Turn the audio on/off and adjust the volume.(→ P.34)

INFORMATION
● The illustration is for left-hand drive vehicles. The button positions and shapes

differ for right-hand drive vehicles.

● The LCD screen may appear washed out or dark depending on the surrounding

environment or angle it is viewed.

● The screen may be difficult to see if sunlight or other external light hits the

screen.

● The screen may appear dark or hard to see if you wear polarized sunglasses.

WARNING
For safety, the driver should operate the display as little as possible while driving
and should stop the vehicle to operate the display. Operating the display while
driving is dangerous such as mistakenly turning the steering wheel or other unforeseen accidents. Additionally, look at the display only as necessary and as
briefly as possible when driving the vehicle.

NOTICE
Do not use the multimedia system for long periods of time with the EV system
turned off. Doing so may deplete the 12-volt battery.

14

1-1. Basic operation of multimedia system

Restarting the system

1

When the system response is extremely slow, you can restart the system.
Basic operation

Press and hold the [
at least 3 seconds.

VOL] knob for

15

1-1. Basic operation of multimedia system

Multimedia screen overview

A Main menu
Changes the function to be displayed on the screen when an icon is touched.
B Microphone button
Displays the voice control screen enabling verbal operation of the navigation,
audio and various other functions.
C Status icons
The clock and icons with information about communication statuses, etc. are
displayed at the top of the screen.
D Climate control buttons
Operate the air conditioner and vehicle functions.*1

INFORMATION
Touch [
] on the map screen to display the map in a larger size, and touch
[
] on the audio screen to display
the content in a larger size.

Related Links
Main menu(P. 18)
Status icons(P. 20)
*1 : Refer to the vehicle "Owner's manual".

16

1-1. Basic operation of multimedia system

Starting voice control(P. 42)

1

Basic operation

17

1-1. Basic operation of multimedia system

Main menu
The function to be displayed on the
screen can be changed by touching
an icon.

: Apple CarPlay®
Displays the Apple CarPlay screen.(→ P.126,129)
: Android Auto™
Displays the Android Auto screen.(→ P.132,135)
: Navigation
Displays the map screen. The navigation system can be operated to
search for a destination or perform other navigation system-related tasks.
(→ P.28,143)
: Audio
Displays the audio control screen. The desired source can be selected to
play audio.(→ P.34,177)
: Phone
Displays the phone screen. A cellular phone connected via Bluetooth® can
be used to make hands-free phone calls.(→ P.209)
: Vehicle information*1
Displays the vehicle information screen. Charging schedule can be set.
: Connected
Displays the apps screen.
This function is not available in some countries. For details (service available countries list, operation, setup, etc.), contact any authorized Toyota
retailer or Toyota authorized repairer, or any reliable repairer.
*1 : Refer to the vehicle "Owner's manual".

18

1-1. Basic operation of multimedia system

INFORMATION
The Apple CarPlay/Android Auto icons are displayed when a supported device
connects to the system and the applicable function is enabled.

19

1

Basic operation

: Settings
Displays the settings screen. Multimedia system and vehicle settings can
be changed.(→ P.56)

1-1. Basic operation of multimedia system

Status icons
The time and icons with information
about communication statuses are
displayed at the top of the screen.

Displays the current time. Touching the clock displays the date and time
settings screen.
Displays the connection status of the cellular phone connected via Bluetooth®. Touching the icon displays the Bluetooth® settings screen.
Displays the reception level of the connected cellular phone.
Displays the remaining battery charge of the connected cellular phone.
Displays the status of sharing data with the Toyota Center Server.
is displayed when data sharing with the Toyota Center Server is disabled.
Displays the reception status of the Data Communication Module (DCM).*1
Displays the Wi-Fi® reception level.
Displayed when the Toyota parking assist-sensor is active.*1
Displayed when a hands-free call was made while a screen other than the
phone screen was being displayed.
*1 : If equipped

20

1-1. Basic operation of multimedia system
1

Displayed when the internet radio is playing.*1

Displays the status of the Excess speed notification method in Road Sign
Assist (RSA). Touching the icon changes the notification buzzer on/off for
excess speed notification.*1
INFORMATION
● The displayed remaining battery charge for the cellular phone may not match

the display on the cellular phone. Additionally, the remaining battery charge
may not be able to be displayed depending on the phone model.

● You may not be able to use Wi-Fi® if the reception level is poor.

● If you use your cellular phone in places or situations like the following, you may

not be able to connect via Bluetooth®:

• The cellular phone is behind or under a seat, or inside the console box
• The cellular phone is touching or covered with metallic materials
● If the cellular phone is set to power saving mode, the Bluetooth® connection

may automatically be disconnected. If that happens, disable power saving
mode on the cellular phone.

Related Links
Changing general multimedia system settings(P. 64)
Setting Bluetooth® devices(P. 99)

*1 : This function is not available in some countries or areas.

21

Basic operation

Displayed when a wireless charger is installed in the vehicle.

1-1. Basic operation of multimedia system

Operating the touch screen
Operate the touch screen by directly touching it with a finger.
■ Touch

Gently touch the screen. You can select items on the screen.

■ Drag

Move your finger while it is touching
the screen. The list and map screens
can be scrolled to the amount that the
finger is moved.

■ Flick

Quickly swipe your fingertip that
touches the screen. The list and map
screens are scrolled by larger amount
than scrolls by dragging.

22

1-1. Basic operation of multimedia system

■ Pinch in/pinch out

1

Basic operation

Move two fingers in and out while
touching the screen. You can zoom in
and out on maps.

INFORMATION
● In order to operate some functions, it may be necessary to touch and hold or

double tap (touch 2 times quickly) the screen.

● The sensitivity level when touching the screen can be changed.

● Response sound when the screen button is touched can be turned on/off.
● Flick operations may not work smoothly in high altitude areas.

● Operation of the screen is restricted while driving.

Related Links
Changing general multimedia system settings(P. 64)

Notes for operating the touch screen
INFORMATION
● If there is no response from the buttons on the screen, take your finger off the

screen and try again.

● In the following situations, the screen buttons may not respond or malfunction:
• If a glove is worn
• If the screen is operated with a fingernail
• If the screen is being touched with another finger or palm at the same time
• Dirt or water is on the screen
• If a plastic film or coating is on the screen
• If the vehicle is near a TV tower, power plant, filling station, broadcast sta-

tion, large display, airport, or any other place from which strong radio waves
or noise emanates

• When you are carrying or charging a portable wireless communication de-

vice, such as a radio or cellular phone, in the vehicle

23

1-1. Basic operation of multimedia system
● If the screen is touched or covered with a metallic object like one of the follow-

ing, the screen buttons may not respond or malfunction:
• A card covered in metal such as aluminum foil
• A cigarette case that uses aluminum foil
• A wallet, purse, or bag with metallic parts
• Coins
• Media, such as CDs and DVDs, a USB cable, etc.

● If the system is started with a finger touching the screen, the screen buttons

may not respond. Remove any fingers off the screen and try again. If the buttons are still not responding, turn off the power switch and restart the system.

● The Apple CarPlay map application does not support the pinch in/pinch out

feature.

NOTICE
● To protect the screen, gently touch the screen with your finger when operating

it.

● Do not operate the touch screen with anything other than your finger.

● Gently clean the screen with a glasses cleaning cloth or similar soft cloth.

Touching the screen forcibly with your finger or a hard cloth may scratch the
surface of the screen.

● Do not use benzine or an alkaline solution to clean the screen. Doing so may

damage the screen.

● Under certain conditions, the screen may feel slightly hot. Be careful as if it is

touched for a long time, it may cause slight burns.

24

1-1. Basic operation of multimedia system

Basic screen function

1

Basic operation

A list screen will be displayed if there are multiple candidates such as
settings and audio. Scroll the list to select the desired item.

A Main menu
Changes the function to be displayed on the screen by touching an icon.
B Submenu
Displays items on a list. Scrolling the list can be done by dragging or flicking the
screen.
C Main area
Displays detailed information about the item you selected on the submenu.
D Breadcrumb list
Displays screen titles in a hierarchy. Touching [<] returns to the hierarchy one
level up.

INFORMATION
Operation of the screen is restricted while driving.

■ Searching a list

Touching text in an index displays the
desired item from the list.

25

1-1. Basic operation of multimedia system

■ Turning the settings on or off

Touching an item turns the setting on
or off.
: On
: Off

■ Multiple setting options

Touching an item that has [
] to
it enables you to select an item from
multiple options.

■ Adjusting the level

Dragging the slider enables the level
of the setting to be adjusted.

Related Links
Main menu(P. 18)

26

1-1. Basic operation of multimedia system

Entering letters and numbers

1

▶ Screen example

: Closes the keyboard and returns to the previous screen.
: Displays suggested text based on current text input.
: Deletes one character.
: Switches the keyboard.
: Toggles between uppercase and lowercase.
[Go] : Perform search based on input text.
: Closes the keyboard.
: Changes to the numbers and symbols input mode.
: Changes to the alphabet text input mode.
: Changes to the handwriting input screen.
INFORMATION
● The displayed keyboard type differs depending on the feature.
● Touch and hold [
● Double tap [

] to directly select the keyboard type.

] to fix the letters to uppercase for input.

27

Basic operation

Letters and numbers can be entered by using the keyboard. Entering letters displays predictive text.
