# 4-6. Map update

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 4 Navigation, pages 175–176

update

Map

4-6. Map update

Map database version and covered area
Coverage areas and legal information can be displayed and map data can
be updated.
■ Displaying map information

1
2
3
4

] on the main menu.
Touch [
Touch [Navigation].
Touch [Map Update].
Check that the map information
screen is displayed.

4

Navigation

A Displays map coverage areas and
map version.
B Updates map.
C Displays legal information.
For map data updates, contact any authorized Toyota retailer or Toyota authorized repairer, or any reliable repairer.

175

4-6. Map update

176
