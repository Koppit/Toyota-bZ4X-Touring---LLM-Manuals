# Pictorial index

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, Introduction, pages 12–12

Introduction

Pictorial index
Instrument panel
The below illustration is for a left-hand drive vehicle.

A Display ..................................................................................................P.14
B Steering switches
Controlling audio ....................................................................................P.36
Operating the system with voice control ................................................P.42
Making a phone call.............................................................................P.218
C Microphones .................................................................................P.41,212
D USB Type-C port ..................................................................................P.38

12
