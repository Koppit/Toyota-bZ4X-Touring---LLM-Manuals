# 2-1. Multimedia system initial setup

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 50–55

setup

initial

system

Multimedia

2-1. Multimedia system initial setup

Registering a user profile*1
For the initial setup of the multimedia system, register a driver and enable
the user profiles.
By using user profiles, various vehicle and multimedia settings can be
saved in "My settings" for each driver. When the vehicle is used by multiple
drivers, such as family and friends, the vehicle can be used without changing the settings of other drivers.
The vehicle can be driven in guest mode if it is desired to not use a user
profile.

User profiles
Multimedia settings and other vehicle settings for each driver can be saved
and the applicable driver can load them before driving the vehicle.
● Up to three user profiles can be registered.
● The volume, navigation system, audio, etc. some multimedia settings can
be saved in a profile.
● Settings are automatically saved to the current profile when they are
changed.
● Search history, individual settings, and other private information can be
protected by setting up a profile.
● By registering a device that identifies the driver, such as a smart key
and smartphone, the profile is automatically loaded when getting in the
vehicle.
■ Linking to a Toyota account*1
● An active Toyota account is required to use a profile.
● If your Toyota account is linked to the Toyota app, your profile can be

downloaded from the cloud when driving any vehicle which has a valid
Toyota account service contract and equipped with the same model of
multimedia system.
● Registered profiles can be reviewed and changed on the Toyota app.
● The driver who is registered as the owner can delete all drivers registered in the vehicle. Drivers who are not the vehicle owner cannot delete
the owner’s profile.
● The same profile cannot be used in another vehicle at the same time.
● Changing some multimedia settings automatically updates the profile
saved at the cloud and a screen notifying the driver that the profile has
been updated appears.
*1 : This function is not available in some countries or areas.

50

2-1. Multimedia system initial setup
● Some multimedia settings are saved in the cloud, so even if a profile is

deleted in the vehicle, it is not deleted from the cloud.
Related Links

2

Setting up how to identify a driver(P. 61)
Settings and registration

Registering a user profile for the first time (Type A)
An active Toyota account is required to use a profile.
1 After the power switch is
turned on, the language selection screen will be displayed.
Touch the desired language.
Select the display language when registering the driver. After completing
the driver registration, the system language will return to the default language.

2 To use the Toyota app on a
smartphone to register a profile,
touch [Link].
● If you have not installed the Toyota

app, touch [Get the App] and download it using the QR code on the
screen.

● If you do not want to register a pro-

file, touch [Don't link now]. If you
touch [Do not show setup again],
the profile registration screen will no longer be displayed.

3 Open the Toyota app on a smartphone, follow the instructions on
the screen and scan the QR code, or enter the verification code to
register a driver.
4 Touch [I Agree].
Once registration is complete, a message is displayed and your profile is saved.

5 After registering your profile, register a device in order to identify
the driver. To continue with setup, touch [Continue].
You can also register a device at a later time.

51

2-1. Multimedia system initial setup

6 Register a device on the driver list screen. By registering
a device to identify the driver,
your profile will be automatically
loaded.

INFORMATION
If a user profile was not registered, registration can be restarted on the driver list
screen.

Related Links
Setting up how to identify a driver(P. 61)
Changing and registering a user profile(P. 58)

Registering a user profile for the first time (Type B)
1 After the power switch is turned on, the language selection screen
will be displayed. Touch the desired language.
Select the display language when registering the driver. After completing the
driver registration, the system language will return to the default language.
This screen may not be displayed in some countries or areas.

2 To register a user profile, touch [Create].
If you do not want to register a profile, touch [Don't create now]. If you touch
[Do not show setup again], the profile registration screen will no longer be
displayed.

3 Enter the user profile name.
4 Enter the desired PIN code.
● Set a PIN code to protect the priva-

cy of the user profile.

● To register a profile without setting a

PIN code, touch [Skip].

5 Reenter your PIN code to register your profile.
Once registration is complete, a message is displayed and your profile is saved.

52

2-1. Multimedia system initial setup

6 After registering your profile, register a device in order to identify
the driver. To continue with setup, touch [Continue].
You can also register a device at a later time.

7 Register a device on the driver list screen. By registering a device
to identify the driver, your profile will be automatically loaded.

Setting up how to identify a driver(P. 61)

Automatically loading a user profile
Taking a device such as a smart key and smartphone to identify the driver
enables the user profile to be automatically loaded.
● The vehicle detects the device registered in the profile when the power
switch is turned to ACC or ON. When a registered device is detected, the
profile that the device is assigned to is automatically loaded.
● If the device registered in the profile is not detected, the vehicle is used
in guest driver mode.
● Touching [Settings] displays the driver list screen enabling you to
change profiles.
● You can select a smartphone or some other device as the device to
identify the driver.
INFORMATION
● If multiple devices registered in a profile are detected, the driver is identified

based on the information of the device detected first. If a highly trusted device
is detected after that, the detection result is updated and the profile changed.

● Of the Bluetooth® devices registered to a user profile, only the Bluetooth®

device of the most recent driver will be detected. Driver identification may
be delayed or may not be able to be performed before starting the vehicle
depending on the usage conditions of the Bluetooth® device. It is therefore
recommended to register a smart key in addition to Bluetooth® devices.

Related Links
Setting up how to identify a driver(P. 61)
Changing and registering a user profile(P. 58)

Changing the user profile (Type A)
You can select the profile that you want to use on the user profile list
registered on the vehicle.

53

Settings and registration

Related Links

2

2-1. Multimedia system initial setup

1 Touch [

] from the main menu.

2 Touch [
] (User profile name or vehicle name) or [
the sub menu.
3 From "Saved profiles", select
the user profile name that you
want to change to.

][Guest] on

4 Enter the password.
● The password may not be required if the Bluetooth® device, which is linked to

the selected profile, is connected to the system.

● Enter the password set on the Toyota app when the Toyota account was

created.

● Once the user profile has changed, a message is displayed on the screen.

INFORMATION
If the system detects a device set to another user profile, a pop-up message will
appear. Touching [

] will enable the user profile to be changed.

Changing the user profile (Type B)
You can select the profile that you want to use on the user profile list
registered on the vehicle.
1 Touch [

] from the main menu.

2 Touch [
] (User profile name or vehicle name) or [
the sub menu.
3 From "Saved profiles", select
the user profile name that you
want to change to.

4 Enter the PIN code.

54

][Guest] on

2-1. Multimedia system initial setup
● Enter the PIN code that you set when you created your user profile.

● Once the user profile has changed, a message is displayed on the screen.

INFORMATION
If the system detects a device set to another user profile, a pop-up message will
] will enable the user profile to be changed.

Settings and registration

appear. Touching [

2

55
