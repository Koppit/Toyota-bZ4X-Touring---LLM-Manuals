# 6-7. Editing contact data

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 6 Hands-free calls, pages 236–242

data

contact

Editing

6-7. Editing contact data

Transferring contact data
Up to 5,000 contacts can be registered for each connected cellular phone.
Only the contacts corresponding to the connected cellular phone can be
displayed. In the contacts, up to 4 phone numbers can be registered for
each contact. Contacts are managed for each connected phone.
This function can only be used with cellular phones that support either
manual contact data transfer (OPP) or automatic contact data transfer
(PBAP). Refer to the included instruction manual or compatible profiles
for the connected cellular phone, to determine whether it supports either of
these.
To transfer contacts with automatic contact data transfer (PBAP), [Sync
contacts] must be set to on in the Bluetooth® settings.
INFORMATION
● When transferring contact data, each data is subject to the following restric-

tions.

• When five or more phone numbers are registered to a single contact, all

phone numbers will be registered to the multimedia system as multiple contacts with the same name.

• The name is transferred at the same time as the phone number.

Depending on the model, some letters, such as symbols, or all letters may
not be transferred. Furthermore, even if they are transferred they may not be
displayed correctly.
• Typically, secret memory is not read. (It is possible in some cases, depend-

ing on cellular phone specifications)

• The group names registered to the cellular phone are not transferred.
• The phone number type shown in contacts on the multimedia system is auto-

matically assigned based on information from the source device. However,
depending on the model of cellular phone and usage environment, the icons
may all be identical.

• Depending on the model of cellular phone, the cellular phone’s pin number

and an authentication password may need to be entered when transferring
contact data. In this case, please enter [1234] as the authentication password.

• The contacts of cellular phones that do not support manual transfer (OPP)

cannot be added or registered via Bluetooth®.

● Models of cellular phone that support batch transfer have the following charac-

teristics when transferring contact data.

• Transfer may take as long as 10 minutes.

236

6-7. Editing contact data
• Even if the contact list transfer screen is being displayed, it is possible to

switch to another screen. In this case, contact list transfer will continue.

● Events will be handled in the following way during contact list transfer.
• If a call is received during a manual contact list transfer (OPP), the call

will be received on the cellular phone itself. Calls cannot be made from the
multimedia system during manual transfer.

• If the cellular phone supports neither automatic contact list transfer (PBAP)

nor manual contact list transfer (OPP), contact data cannot be transferred
using Bluetooth®. Note that the contact data can be transferred using a USB
flash drive.

• If the power switch is turned off during contact list transfer, the transfer

will be canceled. In this case, start the EV system and carry out transfer
operations again.

● In the following cases, the contact data being transferred is not saved. (Some

of the transferred data is not saved either.)

• When automatic transfer (PBAP) ends in the middle due to the memory

capacity of the multimedia system.

6

• When automatic transfer (PBAP) is interrupted for some reason.

phone.

● During contact list transfer, the Bluetooth® audio connection may be discon-

nected. It will be reconnected once transfer is complete. (Reconnection may
not be possible for some models)

● When transferring, make sure the multimedia system has been started.

● The automatic contact list transfer (PBAP) function enables the transfer of

contacts, favorites, and history to the multimedia system. Some cellular phone
models do not allow favorites to be transferred.

● If [Sync contacts] is on, cellular phone favorites will be automatically transfer-

red to the multimedia system.

● Depending on the model, it may be necessary to perform operations on the cel-

lular phone when transferring contact data with automatic contact data transfer
(PBAP).

● If you want to transfer contacts by automatic transfer (PBAP), you need to

enable the contact sharing setting on your cellular phone.

● If automatic contact data transfer (PBAP) does not start, it may start when all

other functions have completed.

● To display contact images, set [Display contact images] to on in the Blue-

tooth® settings. To transfer the contact image data, [Sync contacts] and [Display contact images] must be set to on in the Bluetooth® settings.

237

Hands-free calls

● The multimedia system’s contact data cannot be transferred to the cellular

6-7. Editing contact data

Related Links
Bluetooth® specifications and compatible profiles(P. 107)
Setting Bluetooth® devices(P. 99)

Transferring cellular phone contact data using manual transfer (OPP)
The phone numbers (contact data) registered to the cellular phone can be
transferred to the multimedia system using manual contact data transfer
(OPP).
When [Sync contacts] is set to ON, [Sync contacts] turns off when the
phone book transfer is complete.
Contact data cannot be transferred manually (with OPP) on a cellular
phone that is using Apple CarPlay or Android Auto.
1 Touch [

] from the main menu.
2 Touch [Update contacts].
3 Select from the following transfer method.
[Overwrite with Bluetooth] : Overwrite current contact data.
[Add with Bluetooth] : Add to current
contact data.

4 Operate the cellular phone to
transfer contact data.
If a transfer failed screen is displayed,
start over from the beginning.

Related Links
Bluetooth® specifications and compatible profiles(P. 107)

Transferring phone contact data from a USB flash drive
The phone numbers (contact data) registered to a USB flash drive can be
transferred to the multimedia system.
● When [Sync contacts] is set to ON, [Sync contacts] turns off when the

phone book transfer is complete.
● This function cannot be used when connected to Apple CarPlay or Android Auto.
● Only contact data saved to a USB flash drive in vCard format (.vcf) can
be transferred.

238

6-7. Editing contact data
● Data cannot be transferred from a USB flash drive on its own. Make sure

that the cellular phone can be used with the multimedia system before
performing operations.
1 Connect the USB flash drive to the USB Type-C port.
] from the main menu.
2 Touch [
3 Touch [Update contacts].
4 Select from the following transfer method.
[Overwrite with USB] : Overwrite current contact data with contact data on
the USB flash drive.
[Add with USB] : Add contact data on
the USB flash drive to current contact
data.

5 Select the files you want to
transfer from the file list.
6 Touch [OK].

6

INFORMATION
Depending on the type of cellular phone, vCard data can be transferred as
contact information using the cellular phone connected via USB. It may also be
possible to transfer information from SD cards connected to the cellular phone.

Related Links
Connecting a device via the USB Type-C port(P. 38)

239

Hands-free calls

If a transfer failed screen is displayed, start over from the beginning.

6-7. Editing contact data

Adding new contact data to contacts
Contacts can be created by entering data directly into contacts on multimedia system. For each person in contact, the name, phone numbers (up to
4), and phone types (1 for each phone number, such as home or cellular)
can be registered in contacts.
● New data can also be added from [Modify contact list] on the history

screen to bring up the contacts editing screen.
● If [Sync contacts] is set to on, new multimedia system contacts cannot
be added. Set [Sync contacts] to off before doing this.
This function cannot be used when connected to Apple CarPlay or Android
Auto.
1
2
3
4

] from the main menu.
Touch [
Touch [Update contacts].
Touch [Add manually].
Select and enter each item.
● Touch [Add number] to set addi-

tional phone numbers.

If a phone number has not been
entered, it is not possible to add a
phone number.
● Select the phone type (such as

home or cellular) of the phone number.

5 Touch [Save].
An item cannot be registered unless a name and phone number have been
entered.

Related Links
Setting Bluetooth® devices(P. 99)
Making calls from call history(P. 220)

Modifying data in contacts
Contact data that has been registered can be modified.
If [Sync contacts] is set to on, multimedia system contacts cannot be
edited. Set [Sync contacts] to off before doing this.
This function cannot be used when connected to Apple CarPlay or Android
Auto.
1 Touch [

240

] from the main menu.

6-7. Editing contact data

2
3
4
5

Touch [Update contacts].
Touch [Edit manually].
Select the contact you want to modify.
Select and enter each item.
● Touch [Add number] to set addi-

tional phone numbers.

● Touch the type (such as home or

cellular) below the phone number
to choose the phone type (such as
home or cellular) of the phone number.

6 Touch [Save].
An item cannot be registered unless a name and phone number have been
entered.

Related Links

6

Setting Bluetooth® devices(P. 99)

Contact data that has already been registered can be deleted.
If [Sync contacts] is set to on, multimedia system contacts cannot be
deleted. Set [Sync contacts] to off before doing this.
This function cannot be used when connected to Apple CarPlay or Android
Auto.
1
2
3
4

] from the main menu.
Touch [
Touch [Update contacts].
Touch [Delete manually].
Select the data you want to delete.

5 Touch [Delete] from the bottom
of the submenu.

Related Links
Setting Bluetooth® devices(P. 99)

241

Hands-free calls

Deleting data in contacts

6-7. Editing contact data

Registering favorites
Frequently used contact data can be registered in favorites.
To use this function, set [Sync contacts] to off.
] from the main menu.
1 Touch [
2 Touch [Contacts] or [Recents].
3 Select the data you want to register.
4 Select [
] for the data item to
be registered.

Related Links
Setting Bluetooth® devices(P. 99)

Deleting favorites
Registered favorites can be deleted.
To use this function, set [Sync contacts] to off.
1 Touch [
] from the main menu.
2 Touch [Favourites], [Contacts], or [Recents].
3 Select the data you want to delete.
] for the data item
4 Select the [
to be deleted.

Related Links
Setting Bluetooth® devices(P. 99)

242
