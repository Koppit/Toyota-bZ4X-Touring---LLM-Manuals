# 4-2. Map information

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 4 Navigation, pages 146–154

information

Map

4-2. Map information

Displaying information for a point
Information for a selected point or POI on the map screen can be checked.
1 Touch POI or touch and hold a desired point.
If a desired point is selected, the address for the point will be displayed. Touch
] to register the selected point as a favorite.

[

2 Touch the desired item.
A Touch to register the point as a favorite.
B Displays detailed the address for
the selected point.
Touch
to call the phone number
C
registered to the POI.
D If multiple POIs exist at the same
point, a list of POIs will be displayed.
Touch a POI to display its information. The displayed information can be
changed by touching [
] or [
].
E Touch to set the point as a destination and start route guidance.
F Touch to set the point as a destination and display the full route map screen.
If another destination has already been set, destinations can be added as
waypoints.

146

4-2. Map information

Map options screen
Information displayed on the map, such as POI icons, traffic information,
etc., can be set.
1 Touch [

] on the map screen.

4

Navigation

2 Touch [Points of interest] or
[Display map].
A The POI icons displayed on the
map can be set.
B The information displayed on the
map can be set.

Related Links
Displaying POI icons(P. 148)
Map display settings(P. 150)

147

4-2. Map information

Displaying POI icons
POI icons, such as for restaurant, etc., can be displayed on the map.
1 Touch [

] on the map screen.
2 Touch [Points of interest].
3 Touch the POI you wish to display on the map screen.
To set a genre of POI other than those
displayed, touch [Edit POI].

INFORMATION
● POIs which are not included in the map data cannot be displayed.

● When the map scale is set to higher than 1km (0.6miles) POIs will not be

displayed.

● Only POIs which are within an approximately 10 km (6miles) radius of the

current position mark [

] or [

] can be displayed (Up to 200 POIs).

● When the map scale is set to 800 m (0.5 miles) or lower, instead of densely

displaying each POIs whose category(ies) are set to be displayed , a POI
icon in an area will be displayed as a representative image. (This will make
roads on the map easier to see.)
The displayed icon will show the number of POIs it represents at the top

right corner of the icon (example:[
them.

]). Touch the icon to display all of

● The display of nearby POIs can also be set on the detailed navigation

settings screen.

● When charging facilities are displayed, the display can be filtered to display

[Quick charging only], etc. However, depending on the map data, information may not be obtained and it may not be possible to filter the display.
Default is [Quick charging only].

Related Links
Changing the map display settings(P. 79)

Setting displayed POI icons
Changes to options is limited while driving.

148

4-2. Map information

1
2
3
4
5

Touch [
] on the map screen.
Touch [Points of interest].
Touch [Edit POI].
Touch the registered POI you wish to replace.
Touch a new POI to register.

4

Navigation

149

4-2. Map information

Map display settings
Traffic information, etc. can be displayed on the map screen.
1 Touch [

] on the map screen.
2 Touch [Display map].
A Touch to change the display
of traffic information between displayed/hidden.*1
B Touch to change the display of
nearby on street parking between
displayed/hidden.*1
C Touch to change the display
of Motorway exits between displayed/hidden.
D Touch to change the display of the driven route (route trace) between displayed/hidden.
When changed to hidden, a popup asking to confirm the deletion of stored
information will be displayed.
E Touch to change the display of speed camera between displayed/hidden.*1
F Touch to change the display of the drivable range between displayed/hidden.
The drivable range displayed on the meter is displayed as concentric circles
on the map. Even within concentric circles, it may not be possible to reach
depending on the usage conditions such as road shape and congestion.
G Touch to change the map display to Normal map, Compass map, or Weather
map.

Related Links
On street parking(P. 150)
Displaying the driven route (route trace)(P. 151)
Speed cameras(P. 151)
Traffic Information(P. 152)

On street parking*1
If [On street parking] is set to on in the map display settings, on street
parking near the vehicle will be displayed.

*1 : This function is not available in some countries or areas.

150

4-2. Map information

Touch [
] on the map screen.
On street parking is displayed on the
map. Depending on the availability
of parking, the displayed color will
change.

4

Navigation

● On street parking will not be displayed when the map scale is 1/5,000 or

more (scale display is 50 m (150 ft.) or more).

Displaying the driven route (route trace)
Approximately 1000 km (600miles) of a driven route can be saved and
displayed.
1 Touch [

] on the map screen.
2 Touch [Display map].
3 Touch [Route trace].
INFORMATION
● If the driven distance saved exceeds the limit, the oldest route trace will be

deleted and the newest route trace will be saved.

● The driven route can be displayed with a map scale between 1/2,500 and

1/5,120,000.

Related Links
Map display settings(P. 150)

Speed cameras*1
Speed cameras can be displayed as icons on the map.
*1 : This function is not available in some countries or areas.

151

4-2. Map information
A Speed camera location on the

map.
B Displays information about the
speed camera icon and distance
to speed camera.

INFORMATION
● The above items will be displayed depending on the map scale.

● The above items will be displayed depending on the available map data.
● The displaying of the above items can be switched off.

● Depending on content management conditions, the actual location of cameras

may not be displayed.

Related Links
Guidance settings(P. 84)

Traffic Information*1
Traffic data can be received via IP-Traffic to display traffic information on
the map screen.
To use this function, it is necessary for the Toyota Smart Center usage
contract.
1 Touch [

] on the map screen.
2 Touch [Display map].
3 Touch [Traffic].
Traffic information will be displayed on
the map screen.
● Icons are used to indicate traffic in-

formation, such as construction and
accidents.

● The arrows indicate the flow of traf-

fic. The color changes depending on
the speed.

If the traffic incident icon is selected,
details about the selected traffic incident can be displayed.
*1 : This function is not available in some countries or areas.

152

4-2. Map information

4

Navigation

153

4-2. Map information

Highway mode
When a highway or expressway is entered, the display will automatically
change to the highway mode display.
A Displays the distance from the vehicle’s current position.
B Displays up to 6 POIs for a facility.
C When the displayed segment has
been changed, touch to return the
map to the segment being driven
on.

154
