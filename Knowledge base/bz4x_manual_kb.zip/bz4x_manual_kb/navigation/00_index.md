# Index

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, Index, pages 351–355

Index

Index

A

Changing the route ........................167

Adding a waypoint..........................160

Changing the scale...........................31

Adjusting the image quality.............95

City map............................................ 31
Cleaning the camera............... 267,306

Adjustment
Image quality.................................. 95

Clock settings................................... 64

Sound quality.................................. 96

Compatible profiles........................ 107

Android Auto...................................196

Connected navigation.................... 145

Registered smartphone................ 135

Connecting

Unregistered smartphone............. 132

Bluetooth® devices....................... 112

Answering calls/Receiving calls... 226

iPod.................................................38

Apple CarPlay................................. 193

Miracast®...................................... 204

Registered smartphone................ 129

USB Type-C port.............................38

Unregistered smartphone............. 126

Wi-Fi®........................................... 120

Audio............................................... 178
Audio system on/off ........................ 34

Connecting
Miracast®-compatible
devices.........................................204

Automatic sound leveliser...............91

Contact data (Phone number)

Avoiding............................................ 81
B

Bluetooth® audio............................ 199
Bluetooth® devices
Connect.........................................112

Add............................................... 240
Delete........................................... 241
Modify........................................... 240
Transfer........................................ 236
Current position
Displaying ...................................... 30

Delete............................................ 111

D

Register........................................ 108
Setting as a primary device...........116

DAB radio........................................ 180

Setting as a secondary device...... 117

Dealer information............................71

Browser .......................................... 250

Declined call....................................231

Operation ..................................... 252
Screen ......................................... 251
C

Cellular phone

Deleting
Areas to avoid.................................83
Bluetooth® devices........................111
Contact data (Phone number)...... 241
Destination ...................................170

Connect.........................................112

Favorites list..................................242

Delete............................................ 111

Recent destination.......................... 87

Register........................................ 108
Change route options ................... 166
Changing the orientation................. 32

User profile..................................... 61
Destination
Adding...........................................160

351

Index
Delete recent destination................ 87
Deleting.........................................170
Searching .....................................155

K

Keyboard
Entering letters and numbers .........27

Destination search
L

Destination search screen ........... 156
Display angle setting

Lane display screens..................... 171

Map angle ...................................... 80

Listening to DAB............................ 180

Displaying information for a point 146

Listening to the radio..................... 178

Displaying POI icons......................148
E

Edit...................................................169
Areas to avoid.................................82
F

M

Main menu.........................................18
Making calls
Continuous tone signal................. 225
Favorites list..................................221
In-call............................................ 232

FM radio...........................................178

Message....................................... 248

Format information.........................326

Numeric keypad input................... 223

Full route map screen

Outgoing or incoming call history..220

Estimated time of arrival .............. 163
G

Gracenote®...............................182,326
Guidance demo ..............................165
H

Hands-free (Phone)........................ 210
Heading up display...........................32
High resolution sound sources.....326
Highway mode ............................... 154
Home
Registering ...................................157
Setting home as destination ........ 157
I

Internet ........................................... 250
Operation ..................................... 252
Screen ......................................... 251
Internet radio...................................182
iPod/iPhone.....................................190

352

Registered contacts...................... 222
Toyota roadside assist service......224
Making conference calls................ 233
Map
3D view settings..............................79
Changing map style........................ 79
Changing the orientation.................32
City map..........................................31
Moving ........................................... 33
Traffic information........................... 79
Zoom in/Zoom out...........................31
Map display customization
Customizing the map ..................... 80
Map display settings...................... 150
Displaying the driven route (route
trace) ........................................151
On street parking ......................... 150
Map icon
Speed camera ............................. 151
Map information
Setting displayed POI icons .........148

Index
Map language....................................79

Bluetooth® devices....................... 108

Map options

Dealer information.......................... 71

Map options screen ..................... 147

Face identification...........................62

Map screen .......................................28

Favorites list..................................242

Message.......................................... 243

Saved profiles................................. 58

Miracast®.........................................205

User profile..................................... 50

N

User profile settings........................ 58
Replying to messages....................245

NaviBridge.......................................161

Restarting the system...................... 15

Navigation....................................... 145

Route guidance...............................170

Navigation Settings.......................... 87
Editing Favorites List ..................... 89

S

Position/Direction calibration ......... 89

Scale.................................................. 31

O

Screen operation.............................. 25
Search result list screen ............... 159

On street parking suggestion..........79

Searching by Keywords...................48

Operating the system with voice control.................................................. 40

Searching for a destination .......... 155

P

Character entry ............................ 156

Panoramic view monitor ............... 277
Playback
Android Auto................................. 196
Apple CarPlay...............................193
Bluetooth® audio...........................199
iPod/iPhone.................................. 190
Miracast®...................................... 205
USB flash drive...................... 183,185
Position
Correct the position.........................87
Precautions for the Toyota parking
assist monitor
Camera position ...........................270

A favorite as the destination ........ 157
Charging stations..........................158
Destination history ....................... 158
Drive Plan .................................... 158
Home ........................................... 157
Smartphone compatible apps....... 161
Searching for a route again .......... 173
Second call......................................231
Security lock..................................... 72
Security settings...............................72
Sending new messages................. 245
Setting destinations from your
smartphone................................. 161
Settings
Areas to avoid settings................... 81

R

Bluetooth® device settings..............99

Receiving calls or answering calls.....
......................................................231

Dealer information settings............. 71

Registering

Guidance settings .......................... 84

Areas to avoid.................................82

General settings..............................64
Map display settings................ 79,150

353

Index
Navigation system settings ............ 78

U

Panoramic view monitor settings.. 304

USB flash drive........................ 183,185

Radio settings................................. 91

USB Type-C port............................... 38

Route search settings..................... 81

User profile

Screen display settings...................67

Changing and registering a profile..58

Security settings............................. 72

Register.......................................... 50

Sound and media settings.............. 91
Traffic settings.................................86

V

User profile settings........................ 61

Voice commands.............................. 44

Various settings.............................. 56

Voice control system .......................40

Voice control settings......................69

Volume adjustment...........................34

Wi-Fi® settings................................97

Audio ..............................................34
Navigation volume.......................... 91

Smartphone
Connect.........................................112

Phone (Ringtone/receiver)..............99

Delete............................................ 111

System audio volume..................... 91

Register........................................ 108
Setting destinations (NaviBridge) 161
Sound quality adjustment................96
Status icons...................................... 20
Steering switches
Hands-free (Phone)...................... 218
Voice control................................... 42
Switching phones...........................235
Switching the screen mode............. 94
T

Touch screen.................................... 22
Toyota account................................. 50
Toyota parking assist monitor...... 258
Displaying the guide screen..........260
Transferring
Contact data (Phone number)...... 236
Troubleshooting
Apple CarPlay/Android Auto......... 138
Hands-free (Phone)...................... 214
Panoramic view monitor............... 322
Toyota parking assist monitor....... 275

354

W

Waypoints ...................................... 168
Web browser .................................. 250
Operation ..................................... 252
Screen ......................................... 251
Wi-Fi®...............................................120
Wi-Fi® settings..................................97
