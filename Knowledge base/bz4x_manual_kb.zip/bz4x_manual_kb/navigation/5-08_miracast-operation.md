# 5-8. Miracast® operation

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 5 Audio, pages 204–208

Miracast®operation

5-8. Miracast® operation

Connecting Miracast®-compatible devices
Android smartphones and tablets that support Miracast® can be connected.
To determine whether a device being used supports Miracast®, refer to the
instruction manual and other documentation included with the device.
] from the main menu.
1 Touch [
2 Touch [Sources].
3 Touch [Miracast®].
4 This makes Miracast®-compatible devices capable of connecting.
● For details on how to operate the

device, refer to the instruction manual included with the device.

● If a connection failed screen is dis-

played, start the connection procedure over from the beginning.

5 Check the device name and then touch [OK].
Related Links
Changing Wi-Fi® settings(P. 97)

204

5-8. Miracast® operation

Playing Miracast®
Music and video from a smartphone or tablet can be enjoyed via playback
on the multimedia system.
INFORMATION
● The Miracast® volume may differ depending on the connected device.
● The audio will turn off when the Wi-Fi® connection is disconnected.

Connect a device compatible with Miracast®.
1 Touch [

] from the main menu.
2 Touch [Sources].
5

3 Touch [Miracast®].

Audio

4 Operate the Miracast® content that is playing as necessary.
● Operating during full screen display

Touch the screen to display the operation buttons.
] : Displays the operation
[
screen.

● Operating from the operation screen

To display the operation screen, touch [
[

] on the full screen display.

] : Displays the settable items.

[
] : Switches to full screen
display.
[Disconnect] : Disconnect Miracast®.
The audio will turn off.

Related Links
Changing sound and media settings(P. 91)
Switching the screen mode(P. 94)

205

5-8. Miracast® operation

Adjusting the image quality(P. 95)
Adjusting the sound of each source(P. 96)

206

5-8. Miracast® operation

Precautions for playback of Miracast®
Pay special attention to the following information when using Miracast®
playback.
INFORMATION
● The device is connected via Wi-Fi® (P2P mode).
● Miracast® is a registered trademark of Wi-Fi Alliance®.

● This function cannot be used while Apple CarPlay is connected wirelessly.

● Performance may vary depending on various environmental and electrical fac-

tors.

● The displayed names of Miracast® vary depending on the device.
● When the Wi-Fi® network connection is enabled, Wi-Fi® network connection

WARNING
Do not connect or operate a smartphone or tablet while driving.

NOTICE
Do not leave the smartphone or tablet inside the vehicle. The inside of the vehicle
can become hot, which could cause the smartphone or tablet to malfunction.

Related Links
Changing Wi-Fi® settings(P. 97)
Precautions when using Wi-Fi® devices(P. 118)

207

5

Audio

communication and Miracast® communication can affect each other. This may
cause image distortion and audio stuttering.

5-8. Miracast® operation

208
