# 9-1. Appendix

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 9 Appendix, pages 326–350

Appendix

9-1. Appendix

Information about media and data
Information about media that can be used
The specifications of the media and other devices that can be used are as
follows.
■ Formats and specifications of USB flash drives

The formats and standards of the USB flash drives that can be used, and
the restrictions for use, are as follows.
USB communication format

USB2.0 HS (480MBPS)

File format

FAT 16/32

Communication class

Mass storage class

Maximum number of folders

3000 (including root)

Maximum number of folder levels

8

Maximum number of files

9999 (maximum of 255 files per
folder)

Memory capacity

Up to 32 GB

Maximum size of one file

2GB

● Files other than the formats above may not be played correctly, or infor-

mation such as the file or folder name may not display correctly.
● Please understand in advance that this device may not be able to play
your USB flash drive.
● Depending on the computer used to save files on a USB flash drive,
hidden files may be saved in addition to the playback files. Deletion of
such hidden files is recommended. They may have a negative effect
during playback and prevent files from being switched correctly.

Format information
The specifications of the music data that can be used are as follows.
■ MP3
Supported standard
Supported sampling frequency (kHz)

326

MP3 (MPEG1 LAYER 3, MPEG2 LSF
LAYER 3)
MPEG1 LAYER 3:32, 44.1, 48
MPEG2 LSF LAYER 3:16, 22.05, 24

9-1. Appendix

Supported bit rate (kbps)(1)

MPEG1 LAYER 3:32 to 320
MPEG2 LSF LAYER 3:8 to 160

Supported channel mode

Stereo, joint stereo, dual channel, monaural

ID3 tag

ID3 Ver. 1.0, 1.1, 2.2, 2.3 (number of
characters as specified by each version)

(1) VBR (Variable Bit Rate) is supported.

■ WMA
Supported standard

WMA Ver. 7, 8, 9 (9.1, 9.2)

Supported sampling frequency (kHz)

32, 44.1, 48

Supported bit rate (kbps)(1)(2)

Ver. 7, 8:CBR (Constant Bit Rate) 48 to
192
Ver. 9 (9.1/9.2): CBR 48 to 320

(1) VBR (Variable Bit Rate) is supported.
(2) Multi-channel audio sources are converted to 2ch.

■ AAC
Supported standard(1)

MPEG4 AAC-LC

Supported sampling frequency (kHz)

11.025, 12, 16, 22.05, 24, 32, 44.1, 48

Supported bit rate (kbps)(2)

8 to 320

Supported channel mode(3)

1ch (1/0), 2ch (2/0)

9

(1) ADIF is not supported.

Appendix

(2) VBR (Variable Bit Rate) is supported.
(3) Dual channel is not supported.

■ WAV (LPCM)
Supported sampling frequency (kHz)(1)

8, 11.025, 12, 16, 22.05, 24, 32, 44.1,
48, 88.2, 96, 176.4, 192

Supported number of quantization bits
(bit)(2)

16/24

Supported channel mode

1ch (1/0), 2ch (2/0)

(1) Audio sources higher than 96 kHz/24 bit are down-converted to 96 kHz/24 bit.
(2) Multi-channel audio sources are converted to 2ch.

327

9-1. Appendix

■ FLAC
Supported sampling frequency (kHz)(1)

8, 11.025, 12, 16, 22.05, 24, 32, 44.1,
48, 88.2, 96, 176.4, 192

Supported number of quantization bits
(bit)(2)

16/24

(1) Audio sources higher than 96 kHz/24 bit are down-converted to 96 kHz/24 bit.
(2) Multi-channel audio sources are converted to 2ch.

■ ALAC
Supported sampling frequency (kHz)(1)

8, 11.025, 12, 16, 22.05, 24, 32, 44.1,
48, 64, 88.2, 96

Supported number of quantization bits
(bit)(2)

16/24

(1) Audio sources higher than 96 kHz/24 bit are down-converted to 96 kHz/24 bit.
(2) Multi-channel audio sources are converted to 2ch.

■ Ogg Vorbis
Supported sampling frequency (kHz)(1)

8, 11.025, 16, 22.05, 32, 44.1, 48

Supported bit rate (kbps)(2)

32 to 500

(1) Audio sources higher than 96 kHz/24 bit are down-converted to 96 kHz/24 bit.
(2) VBR (Variable Bit Rate) is supported.

■ File names

The only files that can be recognized as MP3/WMA/AAC/WAV(LPCM)/
FLAC/ALAC/Ogg Vorbis and played are those with the extension
".mp3"/".wma"/".m4a"/".3gp"/".aac"/".wav"/".flac"/".fla"/".ogg"/".ogx"/".oga".
Save MP3/WMA/AAC/WAV(LPCM)/FLAC/ALAC/Ogg Vorbis files with
a".mp3"/".wma"/".m4a"/".3gp"/".aac"/".wav"/".flac"/".fla"/".ogg"/".ogx"/".oga".
■ About ID3 tags, WMA tags, AAC tags, tags, and Vorbis comments
● MP3 files have ancillary character information called ID3 tags that can

store song artist names, title names, album names, and more.

● WMA files have ancillary character information called WMA tags that can

store song artist names, title names, album names, and more.
● AAC files have ancillary character information called AAC tags that can
store song artist names, title names, album names, and more.
● WAV (LPCM) files have ancillary character information called tags that
can store song artist names, title names, album names, and more.

328

9-1. Appendix
● FLAC files have ancillary character information called tags that can store

song artist names, title names, album names, and more.

● ALAC files have ancillary character information called tags that can store

song artist names, title names, album names, and more.
● Ogg Vorbis files have ancillary text information called Vorbis comment
that allows saving of the song artist names, title names, album names,
and more.

■ High resolution sound sources

This device supports high-resolution sound sources. The definition of highresolution is based on the standards of groups such as the CTA (Consumer
Technology Association).
Supported formats and playable media are as follows.
Supported formats
WAV, FLAC, ALAC, Ogg Vorbis
Playable media
USB flash drive

iPhone/iPod
■ Trademark and design certification information

9

Appendix

● Use of the Made for Apple badge means that an accessory has been

designed to connect specifically to the Apple product(s) identified in the
badge and has been certified by the developer to meet Apple performance standards.

329

9-1. Appendix
● Use of the Apple CarPlay logo means that a vehicle user interface meets

Apple performance standards.

● Apple is not responsible for the operation of this vehicle or its compliance

with safety and regulatory standards.
● Please note that the use of this accessory with an Apple product may
affect wireless performance.
● iPhone, iPod, iPod touch, Apple CarPlay, Siri, and Lightning are trademarks of Apple Inc., registered in the U.S. and other countries and
regions.

● IOS is a trademark or registered trademark of Cisco in the U.S. and other

countries and is used under license.

Made for
● iPhone 12 Pro Max
● iPhone 12 Pro
● iPhone 12
● iPhone 12 mini
● iPhone SE (2nd generation)
● iPhone 11 Pro Max
● iPhone 11 Pro
● iPhone 11
● iPhone XS Max
● iPhone XS
● iPhone XR
● iPhone X
● iPhone 8 Plus
● iPhone 8
● iPhone 7 Plus
● iPhone 7
● iPhone SE
● iPhone 6s Plus
● iPhone 6s
● iPod touch (7th generation)

330

9-1. Appendix

Android and Android Auto
■ Trademark and design certification information

Android and Android Auto are trademarks of Google LLC.

USB flash drive
■ Music files recorded using a computer

The following music files can be played.
● MP3
● WMA
● AAC
● FLAC
● WAV
● ALAC
● Ogg Vorbis
■ Video data information playable from USB flash drives

Format
MPEG4 Extension:
".mp4" ".m4v"
AVI container extension:
".avi"
Windows Media Video
extension: ".wmv"

Codec
● Video codec: H.264, MPEG-4 AVC, MPEG-4
● Audio codec: MP3, AAC

● Video codec: H.264, MPEG-4, MPEG-4 AVC,

WMV9, WMV9 Advanced Profile

● Audio codec: MP3, AAC, WMA 9.2 (7, 8, 9.1, 9.2)
● Video codec: WMV9, WMV9 Advanced Profile

● Audio codec: WMA 9.2 (7, 8, 9.1, 9.2)

● The maximum supported image size is 1920 x 1080 pixels.
● The supported frame rate is a maximum of 60i/30p.

331

9

Appendix

The following formats are supported for video files recorded from a computer to a USB flash drive.

9-1. Appendix
● Video playback may not be possible depending on the type of recording

device, the recording conditions, and the USB flash drive that is used.

MP3/WMA/AAC
Certain restrictions apply to the standards of the MP3/WMA/AAC files that
can be used, and the media and formats that store such files. Microsoft,
Windows, and Windows Media are the registered trademarks of Microsoft
Corporation in the USA and other countries.
The specifications of the music data that can be used are as follows.
MP3
MP3 (MPEG Audio LAYER 3) is the standard format related to audio
compression technology. When MP3 is used, the file can be compressed
to approximately 1/10 the size of the original file.
WMA
WMA (Windows Media Audio) is the audio compression format of Microsoft Corporation. This can compress files to an even smaller size than
MP3.
This product is protected by certain intellectual property rights of Microsoft. Use or distribution of such technology outside of this product is
prohibited without a license from Microsoft.
AAC
AAC (Advanced Audio Coding) is the standard format related to audio
compression technology that is used in MPEG2 and MPEG4.

MPEG LA

Bluetooth®
The Bluetooth® specifications and profiles that can be used are as follows.

332

9-1. Appendix
Bluetooth® audio

Item
Supported Bluetooth® specifications

Bluetooth® Core Specification Ver. 5.0 or later
● A2DP (Advanced Audio Distribution Profile) profile for

transmitting music data: Ver. 1.3.2 or later
Supported profiles ● AVRCP (Audio/Video Remote Control Profile) profile for
controlling (playing, stopping, etc.) portable audio from a
multimedia system: Ver. 1.6.2 or later
Supported codecs LDAC™, AAC, SBC

INFORMATION
This is not a guarantee that all Bluetooth® devices can connect to the multimedia
system.

■ Certification

9

Bluetooth® is a registered trademark of Bluetooth SIG, Inc.
Appendix

■ LDAC

LDAC and LDAC logo are trademarks of Sony Corporation.

Wi-Fi®
Wi-Fi®, Miracast®, Wi-Fi CERTIFIED®, Wi-Fi Direct®, and WMM® are registered trademarks of Wi-Fi Alliance®.

333

9-1. Appendix

Wi-Fi Protected Setup™, WPA™, WPA2™, and WPA3™ are trademarks of
Wi-Fi Alliance®.

Gracenote®
When music is played, the database of the multi media system is searched
for the album name, artist name, genre, and track name. If the corresponding information is stored in the database, then the information is assigned
automatically. The Gracenote® media database is used for the database
information stored in this multi media system.
■ Gracenote® media database
● The title information assigned automatically may differ from the actual

title information.
● The contents of the data provided by the "Gracenote media database" is
not guaranteed to be 100% accurate.
● Gracenote, the Gracenote logo and logotype, and the "Powered by
Gracenote" logo are either a registered trademark or a trademark of
Gracenote, Inc. in the United States and/or other countries.

QR Code
The word "QR Code" is registered trademark of DENSO WAVE INCORPORATED in Japan and other countries.

Map data
©2025 HERE
Visit the link below for the data license.
https://legal.here.com/terms/general-content-supplier/terms-and-notices/
END USER LICENSE AGREEMENT
https://legal.here.com/en-gb/terms/end-user-license-agreement

334

9-1. Appendix

Certification
Toyota Motor Europe NV/SA, Avenue du Bourget 60 - 1140 Brussels, Belgium www.toyota-europe.com
Toyota (GB) PLC, Great Burgh, Burgh Heath, Epsom, Surrey, KT18 5UX,
UK

9

Appendix

335

9-1. Appendix

336

9-1. Appendix

9

Appendix

337

9-1. Appendix

338

9-1. Appendix

9

Appendix

339

9-1. Appendix

340

9-1. Appendix

9

Appendix

341

9-1. Appendix

342

9-1. Appendix

9

Appendix

343

9-1. Appendix

344

9-1. Appendix

9

Appendix

345

9-1. Appendix

346

9-1. Appendix

9

Appendix

347

9-1. Appendix

348

9-1. Appendix

9

Appendix

349

9-1. Appendix

350
