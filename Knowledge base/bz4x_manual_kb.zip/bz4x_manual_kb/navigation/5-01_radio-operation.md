# 5-1. Radio operation

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 5 Audio, pages 178–181

operation

Radio

5-1. Radio operation

Listening to the radio
Switch to your preferred frequency and listen to the radio.
INFORMATION
● When a stereo broadcast is received, the broadcast switches to the stereo

broadcast automatically.

● If the signal becomes weak, the radio reduces the amount of channel separa-

tion to prevent the weak signal from creating noise. If the signal becomes
extremely weak, the radio switches from stereo to mono reception.

1
2
3
4

Touch [
] from the main menu.
Touch [Sources].
Touch [FM].
Select the station selection method as necessary.
[Presets] : Select the broadcasting station from the stations registered in the
presets.
[Station list] : Select the broadcasting station from the broadcasting station list.
[Direct tune] : Select the broadcasting station by entering a frequency with the
numeric keypad.

5 Operate the radio that is being received as necessary.
● Operating from the screen

[Seek] : Touch [
] or [
] to automatically select the broadcasting station
closest to that position with the best radio reception. Touch and hold to jump
to the next frequency with available radio signal. When released, the broadcasting station closest to that position with the best radio reception is selected
automatically.
[Scan] : Search for broadcasting stations while moving automatically toward
higher frequencies.
When a broadcasting station is received, it can be monitored for about 5 sec.
Touch to continue listening to this broadcasting station.
] : Registers the received broadcast station in the preset. When regis[
tered, touch to cancel.

178

5-1. Radio operation
[

] : Displays the settable items.

• [Radio text] : Displays the radio text distributed by the FM broadcasting

station.

Preset buttons or station list of submenu : Receives the selected broadcasting station.
● Operating with the steering switches

[<]/[>] switches
When selected from the "Presets"
screen, switch the frequencies or
broadcasting stations registered in
the preset buttons order.
When selected from the "Station
list" screen, switch the broadcasting stations displayed in the station
list.

5

Press and hold to switch frequencies. When released, the broadcasting station closest to that position with the best radio reception is selected automatically.

Related Links
Changing sound and media settings(P. 91)
Adjusting the sound of each source(P. 96)

179

Audio

When selected from the "Direct
tune" screen, automatically selects the broadcasting station closest to that position with the best radio reception.

5-1. Radio operation

Listening to DAB*1
Switch to preferred frequency and listen to DAB.
INFORMATION
The time playable with time shift varies depending on the recorded bit rate of
DAB, DAB unit memory size, and time of starting broadcast reception.

1 Touch [

] from the main menu.
2 Touch [Sources].
3 Touch [DAB].
4 Select the station selection method as necessary.
[Presets] : Select the service from the services registered in the presets.
[Station list] : Select the service from the service list.
[Manual tune] : Select the broadcasting station manually. Select the station by
selecting [Ensemble] or [Service].

5 Operate the radio that is being received as necessary.
● Operating from the screen

[
]/[
] : Use the time shift function to listen again to the service you are
currently listening to. Touch to skip the playback of the service forward or back
by 10 sec. Touch and hold to fast rewind or fast forward.
[Live] : Release time shift to receive the service currently being broadcast.
] : Registers the currently received service in the preset. When regis[
tered, touch to cancel.
[

] : Displays the settable items.

• [Radio text] : Displays the radio text distributed by the DAB.

Preset buttons or station list of sub menu : Receives the selected service.
[
] : Switches to the expanded slideshow or cover art. Touch [
return to the previous screen.
● Operating with the steering switches
*1 : This function is not available in some countries or areas.

180

] to

5-1. Radio operation
[<]/[>] switches
When selected from the "Presets"
screen, switch the services registered in the preset buttons order.
When selected from the "Station
list" screen, switch the services
displayed in the station list.
When selected from the "Manual
tune" screen, automatically selects the service closest to that position with the best radio reception.
Press and hold to switch services. When released, the service closest to that
position with the best radio reception is selected automatically.
5

Related Links

Audio

Changing sound and media settings(P. 91)
Adjusting the sound of each source(P. 96)

181
