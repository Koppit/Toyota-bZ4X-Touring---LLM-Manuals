# 2-9. Sound and media settings

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 91–96

settings

media

and

Sound

2-9. Sound and media settings

Changing sound and media settings
] from the main menu.
1 Touch [
2 Touch [Sound & Media] on the submenu.
3 Select the desired item.

2

Settings and registration

● [Sound] > [Levels]

Setting

Description

[Automatic sound leveliser]

Automatically adjust for volume based on the
vehicle speed.

● [Sound] > [Voice]

Setting
[System volume]

Description
Adjust the system guidance volume.

[Navigation volume]

Adjust the volume of the voice guidance for the navigation system.

[Navigation during
calls]

Turn on or off to interrupt the navigation system
voice guidance during a phone call.

[Adaptive volume
control]

Automatically increases the voice guidance volume
when you are driving on an expressway.

[Driving assist volume]

Adjusts the volume of the driving support system

● [Media] > [General]

Setting

Description

[Display cover art] Displays cover art such as for music albums.
● [FM] > [FM]

Setting
[Station list]
[Enable FM radio]*1

Description
Reorders the station list.
Hides [FM] on the source selection screen.

*1 : This function is not available in some countries or areas.

91

2-9. Sound and media settings
Setting

Description

[FM traffic announce- Automatically switches stations when traffic informent]
mation starts on an FM broadcasting station.
[FM alternative frequency]

Switches to an alternative frequency with better reception when the signal fades for an FM broadcasting station.

[Regional code
change]

Switches to local broadcasting on the same program network.

[FM radio text]

Displays radio text from the FM broadcasting station.

● [Internet radio]*1

Setting

Description

[Enable internet radio]

When the radio reception condition deteriorates, the system switches to IP radio.

[Changing to IP
stream]

Settings can be changed for when switching to IP radio.
• When [Auto] is set, it switches automatically.
• Setting [By request] notifies of a switch request.

Uses the Gracenote® radio recognition technology.
[Enhanced met- • Displays the logos of the favorites and the station list.
adata/art work] • Changes the category names of the station list.
• Automatically updates the station list.
● [DAB]*1

Setting

Description

[Traffic announcement]

Automatically switches stations when traffic information
starts on DAB.
Automatically switches stations when there is a DAB announcement broadcast (such as news, weather information, alerts, or warnings).

[Service news]

• When the announcement ends, the system resumes

the previous program.

• Alarm announcements are broadcast even if the set-

tings is off.

[Alternative fre- Switches to an alternative frequency with better reception
quency]
when the signal fades for DAB.
[Radio text]

Displays radio text from DAB.

*1 : This function is not available in some countries or areas.

92

2-9. Sound and media settings
Setting

Description

[Slideshow]

Displays the slideshow images. The slideshow is available depending on the service.
2

INFORMATION

93

Settings and registration

Using the [
VOL] knob during system voice guidance adjusts the volume of
the voice guidance.

2-9. Sound and media settings

Switching the screen mode
Switch between normal video and widescreen video.
] from the main menu.
1 Touch [
2 Touch [Sources].
3 Touch the source for which screen mode will be switched.
4 Touch [
].
5 Touch [Screen].
The button is displayed in video mode.

6 Touch [Screen format].
7 Select the desired mode.
[Normal] : Displays the input video in
a 4:3 aspect ratio.
[Stretched] : Enlarges the input video
display to fit the screen.
[Zoomed] : Enlarges the input video
display equally in the vertical and horizontal directions.

INFORMATION
● The settable mode varies according to the video mode.

● Black bands may be added to restrict the video display area to prevent the

video from looking strange.

94

2-9. Sound and media settings

Adjusting the image quality
Adjusts the contrast and brightness of the image.
] from the main menu.
1 Touch [
2 Touch [Sources].
3 Touch the source of which image quality will be adjusted.

2

Settings and registration

4 Touch [
].
5 Touch [Screen].
The button is displayed in video mode.

6 Touch [Display].
7 Set each item.
"Brightness" : Adjusts the brightness.
"Contrast" : Adjusts the contrast.

95

2-9. Sound and media settings

Adjusting the sound of each source
Adjusts the sound quality and volume balance of each source.
] from the main menu.
1 Touch [
2 Touch [Sources].
3 Touch the source of the sound to be adjusted.
4 Touch [

].

Depending on the source, go onto 6.

5 Touch [Sound].
6 Set each item.
"Treble" : Adjusts the level of the treble.
"Mid" : Adjusts the level of the midrange.
"Bass" : Adjusts the level of the bass.
Fader and balance : Adjust the fader
and balance by moving the [

].

Touch [Recentre] to return to the
center.

INFORMATION
Adjust the Treble, Mid, and Bass settings independently for each source.

96
