# 2-6. Voice control settings

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 69–70

settings

control

Voice

2-6. Voice control settings

Changing the voice control settings*1
The settings related to the voice recognition feature can be changed.
1 Touch [

] from the main menu.
2 Touch [Voice & Search] on the submenu.
3 Select the desired item.

Settings and registration

Setting

2

Description

"Voice recognition"
[Wake word]

Change the wake word that starts
voice control.

[Set custom wake word]

Set the wake word that starts voice
control to any word.

[Mic button]

Show or hide [
screen.

] button on the

"Voice feedback"
[Voice prompt]

Turn the voice prompts on or off.

"Notification"
[Voice support]

You can respond verbally to an incoming phone call and other notifications.

Changing the wake word to start the voice control system
1 Touch [
] from the main menu.
2 Touch [Voice & Search]on the submenu.
3 Touch [Wake word].

*1 : This function is not available in some countries or areas.

69

2-6. Voice control settings

4 Select the desired wake word
from the list.

INFORMATION
● If you want to set a custom word, touch [Set custom wake word] and enter

your desired word using the keyboard beforehand.

● If custom wake word is too short, the voice control system may not be able

to recognize it when spoken to. Use a wake word with at least 3 syllables.

70
