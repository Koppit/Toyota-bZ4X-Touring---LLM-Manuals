# 1-2. Basic operation of navigation system

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 1 Basic operation, pages 28–33

system

navigation

of

operation

Basic

1-2. Basic operation of navigation system

Map screen
Information displayed on the map screen and its purpose is as follows.
Touch [

] from the main menu.

A Current position mark
Displays current position and orientation of the vehicle.
B Lane information display
Displays the through and turning lanes at an intersection/junction.(Only available for intersections/junctions with information in the map data)
During route guidance, the suggested lane to drive in will be displayed in highlight.
C Name display
Displays the name of the roads being driven on. (Only available for points with
information in the map data)
D Scale display
Displays the scale of the displayed map.
E Orientation mark
Displays the orientation of the map. Touch to change the orientation of the map.
F Zoom in/out button
Zooms the map screen in/out.
G Display setting button
Displays the display setting screen and allows for changing of the nearby POI
display settings, etc.
H Destination button
Displays the destination search screen.
I Microphone button

28

1-2. Basic operation of navigation system
Displays the voice control screen.

1

Related Links
Basic operation

Displaying the vehicle’s current position(P. 30)
Changing the orientation of the map(P. 32)
Map display settings(P. 150)
Searching for a destination(P. 155)
Operating the system with voice control(P. 40)

29

1-2. Basic operation of navigation system

Displaying the vehicle’s current position
The current position of the vehicle is displayed by the current position mark
[
].
When the map screen has been
scrolled, touch [
] or [
] from the
main menu, to return the map to the
vehicle’s current position.

INFORMATION
● When the vehicle is new, or a cable has been disconnected and reconnected

to a 12-volt battery terminal, the actual current position of the vehicle and

the position [
] displayed by the current position mark [
] may differ.
However, after driving for a while, through map matching and received GPS
] will be corrected automaticalinformation, the displayed current position [
ly.(Depending on the situation, it may take several minutes.) If GPS information
is not received and the current position is not corrected automatically, stop the
vehicle in a safe location and correct the current position manually.
● The shape of the current position mark [

color.

Related Links
Map display customization settings(P. 80)
Position/Direction calibration(P. 89)

30

] differs depending on the map

1-2. Basic operation of navigation system

Changing the scale of the map

1

The map screen can be zoomed in/out.
Basic operation

Touch [
] or [
] on the map screen.
● The scale can also be changed using double tap or pinch in/pinch out
operations on the screen.
Double tap zoom in : Touch the
screen quickly 2 times
Zoom out tap : Touch the screen
with two fingers
● Touch and hold [

]/[
] to steplessly change the map scale.

City map
When the map is fully zoomed, a city map can be displayed.
With the map scale display at 50m (150 ft.), touch [
To cancel the city map, touch [

].

] or pinch in on the screen.

INFORMATION
● If the current area is not included in the map data, the city map will not be

displayed.

● If the vehicle moves to or the map is scrolled to an area where the city map is

not available, the city map will be canceled automatically.

31

1-2. Basic operation of navigation system

Changing the orientation of the map
The orientation of the map can be fixed or changed to match the vehicle
heading. Change the orientation as desired.
Each time [
] on the map screen is touched, the orientation of the map
screen will change between north up, heading up, and 3D display.
● North up display [

]
The map is always displayed with north up, regardless of the direction
travel of the vehicle.

● Heading up display [

]
The map is always displayed with the direction of travel of the vehicle
always up.

● 3D map [

]
Displays a 3D map. When 3D map is selected, the map is displayed with
the direction of travel of the vehicle always up.
INFORMATION

● The display angle of the 3D map can be adjusted.

● When the orientation of the map is heading up or 3D map, if the map is

changed to any screen other than the current position screen (destination
setting map screen, full route map screen, etc.), the orientation will change
to north up. However, it will return to heading up or 3D map when the current
position screen is displayed.

Related Links
Display angle setting(P. 80)

32

1-2. Basic operation of navigation system

Moving the map

1

● The center of the map screen will be moved to the touched point.

● If information is available for a POI, it will be displayed when touched.
● By touching [

] after scrolling the map to any point, the point can be
set as a new destination or waypoint.

● By touching [

] after scrolling the map to any point, the point can be

set as a favorite.

● Touch [

] or [

] to return to the vehicle’s current position.

INFORMATION
The map can be scrolled by touching and dragging or flicking the screen.

Related Links
Operating the touch screen(P. 22)
Changing the orientation of the map(P. 32)
Displaying information for a point(P. 146)

33

Basic operation

The map can be moved and a touched point can be set as the center of the
map screen.
Touch a point on the map.
