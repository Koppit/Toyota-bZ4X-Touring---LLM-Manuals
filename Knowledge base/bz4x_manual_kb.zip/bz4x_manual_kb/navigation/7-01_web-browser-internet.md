# 7-1. Web browser (Internet)

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 7 Connected services, pages 250–256

(Internet)

browser

Web

7-1. Web browser (Internet)

About web browser (Internet) function
By connecting to the internet, websites (news sites, blogs, streaming music
sites, video sites, etc.) can be viewed.
INFORMATION
To use the web browser function, it is necessary for the vehicle Wi-Fi® to be
connected to an access point.

WARNING
For safety, only watch website after completely stopping the vehicle and applying
the parking brake or changing the shift position to "P". (Only audio is output while
driving.)

250

7-1. Web browser (Internet)

Displaying the web browser screen
] from the main menu.
1 Touch [
2 Touch [Web browser].
The web browser screen is displayed.

INFORMATION
● Only websites which use "HTTPS"(secure connection) can be accessed.

● Depending on the website, it may not be displayed correctly.
● Some websites cannot be displayed or transitioned.
● Some websites may not display some characters.

● Depending on the content, you may not be able to play video or audio.

● It may take some time to display depending on the resolution of the video

and image and the communication environment.

● Copyright-protected video content cannot be played.

● Do not enter any information such as credit card information or bank ac-

count information.

● Some functions cannot be used, such as downloading files and logging in to

websites.

● Web browser does not support voice input on websites. (voice dictation,

Connected services

etc.)

7

251

7-1. Web browser (Internet)

Operating the web browser screen
The web browser screen can be operated by touching displayed items on a
page or the toolbar at the top of the web browser screen.

A Return to the previous page.
B Proceed to the next page.
C Displays the URL of the page.

Touch to enter a URL and display the corresponding page.
D Reload the displayed page.
While a page is reloading, the button will change to [
]. Touch [
]
to cancel reloading of the page.
E Display the home page.
F Display the bookmark management screen.
By touching the name of a bookmark on the management screen, the
corresponding page will be displayed.
G Display the browsing history management screen.
By touching the name of a page on the management screen, the corresponding page will be displayed.
H Display the tab management screen.
By touching the name of a tab on the management screen, the corresponding tab will be displayed.
I Display the settings screen.
INFORMATION
● While a page is being reloaded, the status can be checked by the changing of

the background color of the toolbar.

● By touching and holding text on the screen, text can be selected to copy. To

copy the text, touch the copy button. Copied text can then be pasted into the
URL display area by touching it.

● Video content that supports full-screen display can be viewed on a full-screen.

If you touch the screen while the full screen is displayed, [

252

] and [

]

7-1. Web browser (Internet)
are displayed for about 3 seconds. To cancel the full screen, touch the reduce
screen button in the content, or touch [
change the position of [

] by touching [

]. If [

] is in the way, you can

].

Related Links
Managing bookmarks(P. 253)
Managing Browsing history(P. 254)
Managing tab(P. 254)
Setting web browser function(P. 255)

Managing bookmarks
Bookmarks can be registered/edited/deleted on the bookmark management
screen.
1 Touch [
] on the toolbar.
2 Touch the desired items.
A Close the bookmark management
screen.
B Displays the URL of the last displayed page.

7

Connected services

Touch to edit the URL.
C Displays the bookmark name for
the most recently displayed page.
The bookmark name can be edited
by touching it.
D Add a bookmark with the content entered in
E Edit bookmarks.

and

.

F Delete bookmarks.

INFORMATION
Up to 100 bookmarks can be saved.

Editing bookmark
The bookmark name and URL can be edited and a bookmark can be set as
the homepage.

253

7-1. Web browser (Internet)
A Edit the bookmark name.
B Edit the bookmark URL.
C By touching [Set] the page regis-

tered to the bookmark can be set
as the homepage.
] icon is displayed for the
The [
bookmark which is set as the homepage.

When done editing, touch [OK] to return to the bookmark management
screen.

Managing Browsing history
Browsing history can be deleted on the browsing history management
screen.
1 Touch [

]on the toolbar.
2 Touch the desired item.
A Close the browsing history management screen.
B Delete the browsing history.

INFORMATION
Up to 100 items can be saved in the browsing history. If the browsing history
exceeds 100 items, the oldest history will be deleted automatically.

Managing tab
Tabs can be changed to/added/closed on the tab management screen.
1 Touch [

] on the toolbar.

The number displayed in [

254

] is the number of tabs currently open.

7-1. Web browser (Internet)

2 Touch the desired item.
A Close the tab management screen.
B Add a new tab. If the added tab is
touched, the home screen will be
displayed.
C Delete the tab.

INFORMATION
● Up to 10 tabs can be opened.

● When a new tab is opened, video or music being played back may stop.

Setting web browser function
Settings related to the web browser function can be changed.
1 Touch [
] on the toolbar.
2 Touch the desired item.
A Enable/disable operation of the
web browser in the background
while using other functions.
B Enable/disable saving and loading
of cookie data, and to block/unblock third party cookies.
C Enable/disable use of JavaScript.

7

Connected services

D Delete browsing history, cookies
and other site data, and cached
images and files.

INFORMATION
If [Background] is set to [Allow], data transfer will occur even when using
other functions.

255

7-1. Web browser (Internet)

256
