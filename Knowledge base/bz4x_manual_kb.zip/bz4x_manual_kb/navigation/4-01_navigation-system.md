# 4-1. Navigation system

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 4 Navigation, pages 144–145

system

Navigation

4-1. Navigation system

About the use of map information provision services using
Wi-Fi®
● Services which use Wi-Fi® (herein referred to as "these services") can

be used for free within a certain validity period*1 which begins when the
vehicle which this multimedia system is installed is first purchased.

● These services include those provided by third-party service providers as

follows.

• Traffic congestion information: The time when the vehicle is connected, etc.,

and position information is sent to TomTom Global Content B.V. (herein referred to as"TomTom"). Based on the information received, TomTom will provide
online services, including sending of traffic congestion information, which is
displayed on this multimedia system.

• Facility information/nearby information: Searched for facility names and po-

sition information will be sent to HERE Global B.V. (herein referred to as
"HERE"). Based on the information received, HERE provides online services,
including sending of facility information and nearby information, which is displayed on this multimedia system.

● To use these services, after connecting the multimedia system to a

Wi-Fi® access point and acknowledging the precautions, privacy policy,
or terms of service for each service provider*2 displayed on the screen,
touch [Agree] on the pop up screen.
TomTom

https://www.tomtom.com/en_gb/legal/eula-automotive/
https://www.tomtom.com/en_us/privacy/

HERE

https://legal.here.com/terms/
https://legal.here.com/privacy/policy

● Toyota Motor Corporation and its affiliates do not guarantee the opera-

tion, quality, accuracy of information provided, or make any other guarantees regarding these services, and are not liable for any damages to the
user caused by the content of, delays in, or interruption of these services.
Services provided through this multimedia system may be subject to
change, discontinuation, or suspension without notice.

*1 : The expiration date can be checked on the navigation system settings screen.

For details, refer to the navigation system settings screen. If you wish to continue using the services after the expiration date, contact your Toyota dealer.
*2 : For the terms of service for the services of each service provider, refer to the
following URL.

144

4-1. Navigation system

Connected navigation*1

INFORMATION
● When a destination is set, a route will automatically be searched for by the

Toyota Smart Center. Routes sent from the Toyota Smart Center are indicated
by [

].

● When a Toyota Smart Center subscription contract has not been entered, the

vehicle navigation system is available for map display and route guidance.

*1 : This function is not available in some countries or areas.

145

4

Navigation

Connected navigation is a wireless communication based navigation service using updated map data and destination information obtained from the
Toyota Smart Center. To use this service, it is necessary to enter a Toyota
Smart Center subscription contract.
● Displays updated map, obtained from the Toyota Smart Center, of the
area near your current location. During the route guidance, obtains updated map of the area along the route.
● The Toyota Smart Center searches for the optimum route on a regular
basis, including while the route guidance is taking place, and proposes a
new route if more time-saving route to the destination is found.
As the vehicle device has navigation map data, this service uses it in areas
where it is not possible to communicate with the Toyota Smart Center and
displays the vehicle navigation map and searches for routes. When the
vehicle enters a good communication environment, communication with the
Toyota Smart Center will begin automatically, and the connected navigation
will display the map and search for routes.
