# Reading this manual

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, Introduction, pages 10–11

Introduction

Reading this manual
Explains symbols used in this manual.

Symbols in this manual
Symbols

Meanings
WARNING : Explains something that, if not obeyed, could cause death
or serious injury to people.
NOTICE : Explains something that, if not obeyed, could cause damage
to or a malfunction in the vehicle or its equipment.

Indicates operating or working procedures.
INFORMATION : Explains something other than descriptions about
operation methods and functions that you should know and are useful to
know.

Symbols in illustrations

Symbols

Meanings
Indicates the action (pushing, turning, etc.) used to operate buttons and
other devices.

10

Introduction

Symbols

Meanings
Indicates the component or place being explained.

11
