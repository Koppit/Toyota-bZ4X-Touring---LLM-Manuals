# 3-2. Connecting to a Wi-Fi® network

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 3 Connecting a smartphone or communication device, pages 118–122

Wi-Fi®network

a

to

Connecting

3-2. Connecting to a Wi-Fi® network

Precautions when using Wi-Fi® devices
Pay special attention to the following information when using the Wi-Fi® of
the multimedia system.
■ Users with pacemakers or other electrical medical devices

Observe the following precautions with regard to radio waves during Wi-Fi®
communication.
WARNING
● Use Wi-Fi® devices only when safe and legal to do so.
● The vehicle antenna for Wi-Fi® communication is built into the multimedia sys-

tem.

● People with implantable cardiac pacemakers, cardiac resynchronization thera-

py-pacemakers or implantable cardioverter defibrillators should maintain a reasonable distance between themselves and the Wi-Fi® antennas.

The radio waves may affect the operation of such devices.
● Before using Wi-Fi® devices, users of any electrical medical device other than

implantable cardiac pacemakers, cardiac resynchronization therapy-pacemakers or implantable cardioverter defibrillators should consult the manufacturer
of the device for information about its operation under the influence of radio
waves.
Radio waves could have unexpected effects on the operation of such medical
devices.

■ Using Wi-Fi® and Bluetooth® simultaneously

The vehicle uses 2.4GHz Wi-Fi® which is the same frequency used by
Bluetooth®. Using both Wi-Fi® and Bluetooth® simultaneously could cause
interference to occur with each other which can result in poor performance
or connection issues.
■ Things to know about Wi-Fi®

INFORMATION
● Performance may vary depending on various environmental and electrical fac-

tors.

● Use this function when connecting to a portable device. Connections to devices

other than portable devices may be disconnected, depending on the environment.

● Leaving the Wi-Fi® area will disconnect communication.

● If the vehicle is near a radio antenna, radio station or other source of strong

radio waves and electrical noise, communication may be slow or impossible.

118

3-2. Connecting to a Wi-Fi® network
● The communication speed may drop or it even may become impossible to use

this service in certain usage environments. (Due to factors such as the wireless
antenna location and any wireless devices being used nearby.)

Compatible Wi-Fi® communication protocols
IEEE 802.11b/g/n (2.4GHz)
IEEE 802.11a/n/ac (5GHz)*1
Compatible security protocols
● WEP
● WPA™
● WPA2™
● WPA3™

3

Connecting a smartphone or communication device

Related Links
Precautions for playback of Miracast®(P. 207)
Precautions when using Bluetooth® devices(P. 104)
Status icons(P. 20)
Changing Wi-Fi® settings(P. 97)
About web browser (Internet) function(P. 250)

*1 : This function is not available in some countries or areas.

119

3-2. Connecting to a Wi-Fi® network

Connecting to a network using Wi-Fi® *1
The multimedia system can be connected to the Internet by connecting to a
Wi-Fi® network.
INFORMATION
● The reception level is displayed at the top of the screen.

● This function cannot be used while Apple CarPlay is connected wirelessly.

● Some smartphone models may require establishing a connection each time.

● If networks are detected while the Wi-Fi® function is on, automatic connection

will prioritize connecting to the network with the most recent connection.

Related Links
Changing Wi-Fi® settings(P. 97)

Connecting to Wi-Fi® using a smartphone
Refer to the following operation example to establish a Wi-Fi® connection
using a smartphone that supports Wi-Fi® tethering. For details on setting up
tethering, refer to documents such as the instruction manual for the smartphone. Some smartphone models may require establishing a connection
each time.
1 Touch [
] from the main menu.
2 Touch [Wi-Fi] on the sub menu.
3 Set [Wi-Fi] in the main area to
on.
● A message may be displayed de-

pending on the multimedia system
settings. Perform the operation according to the screen guidance.

● Turning on [Wi-Fi] will display near-

by networks that are available.

4 Select the name of the network that matches the name being
broadcasted by the smartphone.
● Network name may display as duplicate when more than one MAC address

shares the same network.

● A maximum of 30 networks can be displayed. The list is automatically updat-

ed every six seconds.

*1 : This function is not available in some countries or areas.

120

3-2. Connecting to a Wi-Fi® network
● If there are devices using the same network name (Network SSID), it cannot

identify which device to use. Use different network names (Network SSIDs) if
using multiple devices.

● No selections can be made while driving.

5 Enter the corresponding password for this network.
● If no password is set, the connection will be made after selecting the network.

● If networks are detected with the automatic connection setting on, they will be

connected to automatically.

Connecting a smartphone or communication device

INFORMATION
The network connection history retains up to 20 items, deleting the oldest
when a new one is saved.

Establishing a Wi-Fi® connection to an available network
Connect to the Internet from a nearby network using Wi-Fi®.
Confirm the password of the network to be used in advance.
1 Touch [
] from the main menu.
2 Touch [Wi-Fi] on the sub menu.
3 Set [Wi-Fi] in the main area to
on.
● A message may be displayed de-

pending on the multimedia system
settings. Perform the operation according to the screen guidance.

● Turning on [Wi-Fi] will display near-

by networks that are available.

4 Touch the network to be connected to from [Available networks] in the main area.
● Network name may display as duplicate when more than one MAC address

shares the same network.

● A maximum of 30 networks can be displayed. The list is automatically updat-

ed every six seconds.

● If there are devices using the same network name (Network SSID), it cannot

identify which device to use. Use different network names (Network SSIDs) if
using multiple devices.

● No selections can be made while driving.
● Touch [

3

] for the applicable network to check network details.

5 Enter the corresponding password for this network.
● If no password is set, the connection will be made after selecting the network.

121

3-2. Connecting to a Wi-Fi® network
● If networks are detected with the automatic connection setting on, they will be

connected to automatically.

INFORMATION
The network connection history retains up to 20 items, deleting the oldest
when a new one is saved.

Disconnecting Wi-Fi®
Wi-Fi® can be disconnected by turning off the Wi-Fi® function.
] from the main menu.
1 Touch [
2 Touch [Wi-Fi] on the sub menu.
3 Set [Wi-Fi] in the main area to
off.

122
