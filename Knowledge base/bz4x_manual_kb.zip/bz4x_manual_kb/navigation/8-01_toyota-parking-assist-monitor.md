# 8-1. Toyota parking assist monitor

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 8 Parking assist system, pages 258–276

monitor

assist

parking

Toyota

8-1. Toyota parking assist monitor

Toyota parking assist monitor functions*
The Toyota parking assist monitor is a device that assists reversing when
parking and in other situations by displaying vision from the rear camera
installed on the vehicle.
INFORMATION
The illustrations of screens used in the descriptions are examples and may differ
to the actual vision from the camera due to vehicle glare and such like.

WARNING
● Always make sure to visually check your surroundings while you are driving.

● Due to the characteristics of the camera lens, the actual position and distance

of people and obstacles differ from what appears on the screen.

Displaying the Toyota parking assist monitor screen
When the shift position is in "R" with the power switch turned ON, the
Toyota parking assist monitor screen will be displayed.

A Rear view
B Wide rear view
C Touch the display mode switching button

INFORMATION
● Display settings, such as the guide line modes, can be saved as My Setting by

registering to user profiles. They can be recalled when the driver is recognized.

● The voice control system can be used to change the screen mode.*1

* : If equipped
*1 : This function is not available in some countries or areas.

258

8-1. Toyota parking assist monitor

Related Links
Registering a user profile(P. 50)
Starting voice control(P. 42)

8

Parking assist system

259

8-1. Toyota parking assist monitor

Displaying the guide screen
1. Shift the shift position to "R".
● The mode switches each time touch the display mode button.

■ Rear view

■ Wide rear view

A Voice recognition icon*1
This icon is displayed when the voice control system is in operation.
B Display mode switching
Switches display mode between the rear view and the wide rear view.
C Guide line switching
Switches the guide line mode.

WARNING
The position of the guide lines displayed on the screen may change due to factors
such as number of passengers, load weight, and road gradient. Always make sure
to visually check behind you and your surroundings while you are driving.

Related Links
Changing the guide line display mode(P. 262)

*1 : This function is not available in some countries or areas.

260

8-1. Toyota parking assist monitor

Turning off the Toyota parking assist monitor
The Toyota parking assist monitor turns off when the shift position is in any
position other than "R".

8

Parking assist system

261

8-1. Toyota parking assist monitor

Changing the guide line display mode
The guide line display mode changes every time you touch the guide line
switching button.
■ Estimated course lines mode

This mode displays estimated course lines that move in accordance with
the operation of the steering wheel.

A Vehicle width guide lines
Displays course lines when the vehicle is being reversed in a straight line.
● The lines are wider than the actual width of the vehicle.

● When the vehicle is straight, the guide lines will overlap with the estimated

course lines.

B Estimated course lines
Displays course lines (yellow) that are linked to operation of the steering wheel.
C Distance guide lines
Displays the distance behind the vehicle.
● The distance guide line is linked to the estimated course lines.

● Displays about 0.5 m (1.5 ft.) (red) and 1 m (3 ft.) (yellow) from the center of

the end of the rear bumper.

D Distance guide line
Displays about 0.5 m (1.5 ft.) (blue) from the end of the rear bumper.
E Vehicle center guide line
Displays the center of the vehicle width guide lines.

■ Parking assist guide lines mode

This mode displays the steering wheel return points (parking assist guide
lines). This mode is recommended for those who have a sense of the
vehicle and can park the vehicle without the aid of the estimated course
lines.

262

8-1. Toyota parking assist monitor

A Vehicle width guide lines
Displays course lines when the vehicle is being reversed in a straight line.
● The lines are wider than the actual width of the vehicle.

B Parking assist guide lines

Displays the course lines of the smallest turn possible behind the vehicle.
● Use the position of operating the steering wheel when parking as a guide.

C Distance guide line

Displays the distance behind the vehicle.
● Displays about 0.5 m (1.5 ft.) (red) from the center of the end of the rear

bumper.

D Vehicle center guide line
Displays the center of the vehicle width guide lines.

■ Distance guide line mode

8

A Distance guide line
Displays the distance behind the vehicle.
● Displays about 0.5 m (1.5 ft.) (red) from the center of the end of the rear

bumper.

263

Parking assist system

This mode only displays the distance guide line. It is recommended for
those who do not need the guide lines.

8-1. Toyota parking assist monitor

■ Estimated course center line mode

This mode displays estimated course lines and a vehicle center guide line
that move in accordance with the operation of the steering wheel.
Use this mode when you are approaching a signpost or pole with the center
of the rear bumper.

A Distance guide lines
Displays the distance behind the vehicle.
● The distance guide line is linked to the estimated course lines.

● Displays about 0.5 m (1.5 ft.) (red) and 1 m (3 ft.) (yellow) from the center of

the end of the rear bumper.

B Estimated course center line
Displays the vehicle center guide line (green) that is linked to operation of the
steering wheel.
C Estimated course lines
Displays course lines (yellow) that are linked to operation of the steering wheel.

INFORMATION
The guide lines will not be displayed if the back door is not closed. If the back
door is closed but the guide lines are still not displayed, have the vehicle inspected by any Toyota retailer or Toyota authorized repairer, or any reliable repairer.

WARNING
The vehicle width guide lines are wider than the actual width of the vehicle.
Always make sure to visually check behind you and your surroundings when you
are reversing.

Parking using the estimated course lines mode
1 Shift the shift position to "R".

264

8-1. Toyota parking assist monitor

2 Turn the steering wheel so that
the estimated course lines are
within the parking space and
then reverse slowly.
A Estimated course lines
B Parking space

3 When the rear of the vehicle
has entered the parking space,
turn the steering wheel so that
the vehicle width guide lines are
within the left and right dividing
lines of the parking space.

8

Parking assist system

A Vehicle width guide lines

4 Once the vehicle width guide lines and the parking space lines are
parallel, straighten the steering wheel and reverse slowly until the
vehicle has completely entered the parking space.
5 Stop the vehicle in an appropriate place to finish parking.

265

8-1. Toyota parking assist monitor

Parking using the parking assist guide lines mode
1 Shift the shift position to "R".
2 Reverse until the parking assist
guide lines align with the dividing line of the parking space.
A Parking space dividing line
B Parking assist guide lines

3 Turn the steering wheel all the way, and reverse slowly.
4 Once the vehicle is parallel with the parking space, straighten the
steering wheel and reverse slowly until the vehicle has completely
entered the parking space.
5 Stop the vehicle in an appropriate place to finish parking.

266

8-1. Toyota parking assist monitor

Precautions for the Toyota parking assist monitor
Driving precautions
The Toyota parking assist monitor is equipment that assists the driver reverse the vehicle. Always make sure to visually check behind you and your
surroundings when reversing. If not, you may collide with other vehicles
or an unforeseen accident may occur. Follow the below precautions when
using the Toyota parking assist monitor.
WARNING
● Never reverse only looking at the screen. The images displayed on the screen

may differ to the actual situation. Hence, if only looking at the screen when reversing, you may collide with another vehicle or have an unforeseen accident.
In particular, be careful not to collide with vehicles parked nearby or other
objects. Always make sure to use the rear-view and side mirrors as well as
visually check behind you and your surroundings when reversing.

● Depress the brake pedal to adjust your speed and slowly reverse the vehicle.

● If collision is likely with a nearby vehicle, obstacle, or person, or mount the

shoulder of the road, depress the brake pedal to stop the vehicle.

● The instructions given for the Toyota parking assist monitor modes are only

guidelines. When and how much to turn the steering wheel will vary according
to traffic conditions, road surface conditions, vehicle condition, and so on when
parking. It is necessary to be fully aware of this before using the Toyota parking
assist monitor.

vehicle before reversing into it.

● Do not use the Toyota parking assist monitor in the following cases:
• On icy or slick road surfaces, or in snow
• When using tire chains or emergency tires
• When the back door is not closed completely
• On roads that are not flat or straight, such as hills or bends
• If the tires of a size other than specified by Toyota are installed
• If the suspension has been modified
• If a non-Toyota product is installed on the area displayed on the screen

● In low external temperatures, the screen may darken or the image may become

faint. The image could distort when the vehicle is moving, or you may not be
able to see the image on the screen, so always visually check your surroundings while you are driving.

● If tire sizes are changed, the position of the guide lines displayed on the screen

may be incorrect.

267

Parking assist system

● When parking, be sure to check that the parking space will accommodate your

8

8-1. Toyota parking assist monitor

NOTICE
● The camera may not function correctly and the image may be displayed on the

screen in the following manner:

• When the shift position is in "R", part or all of the screen may appear black
• When the shift position is in "R", the screen may not change to the camera

image

• When a shift position other than "R" is selected, the image from the camera

may remain displayed

• The guide lines are not displayed on the camera image, and attention sym-

bols and caution notices are displayed

Area displayed on the screen
■ Rear view
A Area displayed on the screen
B Objects not displayed on the

screen
Areas close to both corners of the
bumper will not appear on the screen.

268

8-1. Toyota parking assist monitor

■ Wide rear view
A Area displayed on the screen
B Objects not displayed on the

screen
Areas close to both corners of the
bumper will not appear on the screen.

INFORMATION
● The range that is displayed on the screen may differ due to the state of the

vehicle and road surface.

8

● Areas close to both corners of the bumper and under the bumper will not
● The depth perception of the image displayed on the screen differs to the actual

distance due to the camera lens characteristics.

● Objects that are higher than the camera may not appear in the monitor.

Related Links
Changing the screen display settings(P. 67)

269

Parking assist system

appear on the screen.

8-1. Toyota parking assist monitor

Camera position
The Toyota parking assist monitor
camera is in the locations shown in
the figure.

Cleaning the camera
If dirt or foreign matter, such as water droplets, snow, or mud, has stuck to
the camera, you will not be able to see the image clearly. If that happens,
splash the camera with a large amount of water and then wipe the camera
lens clean with a soft, damp cloth.
NOTICE
● The Toyota parking assist monitor may stop functioning correctly. Take note of

the following items:

• Do not hit or apply a forceful impact on the camera. Doing so may change

the position and mounting angle of the camera.

• The camera is designed to be waterproof. Do not detach, disassemble, or

modify it.

• When washing the camera lens, splash the camera with a large amount of

water and then wipe the camera lens clean with a soft, damp cloth. Rubbing
the camera lens forcibly may scratch the camera lens and images may no
longer be able to be seen clearly.

• The camera cover is made of resin. Do not allow an organic solvent, car

wax, window cleaner, or glass coating to adhere to the camera. If this happens, wipe it off immediately.

• Do not pour hot water on the vehicle in cold weather or apply other rapid

changes of temperature.

• If you wash the vehicle with a high pressure car washer, do not point the

hose directly at the camera or camera area. Applying strong water pressure
may result in the camera malfunctioning.

● If the camera is hit, it may cause a camera malfunction. If this happens, have

the vehicle inspected by any Toyota retailer or Toyota authorized repairer, or
any reliable repairer as soon as possible.

270

8-1. Toyota parking assist monitor

■ Cleaning the rear camera with washer fluid

Dirt on the rear camera lens can be cleaned by operating the dedicated
camera cleaning washer. For details, refer to "Owner's manual".
● When cleaning the camera, it may be difficult to see the image due to the
washer fluid. When backing up, be sure to visually check all around the
vehicle both directly and using the mirrors before proceeding.
● If washer fluid remains on the camera lens surface after cleaning, the
image may be difficult to see at night due to the height or inclination of
the headlights of the vehicle behind.
● Some dirt may not be removed completely after cleaning. In this case,

rinse the camera lens with a large quantity of water and then wipe it
clean with a soft cloth dampened with water.
● Washer fluid is sprayed onto the camera lens surface. Therefore, the ice,
snow, etc. adhering around the camera cannot be removed.
NOTICE
Do not strike or hit the washer nozzle or subject it to a strong impact, as the
washer nozzle installation position and angle may be changed.

Differences between the screen and the actual road
● The distance guide lines and the vehicle width guide lines may not ac-

271

8

Parking assist system

tually be parallel with the dividing lines of the parking space, even when
they appear to be so. Be sure to check visually.
● The distances between the vehicle width guide lines and the left and
right dividing lines of the parking space may not be equal, even when
they appear to be so. Be sure to check visually.
● The distance guide lines show a distance guide for flat road surfaces.
Therefore, there is a margin of error between the guide lines on the
screen and the actual distance and course on the road.

8-1. Toyota parking assist monitor

■ When the ground behind the vehicle slopes up sharply

The distance guide lines will appear
to be closer to the vehicle than the
actual distance. Thus, objects on upslopes will appear to be farther away
than they actually are. In the same
way, there will be a margin of error
between the guidelines and the actual
distance and course on the road.

■ When the ground behind the vehicle slopes down sharply

The distance guide lines will appear
to be further from the vehicle than
the actual distance. Thus, objects on
down-slopes will appear to be closer
than they actually are. In the same
way, there will be a margin of error
between the guidelines and the actual
distance and course on the road.

272

8-1. Toyota parking assist monitor

■ When any part of the vehicle sags

When any part of the vehicle sags
due to the number of passengers or
the distribution of the load, there is
a margin of error between the guide
lines on the screen and the actual distance and course on the road.
A Margin of error

■ Estimated course center line

As the guide lines are shown midair
near the rear bumper, there are times
that they may look like they are offcenter.

Differences between the screen and actual 3D objects

8

273

Parking assist system

Since the estimated course lines and distance guide lines are displayed
for a flat road surface, it is not possible to determine the position of threedimensional objects. When approaching a three-dimensional object that
extends outward (such as the flatbed of a truck), take note of the following
cautions.

8-1. Toyota parking assist monitor

■ Estimated course lines

Make sure to visually check behind
you and your surroundings. On the
screen, a truck flatbed may appear
to be outside of the estimated course
lines and the vehicle does not look as
if it will collide with the truck. However, the flatbed may actually cross over
the estimated course lines and if you
reverse as guided by the estimated
course lines, the vehicle may hit the
truck.
A Estimated course lines

■ Distance guide lines

Make sure to visually check behind
you and your surroundings. On the
screen, the distance guide lines
shows that a truck is parking at point
. However, in reality if you reverse
to point , you will collide with the
truck. On the screen, it appears that
is closest followed by points
point
and . However, in reality, the
distance to points
and
is the
same, and point
is farther than
and . The distance to point
is
about 1 m (3 ft.).

274

8-1. Toyota parking assist monitor

If you notice any symptoms
If you notice or are troubled by any of the symptoms below, check the issue
again referring to the likely cause and solution.
If the symptom is not resolved by the solution, have the vehicle inspected
by any Toyota retailer or Toyota authorized repairer, or any reliable repairer.
Symptom

Likely cause

Solution

● The vehicle is in a dark

area or it is night.

● The temperature around

the lens is either high or
low.

● The outside temperature

is low.

The screen is
difficult to see

● There are water droplets

on the camera.

Visually check your vehicle’s surroundings while you are driving.
(Use the Toyota parking assist
monitor again once the camera
and conditions have improved.)

● It is raining or humid.

The procedure for adjusting the
● Foreign matter (mud etc.) picture quality of the Toyota parking assist monitor is the same
is stuck to the camera.
as the procedure for adjusting the
● Sunlight or headlights are
multimedia screen.
shining directly into the
camera.
8

● The vehicle is under flu-

Splash the camera with a large
amount of water and then wipe
the camera lens clean with a soft,
damp cloth.

The image is
blurry

Dirt or foreign matter, such
as water droplets, snow, or
mud, has stuck to the camera lens.

The screen is
misaligned

The camera has received a
strong impact.

Have the vehicle inspected by any
Toyota retailer or Toyota authorized repairer, or any reliable repairer.

The guide
lines are signif- The camera position is misaligned.
icantly misaligned

Have the vehicle inspected by any
Toyota retailer or Toyota authorized repairer, or any reliable repairer.

Operate the dedicated camera
cleaning washer and clean the
camera lens. For details, refer to
"Owner's manual".

275

Parking assist system

orescent lights, sodium
lights, mercury lights, etc.

8-1. Toyota parking assist monitor
Symptom

Likely cause

Solution

● The vehicle is tilted

The guide
lines are significantly misaligned

(There is a heavy load on
the vehicle, tire pressure
Visually check your vehicle’s suris low due to a tire puncroundings while you are driving.
ture, etc.).

● The vehicle is on an in-

cline.

The estimated
course lines
move even
though the
steering wheel
There is a malfunction in the
is straight (the
signals being output by the
vehicle width
steering sensor.
guide lines and
estimated
course lines
are out of
alignment)

Have the vehicle inspected by any
Toyota retailer or Toyota authorized repairer, or any reliable repairer.

Close the back door.
The guide
lines are not
displayed

The back door is open.

If this does not resolve the issue,
have the vehicle inspected by any
Toyota retailer or Toyota authorized repairer, or any reliable repairer.

Related Links
Changing the screen display settings(P. 67)

276
