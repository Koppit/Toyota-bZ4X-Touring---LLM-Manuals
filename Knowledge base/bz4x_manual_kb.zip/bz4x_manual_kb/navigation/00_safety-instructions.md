# Safety instructions

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, Introduction, pages 9–9

Introduction

Safety instructions
To use this system in the safest possible manner, follow all the safety tips
shown below.
This system is intended to assist in reaching the destination and, if used
properly, can do so. The driver is solely responsible for the safe operation
of the vehicle and the safety of your passengers. Do not use any feature
of this system to the extent it becomes a distraction and prevents safe
driving. The first priority while driving should always be the safe operation
of the vehicle. While driving, be sure to observe all traffic regulations. If a
traffic sign on the road has been changed, route guidance may not have
the updated information such as the direction of a one way street.
While driving, listen to the voice instructions as much as possible and
glance at the screen briefly and only when it is safe. However, do not
totally rely on voice guidance. Use it just for reference. If the system cannot
determine the current position correctly, there is a possibility of incorrect or
delayed guidance, or no voice guidance at all.
The data in the system may occasionally be incomplete. Road conditions,
including driving restrictions (no left turns, street closures, etc.) frequently
change. Therefore, before following any instructions from the system, look
to see whether the instruction can be done safely and legally.
This system cannot warn about such things as the safety of an area, condition of streets, and availability of emergency services. If unsure about
the safety of an area, do not drive into it. Under no circumstances is this
system a substitute for the driver’s personal judgement.
WARNING
● For safety, the driver should not operate the system while he/she is driving.

Insufficient attention to the road and traffic may cause an accident.

● While driving, be sure to obey the traffic regulations and maintain awareness of

the road conditions.

9
