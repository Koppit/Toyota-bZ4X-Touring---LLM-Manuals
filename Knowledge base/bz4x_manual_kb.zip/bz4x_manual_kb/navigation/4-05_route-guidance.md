# 4-5. Route guidance

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 4 Navigation, pages 170–174

guidance

Route

4-5. Route guidance

Route guidance screen
Easy to understand, vocal and visual guidance are provided during route
guidance at relevant points, such as intersections and junctions.

A Displays the distance and estimated time of arrival from the current

position of the vehicle to the destination.
If the route has been deviated from, the estimated time of arrival will not
be displayed. Instead, the straight line distance to the destination will be
displayed.
Touch to display the full route map screen.
B Displays the distance to the next turn and the turn direction.
Touch to display a lane list up to the destination.
C Display the route to the destination.
For setting the display color of the route, refer to setting the map display.
D Displays the nearest intersection/junction to be passed or turned at
during route guidance.
E End route guidance. When multiple destinations have been set, touch
[Delete destination] to delete all destinations and stop route guidance,
and touch [Delete next destination] to delete only the next destination
and continue route guidance.
INFORMATION
● If the route cannot be searched for, a message will be displayed on the

screen.

● When map data is not available, a compass screen will be displayed.

Related Links
Changing the map display settings(P. 79)
Lane display screens(P. 171)

170

4-5. Route guidance

Lane display screens
During route guidance, when approaching an intersection/junction which is
to be turned at, a enlarged intersection display will be displayed.

Enlarged intersection display

INFORMATION
● The enlarged intersection display will not be displayed for intersections which

there is no information in the map data.

● The displayed enlarged intersection display may differ from the actual intersec-

tion.

● Intersection guidance may not be output immediately after beginning route

guidance.

● The enlarged intersection display may be displayed late or early.

● When intersections which are to be turned at are close to each other, the

enlarged intersection display will be displayed continuously.

● The enlarged intersection display will be displayed for intersections to be turned

at. Intersection guidance will not be output for intersections before the intersection to be turned at.

● The remaining distance displayed on the enlarged intersection display and

displayed on the multi-information display may differ.

● The enlarged intersection display displayed on the navigation system display

and displayed on the multi-information display differ.

Related Links
Guidance settings(P. 84)

171

4

Navigation

Intersection guidance is output when approaching an intersection which
is to be turned at. Also, an enlarged display of the intersection will be
displayed just before the intersection.
A Displays the names of roads
which are passed through or
turned at.
B Displays the distance from the
current position
C Closes the enlarged intersection
display.
D Displays the remaining distance
bar to the guidance point.

4-5. Route guidance

Enlarged 3D display
In order to make a turn easier to understand during route guidance, an
enlarged 3D display which matches the surroundings of the intersection
may be displayed.
Touch [
display.

172

] to cancel the enlarged

4-5. Route guidance

Searching for a route again
During route guidance (even when the route has been deviated from), the
route can be searched for again.
1 Touch [∨] on the map screen.

4

Navigation

2 Touch [Route options] or [Alternative route].
3 Touch the search conditions.
4 Touch [OK].
Related Links
Changing route options(P. 166)
Full route map screen(P. 163)
Changing the route(P. 167)

173

4-5. Route guidance

Typical voice guidance prompts
As the vehicle approaches an intersection, or point, where maneuvering the
vehicle is necessary, the navigation system’s voice guidance will provide
various messages.
INFORMATION
● Voice guidance may be made early or late.

● If the navigation system cannot determine the current position correctly, you

may not hear voice guidance or may not see the magnified intersection on the
screen.

WARNING
Be sure to obey the traffic regulations and keep the road condition in mind especially when you are driving on IPD roads (roads that are not completely digitized in
our database). The route guidance may not have the updated information such as
the direction of a one way street.

Related Links
Changing sound and media settings(P. 91)
Guidance settings(P. 84)

174
