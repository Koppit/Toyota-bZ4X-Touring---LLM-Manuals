# 2-2. Various settings

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 56–57

settings

Various

2-2. Various settings

Changing the various settings
The various settings related to the multimedia system can be changed.
] from the main menu.
1 Touch [
2 Select the desired item.

Setting

Description

"Current driver"(1)
[
](User profile name or vehicle
name)
[

Guest]

Displays the name of the current driver. Touching the driver name enables
to switch or register a user profile.
(→ P.58)

"My settings"

56

[Personal info]

Register a device to identify the driver.
(→ P.61)

[Bluetooth & Devices]

Register or edit a Bluetooth® device.
(→ P.99)

[General]

Change the clock settings, display language, and other general multimedia
settings.(→ P.64)

[Wi-Fi]

Configure Wi-Fi® settings and other
advanced settings.
(→ P.97)

[Display]

Adjust the screen contrast and brightness, etc.(→ P.67)

[Sound & Media]

Change the system voice volume and
audio source settings.(→ P.91)

[Navigation]

Change settings related to map display and route guidance.(→ P.78)

[Voice & Search]

Change settings related to the voice
recognition feature.(→ P.69)

2-2. Various settings
Setting

Description

"Vehicle"
Change settings related to vehicle devices.

[Driving assist](2)

Change function settings related to the
Toyota parking assist-sensor and other driving support.

[Dealer info]

Register and delete dealer information.(→ P.71)

[Info & Security]

Change settings related to security
and privacy.(→ P.72)

[Software update]

Check and update software information.(→ P.75)

(1) This function is not available in some countries or areas.
(2) Refer to the vehicle "Owner's manual".

INFORMATION
For safety purposes, there are functions that cannot be operated while the
vehicle is moving.

57

2

Settings and registration

[Vehicle customise](2)
