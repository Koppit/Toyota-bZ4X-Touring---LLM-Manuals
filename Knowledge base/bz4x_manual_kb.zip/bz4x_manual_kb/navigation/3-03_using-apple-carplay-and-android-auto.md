# 3-3. Using Apple CarPlay and Android Auto

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 3 Connecting a smartphone or communication device, pages 123–142

Auto

Android

and

CarPlay

Apple

Using

3-3. Using Apple CarPlay and Android Auto

Precautions when using Apple CarPlay and Android Auto
Apple CarPlay and Android Auto allow for some applications (such as map,
phone, and music applications) to be used by the multimedia system. While
connected to Apple CarPlay or Android Auto, supported applications will
display. Pay special attention to the following information when using Apple
CarPlay or Android Auto.
To use Android Auto in your car, install the Android Auto app from Google's
Play Store.
● Apple iPhone devices that support Apple CarPlay. (iOS Ver. 13.3 or later)

For the supported devices, check https://www.apple.com/ios/carplay/.*1
● Android devices that supports Android Auto.
For the supported devices, check https://www.android.com/auto/.*1
WARNING
For safety reasons, drivers should not operate the smartphone itself while driving.

NOTICE
● Do not leave the smartphone inside the vehicle. The inside of the vehicle can

become hot, which could cause the smartphone to malfunction.

● Do not push down on or subject the smartphone to unnecessary pressure while

it is connected. The smartphone or port may be damaged.

● Keep the USB Type-C port free of foreign matter. The smartphone or port may

be damaged.

INFORMATION
● For USB connections, use a data USB Type-C cable provided by the phone

manufacturer.

● Some system button functions will change while connected to Apple CarPlay or

Android Auto.

● When connected via Apple CarPlay/Android Auto, some related functions like

Bluetooth® audio and phone will be managed by Apple CarPlay/Android Auto.

● The Bluetooth® function cannot be used by the multimedia system while Apple

CarPlay is connected wirelessly in some countries or areas.

● Starting Apple CarPlay or Android Auto while using Miracast® may stop Mira-

cast®.

*1 : Operation is not guaranteed.

123

Connecting a smartphone or communication device

■ Compatible devices

3

3-3. Using Apple CarPlay and Android Auto
● The guidance volume can be changed on the [Sound & Media] settings

screen. It can also be changed using the audio system volume adjustment.

● While Apple CarPlay or Android Auto of a device is connected, Apple CarPlay

or Android Auto of a different device cannot be used.

● Apple CarPlay/Android Auto is an application developed by Apple Inc/Google

LLC. Its functions and services may be terminated or changed without notice
depending on the connected device’s operation system, hardware and software, or due to changes in Apple CarPlay/Android Auto specifications.

● For applications that support Apple CarPlay or Android Auto, refer to the re-

spective website.

● While using Apple CarPlay or Android Auto, vehicle and user information such

as the location and vehicle speed will be shared with the application publisher
and cellular phone service provider.

● Downloading and using an application signifies your consent with its terms of

use.

● Data is sent over the Internet and may result in charges being incurred. For

information on data rates, contact the cellular phone service provider.

● Some functions including music playback may be restricted, depending on the

application.

● Each function is an application provided by its respective company, and may be

changed or suspended without prior notice. For details, refer to the website for
the respective function.

● If the vehicle's navigation system is being used during route guidance and a

new route is set using the Apple CarPlay or Android Auto map app, route
guidance using the vehicle's navigation system will stop. If the Apple CarPlay
or Android Auto map app is being used during route guidance and a new route
is set using the vehicle’s navigation system, route guidance using the Apple
CarPlay or Android Auto map app will stop.

● Devices connected via Apple CarPlay cannot use Bluetooth® functions.
● Devices connected via Android Auto cannot use Bluetooth® functions other

than hands-free calling.

● In case of USB connection, if the USB Type-C cable is unplugged while con-

nected via USB, Apple CarPlay or Android Auto will stop operating. Audio
output will stop and the screen will switch to the multimedia system screen.

● Even if Android Auto is disconnected, the hands-free phone system can be

used because the phone will still be connected.

Related Links
Changing sound and media settings(P. 91)
Audio system ON/OFF and volume adjustment(P. 34)
Precautions for playback of iPod/iPhone(P. 192)

124

3-3. Using Apple CarPlay and Android Auto

Precautions for playback of Apple CarPlay(P. 195)
Precautions for playback of Android Auto(P. 198)
Precautions for playback of Miracast®(P. 207)
Precautions when using Bluetooth® devices(P. 104)
Precautions when using Wi-Fi® devices(P. 118)
Precautions for Bluetooth® audio playback(P. 202)

3

Connecting a smartphone or communication device

125

3-3. Using Apple CarPlay and Android Auto

Using Apple CarPlay with an unregistered smartphone
Apple CarPlay can be used by connecting an unregistered smartphone
to the multimedia system. The procedure is different for registered smartphones.
This function is not available in some countries or areas.
Related Links
Using Apple CarPlay with a registered smartphone(P. 129)

Using Apple CarPlay with a USB connection
Apple CarPlay can be used by connecting a smartphone to the multimedia
system using a data USB Type-C cable.
1 Enable Siri from your smartphone's settings menu.
2 Connect the smartphone to the USB Type-C port.
The Apple CarPlay home screen is displayed.
● It may take around three to six seconds to return to the original screen,

depending on the smartphone being connected.

● If guidance is displayed on the smartphone screen, follow those operation

instructions.

3 Operate Apple CarPlay.
iPhone applications that support Apple
CarPlay can be used by touching the
application.
]

[

Displays the multimedia system
screen.
To display the Apple CarPlay home
screen again, touch [
main menu.
]/[

[

] from the

]

Switch the screen display.
Touching and holding this will start Siri.
]/[

[

]

Show or hide the main menu of the multimedia system screen.

126

3-3. Using Apple CarPlay and Android Auto

INFORMATION
● While Apple CarPlay is connected, press and hold the [

] switch on the

steering to start Siri. To cancel Siri, perform a short press of the [
on the steering.

] switch

Siri. The wake word function of Siri can only be used when the language
is set to English/German/French/Spanish/Italian. Also, the connected device
must have iOS version 14.3 or later.

3

● If wireless connection is set to be used on the smartphone when registered

Connecting a smartphone or communication device

● While Apple CarPlay is connected, speaking the Siri wake word will start

via USB connection, the device can be wirelessly connected on the next
attempt.

Related Links
Connecting a device via the USB Type-C port(P. 38)
Voice control system(P. 40)
Changing the voice control settings(P. 69)

Using Apple CarPlay with wireless connection
Apple CarPlay can be connected to the multimedia system wirelessly using
vehicle's wireless connection capability.
1 Enable Siri from your smartphone's settings menu.
2 Touch [
] from the main menu.
3 Touch [Bluetooth & Devices].
● The device search screen will be displayed if there is no smartphone regis-

tered to the multimedia system. Proceed to Procedure 5.

4
5
6
7

Touch [Add another device].
Touch [If not found].
Select the smartphone to register.
Check that the displayed PIN code matches the PIN code displayed
on the smartphone, and then touch [OK].
● Perform the operation according to the guidance on the screen.

8 If Apple CarPlay settings are displayed, touch [Yes].
The Apple CarPlay home screen is displayed.
● It may take around three to six seconds to return to the original screen,

depending on the smartphone being connected.

● If an operation failed screen is displayed, follow the operation instructions on

the screen.

127

3-3. Using Apple CarPlay and Android Auto
● If guidance is displayed on the smartphone screen, follow those operation

instructions.

9 Operate Apple CarPlay.
iPhone applications that support Apple
CarPlay can be used by touching the
application.
[

]
Displays the multimedia system
screen.
To display the Apple CarPlay home
screen again, touch [
main menu.

[

]/[

] from the

]

Switch the screen display.
Touching and holding this will start Siri.
[

]/[

]

Show or hide the main menu of the multimedia system screen.

INFORMATION
● While Apple CarPlay is connected, press and hold the [

] switch on the

steering to start Siri. To cancel Siri, perform a short press of the [
on the steering.

] switch

● While Apple CarPlay is connected, speaking the Siri wake word will start

Siri. The wake word function of Siri can only be used when the language
is set to English/German/French/Spanish/Italian. Also, the connected device
must have iOS version 14.3 or later.

Related Links
Voice control system(P. 40)
Changing the voice control settings(P. 69)

128

3-3. Using Apple CarPlay and Android Auto

Using Apple CarPlay with a registered smartphone
Apple CarPlay can be used by connecting a registered smartphone to
the multimedia system. The procedure is different for unregistered smartphones.
This function is not available in some countries or areas.
Related Links

3

Using Apple CarPlay with an unregistered smartphone(P. 126)

Apple CarPlay can be used by connecting a smartphone to the multimedia
system using a data USB Type-C cable.
● Check that your smartphone is connected to multimedia system.

1 Enable Siri from your smartphone's settings menu.
2 Connect the smartphone to the USB Type-C port.
The Apple CarPlay home screen is displayed.
● It may take around three to six seconds to return to the original screen,

depending on the smartphone being connected.

● If an operation failed screen is displayed, follow the operation instructions on

the screen.

● If guidance is displayed on the smartphone screen, follow those operation

instructions.

● If the Apple CarPlay home screen is not displayed, check the following.
• Touch [

] from the main menu.

• If [

] of the main menu is not displayed, select the smartphone to use
with Apple CarPlay and set [Use for Apple CarPlay] to ON.

3 Operate Apple CarPlay.
iPhone applications that support Apple
CarPlay can be used by touching the
application.
[

]
Displays the multimedia system
screen.
To display the Apple CarPlay home
screen again, touch [
main menu.

[

]/[

] from the

]

Switch the screen display.

129

Connecting a smartphone or communication device

Using Apple CarPlay with a USB connection

3-3. Using Apple CarPlay and Android Auto
Touching and holding this will start Siri.
[

]/[

]

Show or hide the main menu of the multimedia system screen.

INFORMATION
● While Apple CarPlay is connected, press and hold the [

] switch on the

steering to start Siri. To cancel Siri, perform a short press of the [
on the steering.

] switch

● While Apple CarPlay is connected, speaking the Siri wake word will start

Siri. The wake word function of Siri can only be used when the language
is set to English/German/French/Spanish/Italian. Also, the connected device
must have iOS version 14.3 or later.

Related Links
Connecting a device via the USB Type-C port(P. 38)
Voice control system(P. 40)
Changing the voice control settings(P. 69)
Setting Bluetooth® devices(P. 99)

Using Apple CarPlay with wireless connection
Apple CarPlay can be connected to the multimedia system wirelessly using
vehicle's wireless connection capability.
● Check that your smartphone is connected to multimedia system.

1 Enable Siri from the settings menu on the smartphone.
] from the main menu.
2 Touch [
3 Touch [Bluetooth & Devices].
4 Select the smartphone to use with Apple CarPlay and set [Use for
Apple CarPlay] to ON.
The Apple CarPlay home screen is displayed.
● It may take around three to six seconds to return to the original screen,

depending on the smartphone being connected.

● If an operation failed screen is displayed, follow the operation instructions on

the screen.

● If guidance is displayed on the smartphone screen, follow those operation

instructions.

● If the Apple CarPlay home screen is not displayed, Touch [

menu.

130

] from the main

3-3. Using Apple CarPlay and Android Auto

5 Operate Apple CarPlay.
iPhone applications that support Apple
CarPlay can be used by touching the
application.
[

]
Displays the multimedia system
screen.

3

To display the Apple CarPlay home

[

]/[

] from the

]

Switch the screen display.
Touching and holding this will start Siri.
[

]/[

]

Show or hide the main menu of the multimedia system screen.

INFORMATION
● While Apple CarPlay is connected, press and hold the [

] switch on the

steering to start Siri. To cancel Siri, perform a short press of the [
on the steering.

] switch

● While Apple CarPlay is connected, speaking the Siri wake word will start

Siri. The wake word function of Siri can only be used when the language
is set to English/German/French/Spanish/Italian. Also, the connected device
must have iOS version 14.3 or later.

Related Links
Voice control system(P. 40)
Changing the voice control settings(P. 69)
Setting Bluetooth® devices(P. 99)

131

Connecting a smartphone or communication device

screen again, touch [
main menu.

3-3. Using Apple CarPlay and Android Auto

Using Android Auto with an unregistered smartphone
Android Auto can be used by connecting an unregistered smartphone
to the multimedia system. The procedure is different for registered smartphones.
This function is not available in some countries or areas.
Related Links
Using Android Auto with a registered smartphone(P. 135)

Using Android Auto with a USB connection
Android Auto can be used by connecting a smartphone to the multimedia
system using a data USB Type-C cable.
1 Confirm that the Android Auto application is installed on the smartphone to connect.
2 Connect the smartphone to the USB Type-C port.
The Android Auto home screen is displayed.
● It may take around 3 to 6 seconds to return to the original screen, depending

on the smartphone being connected.

● If guidance is displayed on the smartphone screen, follow those operation

instructions.

3 Operate Android Auto.
Applications that support Android Auto
can be used by touching the application.
[

]
Displays the multimedia system
screen.
To display the Android Auto home
screen again, touch [
main menu.

] from the

]

[

Start Google Assistant™.

INFORMATION
While Android Auto is connected, press and hold the [
] switch on the
steering to start Google Assistant™. To cancel Google Assistant™, perform a
short press of the [

132

] switch on the steering.

3-3. Using Apple CarPlay and Android Auto

Related Links
Connecting a device via the USB Type-C port(P. 38)

Using Android Auto with wireless connection*1
Android Auto can be connected to the multimedia system wirelessly using
vehicle's wireless connection capability.

] from the main menu.
2 Touch [
3 Touch [Bluetooth & Devices].
The device search screen will be displayed if there is no smartphone registered
to the multimedia system. Proceed to Procedure 5.

4
5
6
7

Touch [Add another device].
Touch [If not found].
Select the smartphone to register.
Check that the displayed PIN code matches the PIN code displayed
on the smartphone, and then touch [OK].
● Perform the operation according to the guidance on the screen.

8 If Android Auto settings are displayed, touch [Yes].
The Android Auto home screen is displayed.
● It may take around 3 to 6 seconds to return to the original screen, depending

on the smartphone being connected.

● If an operation failed screen is displayed, follow the operation instructions on

the screen.

9 Operate Android Auto.
Applications that support Android Auto
can be used by touching the application.
[

]
Displays the multimedia system
screen.
To display the Android Auto home
screen again, touch [
main menu.

[

] from the

]
Start Google Assistant™.

*1 : This function is not available in some countries or areas.

133

3

Connecting a smartphone or communication device

This function is not available in some countries or areas.
1 Confirm that the Android Auto application is installed on the smartphone to connect.

3-3. Using Apple CarPlay and Android Auto

INFORMATION
While Android Auto is connected, press and hold the [
] switch on the
steering to start Google Assistant™. To cancel Google Assistant™, perform a
short press of the [

134

] switch on the steering.

3-3. Using Apple CarPlay and Android Auto

Using Android Auto with a registered smartphone
Android Auto can be used by connecting a registered smartphone to
the multimedia system. The procedure is different for unregistered smartphones.
This function is not available in some countries or areas.
Related Links

3

Using Android Auto with an unregistered smartphone(P. 132)

Android Auto can be used by connecting a smartphone to the multimedia
system using a data USB Type-C cable.
● Check that your smartphone is connected to multimedia system.

1 Confirm that the Android Auto application is installed on the smartphone to connect.
2 Connect the smartphone to the USB Type-C port.
The Android Auto home screen is displayed.
● It may take around 3 to 6 seconds to return to the original screen, depending

on the smartphone being connected.

● If an operation failed screen is displayed, follow the operation instructions on

the screen.

● If guidance is displayed on the smartphone screen, follow those operation

instructions.

● If the Android Auto home screen is not displayed, check the following.
• Touch [

] from the main menu.

• If [

] of the main menu is not displayed, select the smartphone to use
with Android Auto and set [Use for Android Auto] to ON.

3 Operate Android Auto.
Applications that support Android Auto
can be used by touching the application.
[

]
Displays the multimedia system
screen.
To display the Android Auto home
screen again, touch [
main menu.

] from the

135

Connecting a smartphone or communication device

Using Android Auto with a USB connection

3-3. Using Apple CarPlay and Android Auto
[

]
Start Google Assistant™.

INFORMATION
While Android Auto is connected, press and hold the [
] switch on the
steering to start Google Assistant™. To cancel Google Assistant™, perform a
short press of the [

] switch on the steering.

Related Links
Connecting a device via the USB Type-C port(P. 38)
Setting Bluetooth® devices(P. 99)

Using Android Auto with wireless connection*1
Android Auto can be connected to the multimedia system wirelessly using
vehicle's wireless connection capability.
This function is not available in some countries or areas.
● Check that your smartphone is connected to multimedia system.

1 Confirm that the Android Auto application is installed on the smartphone to connect.
] from the main menu.
2 Touch [
3 Touch [Bluetooth & Devices].
4 Select the smartphone to use with Android Auto and set [Use for
Android Auto] to ON.
The Android Auto home screen is displayed.
● It may take around 3 to 6 seconds to return to the original screen, depending

on the smartphone being connected.

● If an operation failed screen is displayed, follow the operation instructions on

the screen.

● If guidance is displayed on the smartphone screen, follow those operation

instructions.

● If the Android Auto home screen is not displayed, touch [

menu.

*1 : This function is not available in some countries or areas.

136

] from the main

3-3. Using Apple CarPlay and Android Auto

5 Operate Android Auto.
Applications that support Android Auto
can be used by touching the application.
[

]
Displays the multimedia system
screen.

[

3

]

INFORMATION
While Android Auto is connected, press and hold the [
] switch on the
steering to start Google Assistant™. To cancel Google Assistant™, perform a
short press of the [

] switch on the steering.

Related Links
Setting Bluetooth® devices(P. 99)

137

Connecting a smartphone or communication device

Start Google Assistant™.

3-3. Using Apple CarPlay and Android Auto

When Apple CarPlay or Android Auto might be malfunctioning
If having trouble with Apple CarPlay or Android Auto, check the following
table first.
Symptom

Solution
Confirm that the smartphone being connected supports Apple CarPlay or Android Auto.
Confirm that Apple CarPlay or Android Auto is enabled on the smartphone.
Confirm that the Android Auto application is installed
on the smartphone being connected.
For details, refer to the following URL.
● Apple CarPlay: https://www.apple.com/ios/carplay/

● Android Auto: https://www.android.com/auto/

Confirm that the Apple CarPlay or Android Auto function on the registered smartphone is turned on in the
multimedia system.
If connecting with a USB Type-C cable, confirm that
the USB Type-C cable is securely connected to the
smartphone and the USB Type-C port. Connect the
smartphone directly to the USB Type-C port. Do not
use a USB hub.
Apple CarPlay or Android
Auto does not start.

Make sure the correct USB Type-C port is used to
connect Apple CarPlay and Android Auto. USB TypeC port used exclusively for charging cannot be used
for smartphone apps. Wireless charger used for wireless charging will not start wireless Apple CarPlay or
wireless Android Auto connection.
For an Apple CarPlay wireless connection, check the
following items.
● Confirm that the smartphone can be connected via

Bluetooth® to the multimedia system.

● Confirm that the smartphone is set to be able to

use Wi-Fi®.

For Apple CarPlay: Confirm that the Lightning cable
being used is Apple-certified.
Confirm that Siri is enabled.
The smartphone linking function cannot be used with
a charging-only USB Type-C cable.
Use a cable capable of transferring data. Some cables may not be supported.

138

3-3. Using Apple CarPlay and Android Auto
Symptom

Solution
Recommended USB Type-C cable requirements are
listed below.
● iPhone: Use an official Apple USB Type-C cable

or a USB Type-C cable that has been Apple MFi
certified.

Apple CarPlay or Android
Auto does not start.

● Android: Use a cable that is 1.8 m (6 ft.) or shorter,

and do not use an extension cable.

● Use a cable displaying the USB logo

.

After checking all of the above, connect Apple CarPlay or Android Auto.
When an Apple CarPlay/Android Auto connection is established and a
As the system is not designed to play video through
video is being played, the
Apple CarPlay/Android Auto, this is not a malfunction.
video is not displayed, but
audio is output through the
system.
The volume of the multimedia system may be muted
or set too low. Increase the volume on the multimedia
system.

The screen flickers and
audio is noisy.

Make sure Apple supported apps are used for Apple
CarPlay and Google supported apps are used for Android Auto. Playing music from web browser will lead
to no or improper audio output.
Check whether the USB Type-C cable connected to
the multimedia system is damaged. To check whether
there is internal damage to the USB Type-C cable,
connect the smartphone to another system such as
a PC, then confirm that charging starts and that it is
recognized by the system.
Replace the USB Type-C cable with another cable.

The map display cannot
be enlarged or shrunk us- Pinch operations are not supported for the Apple Caring the Apple CarPlay map Play map app.
app.

139

Connecting a smartphone or communication device

If the smartphone linking function worked previously
but no longer works, replacing the USB Type-C cable
may resolve the issue.

Audio is not outputted.

3

3-3. Using Apple CarPlay and Android Auto
Symptom

Solution

The Apple CarPlay screen
is shown in the center and Full-screen display is supported on iOS Ver. 10 or
does not fill up the whole
later. Update to the latest iOS version.
display.
During Apple CarPlay music app playback, if an application that is not compatible with Apple CarPlay(1) is started on the
iPhone and audio is output and then the volume
is changed on the multimedia system, the audio
of the incompatible application stops and the system resumes playback on
the original music application.

This operation is in accordance with the specifications of the multimedia system, and is not a malfunction.

During audio playback on
the multimedia system
(such as FM), if interrupt
audio is output from an
app that is not compatible
with Apple CarPlay(1), the
system does not return to
the original audio source.

This operation is in accordance with the specifications of the multimedia system, and is not a malfunction. Manually change the audio source. Alternatively,
avoid using apps that are not compatible with Apple
CarPlay(1). Some navigation apps are compatible beginning with iOS 12. Update iOS and apps to the
latest versions.

While using Apple CarPlay, the route guidance
arrow and turn-by-turn
navigation are not displayed on the multi-information display.
While using Android Auto,
turn-by-turn navigation is
not displayed on the multiinformation display or the
multimedia system screen.
While using Android Auto,
hands-free call audio cannot be heard from the vehicle's speakers.

140

Depending on specifications with the multi-information display, this operation may not be displayed.

End current call.
Disconnect the USB Type-C cable from the smartphone and try using hands-free calling. Check whether audio can be heard now.

3-3. Using Apple CarPlay and Android Auto
Symptom

Solution

While using Android Auto,
hands-free call audio cannot be heard from the vehicle's speakers.

Increase the volume on the multimedia system and
check whether hands-free call audio can be heard.
Try using another smartphone. Check whether audio
can be heard now.

The phone was connected after Android Auto was
stopped.

This operation is in accordance with the specifications of the multimedia system, and is not a malfunction.

iPhone that are not displayed in the app list on the Apple CarPlay screen.

Related Links
Setting Bluetooth® devices(P. 99)
Connecting a device via the USB Type-C port(P. 38)
Audio system ON/OFF and volume adjustment(P. 34)
Connecting with a Bluetooth® device(P. 112)
Changing sound and media settings(P. 91)
Notes for operating the touch screen(P. 23)

141

Connecting a smartphone or communication device

(1) Apps that are not compatible with Apple CarPlay are the apps installed on an

3

3-3. Using Apple CarPlay and Android Auto

142
