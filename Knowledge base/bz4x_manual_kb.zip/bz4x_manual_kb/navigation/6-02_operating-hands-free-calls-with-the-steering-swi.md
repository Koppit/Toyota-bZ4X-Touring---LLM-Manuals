# 6-2. Operating hands-free calls with the steering switches

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 6 Hands-free calls, pages 218–219

switches

steering

the

with

calls

hands-free

Operating

6-2. Operating hands-free calls with the steering switches

Operating with the steering switches
Some hands-free call functions can be operated from the steering switches,
such as receiving or making calls.
● Operate the switches as neces-

sary.
[

] switch

● While a call cannot be made, dis-

plays the history screen.

● Phone calls can be made when

[
] is displayed on the phone
screen.
● While making a call or during a call,

ends the call.

● While receiving a call or during call waiting, answers the call.

[

] switch
Adjusts the ringtone volume or receiver volume.
Keep raising or lowering to adjust continuously.

[

] switch
Calls can be made using voice command.
To end voice control system, press and hold the talk switch.

INFORMATION
● While Apple CarPlay or Android Auto is connected, press [

] to display
the Apple CarPlay or Android Auto phone screen on the multimedia system.

● While Apple CarPlay and a hands-free phone are connected, press [

] to
display the Apple CarPlay or multimedia system phone screen. The function
that was used last is prioritized. If neither has been used, the primary device
is prioritized.*1

● While Android Auto and a hands-free phone are connected, press [

display the multimedia system phone screen.*1

● When receiving a call, the incoming call screen for the cellular phone

(hands-free phone, Apple CarPlay, or Android Auto) is displayed.*1

Related Links
Precautions when using Apple CarPlay and Android Auto(P. 123)
*1 : This function is not available in some countries or areas.

218

] to

6-2. Operating hands-free calls with the steering switches

Starting voice control(P. 42)

6

Hands-free calls

219
