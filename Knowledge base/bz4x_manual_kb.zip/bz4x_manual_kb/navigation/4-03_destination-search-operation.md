# 4-3. Destination search operation

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 4 Navigation, pages 155–162

operation

search

Destination

4-3. Destination search operation

Searching for a destination
A destination can be searched for and set on the destination search
screen.
1 Touch [

] on the map screen.

2 The destination search screen
will be displayed. Touch the desired search method.
4

● If a destination has already been set, touch [New destination] (set a new

destination) or [Add to route].

● When using Connected navigation, destinations can also be searched for

using content on the cloud.

Related Links
Editing waypoints(P. 169)
Searching for information using the keyboard(P. 48)

155

Navigation

3 The search result list screen is displayed. Touch the item you want
to set as the destination from the list.

4-3. Destination search operation

Destination search screen
A Touch to search using a location

name, address, or phone number.
B Touch to move the text cursor.
C Touch to display a list of all points
registered as a favorites.
This can only be used if a point
has been registered as a favorite.
D Touch to display a list of all points
from the destination history (previously set destinations).
This can only be used if destination history exists.
E Searches for nearby charging stations.
F Touch to display a list of the destinations of the Drive Plan sent in
advance from a smartphone.*1
G Starts a route search with your home as the destination.
If a home is not registered, it can be registered by touching [
].
H If the name of a destination is touched, the full route map screen will be
displayed. Touch [Go] to start route guidance immediately.
Related Links
Searching through character entry(P. 156)
Searching through destination history(P. 158)
Searching through Drive Plan(P. 158)
Setting home as destination(P. 157)
Setting a favorite as the destination(P. 157)
Searching for charging stations(P. 158)

Searching through character entry
A destination can be searched for by entering a location name, address, or
phone number.
1 Touch [

] on the map screen.
2 Touch [Where to? (POI, Street, Town etc.)].
3 Enter the location name, address, phone number, etc. and touch
[Go].
*1 : This function is not available in some countries or areas.

156

4-3. Destination search operation
● Potential destinations are searched for and displayed with each entered char-

acter.

● According to the input characters and based on previously searched for

terms, the destination history, and favorites, predictive search terms will be
displayed.

● If a search does not turn up any results due to a possible typo, a potentially

correct search term will be displayed.

● If the number of input characters exceeds the character limit, the excess

characters will be deleted.

Related Links

4

Entering letters and numbers(P. 27)

1 Touch [

] on the map screen.

2 Touch [

].
3 Move the map to the location you wish to register and touch [OK].

Setting home as destination
1 Touch [

]on the map screen.

2 Touch [

].

Touch [Go] to start route guidance immediately.

Related Links
Favorites settings(P. 87)

Setting a favorite as the destination
1 Touch [
] on the map screen.
2 Touch the desired favorite.
If the name of a destination is touched, the full route map screen will be displayed.
Touch [Go] to start route guidance immediately.

INFORMATION
Registered favorite points can also be searched for by entering their name.

Related Links
Favorites settings(P. 87)

157

Navigation

Setting up home

4-3. Destination search operation

Searching through destination history
1 Touch [
] on the map screen.
2 Touch [Recents].
3 Touch the desired destination from the destination history.
If the name of a destination is touched, the full route map screen will be displayed.
Touch [Go] to start route guidance immediately.

Searching for charging stations
] on the map screen.
1 Touch [
2 Touch [Charging station].
3 Select the desired charging station from the list.
● Nearby charging stations and facility information will be displayed.
● By touching [

], you can filter the types of charging stations, narrow the
search area, and sort the list.

Searching through Drive Plan*1
When a drive plan (destination, departure time, etc.) has been set using
a smartphone, the vehicle navigation system is notified of the drive plan
after entering the vehicle, and a destination can be set by selecting the
registered drive plan.
To use this function, a driver must be registered.
] on the map screen.
1 Touch [
2 Touch [Trips].
3 Touch the desired Drive Plan.
If the name of a destination is touched, the full route map screen will be displayed.
Touch [Go] to start route guidance immediately.

INFORMATION
If the vehicle is parked far from the destination, the destination set in the vehicle navigation system can be sent to the smartphone navigation application.

Related Links
Registering a user profile(P. 50)
*1 : This function is not available in some countries or areas.

158

4-3. Destination search operation

Search result list screen

Search options
The displayed range and order of the search result list can be changed.
] on the search result list screen.
1 Touch [
2 Set search options.
3 Touch [OK] to complete changing settings.

159

4

Navigation

When searching for a destination, if there are multiple search results, a
destination list will be displayed.
A Touch to return to the previous
screen.
B Displays the input characters for
the search.
C Touch to display the search options.
D Displays a list of search results.
Potential destinations within a location will also be displayed.
E Displays the position of the items in the currently displayed list on the
map.
● After scrolling the map, if [Search this area] is touched, a destination
can be searched for within the area scrolled to.

4-3. Destination search operation

Adding a waypoint
If a destination has already been set, new destinations can be added as
waypoints.
● With a destination already set, search for a destination.
A message is displayed when you try to set a destination.
● [New destination] : Delete the currently set destination and begin searching

for a route to the new destination.

● [Add to route] : Add the selected point as a waypoint and begin searching for

a route to the destination.

INFORMATION
● A waypoint can be added by touching any point on the map screen.

● Up to 10 destinations, including waypoints, can be set.

● The most recently added waypoint will be set as the first destination. The

order of the destinations can be changed by editing the waypoints.

Related Links
Searching for a destination(P. 155)
Editing waypoints(P. 169)

160

4-3. Destination search operation

Setting destinations from your smartphone
NaviBridge
NaviBridge*1 is a "Send To Car" app that can easily send destinations
searched for with keyword search and a wide variety of compatible apps on
your smartphone to your vehicle navigation system, and automatically sets
it as the destination for navigation.

4

Navigation

NaviBridge (for iOS/Android) is available for free download.
Refer to the following website for detailed information such as download
methods.
NaviBridge support website: https://navicon.com/navibridge/support

▶ Connection methods:

Connection method

iOS device

Android device

Bluetooth® (Wireless)

○

○

USB (Wired)

△(1)

×

(1) Requires HF connection
*1 : "NaviBridge" is a registered trademark of Micware Co., Ltd.

161

4-3. Destination search operation
▶ Available functions:

Destination setting

Multiple destinations

Map operation

Sharing locations
with friends

○

○

×

×

162
