# 5-7. Bluetooth®audio operation

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 5 Audio, pages 199–203

operation

Bluetooth®audio

5-7. Bluetooth®audio operation

Playing Bluetooth® audio
By connecting a portable device, the portable device can be used without
operating it directly.
INFORMATION
● The following information may not be displayed depending on the connected

portable device.
• Folder title
• Song name
• Album name
• Artist name

• Playback time

5

• Total time

Audio

• Random
• Repeat
• Playback/pause
• Track up/down

● The following issues may occur depending on the connected device.
• Operation cannot be performed from the multimedia system.
• Operation or volume is different.
• The display of data such as song information or time may differ between the

multimedia system and the portable device.

• The connection may disconnect when playback stops.

● When playing for a long time, the sound may skip.

● The volume while connected may differ depending on the portable device.

A portable device can be connected to the multimedia system.
1 Touch [

] from the main menu.
2 Touch [Sources].
3 Touch the device name or [Bluetooth].
4 Operate the Bluetooth® audio that is playing as necessary.
● Operating from the screen

199

5-7. Bluetooth®audio operation

[

] : Performs random playback.
Each touch switches the random setting.*1

[
] : Plays the currently playing track from the beginning. When at the start
of the track, the previous track will play from the beginning.
Touch and hold to fast rewind. Release to start playback from that position.
[

] : Pauses playback.

[

] : Plays.

[

] : Switches the tracks.
Touch and hold to fast forward. Release to start playback from that position.

[

] : Performs repeat playback.
Each touch switches the repeat setting.*1

[

] : Displays the settable items.

Folder names or track names of sub menu : Touch a folder name to select
the folder, and touch a file name to change the playback file.
● Operating with the steering switches

[<]/[>] switches
Switch the tracks.
Press and hold to fast forward or
fast rewind. Release to start playback from that position.

Related Links
Changing sound and media settings(P. 91)
Adjusting the sound of each source(P. 96)
*1 : The order in which random or repeat settings switch depends on the model.

200

5-7. Bluetooth®audio operation

Setting Bluetooth® devices(P. 99)

5

Audio

201

5-7. Bluetooth®audio operation

Precautions for Bluetooth® audio playback
Pay special attention to the following information when using Bluetooth®
audio playback.
INFORMATION
● Registration of the cellular phone or other Bluetooth® portable audio player

(hereafter referred to as portable device) in the multimedia system is required
before use.

● Please be aware that some functions may be limited depending on the model

of portable device.

● This function cannot be used while Apple CarPlay is connected wirelessly in

some countries or areas.

● Using simultaneously with a wireless device could negatively affect communi-

cation for each.

● When the Wi-Fi® function is enabled in the multimedia system settings, the

Bluetooth® audio sound may be interrupted.

WARNING
● For safety reasons, the driver should not operate the portable device while

driving.

● The vehicle antenna for Bluetooth® communication is built into the multimedia

system.

People using electrical medical devices other than implantable cardiac pacemakers, implantable cardiac resynchronization therapy-pacemakers, or implantable cardioverter defibrillators should consult with their physician and the
device manufacturer to determine whether electrical waves could adversely
affect devices before use.

NOTICE
● Do not leave the portable device inside the vehicle. The inside of the vehicle

can become hot, which could cause the portable device to malfunction.

● Do not use a portable device near the multimedia system. Bringing it too close

could cause sound or connection quality to deteriorate.

Related Links
Changing Wi-Fi® settings(P. 97)
Bluetooth®(P. 332)
Precautions when using Bluetooth® devices(P. 104)

202

5-7. Bluetooth®audio operation

Registering a Bluetooth® device from the multimedia system(P. 108)

5

Audio

203
