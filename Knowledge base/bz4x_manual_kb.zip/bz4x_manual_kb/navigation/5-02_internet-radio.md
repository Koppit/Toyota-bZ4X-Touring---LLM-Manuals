# 5-2. Internet radio

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 5 Audio, pages 182–182

radio

Internet

5-2. Internet radio

Using Internet radio*1
Information such as the song name, cover art, and station logo is available
for the track broadcast on the radio while listening to FM/DAB. This information can be retrieved from the Gracenote® server via DCM or Wi-Fi® and
displayed.
When connected to the internet via DCM or Wi-Fi®, the broadcast connection can switch to the internet if the radio signal reception worsens. This
enables continued listening of the same broadcast.
INFORMATION
● Not all broadcasting stations are necessarily supported.

● Internet radio can be received when the radio signal reception deteriorates.

● When using the internet radio, the broadcast switches to the analog broadcast

automatically once the radio signal has been receivable for a certain continuous period.

● Turning the internet radio on and off or changing the switchover between auto-

matic and manual when using internet radio in the settings.

Related Links
Changing sound and media settings(P. 91)

*1 : This function is not available in some countries or areas.

182
