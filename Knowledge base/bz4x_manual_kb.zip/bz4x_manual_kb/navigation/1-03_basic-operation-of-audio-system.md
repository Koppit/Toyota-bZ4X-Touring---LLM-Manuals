# 1-3. Basic operation of audio system

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 1 Basic operation, pages 34–39

system

audio

of

operation

Basic

1-3. Basic operation of audio system

Audio system ON/OFF and volume adjustment
The audio can be turned off when not in use, or the volume can be adjusted
to an appropriate level.
The system can be used when the power switch is in ACC*1 or ON.
INFORMATION
■ When ACC customization is in off
With the power switch turned off, the multimedia system can still be used for
a certain time until the battery-saving function starts operating. To turn off the
multimedia system, perform either of the following actions:
● Press [

VOL] knob.

● Open the driver's door.

NOTICE
● Do not use the multimedia system for extended periods when the EV system is

not running. Doing so may deplete the 12-volt battery.

● Listen to the audio at an appropriate volume that will not interfere with safe

driving.

■ Operating with the audio control knob

Press [
VOL] knob to turn the audio on and off. Turn the knob to adjust
the volume.

*1 : ACC mode can be enabled/disabled on the customize menu. For details, refer

to the vehicle "Owner's manual".

34

1-3. Basic operation of audio system

■ Operating with the steering switches

1

Basic operation

] switch
[
Adjust the audio volume. Keep raising
or lowering to adjust continuously.

35

1-3. Basic operation of audio system

Changing the audio source
Source can be changed to radio, USB, etc.
] from the main menu.
1 Touch [
2 Touch [Sources].
3 Touch the source you wish to
select.

INFORMATION
● If a cellular phone is used inside the vehicle or nearby while listening to

audio, noise may be output from the audio speakers.

● The following functions cannot be used depending on the connection meth-

od for Apple CarPlay.
• iPod

• USB audio or USB video
• Bluetooth® audio
• Miracast®
• Android Auto

● The following functions are not available while connected to Android Auto.
• iPod
• USB audio or USB video
• Apple CarPlay

Changing the source with the steering switch
Changing the source with the steering switch is possible.

36

1-3. Basic operation of audio system

[MODE] switch
The sources will switch in order.
Press and hold to pause or mute.
Press and hold again to cancel.

1

Basic operation

If you change the button layout on the
source selection screen, the switching
order will also change.

Changing the list layout on the source selection screen
The list layout can be changed as desired to make it easier to operate.
● Change the list layout by dragging [
] on the right side of the
source to be relocated.

37

1-3. Basic operation of audio system

Connecting a device via the USB Type-C port
Connect a device such as smartphone or portable player.
● Connect the USB Type-C cable to
the port.
When connecting a USB flash drive,
connect it directly to the USB Type-C
port.

INFORMATION
● Viewing may not be possible, depending on your device.

● When a USB hub is used to connect multiple devices, devices other than the

first device to be recognized cannot be used.*1

● Refer to the instruction manual of the USB Type-C cable and the device to

be connected.

● Use a power source such as the battery supplied with the connected device.

Using the accessory socket installed in the vehicle may cause noise output.
For details about the accessory socket, refer to the "Owner’s manual".

WARNING
● For safety, driver should not operate portable device while driving.

● To prevent device malfunction or burn injuries

Observe the following precautions. Failure to do so may lead to a device
malfunction/damage, or may result in burn injuries due to overheating.
• Do not cover connected devices with cloth etc.
• Do not use damaged harness or a device.
• Do not disassemble, modify, or remove the USB Type-C port.
• Do not apply excessive force or impact to the connected device or cable.

NOTICE
● Do not push down on or subject the connected device to unnecessary pres-

sure. The device or its terminal may be damaged.

*1 : USB flash drive and iPod/iPhone

The USB hub support cannot be guaranteed.

38

1-3. Basic operation of audio system

NOTICE

1

In situations such as the following, the connected device may not be charged
properly:
• When the connected device or cable is damaged

39

Basic operation

● Keep the port free of foreign matter. The device or its port may be damaged.

● Situations in which the connected device may not operate correctly
