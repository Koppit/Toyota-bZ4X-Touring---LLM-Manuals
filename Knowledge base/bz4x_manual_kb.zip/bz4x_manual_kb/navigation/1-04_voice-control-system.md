# 1-4. Voice control system

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 1 Basic operation, pages 40–48

system

control

Voice

1-4. Voice control system

Operating the system with voice control*1
Using the voice control system enables the operation of the navigation
system, audio, hands-free phone calls, and many other features with voice
commands. When using the Toyota Link*1, information that takes advantage of content on the cloud server can be searched.

A Displays voice recognition status.

/

: Waiting for speech
: Listening

: Processing voice recognition
Displays
the response of the system and recognition results as text.
B
C Displays the keyboard screen.
Enables you to search for various information using a keyboard.
D Displays examples of voice commands in a list.
You can check examples of speech frequently used in voice commands by
feature.
E Closes the voice control screen.
F Displays a country name where POI or address is searched.*1

INFORMATION
● The connection status of Toyota Link*1 may be displayed on the screen.

[No online service] : No valid online service contract or a language was
selected in which online services are not available.
[No internet connection] : Not connected to the internet.
● The voice recognition screen will be displayed as a banner while driving.

*1 : This function is not available in some countries or areas.

40

1-4. Voice control system

Related Links

1

Searching for information using the keyboard(P. 48)

Basic operation

Microphones
Microphones are installed on the driver's side and the passenger's side, respectively.

INFORMATION
● Voice controls can be done from the driver seat or passenger seat by activating

the voice control system with wake word. In this case, voice commands from
seats other than the system activating seats are not recognized.

● Some functions are not available for voice control from passenger seat.

Supported languages
This function is compatible with the following languages:
■ Europe
● Local voice recognition support : English, German, French, Spanish,

Italian, Russian, Dutch, Portuguese, Polish, Flemish, Swedish, Turkish,
Czech, Norwegian, Danish, Finnish, Greek, Slovak, Hungarian
● Cloud voice recognition support : English, German, French, Spanish,
Italian, Russian, Dutch, Portuguese, Polish, Flemish, Swedish, Turkish,
Czech, Norwegian, Danish

41

1-4. Voice control system

Starting voice control*1
Voice control can be started by any of the following operations:
■ Press the talk switch

] switch (talk switch) on the
Press [
steering wheel.

■ Say the wake word

Say "Hey Toyota".
● The wake word can be changed on
the settings screen.
● The wake word can be used and
then immediately issue a voice
command.
Example : "Hey Toyota", "Go to nearby coffee shop"
■ Touch the microphone button

Touch [

] on the screen.

INFORMATION
● If the voice control system was activated by the [

] switch on the steering or
microphone button, voice controls from the driver seat can be done.

● The voice control system may not recognize commands if they are not said

clearly. Take note of the following points when using it:

*1 : This function is not available in some countries or areas.

42

1-4. Voice control system
• Speak in a clear voice.

1

• Close the window as commands may not be recognized properly due to
• If the air conditioner blows loudly, commands may not be recognized proper-

ly, so reduce the air volume.

• If music is being played loudly while a command is issued, that command

may not be recognized, so lower the music volume.

• Commands may not be recognized if several people speak at once.

● You can interrupt the voice prompt by saying a voice command.

● You can turn voice prompt on or off on the voice control settings screen.

● You can adjust the system voice volume on the sound and media settings

screen.

Related Links
Changing the voice control settings(P. 69)
Changing sound and media settings(P. 91)

Stopping voice control
Voice control can end with one of the following operations:
● Say "Cancel".
● Touch [

] on the voice control screen.

● Press and hold [

] switch on the steering.

43

Basic operation

noise (wind noise or external noise).

1-4. Voice control system

Speaking a voice command*1
Say a voice command when the voice
control screen appears. The system
can recognize natural speech.

INFORMATION
● Commands may not be recognized if said with an accent or non-standard

phrasing.

● If the voice control system does not recognize aliases or abbreviations when

searching for place names and facilities, say the official name.

● Speaking by including what you want to do, makes it easier for the voice

control system to recognize your command. For example, when searching for
a destination by name, do not say only the name. Instead, say a phrase which
includes a name and a verb, such as "Go to nearby coffee shop".

List of features
This is a list of the main features that can be operated verbally and example voice commands.
The available features differ depending on the vehicle and equipped system.
■ Common commands
Action

Example voice command

Start from the beginning

"Start over"

Stop voice control

"Cancel"

Open hints for voice commands "Help"
Return to the previous screen

"Go back"

Select a list number

"Number one"

Change the list page

"Next page" "Previous page"

■ Destination search

The destination can be set using the locations address, facility name or
category.
*1 : This function is not available in some countries or areas.

44

1-4. Voice control system
Action

Example voice command

Search for a facility

"Find a <POI category/POI name>" "Go to nearby coffee
shop"

1

Return to your home

"Take me home"

■ Navigation operation

The map can be operated and destination can be deleted.
Action

Example voice command

Change the map type

"Change map to 3D"

Changing the map scale

"Zoom in" "Zoom out"

Display the map screen

"Show map"

Check the route information

"What's my ETA?"

Delete the destination

"Delete destination"

Displays the destination history "Show recent destinations"

■ Audio operation

Audio operations, such as radio, USB memory, Bluetooth® audio, can be
performed.
Artist names, album names, song names which are registered to the media
can be specified.
Radio station names can also be specified.
Action

Example voice command

Adjust the volume

"Volume up" "Volume down"

Mute the volume

"Mute audio"

Play next/previous song "Next song" "Previous song"
Specify a song to play*1

"Play <artist>""Play <album>" "Play <song>"

Select a radio station*2

"Tune to <FM frequency>" "Tune to <FM station
name>"

Change the audio source "Change to <audio source>"

*1 : You can play music stored on a device connected via USB.
*2 : This function is not available in some countries or areas.

45

Basic operation

Search for an address "Get directions to <address>"

1-4. Voice control system

■ Hands-free phone operation

Phone calls can be made with a Bluetooth® cellular phone connected to the
vehicle.
The name and phone type, which are registered in the contacts, can be
specified and from there the phone number can be called.
Action

Example voice command

Make a phone call to a contact in your phone
book*1
Make a phone call to a phone number*1
Display the call history*1

"Call <contacts>"
"Call <phone number>"
"Show recent calls"

Send a message*1*2

"Send message to <contact
name>"

Read out a message*1

"Read message"

Display the Bluetooth® connection screen

"Show Bluetooth Settings"

■ Information search service*3*4

Using online service and searching information can be done.
Action

Example voice command

Check the weather information "Tell me the weather today"

■ Climate control

Air conditioner temperature and fan speed can be operated.
Action

Example voice command

Turn the air conditioning on
or off

"Turn on the air conditioner" "Turn off the air conditioner"

Adjust the air conditioner
temperature

"Turn up the temperature" "Turn down the temperature" "Set the temperate to 25 degrees"

Adjust the air conditioner fan "Turn the fan speed up" "Turn the fan speed down "
speed
"Set the fan speed to 3"

■ Vehicle device control*1*3*4

Vehicle functions such opening and closing the windows can be operated.
*1 : Voice commands from the passenger’s seat are not recognized.
*2 : The new message function is available only for SMS. The reply to message

function is available for SMS and MMS.
*3 : If equipped
*4 : Toyota Link contract is required.

46

1-4. Voice control system
Action

Example voice command

Open or close the window

"Open all windows" "Close all windows" "Open
driver side window" "Close driver side window"

1

Display the odometer

"Show odometer"

Display Trip Meter A

"Show Trip A"

Display the camera view*1

"Show side camera view" "Show wide front
camera" "Show moving camera"

Change the camera view*1

"Change camera view"

■ Vehicle information

Information, such as cruising range can be checked.
Action

Example voice command

Check the cruising range "What's my cruising range?"
Check the average speed "What's my average speed?"

■ Verbal response to displayed notifications

Verbal responses can be made to incoming phone calls and receiving messages. Settings related to verbal responses can be changed on the voice
settings screen.
Related Links
Changing the voice control settings(P. 69)

*1 : If equipped

47

Basic operation

Turn on the front windshield wip"Turn on the front wiper"
er

1-4. Voice control system

Searching for information using the keyboard
Various information can be searched by using the keyboard.
1 Touch [

Keyboard search].

If search history exists, the history
screen will appear, enabling you to select from the history.

2 Select the category that you
want to search.
[Navigation] : Enter an address, facility name, phone number, area, road
name, intersection, etc.
[Media] : Enter an album, artist, song
name, playlist, genre, radio station,
etc.
[Phone] : Enter a name, phone number, or something else registered in the
phone book.
[Vehicle] : Enter a vehicle information that you want to display.
[Settings] : Enter the setting that you want to configure, such as audio, phone,
and navigation.

3 Enter the search keyword and
touch [Go].

4 When the list of search results is displayed, touch the desired item.
INFORMATION
● Operation of the screen is restricted while the vehicle is moving.

● Search is not available when you are connected to Apple CarPlay/Android

Auto.

48
