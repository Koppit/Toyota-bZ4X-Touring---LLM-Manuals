# 6-5. In-call operations

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 6 Hands-free calls, pages 229–234

operations

In-call

6-5. In-call operations

Perform operations from the call screen
During a call, various operations can be performed from the call screen.
[
] : Mutes the sound transmission
so that the other party on the call cannot hear you speak. While muted, the
button changes to blue.
To deactivate, touch the button
again.
● You can hear what the other party
is saying.
[
] : Displays the keypad screen. The call screen will be displayed as
small while the keypad screen is displayed.
[

] : Hang up during a call.

[
] : Allows a call to be switched between the cellular phone and the
multimedia system. During a cellular phone call, the button changes to
blue.
[

] : Cancel the pending call. Only displayed on hold.

[

] : Reduce the call screen.

[

] : Display the call screen in the main area.

[

] : Displays the option screen.
The following operations can be performed on the option screen.
● [Transmit] : Adjusts the transmission volume.
Changing the transmission volume may cause the sound quality to deteriorate.
● [Navigation] : Turn on or off to interrupt the navigation system voice
guidance during a phone call.

229

6

Hands-free calls

[
] : Display the contact list in the submenu to make a call to another
person.
● You can make a call to another person by touching the phone number
during a call to make a call.

6-5. In-call operations
● [On hold] : Temporarily puts the call on hold.

Turn off [On hold] to deactivate.
Depending on the model of cellular phone, it may not be possible to
put calls on hold.
●[

] : Returns to the call screen. If the call screen is returned to while
a call is on hold, the held call can be released by displaying the option
screen again.
INFORMATION

● Depending on the state of the multimedia system, the call screen may be

reduced or not displayed.

● Switching calls may not be possible depending on the cellular phone model.

● Calls cannot be switched from the hands-free system to the cellular phone

while driving.

● If the cellular phone you are talking on is connected to the multimedia system

as a hands-free phone, the call screen is displayed. Depending on the model of
cellular phone, the call will either continue on the cellular phone or switch to a
call on the multimedia system.

● If you operate the power switch during a call with a hands-free phone, the

call may be disconnected or continued on the cellular phone depending on the
cellular phone model. If you want to continue on your cellular phone, you may
need to operate your cellular phone.

Related Links
Operating with the steering switches(P. 218)
Changing sound and media settings(P. 91)

230

6-5. In-call operations

Answering a second call
If you receive a second call from another party during an ongoing call, callwaiting can be used to handle both calls. When a second call is received,
an incoming call notification is displayed at the top of the screen.
INFORMATION
● You must have a call waiting contract with your cellular phone provider.

● If the cellular phone does not support HFP Ver. 1.5 or later, call-waiting will not

be available.

● Depending on the cellular phone model and subscription details, it may not be

possible to use this function.

● When receiving a second call,

touch [

] on the screen, or

press the [
steering.

] switch on the
6

Hands-free calls

Answering the second call places the
previous call on hold.
The caller will be switched each time
[Swap calls] is touched.

Related Links
Operating with the steering switches(P. 218)

Declining second calls
When a second call is received during another call, the call waiting call can
be declined.
When receiving a second call, touch [

].

INFORMATION
Depending on the model of cellular phone, both calls may be disconnected. Refer
to the instruction manual included with the cellular phone.

Related Links
Operating with the steering switches(P. 218)

231

6-5. In-call operations

Making a call to another party during an ongoing call
You can call a new third party during an ongoing call.
1 Touch [

] on the call screen.

2 Select the contact.
3 Select the phone number.
This function puts the other party on
hold during a call.

INFORMATION
● You must have a call waiting contract with your cellular phone provider.

● If the cellular phone does not support HFP Ver. 1.5 or later, call-waiting will

not be available.

● Depending on the cellular phone model and subscription details, it may not

be possible to use this function.

232

6-5. In-call operations

Making conference calls
Add the person on hold when talking to another party while a call is on
hold.
● Touch [Merge calls] during an ongoing call with a third party.
Calls on hold are taken off hold and switched to a conference call.

INFORMATION
● A subscription for conference calls may be needed to be purchased from

your cellular phone provider.

● Depending on the cellular phone model and subscription details, it may not

be possible to use this function.

● When the conference call ends, the call ends with all members of the confer-

ence call.

6

Hands-free calls

233

6-5. In-call operations

Ending calls
Several methods are available for ending a hands-free call.
● Perform any of the following operations during a call.
● Press the [

] switch on the steering.

If the switch is pressed and held, all calls will be ended, including calls on hold.
● Touch [

] while making a call or on the call screen.

● Operate the cellular phone to end the call.

Related Links
Operating with the steering switches(P. 218)

234
