# 3-1. Using the Bluetooth® function

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 3 Connecting a smartphone or communication device, pages 104–117

Bluetooth®function

the

Using

3-1. Using the Bluetooth® function

Precautions when using Bluetooth® devices
Pay special attention to the following information when using a Bluetooth®
device on the multimedia system.
INFORMATION
● The vehicle uses Bluetooth® communications on the 2.4GHz frequency band.

Performance may vary depending on various factors.

● Simultaneous use of Wi-Fi® using the same 2.4GHz band wireless communica-

tion as Bluetooth® could cause mutual interference.

● Mutual interference between Bluetooth® and Wi-Fi® could cause issues such

as garbled video, audio skipping, or reduced communication speed. The effect
of interference will be reduced if a Bluetooth® device is connected. If a Bluetooth® device has been registered, connecting with the registered device could
improve this issue. (The connection of a Bluetooth® device can be checked
with by the status icon on the multimedia system screen.)

● Using a Bluetooth® cellular phone simultaneously with a wireless device could

negatively affect communication for each.

● The Bluetooth® function cannot be used by the multimedia system while Apple

CarPlay is connected wirelessly in some countries or areas.

● Wi-Fi® functions (Wi-Fi® and Miracast®) use the same 2.4GHz band for wire-

less communication. Using a Bluetooth® device simultaneously could negatively affect communication for each. Turning off the Wi-Fi® function will allow for
use without issue.

● When a Bluetooth® device is connected via Bluetooth®, its battery will be

consumed more quickly than normal.

● Bluetooth® connections will be disconnected during emergency calls. Any dis-

connected Bluetooth® devices will be reconnected once the emergency call is
finished.

WARNING
● For safety, the driver should not operate the cellular phone itself while driving

when using hands-free calling.

● Stop the vehicle in a safe location prior to calling. If a call is received while

driving, be sure to drive safely and keep the call short.

NOTICE
● Do not use a Bluetooth® device near the multimedia system. Coming too close

could worsen sound quality or the connection.

104

3-1. Using the Bluetooth® function

NOTICE
● Do not leave a cellular phone inside the vehicle. The inside of the vehicle can

become hot, which could cause the cellular phone to malfunction.

■ Users with pacemakers or other electrical medical devices

Observe the following precautions with regard to radio waves during Bluetooth® communication.

● The vehicle antenna for Bluetooth® communication is built into the multimedia

system.

● People with implantable cardiac pacemakers, cardiac resynchronization thera-

py-pacemakers or implantable cardioverter defibrillators should maintain a reasonable distance between themselves and the Bluetooth® antennas. The radio
waves may affect the operation of such devices.

● Before using Bluetooth® devices, users of any electrical medical device other

than implantable cardiac pacemakers, cardiac resynchronization therapy-pacemakers or implantable cardioverter defibrillators should consult the manufacturer of the device for information about its operation under the influence of radio
waves. Radio waves could have unexpected effects on the operation of such
medical devices.

■ When used simultaneously with Bluetooth® audio
● The following behaviors will occur if a Bluetooth®-compatible device

(cellular phone) is used hands-free and simultaneously with Bluetooth®
audio.
• The Bluetooth® connection of the cellular phone may be disconnected.
• There is possibility that background noise may exist during a hands-free

phone call.

• Hands-free call operation may lag.
● Audio may skip if the communication device selected for hands-free call-

ing is changed during Bluetooth® audio playback.
● The portable device connection may be disconnected when transferring
contact data. It will be reconnected once transfer is complete. (Reconnection may not be possible for some models)
● It may not be possible to make both a hands-free connection and audio
connection, even for cellular phones that support both hands-free connections and audio connections.

105

Connecting a smartphone or communication device

WARNING

3

3-1. Using the Bluetooth® function
● For a list of specific devices which operation has been confirmed on this

system, check with any authorized Toyota retailer or Toyota authorized
repairer, or any reliable repairer.
Related Links

Precautions when using Wi-Fi® devices(P. 118)
Precautions for Bluetooth® audio playback(P. 202)
Precautions for hands-free calling(P. 210)
Precautions for playback of Miracast®(P. 207)
Status icons(P. 20)

106

3-1. Using the Bluetooth® function

Bluetooth® specifications and compatible profiles
The multimedia system supports the following specifications and compatible profiles. Operation is not guaranteed for all Bluetooth® devices.
■ Supported Bluetooth® specifications

Bluetooth® Core Specification Ver.5.0
■ Compatible profiles

3

● HFP (Hands Free Profile)

Supported versions: Ver.1.4.2
This is a profile to use phone message functions.
● SPP (Serial Port Profile)
Supported versions: Ver.1.2
• Profile for converting Bluetooth®-equipped devices as virtual serial ports
• Profile for linking smartphones
● A2DP (Advanced Audio Distribution Profile)

Supported versions: Ver.1.3.2
This is a profile to transmit stereo audio or high quality sound to the
audio system.
● AVRCP (Audio/Video Remote Control Profile)
Supported versions: Ver.1.6.2
Profile for controlling audio remotely

107

Connecting a smartphone or communication device

Supported versions: Ver.1.7.2
This is a profile to allow hands-free phone calls using a cellular phone. It
has outgoing and incoming call functions.
● PBAP (Phone Book Access Profile)
Supported versions: Ver.1.2.3
Profile for synchronizing data such as contact data and call history
● OPP (Object Push Profile)
Supported versions: Ver.1.2.1
Profile for transferring contact data
● MAP (Message Access Profile)

3-1. Using the Bluetooth® function

Registering a Bluetooth® device from the multimedia system
A cellular phone or portable device must be registered in order to use
hands-free calling or Bluetooth® audio. Once registration is complete, Bluetooth® will automatically be connected each time the multimedia system is
started.
When Apple CarPlay/Android Auto is connected, the device will be automatically registered.
If no Bluetooth® device is connected, the registration screen can also be
displayed by pressing and holding the [

] switch on the steering wheel.

INFORMATION
● A cellular phone can be registered as both a hands-free phone and Bluetooth®

audio device.

● Up to 5 Bluetooth® devices can be registered. However, a maximum of 2

devices can be used as a hands-free phone. (Setting of a driver is required to
connect 2 hands-free phones.)*1

● Refer to the Bluetooth® device’s instruction manual for information on how to

operate the Bluetooth® device.

● Registration will need to be repeated once for each Bluetooth® device if multi-

ple Bluetooth® devices will be used.

● A PIN code is a verification code used when registering a Bluetooth® device to

the multimedia system.

● Dialing may be locked out after connecting, depending on the cellular phone

settings. Cancel the auto lock function on the cellular phone before use.

● If another device is registered while connected to a cellular phone or portable

device, the connection to the portable device or cellular phone playing audio
will be disconnected.

● Miracast® audio may skip if a Bluetooth® device is registered while using Mira-

cast®.

● For safety reasons, devices cannot be registered while driving.
● If Bluetooth® device registration cannot be completed, restart the Bluetooth®

device.

] from the main menu.
1 Touch [
2 Touch [Bluetooth & Devices].
If no device is registered, proceed to Procedure 4.

3 Touch [Add another device].
*1 : This function is not available in some countries or areas.

108

3-1. Using the Bluetooth® function
While a device is connected to the multimedia system, the confirmation screen
for disconnecting the device may be displayed. Disconnect the device to perform
registration.

4 Touch [If not found].

3

● The Bluetooth® address may be displayed instead of the device name.

● If the device to register is not displayed in the main area, try registering from

the Bluetooth® device.

● Certain models of Bluetooth® devices may not be displayed in the device list,

unless a certain screen is displayed on the Bluetooth® device. Refer to the
Bluetooth® device’s instruction manual for details.

6 Check that the displayed PIN code matches the PIN code displayed
on the Bluetooth® device, and then touch [OK].
● Some Bluetooth® devices may need to be operated to complete registration.
● When an HFP supported Bluetooth® device is registered, that device is auto-

matically set as the main device if the driver does not have a main device
set.*1

● The Apple CarPlay settings may be displayed. The Apple CarPlay screen will

be displayed if the use of either is enabled.

● A message indicating that connection is complete is displayed, and the name

of the registered Bluetooth® device is displayed in the submenu.

● If an operation failed screen is displayed, follow the operation instructions on

the screen.

Related Links
Registering a user profile(P. 50)
Changing and registering a user profile(P. 58)
Precautions when using Apple CarPlay and Android Auto(P. 123)

*1 : This function is not available in some countries or areas.

109

Connecting a smartphone or communication device

5 Touch the device to register from the main area.

3-1. Using the Bluetooth® function

Registering from a Bluetooth® device
If the Bluetooth® device cannot be found by searching with the multimedia
system, register by searching for the multimedia system from the Bluetooth® device.
] from the main menu.
1 Touch [
2 Touch [Bluetooth & Devices].
3 Touch [Add another device].
While a device is connected to the multimedia system, the confirmation screen
for disconnecting the device may be displayed. Disconnect the device to perform
registration.

4 Register the multimedia system
from the Bluetooth® device to
be used.
● Perform the operation according to

the operating procedure of the Bluetooth® device.

● Be sure to display this Bluetooth®

connection screen before performing registration on the Bluetooth®
device.

5 Check that the displayed PIN code matches the PIN code displayed
on the Bluetooth® device, and then touch [OK].
● Some Bluetooth® devices may need to be operated to complete registration.
● When an HFP supported Bluetooth® device is registered, that device is auto-

matically set as the main device if the driver does not have a main device
set.*1

● The Apple CarPlay settings may be displayed. The Apple CarPlay screen will

be displayed if the use of either is enabled.

● A message indicating that connection is complete is displayed, and the name

of the registered Bluetooth® device is displayed in the submenu.

● If an operation failed screen is displayed, follow the operation instructions on

the screen.

Related Links
Registering a user profile(P. 50)
Changing and registering a user profile(P. 58)
Precautions when using Apple CarPlay and Android Auto(P. 123)
*1 : This function is not available in some countries or areas.

110

3-1. Using the Bluetooth® function

Deleting a registered Bluetooth® device
Registered Bluetooth® devices can be deleted.
1 Touch [

] from the main menu.
2 Touch [Bluetooth & Devices].
3 Touch the Bluetooth® device to
be deleted from the submenu.

3

4 Touch [Forget].

5 Touch [Forget].
INFORMATION
● A registered cellular phone cannot be deleted during an emergency call.

● It may not be possible to delete on the first try, depending on the status of

the Bluetooth® device.

Related Links
Setting a Bluetooth® device as a primary device(P. 116)
Registering a user profile(P. 50)
Changing and registering a user profile(P. 58)

*1 : This function is not available in some countries or areas.

111

Connecting a smartphone or communication device

A device that has been set as the primary device of another user cannot be
deleted.*1

3-1. Using the Bluetooth® function

Connecting with a Bluetooth® device
Connection with a Bluetooth® device is required to use various function of
the multimedia system. There are two connection methods, automatic and
manual.
INFORMATION
● Refer to the Bluetooth® device's instruction manual for information on how to

operate the Bluetooth® device.

● If multimedia system behavior is unstable when connecting a cellular phone,

end the call and try connecting again.

● A connection cannot be made if Bluetooth® on the Bluetooth® device is not

turned on.

● When connection of the Bluetooth® device is completed, it will be displayed at

the top of the screen.

● While the Bluetooth® device is connected, the Bluetooth® connection status

icon is displayed.

● The display area may illuminate and stay on while the power switch is turned

on, depending on the model of cellular phone. If this occurs, turn illumination
off on the cellular phone. (For information on setting, refer to the cellular phone
instruction manual)

● The Bluetooth® function cannot be used on the device connected as Apple

CarPlay.

● The Bluetooth® function cannot be used by the multimedia system while Apple

CarPlay is connected wirelessly in some countries or areas.

● The Bluetooth® function except the hands-free function cannot be used on the

device connected as Android Auto.

● Miracast® audio may skip if a Bluetooth® device is connected while using

Miracast®.

■ Bluetooth® reconnection

If a Bluetooth® connection that was once established is disconnected while
the power switch is turned on, a reconnection will be automatically attempted.
■ Number of Bluetooth® device connections
● When a driver is set*1

Up to two hands-free phones and one audio device will be connected
automatically. (The hands-free phone and audio device can also be set
as the same device.)
*1 : This function is not available in some countries or areas.

112

3-1. Using the Bluetooth® function
● When a driver is not set

Up to one hands-free phone and one audio device will be connected
automatically. (The hands-free phone and audio device can also be set
as the same device.)
INFORMATION
● Try connecting manually if reconnection fails.

3

● If Apple CarPlay is connected, you may not be able to reconnect the Blue-

Related Links
Status icons(P. 20)
Registering a user profile(P. 50)
Changing and registering a user profile(P. 58)
Manually connecting Bluetooth® devices(P. 114)

Automatically connecting Bluetooth® devices
The multimedia system will automatically connect to Bluetooth® devices in
the set priority order each time the power switch is turned from off to on.
● When a driver is set*1

Automatically connects in order of the primary device, secondary device,
and then devices in order of most recent connection.
Up to two hands-free phones and one audio device will be connected
automatically. (The hands-free phone and audio device can also be set
as the same device.)
● When a driver is not set
Automatically connects in order of most recent connection.
Up to one hands-free phone and one audio device will be connected
automatically. (The hands-free phone and audio device can also be set
as the same device.)
INFORMATION
● Try connecting manually if reconnection fails.
● The Bluetooth® device may need to be operated, depending on the model of

Bluetooth® device.

*1 : This function is not available in some countries or areas.

113

Connecting a smartphone or communication device

tooth® connection.

3-1. Using the Bluetooth® function
● Devices that were manually disconnected such as by touching the [Discon-

nect] button will not be automatically reconnected.

Related Links
Setting a Bluetooth® device as a primary device(P. 116)
Setting a Bluetooth® device as a secondary device(P. 117)
Registering a user profile(P. 50)
Changing and registering a user profile(P. 58)

Manually connecting Bluetooth® devices
In order to connect another Bluetooth® device, or if automatic connection
fails, it is possible to connect to registered Bluetooth® devices.
1 Touch [

] from the main menu.
2 Touch [Bluetooth & Devices] on the submenu.
The device search screen will display on the multimedia system if no Bluetooth®
devices are registered. Register the Bluetooth® device.

3 Touch the Bluetooth® device to connect to on the submenu.
If the Bluetooth® device to connect to is not listed in the submenu, register the
Bluetooth® device.

4 Turn on the function (phone, audio, etc.) that you want to connect from the main area.
A confirmation screen may be displayed if another device is already
connected.

INFORMATION
It may not be possible to connect on the first try, depending on the status of the
Bluetooth® device. If this occurs, try connecting again after a while.

Related Links
Registering a Bluetooth® device from the multimedia system(P. 108)

114

3-1. Using the Bluetooth® function

Disconnecting Bluetooth® devices
Connected Bluetooth® devices can be disconnected from the multimedia
system.
] from the main menu.
1 Touch [
2 Touch [Bluetooth & Devices] on the submenu.

115

3

Connecting a smartphone or communication device

3 Touch the Bluetooth® device to be disconnected on the submenu.
4 Touch [Disconnect] from the
main area.

3-1. Using the Bluetooth® function

Setting a Bluetooth® device as a primary device*1
Setting a Bluetooth® device as the primary device makes it the first to be
connected during automatic connection.
● A Bluetooth® device that supports HFP must be connected to the multi-

media system.
● Registration of a driver is required to set a device as the primary device.
INFORMATION
A Bluetooth® device set as the primary device of another user cannot be set as
the primary device.

1 Touch [
] from the main menu.
2 Touch [Personal info].
3 Touch [Link devices] or [Change
link devices] from the main area.
The device search screen will be displayed if there is no Bluetooth® device
that can be set as the primary device.
Search for the Bluetooth® device to set
and newly register it to the multimedia
system. After the device is newly registered, it can be set as the primary
device.

4 Select the Bluetooth® device to be set as the primary device.
Disconnect the currently connected Bluetooth® device, then connect the primary
device and secondary device.

Related Links
Automatically connecting Bluetooth® devices(P. 113)
Setting Bluetooth® devices(P. 99)
Registering a user profile(P. 50)
Changing and registering a user profile(P. 58)
Registering a Bluetooth® device from the multimedia system(P. 108)

*1 : This function is not available in some countries or areas.

116

3-1. Using the Bluetooth® function

Setting a Bluetooth® device as a secondary device*1
By setting a Bluetooth® device as a secondary device, it will be recognized
as a secondary device when connected.
● The same Bluetooth® device cannot be set as a primary device and

secondary device for a driver.

● A Bluetooth® device that supports HFP must be connected to the multi-

1 Touch [
] from the main menu.
2 Touch [Bluetooth & Devices] on the submenu.
The device search screen will display if no Bluetooth® devices are registered.
Register a Bluetooth® device.

3 Touch the Bluetooth® device to be set as the secondary device.
If the Bluetooth® device to be set is not listed, register the Bluetooth® device.

4 Touch [Set as secondary device]
from the main area.
This will change to [Remove secondary device setting] if the device is
already set as a secondary device.

Related Links
Automatically connecting Bluetooth® devices(P. 113)
Setting Bluetooth® devices(P. 99)
Registering a user profile(P. 50)
Changing and registering a user profile(P. 58)

*1 : This function is not available in some countries or areas.

117

3

Connecting a smartphone or communication device

media system.
● Registration of a driver is required to set a device as the secondary
device.
