# 5-5. Apple CarPlay operation

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 5 Audio, pages 193–195

operation

CarPlay

Apple

5-5. Apple CarPlay operation

Playing Apple CarPlay
Play music files on an iPhone connected to the USB Type-C port or a
wirelessly connected iPhone. When Apple CarPlay is connected, a button
with the device's name is displayed on the source selection screen. This
may not be displayed for some devices.
INFORMATION
● Some operations may not be available or they may operate differently, depend-

ing on the generation and model of iPhone that is connected.

● In cases such as the track not playing normally or audio skipping, update iOS

to the latest version. Updating may resolve the issues.

Connect Apple CarPlay.

5

1 Touch [

Audio

] from the main menu.
2 Touch [Sources].
3 Touch [Apple CarPlay] (device name).
4 Operate the Apple CarPlay that is playing as necessary.
● Operating from the screen

[

] : Performs shuffle playback.
Each touch switches the shuffle setting.*1

[

] : Plays the currently playing track from the beginning.
When at the start of the track, the previous track will play from the beginning.
Touch and hold to fast rewind. Release to start playback from that position.

[

] : Pauses playback.

[

] : Plays.

[

] : Switches the tracks.
Touch and hold to fast forward. Release to start playback from that position.

*1 : The order in which shuffle or repeat settings switch depends on the connected

device.

193

5-5. Apple CarPlay operation
[

] : Performs repeat playback.
Each touch during repeat playback switches the repeat setting.*1

[

] : Displays the settable items.

[Open CarPlay] : Displays the Apple CarPlay screen.
● Operating with the steering switches

[<]/[>] switches
Switch the tracks.
Press and hold to fast forward or
fast rewind. Release to start playback from that position.

Related Links
Changing sound and media settings(P. 91)
Adjusting the sound of each source(P. 96)
Using Apple CarPlay with an unregistered smartphone(P. 126)
Using Apple CarPlay with a registered smartphone(P. 129)
Setting Bluetooth® devices(P. 99)

*1 : The order in which shuffle or repeat settings switch depends on the connected

device.

194

5-5. Apple CarPlay operation

Precautions for playback of Apple CarPlay
Pay special attention to the following information about playing Apple CarPlay.
This function is not available in some countries or areas.
INFORMATION
● This function cannot be used while Android Auto is connected.

● Disconnecting a connected device while Apple CarPlay is connected via USB

may cause noise to be output.

● When a different source is switched to Apple CarPlay while an iPhone is con-

nected, playback will be started from the previously played track.

5

WARNING

Audio

For safety reasons, the driver should not operate the iPhone while driving.

NOTICE
● Do not leave the iPhone inside the vehicle. The inside of the vehicle can

become hot, which could cause the iPhone to malfunction.

● Do not push down on or subject the connected iPhone to unnecessary pres-

sure. The iPhone or port may be damaged.

● Keep the port free of foreign matter. The iPhone or port may be damaged.

Related Links
Precautions when using Apple CarPlay and Android Auto(P. 123)

195
