# 2-5. Screen settings

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 67–68

settings

Screen

2-5. Screen settings

Changing the screen display settings
The screen contrast and brightness can be adjusted.
] from the main menu.
1 Touch [
2 Touch [Display] on the submenu.
3 Select the desired item.

2

Settings and registration

● [Screen]

Setting

[Display]

Description
Set whether to turn the screen display on or off. If the screen is turned
off, nothing will be displayed on the
screen and only audio will be played.
To display the screen again, touch
the screen and touch the button in
the center of the screen.

"Mode"

[Automatic]

The screen can automatically be
changed between daytime mode and
nighttime mode when the headlights
illuminate or turn off.

[Daytime (light)]

When [Automatic] is turned off, the
screen can be changed to daytime
mode manually.

[Nighttime (dark)]

When [Automatic] is turned off, the
screen can be changed to nighttime
mode manually.

[Brightness]

Adjust the screen brightness.

[Contrast]

Adjust the strength of the screen
contrast.

● [Camera]

67

2-5. Screen settings
Setting

Description

"Camera screen"
[Brightness]

Adjust the camera screen brightness.

[Contrast]

Adjust the strength of the camera
screen contrast.

INFORMATION
● For details of how to adjust the audio image quality, see “Adjusting the

image quality”(→ P.95).

● Even if the screen is turned off, the GPS will continue to track the vehicle’s

current location.

● When the screen is turned off
• When the screen is off, if the screen is touched, the air conditioning

system can be operated.

• If the screen is touched while the screen display is off, the release button

will be displayed in the center of the screen. To display the screen, touch
the release button. If there is no operation for 3 seconds, the screen
display will turn off again.

• Even if the screen display is off, the screen may be displayed temporarily,

such as when you press the [
] switch (talk switch) on the steering
wheel or when the shift position is set to "R".

68
