# 2-4. General settings

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 64–66

settings

General

2-4. General settings

Changing general multimedia system settings
The time settings, display language, and other general multimedia system
settings can be changed.
] from the main menu.
1 Touch [
2 Touch [General] on the submenu.
3 Select the desired item.

● [Accessibility]

Setting

Description

[Reduce animation]

Reduce the animations displayed
when changing screens.

[Screen beep]

Turn the sound that is made when
you touch the screen on or off.

[Screen sensitivity]

Adjust the screen touch sensitivity.

● [Date & Time]

Setting

[Set automatically]

Description
Use GPS information and map data
to automatically set the time. Turning
this setting off will enable you to set
the time and time zone manually.

"Time"

64

[24-hour time]

Change between 24-hour and 12hour time display.

[Time zone]

When [Set automatically] is turned
off, you can set the time zone.

[Daylight savings]

When [Set automatically] is turned
off, you can set summer time to [Auto], [On], or [Off].

2-4. General settings
Setting

Description

[Set time manually]

When [Set time automatically] is
turned off, you can manually set the
time.

"Date"
Change the date display format. (MM/DD/YYYY, DD/MM/YYYY,
YYYY/MM/DD, etc.)

[Format]
● [Keyboard]

Setting

Description

"History"
[Memorise keyboard]

Enable the system to learn the keyboard input results.

[Delete keyboard history]

Delete the keyboard text learning history.

[Delete search history]

Delete the keyboard search history.

● [Language & Units]

Setting

Description

[Language]

Change languages. Both the language displayed on the screen and
system voice language change.

[System language](1)

Change the language displayed on
the screen.

[Voice language](1)

Change the system voice language.

"Measurements"
[Set automatically]

Automatically sets the display units
for distance, and so on based on the
country information.

[Trip info. unit]

When [Set automatically] is turned
off, you can manually set the display
unit.

65

2

Settings and registration

[Set time automatically]

When [Set automatically] is turned
off, you can decide whether to set
the time automatically using GPS.
Turning this setting off will enable
you to set the time manually.

2-4. General settings
Setting
[Tyre pressure]

Description
When [Set automatically] is turned
off, you can manually set the tire
pressure display unit.

(1) This function is not available in some languages.

INFORMATION
Set the Apple CarPlay/Android Auto language using the connected device.

66
