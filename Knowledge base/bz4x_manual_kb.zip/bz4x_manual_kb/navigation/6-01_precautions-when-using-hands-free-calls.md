# 6-1. Precautions when using hands-free calls

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 6 Hands-free calls, pages 210–217

calls

hands-free

using

when

Precautions

6-1. Precautions when using hands-free calls

Precautions for hands-free calling
By connecting a Bluetooth® cellular phone (hereafter referred to as "cellular
phone") that has been verified with the system, the phone function can be
used to make and receive calls without operating the cellular phone directly.
This is known as hands-free calling.
A cellular phone must support the multimedia system specifications in order
to connect to the system. However, be aware that some functions may be
limited depending on the model of cellular phone.
Even while connected to Apple CarPlay or Android Auto, the hands-free
phone screen for Apple CarPlay or Android Auto may not be displayed,
depending on conditions.
INFORMATION
● Observe the following precautions when using the cellular phone with the

hands-free function.

• A cellular phone must be registered to the multimedia system and connected

with Bluetooth® before hands-free calling can be used. To use hands-free
calling, first register a cellular phone.

• Make sure the cellular phone is able to utilize the Bluetooth® function.
• If attempting to make or receive a call during Bluetooth® audio playback, the

screen display and dial tone or ringtone sound may be delayed.

● The multimedia system is not guaranteed to operate with all Bluetooth® devi-

ces.

The following issues may occur depending on the cellular phone model.
• When the power switch is operated during a hands-free call, the call may be

disconnected.

• The calling screen may not be displayed, or the call screen may be dis-

played before the other party answers the phone.

• Even if numbers are entered using the numeric keypad on the call screen,

the tone signal may not be transmitted depending on the cellular phone
service provider.

• After dialing, it may be necessary to perform operations on the cellular

phone.

● Hands-free calling may be unavailable in the following situations.
• When outside of the calling area
• When outgoing calls are restricted, such as when the lines are congested
• During emergency calls
• While contact data is being transferred from the cellular phone

210

6-1. Precautions when using hands-free calls
• When dial lock is turned on for the cellular phone
• When the cellular phone is in use, such as when transmitting data
• When the cellular phone is malfunctioning
• When the cellular phone is not connected
• When the cellular phone has a low battery
• When the cellular phone is turned off
• When the settings prevent the cellular phone from being used for hands-free

calls

• When switching from data communication or contact transfer to hands-free

calling with the multimedia system. (While switching, Bluetooth® connection
status for the multimedia system will not be displayed)

• When the cellular phone itself cannot be used for any other reason
● If hands-free calling and the Wi-Fi® function (Wi-Fi® or Miracast®) are used

simultaneously, the Bluetooth® connection of the cellular phone may be disconnected.

● The driver should operate mobile devices in hands free mode only.

Failure to follow this warning will lead to driver distraction which can cause
personal injury or death.
● The driver is solely responsible for the safe operation of the vehicle.

● People with implantable cardiac pacemakers, cardiac resynchronization thera-

py-pacemakers or implantable cardioverter defibrillators should maintain a reasonable distance between themselves and the Bluetooth® antennas. The radio
waves may affect the operation of such devices.

● Before using Bluetooth® devices, users of any electrical medical device other

than implantable cardiac pacemakers, cardiac resynchronization therapy-pacemakers or implantable cardioverter defibrillators should consult the manufacturer of the device for information about its operation under the influence of radio
waves. Radio waves could have unexpected effects on the operation of such
medical devices.

NOTICE
Do not leave a cellular phone inside the vehicle. The inside of the vehicle can
become hot, which could cause the cellular phone to malfunction.

Related Links
Precautions when using Bluetooth® devices(P. 104)

211

Hands-free calls

WARNING

6

6-1. Precautions when using hands-free calls

Bluetooth® specifications and compatible profiles(P. 107)
Registering a Bluetooth® device from the multimedia system(P. 108)

Precautions for call audio
In a hands-free call, the car's built-in microphone can be used to speak.
Pay special attention to the following information when making a handsfree call.
● The audio when receiving calls or
when talking during calls is output
from speakers on both sides of the
front seats.
● The audio is muted when a voice or
ringtone is output from the handsfree system.

INFORMATION
● During calls, take turns speaking with the other party on the phone. If both

parties speak at the same time, it may be difficult to hear what the other party is
saying.

● If the receiver volume is too high, the other party's voice may be audible

outside the vehicle or echoes may be heard.

● Speak clearly in a loud voice.

● In the following cases, it may be difficult for the other party to hear your voice.
• Driving on an unpaved road.
• Driving at high speeds.
• The roof or windows are open.
• The air conditioning vents are pointed towards the microphone.
• The sound of the air conditioning fan is loud.
• Bring your cellular phone closer to the microphone

● There might be an adverse effect on sound quality (such as noise or echo)

depending on the phone or network being used.

● If other Bluetooth® devices are connected at the same time, noise may be

generated in the hands-free system audio.

● If the multimedia system has been configured to use the Wi-Fi® function

(Wi-Fi® or Miracast®), noise may be generated in the hands-free system audio.

212

6-1. Precautions when using hands-free calls
● Cellular phone and multimedia system speaker volume/ringtone volume may

be synchronized. The speaker volume/ringtone volume with the multimedia
system cannot be synchronized depending on the cellular phone model.

NOTICE
Do not touch or poke sharp objects into the microphone. This may cause a
malfunction.

Precautions when selling or disposing of the vehicle
A lot of personal information is registered when using the hands-free system. Make sure to clear all information before selling or disposing of the
vehicle.
After initializing all the information, all the data in the multimedia system will
be initialized and returned to the factory default. It cannot be returned to the
state before initialization.
6

Related Links

Hands-free calls

Changing the security settings(P. 72)

213

6-1. Precautions when using hands-free calls

When hands-free calling might be malfunctioning
If you notice any of the following symptoms, refer to the following table for
possible reasons and solutions, and check the symptom again.
■ Using hands-free calls
Symptom

Hands-free calls cannot be used

Possible reason

Solution

Your cellular phone
does not support
Bluetooth®.

For a list of specific devices which
operation has been confirmed on
multimedia system, check with
any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer.

Your cellular phone
Use a cellular phone compatible
version is not compat- with Bluetooth® Core Specificaible with Bluetooth®.
tion Ver. 5.0 or later.

■ Cellular phone registration and connection
Symptom

Your cellular phone
cannot be registered

Possible reason

Solution

The cellular phone
registration operation
has not been completed.

Select the authentication button
when it is shown on your cellular
phone and continue the registration operation.

There is registration
information remaining
on either the cellular
phone or the multimedia system.

Perform the registration operation
again after deleting the registration information from both the
multimedia system and the cellular phone.

A cellular phone other
Manually connect the cellular
than the one to use is
®
already connected via phone to use via Bluetooth from
the
multimedia
system.
Bluetooth®.
Cannot connect via
Bluetooth®

The Bluetooth® function of the cellular
phone is not activated.

While the power switch is in ACC
or ON, activate the Bluetooth®
function on the cellular phone.

Perform the registration operation
The cellular phone
after deleting the registration inregistration informaformation from both the multimetion has been deleted.
dia system and the cellular phone.

214

6-1. Precautions when using hands-free calls

■ Calling and receiving calls
Symptom

Cannot make or receive calls

Possible reason

Solution

Outside the service
area

Move the vehicle into to a service
coverage area.

Call restriction (dial
lock) is turned on for
the cellular phone.

Turn off call restriction (dial lock)
for the cellular phone.

Possible reason

Solution

The cellular phone
profile does not support transferring contact data.

For a list of specific devices which
operation has been confirmed on
multimedia system, check with
any authorized Toyota retailer or
Toyota authorized repairer, or any
reliable repairer.

■ Contacts
Symptom

[Sync contacts] in
the Bluetooth® settings on the multimedia system is set to
off.

Set [Sync contacts] in the Bluetooth® settings on the multimedia
system to on.

The cellular phone is Select the contacts transfer apwaiting for approval to proval button on the cellular
transfer contacts.
phone.
An approval confirmaThe cellular phone is
tion screen is disnot set to always alplayed on the cellular
low.
phone

Set the cellular phone to always
allow.

The contact data is
registered elsewhere

The contacts are not
Please register the contacts to the
registered to the cellucellular phone.
lar phone.

Cannot edit contact
data

[Sync contacts] in
the Bluetooth® settings on the multimedia system is set to
on.

Set [Sync contacts] in the Bluetooth® settings on the multimedia
system to off.

215

6

Hands-free calls

Cannot transfer or
automatically transfer
contact data

6-1. Precautions when using hands-free calls

■ When using the Bluetooth® message function
Symptom

Possible reason

Solution

Messages cannot be
viewed.

Message transfer is
not enabled on the
cellular phone.

Enable message transfer on the
cellular phone (approve message
transfer on the phone).

New message notifications are not displayed.

Automatic message
transfer function is not Enable automatic transfer function
enabled on the cellu- on the cellular phone.
lar phone.

■ Other conditions
Symptom

Possible reason

Solution

The cellular phone
and multimedia system are too far apart.

Move the cellular phone and multimedia system closer together.

Turn the power off for any devices
that may be generating electroElectromagnetic inter- magnetic waves, such as Wi-Fi®
ference is being gen- devices.
erated.
Set the Wi-Fi® setting on the multimedia system to off.
Turn the power off for the cellular phone, and remove the battery
pack.

If symptoms do not
improve after applying
possible solutions.

Turn the cellular phone's Bluetooth® connection from off to on.
The cause lies in the
cellular phone.

Turn off the cellular phone's
Wi-Fi® connection.
Stop any security software or
background applications that are
running on the cellular phone.
Make sure to carefully confirm the
provider and operating status of
applications installed on the cellular phone before use.

INFORMATION
For more details, refer to the instruction manual included with the cellular phone.

216

6-1. Precautions when using hands-free calls

Related Links
Registering a Bluetooth® device from the multimedia system(P. 108)
Deleting a registered Bluetooth® device(P. 111)
Setting Bluetooth® devices(P. 99)
Disconnecting Wi-Fi®(P. 122)

6

Hands-free calls

217
