# 5-6. Android Auto operation

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 5 Audio, pages 196–198

operation

Auto

Android

5-6. Android Auto operation

Playing Android Auto
Play music files on an Android device connected to the USB Type-C port
or a wirelessly connected Android device. When an Android device is
connected, a button with the device’s name is displayed on the source
selection screen. This may not be displayed for some devices.
Connect Android Auto.
1
2
3
4

] from the main menu.
Touch [
Touch [Sources].
Touch [Android Auto] (device name).
Operate the Android Auto that is playing as necessary.
● Operating from the screen

[
] : Plays the currently playing track from the beginning. When at the start
of the track, the previous track will play from the beginning.
[

] : Pauses playback.

[

] : Plays.

[

] : Switches the tracks.

[

] : Displays the settable items.

[Open Android Auto] : Displays the Android Auto screen.
● Operating with the steering switches

[<]/[>] switches
Switch the tracks.

196

5-6. Android Auto operation

Related Links
Changing sound and media settings(P. 91)
Adjusting the sound of each source(P. 96)
Setting Bluetooth® devices(P. 99)
Using Android Auto with an unregistered smartphone(P. 132)
Using Android Auto with a registered smartphone(P. 135)

5

Audio

197

5-6. Android Auto operation

Precautions for playback of Android Auto
Pay special attention to the following information about playing Android
Auto.
This function is not available in some countries or areas.
INFORMATION
● This function cannot be used while Apple CarPlay is connected.

● Disconnecting a connected device while Android Auto is connected may cause

noise to be output.

● When a different source is switched to Android Auto while an Android device is

connected, playback will be started from the previously played track.

WARNING
For safety reasons, the driver should not operate the Android device while driving.

NOTICE
● Do not leave the Android device inside the vehicle. The inside of the vehicle

can become hot, which could cause the Android device to malfunction.

● Do not push down on or subject the connected Android device to unnecessary

pressure. The Android device or port may be damaged.

● Keep the port free of foreign matter. The Android device or port may be dam-

aged.

Related Links
Precautions when using Apple CarPlay and Android Auto(P. 123)

198
