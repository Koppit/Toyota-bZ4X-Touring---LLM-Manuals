# 6-4. How to receive calls

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 6 Hands-free calls, pages 226–228

calls

receive

to

How

6-4. How to receive calls

Answering calls
When a call is received, a ringtone sounds and the incoming call screen
or incoming call notification is displayed. When the voice control system
setting is on, the voice control system will start when a call is received.*1
● Answer the call by doing one of
the following.
● Touch [

].

● Press the [

] switch on the steer-

ing wheel.

INFORMATION
● The incoming call screen is not displayed while the rear view monitor system

screen is being displayed. Incoming call notification is provided by ringtone
only.

● During an incoming call, all sounds other than those coming from the hands-

free call are muted. However, voice guidance with a higher priority than the
hands-free call is not muted.

● Even if the cellular phone ringtone is set on the multimedia system, the

multimedia system may output a different ringtone depending on the cellular
phone settings.

● Depending on the cellular phone settings such as drive mode, you may not

be able to receive calls.

● Depending on the cellular phone model, the following may occur.
• The ringtone may be heard from both the vehicle speakers and the cellu-

lar phone.

• When receiving a call, the caller's phone number may not be displayed.
• If a call was received by operating the cellular phone directly, or if the

cellular phone has been set to automatically answer calls, the call may
stay on the cellular phone.

• If there was an incoming call while the cellular phone is transmitting data,

the incoming call screen may not be displayed on the multimedia system
and the ringtone may not sound.

● If the cellular phone supports automatic contact data transfer (PBAP), the

image data in contacts has been transferred, and [Display contact images]
is set to on, the contact's image will be shown alongside their phone number
when a call is received.

*1 : This function is not available in some languages.

226

6-4. How to receive calls
● If the ringtone setting on the multimedia system has been set to anything

other than the cellular phone ringtone, the ringtone that has been registered
on the multimedia system sounds, even if the cellular phone has been
placed in silent (vibrate) mode or the ringtone deleted.

● The call is declined when a call is received from a phone number that is set

to be declined in the cellular phone settings.

Related Links
Changing the voice control settings(P. 69)
Operating with the steering switches(P. 218)
Operating the system with voice control(P. 40)
Setting Bluetooth® devices(P. 99)

6

Hands-free calls

227

6-4. How to receive calls

Declining calls
On the multimedia system, calls can be declined using several methods.
● When receiving a call, perform any of the following operations to
decline the call.
● Touch [

].

● Operate the cellular phone directly.

● Speak a voice command to decline the call with the voice control system.

INFORMATION
The call is declined when a call is received from a phone number that is set to
be declined in the cellular phone settings.

Related Links
Operating with the steering switches(P. 218)
Operating the system with voice control(P. 40)

228
