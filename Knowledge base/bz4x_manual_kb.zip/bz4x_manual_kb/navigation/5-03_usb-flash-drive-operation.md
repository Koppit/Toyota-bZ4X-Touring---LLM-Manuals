# 5-3. USB flash drive operation

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 5 Audio, pages 183–189

operation

drive

flash

USB

5-3. USB flash drive operation

Playing music files on a USB flash drive
Play music files on a USB flash drive connected to the USB Type-C port
to enjoy music. When a USB flash drive is connected, a button with the
device's name is displayed on the source selection screen. This may not be
displayed for some devices.
Connect the USB flash drive.
] from the main menu.
1 Touch [
2 Touch [Sources].
3 Touch the device name or [USB].
If there are no video files on the USB flash drive, go onto Procedure 5.

4 Touch [Music].
5 Operate the USB flash drive that is playing as necessary.

5

[

Audio

● Operating from the screen

] : Performs random playback.
Each time this is touched, the mode switches between random playback for
all files or tracks, random playback canceled, and random playback of the
currently playing folder or album.

] : Plays the currently playing file or track from the beginning. When
[
at the start of the file or track, the previous file or track will play from the
beginning.
Touch and hold to fast rewind. Release to start playback from that position.
[

] : Pauses playback.

[

] : Plays

[

] : Switches the files or tracks.
Touch and hold to fast forward. Release to start playback from that position.

[

] : Touch to perform repeat playback.
Each time this is touched, the mode switches in order from repeat the currently playing file or track, repeat playback of the currently playing folder or
album, and repeat playback of all files or tracks.

183

5-3. USB flash drive operation
[

] : Displays the settable items.

List of submenu : Selects a track from the following conditions.
• [Artists] : Select a track by artist name.
• [Albums] : Select a track from the album name.
• [Folders] : Select a track from the folder name.
• [Songs] : Select a track from the song name.
• [Genres] : Select a track from the genre.
• [Composers] : Select a track from the composer name.
● Operating with the steering switches

[<]/[>] switches
Switch the files or tracks.
Press and hold to fast forward or
fast rewind. Release to start playback from that position.

Related Links
Connecting a device via the USB Type-C port(P. 38)
Changing sound and media settings(P. 91)
Adjusting the sound of each source(P. 96)

184

5-3. USB flash drive operation

Playing video files on a USB flash drive
Play video files on a USB flash drive connected to the USB Type-C port to
enjoy music or videos. When a USB flash drive is connected, a button with
the device's name is displayed on the source selection screen. This may
not be displayed for some devices.
Connect the USB flash drive.
1
2
3
4
5

]
Touch [
Touch [Sources].
Touch the device name or [USB].
Touch [Video].
Operate the USB flash drive that is playing as necessary.
5

● Operating during full screen display

Touch the screen to display the operation buttons.

Audio

] : Plays the currently playing file from the beginning. When at the start
[
of the file, the previous file will play from the beginning.
Touch and hold to fast rewind the video. Release to start playback from that
position.
[

] : Pauses video playback.

[

] : Plays the video.

[

] : Switches the files.
Touch and hold to fast forward the video. Release to start playback from that
position.
Touch and hold while the video is paused to perform slow playback.

[Move] : Moves the operation buttons.
Move the operation buttons when they overlap and make the video difficult to
see.
[

] : Displays the operation screen.

● Operating from the operation screen

185

5-3. USB flash drive operation
To display the operation screen, touch [

] on the full screen display.

[
] : Plays the currently playing file from the beginning. When at the start
of the file, the previous file will play from the beginning.
Touch and hold to fast rewind the video. Release to start playback from that
position.
[

] : Pauses video playback.

[

] : Plays the video.

[

] : Switches the files.
Touch and hold to fast forward the video. Release to start playback from that
position.
Touch and hold while the video is paused to perform slow playback.

[
[

] : Switches to full screen display.
] : Displays the settable items.

Folder names or file names of submenu : Touch a folder name to select the
folder, and touch a file name to change the playback file.
● Operating with the steering switches

[<]/[>] switches
Switch the files.
Press and hold to fast forward or
fast rewind the video. Release to
start playback from that position.
Press and hold while the full
screen video is paused to perform
slow playback.

Related Links
Connecting a device via the USB Type-C port(P. 38)
Changing sound and media settings(P. 91)
Switching the screen mode(P. 94)

186

5-3. USB flash drive operation

Adjusting the image quality(P. 95)
Adjusting the sound of each source(P. 96)

5

Audio

187

5-3. USB flash drive operation

Precautions for playback of USB flash drive
Pay special attention to the following information about playing a USB flash
drive.
INFORMATION
● Removing a USB flash drive or disconnecting a connected device during play-

back may cause noise to be output.

● When a USB flash drive is connected and the source is switched from another

source to the USB flash drive, the first file on the drive is played. If the same
USB flash drive (without its contents changed) is inserted again, playback will
be started from the previously played song.

● Reading a file in an unsupported format may affect operations.

● When a USB hub is used to connect multiple devices, devices other than the

first device to be recognized cannot be used.

WARNING
For safety reasons, the driver should not operate the USB flash drive while driving.

NOTICE
● Do not leave a USB flash drive inside the vehicle. The inside of the vehicle can

become hot, which could cause the USB flash drive to malfunction.

● Do not push down on or subject the connected USB flash drive to unnecessary

pressure. The USB flash drive or port may be damaged.

● Keep the port free of foreign matter. The USB flash drive or port may be

damaged.

■ Playback of MP3/WMA/AAC/WAV/FLAC/ALAC/Ogg Vorbis

When a USB flash drive storing MP3/WMA/AAC/WAV/FLAC/ALAC/Ogg
Vorbis files is connected, first all the files on the USB flash drive are
checked.
It is recommended that no files other than MP3/WMA/AAC/WAV/FLAC/
ALAC/Ogg Vorbis files and no unnecessary folders are written onto the
USB flash drive. This ensures that the USB flash drive check finishes
quickly.
INFORMATION
Many types of encoder software, such as freeware, are available in the market for
MP3/WMA/AAC/WAV/FLAC/ALAC/Ogg Vorbis. Depending on the encoder condi-

188

5-3. USB flash drive operation
tion or file format, audio quality deterioration or noise at playback start may occur,
or playback may not be possible.

NOTICE
Do not add an incorrect extension to a file. Adding an extension to a file that does
not match the file contents may result in files being incorrectly recognized and
played. This will output a loud noise that may damage the speakers.
Incorrect examples:
● Adding the ".mp3" extension to a file that is not MP3

● Adding the ".wma" extension to a file that is not WMA

Related Links
5

Changing sound and media settings(P. 91)
Information about media that can be used(P. 326)

Audio

Format information(P. 326)
USB flash drive(P. 331)

189
