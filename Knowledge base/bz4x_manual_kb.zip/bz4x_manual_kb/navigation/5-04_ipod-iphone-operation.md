# 5-4. iPod/iPhone operation

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 5 Audio, pages 190–192

operation

iPod/iPhone

5-4. iPod/iPhone operation

Playing iPod/iPhone
Play back music files on an iPod/iPhone connected to the USB Type-C
port. When an iPod/iPhone is connected, a button with the device’s name
is displayed on the source selection screen. This may not be displayed for
some devices.
INFORMATION
● Depending on the generation and model of iPod/iPhone that is connected, the

cover art image may look grainy or list scroll display may be slow.

● Some operations may not be available or they may operate differently, depend-

ing on the generation and model of iPod/iPhone that is connected.

Connect an iPod or iPhone.
1 Touch [

] from the main menu.
2 Touch [Sources].
3 Touch the device name or [USB].
4 Operate an iPod/iPhone that is playing as necessary.
● Operating from the screen

[

] : Performs shuffle playback.
Each touch switches the shuffle setting.*1

[
] : Plays the currently playing track from the beginning. When at the start
of the track, the previous track will play from the beginning.
Touch and hold to fast rewind. Release to start playback from that position.
[

] : Pauses playback.

[

] : Plays.

[

] : Switches the tracks.
Touch and hold to fast forward. Release to start playback from that position.

*1 : The order in which shuffle or repeat settings switch depends on the connected

device.

190

5-4. iPod/iPhone operation
[

] : Performs repeat playback.
Each touch switches the repeat setting.*1

[

] : Displays the settable items.

List of submenu : Selects a track from the following conditions.
• [Playlists] : Select a track from the playlist.
• [Artists] : Select a track by artist name.
• [Albums] : Select a track from the album name.
• [Songs] : Select a track from the song name.
• [Genres] : Select a track from the genre.
• [Composers] : Select a track from the composer name.
• [Radio] : Select a track from the radio station.

5

• [Audiobooks] : Select a track from the audiobook name.

Audio

• [Podcasts] : Select a track from the Podcast name.
● Operating with the steering switches

[<]/[>] switches
Switch the tracks.
Press and hold to fast forward or
fast rewind. Release to start playback from that position.

Related Links
Connecting a device via the USB Type-C port(P. 38)
Changing sound and media settings(P. 91)
Adjusting the sound of each source(P. 96)

*1 : The order in which shuffle or repeat settings switch depends on the connected

device.

191

5-4. iPod/iPhone operation

Precautions for playback of iPod/iPhone
Pay special attention to the following information about playing iPod/
iPhone.
INFORMATION
● This function cannot be used while Android Auto is connected.

● Disconnecting a port or disconnecting a connected device while in iPod/iPhone

mode may cause noise to be output.

● When a USB hub is used to connect multiple devices, devices other than the

first device to be recognized cannot be used.

● When switching from a different source to an iPod/iPhone while the iPod/

iPhone is connected, playback may be started from the previously played
track.*1

WARNING
For safety reasons, the driver should not operate the iPod/iPhone while driving.

NOTICE
● Do not leave the iPod/iPhone inside the vehicle. The inside of the vehicle can

become hot, which could cause the iPod/iPhone to malfunction.

● Do not push down on or subject the connected iPod/iPhone to unnecessary

pressure. The iPod/iPhone, or the port, may be damaged.

● Keep the port free of foreign matter. The iPod/iPhone or the port may be

damaged.

Related Links
iPhone/iPod(P. 329)

*1 : Depending on the device connected, operation may be different from descri-

bed.

192
