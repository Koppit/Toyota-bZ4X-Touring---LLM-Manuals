# 2-8. Navigation Settings

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 78–90

Settings

Navigation

2-8. Navigation Settings

Navigation system settings
Through the navigation system settings, various settings can be changed,
such as the map color, text size, etc.
] from the main menu.
1 Touch [
2 Touch [Navigation].
3 Touch the desired item.
● Map display settings
● Route settings

● Guidance settings

● Map update settings
● Traffic settings

● Other settings

Related Links
Changing the map display settings(P. 79)
Route settings(P. 81)
Guidance settings(P. 84)
Map database version and covered area(P. 175)
Traffic settings(P. 86)
Other settings(P. 87)

78

2-8. Navigation Settings

Changing the map display settings
] from the main menu.
1 Touch [
2 Touch [Navigation].
3 Touch the desired item.

Settings and registration

Setting

2

Description
Touch to turn the country border guidance setting on/off.

[Country border guidance]

When set to on, voice guidance will be
output when crossing country borders.
In addition, information on speed limits
and driving regulations for that country
is displayed.

[Map style customisation]

Touch to change the map display customization settings.

"Traffic information"

[Show road class]

Touch to change the traffic information
display road type setting.
After touching a desired road type,
touch [OK].

"Real-time information"
[Show traffic jam flows]

Touch to turn the display of congestion
and traffic jams, based on current information, on/off.

[Show free traffic flows]

Touch to turn the display of free flowing roads, based on current information, on/off.

[Traffic incident warning]

Touch turn the traffic incident warning
display on/off.

[Show POI icons settings]

Touch to change the Points Of Interest
(POI) icon settings.

79

2-8. Navigation Settings
Setting

Description

[3D view settings]

Touch to change the display angle of
the 3D map.

[On street parking suggestion](1)

Touch to turn the street parking suggestions on/off.
Touch to change the map language.

[Map language]

After touching [Region] or [System
Language], touch [OK].

(1) This function is not available in some countries or areas.

Related Links
Display angle setting(P. 80)
Map display customization settings(P. 80)

Map display customization settings
The map color and text size can be changed.
1
2
3
4

Touch [
] from the main menu.
Touch [Navigation].
Touch [Map style customization].
Touch the desired item.
A Touch to change the size of the
text on the map display.
B Touch to change the map color.

5 Touch [OK].

Display angle setting
The display angle of the 3D map can be set.
] from the main menu.
1 Touch [
2 Touch [Navigation].
3 Touch [3D view settings].
4 Touch [

] (increase angle) or [
5 Touch [OK].

80

] (decrease angle).

2-8. Navigation Settings

Route settings
] from the main menu.
Touch [
Touch [Navigation].
Touch [Route].
Touch the desired item.

Setting
[Area to avoid]

[Avoid traffic]

[Charging stations suggestion]

2

Settings and registration

1
2
3
4

Description
Touch to register and edit areas to
avoid.
Touch to change the avoid traffic function setting.
After touching [Auto], [manual] or
[off], touch [OK].
Automatic display of the charging stations list can be turned on/off.

Related Links
Areas to avoid settings(P. 81)
Search result list screen(P. 159)
Full route map screen(P. 163)

Areas to avoid settings
If an area is known to have road construction, is closed, or frequently has
traffic jams, it can be registered as an area to avoid, and routes which avoid
this area will be searched for.
1
2
3
4

] from the main menu.
Touch [
Touch [Navigation].
Touch [Route].
Touch [Area to avoid].

81

2-8. Navigation Settings

5 Touch the desired item.
A Displays a list of registered areas
to avoid. Touch to edit the touched
area to avoid.
B Touch to delete a registered area
to avoid.
C Touch to register an area to avoid.

Registering areas to avoid
1
2
3
4
5
6
7

Touch [
] from the main menu.
Touch [Navigation].
Touch [Route].
Touch [Area to avoid].
Touch [Add].
Scroll the map to search for an area to avoid.
Touch [OK].
The range of the area to avoid is displayed as a yellow square.

8 Touch [
](increase) or [
](decrease) to set the range of the
area to avoid and then touch [OK].
9 After changing the desired items on the editing screen, touch [OK].
INFORMATION
● If there are no other routes but passing through an area to avoid, search result

may include roads in the area to avoid.

● Minimizing an area to avoid can change it to an [

] (memory point to avoid)
display. Highways and sea routes in areas set to avoid may not be able to
be avoided in search results. Set specific memory point to avoid on the road
separately.

Editing areas to avoid
1
2
3
4
5

Touch [
] from the main menu.
Touch [Navigation].
Touch [Route].
Touch [Area to avoid].
Touch the area to avoid you wish to edit.

82

2-8. Navigation Settings

6 Touch the setting you wish to
change.
A Touch to change the name of the
area to avoid.
B Touch to change the area to avoid
and the range of the area to avoid.

2

Settings and registration

7 Touch [OK].

Deleting areas to avoid
1
2
3
4
5

Touch [
] from the main menu.
Touch [Navigation].
Touch [Route].
Touch [Area to avoid].
Touch [Edit].

6 Touch [

] of the area to avoid you wish to delete.

● [Del. All]: Delete all areas to avoid.

● [Cancel]: Cancel deletion of areas to avoid.

7 Touch [Complete].

83

2-8. Navigation Settings

Guidance settings
1
2
3
4

] from the main menu.
Touch [
Touch [Navigation].
Touch [Guidance].
Touch the desired item.

Setting

Description

[Intersection map]

Touch to turn the enlarged intersection
display on/off.

[Automatic zoom]

Touch to turn automatic zoom on/off.
Touch to set speed limit information
on/off.

[Speed limit](1)

[Speed camera](1)

84

If the vehicle has entered a time-dependent speed limit area (shopping
center area, pedestrian zone, school
zone, etc.) within specified time, a
mark will be displayed near the warning and speed limit information display.
Touch to change the speed cameras
icons display setting.
After touching [On], [On & Audible] or
[Off], touch [OK].

[Guidance with street names]

Touch to set the street name guidance
on/off.

[Weather warning](1)

Touch to set the weather warning on/
off.

[Traffic jam warning guidance]

Touch to turn traffic jam voice guidance on/off.

[Landmark voice guidance]

Touch to set the Landmark voice guidance on/off.

2-8. Navigation Settings
Setting

Description
Touch to change the voice guidance
language.
● After touching the language, touch

[Guide language]

[OK].

Settings and registration

● Although the general voice guid-

2

ance language can be changed,
the language for location specific
names cannot be changed.

(1) This function is not available in some countries or areas.

Related Links
Lane display screens(P. 171)
Speed cameras(P. 151)

85

2-8. Navigation Settings

Traffic settings
Traffic information such as traffic congestion or traffic incident warnings can
be made available.
1
2
3
4

]from the main menu.
Touch [
Touch [Navigation].
Touch [Traffic].
Touch the desired item.

Setting

Description

"TMC settings"
[Auto]

Touch change the traffic information
reception settings.

"Receiving status"

86

[Frequency]

Touch to change the frequency. (When
TMC automatic reception setting is
turned off)

[Station name]

Displays the station name.

[Emergency events]

Touch to display the emergency
events list. Touch list to display details.

2-8. Navigation Settings

Other settings
] from the main menu.
Touch [
Touch [Navigation].
Touch [Other].
Touch the desired item.

Setting

2

Settings and registration

1
2
3
4

Description
Touch to delete the destination history.

[Delete recent destinations]

After touching the destinations you
wish to delete, touch [OK]. To delete
all, touch [Delete all], and then touch
[OK].

[Favourites]

Touch to edit favorites.

[Position/Direction]

Touch to correct the position of your
vehicle.

[Copyright]

Touch to display the copyright.

Related Links
Favorites settings(P. 87)
Position/Direction calibration(P. 89)

Favorites settings
1
2
3
4

Touch [
] from the main menu.
Touch [Navigation].
Touch [Other].
Touch [Favourites].

87

2-8. Navigation Settings

5 Touch the desired item.
A Displays a list of registered favorites. Touch to edit the touched favorite.
B Touch to delete a registered favorites.

Registering favorites
To register a point as a favorite, when the information screen for a point is
displayed on the map screen, touch [

] to register the point.

▶ When the map is scrolled

▶ Information screen for a point

INFORMATION
Up to 400 items can be saved in the favorites.

Related Links
Displaying information for a point(P. 146)
Full route map screen(P. 163)

88

2-8. Navigation Settings

Editing favorites list
Touch [
] from the main menu.
Touch [Navigation].
Touch [Other].
Touch [Favourites].
Touch the favorite you wish to edit.
Touch the desired item.

2

Settings and registration

1
2
3
4
5
6

A Edit your favorite name.
B Edit the phone number.
C Touch to register the current point
as home.
D Touch to register the current point
as a frequently visited point.
E Change the icon displayed on the
map.

7 Touch [OK].
INFORMATION
When a frequently visited point is registered, it will be displayed at the top of
the favorites list when setting a destination.

Deleting favorite
1
2
3
4
5

Touch [
] from the main menu.
Touch [Navigation].
Touch [Other].
Touch [Favourites].
Touch [Edit].

6 Touch [

] of the favorite you wish to delete.

● [Del. All]: Delete all favorites.

● [Cancel]: Cancel deletion of favorites.

7 Touch [Complete].

Position/Direction calibration
When driving, the current position mark will be automatically corrected by
GPS signals. If GPS reception is poor at the current location, the current
position mark can be adjusted manually.
1 Touch [

] from the main menu.

89

2-8. Navigation Settings

2
3
4
5
6

Touch [Navigation].
Touch [Other].
Touch [Position / Direction].
Scroll the map to the desired point and touch [OK].
Touch an arrow to adjust the direction of the current position mark
and touch [OK].

90
