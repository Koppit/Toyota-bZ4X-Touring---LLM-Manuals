# 2-10. Wi-Fi® Settings

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 2 Settings and registration, pages 97–98

Wi-Fi®Settings

2-10. Wi-Fi® Settings

Changing Wi-Fi® settings
Change Wi-Fi® settings.
1 Touch [
] from the main menu.
2 Touch [Wi-Fi] on the sub menu.
3 Set each item.

2

Settings and registration

● "Wi-Fi settings"

Setting

Description

[Wi-Fi] Enables or disables the Wi-Fi® function.
• A message may be displayed depending on the multimedia system set-

tings. Perform the operation according to the guidance on the screen.

• Turning on [Wi-Fi] will display nearby networks that are available.
• Turning off [Wi-Fi] will disconnect the Wi-Fi® connection.

● "Available networks" ("Available networks" will display while [Wi-Fi] is on.)

Setting

Description

Name of network to connect to (Network SSID)

Connects to the network touched.

Name of network display (Network
SSID)[

]

Displays the network information
display.

• Network name may display as duplicate when more than one MAC address

shares the same network.

• A maximum of 30 networks can be displayed. The list is automatically

updated every six seconds.

• If there are devices using the same network name (Network SSID), it can-

not identify which device to use. If using multiple devices, use different
network names (Network SSIDs) for each device.

● Network information display (Displays when [

] for the network name is

touched.)

97

2-10. Wi-Fi® Settings
Setting

Description

[Auto connect]*1

Turns on or off the setting to automatically connect when
searching for networks.

"Network SSID"

Displays the network name (Network SSID).

"MAC address"

Displays the MAC address of the network.

"Security"

Displays the security protocol of the network.

"Frequency
band"

Displays the network frequency.

Deletes the connection history of the selected network
[Forget this net- from the multimedia system.
work]*1
The deleted network will be recognized as a network
which has never been connected to the system before.
• [Forget this network] does not disconnect the current Wi-Fi® network

connection. The network information will not be remembered and not reconnect to this Wi-Fi® network when restarting Wi-Fi®.

INFORMATION
● The network connection history retains up to 20 items, deleting the oldest

when a new one is saved.

● Insecure networks are not registered in the network connection history.

Related Links
Precautions when using Wi-Fi® devices(P. 118)
Connecting to a network using Wi-Fi® (P. 120)

*1 : Only networks with a connection history to the multimedia system are dis-

played.

98
