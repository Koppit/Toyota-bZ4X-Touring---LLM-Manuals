# 4-4. Destination setting

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 4 Navigation, pages 163–169

setting

Destination

4-4. Destination setting

Full route map screen
After setting a destination, the full route map screen will be displayed. On
the full route map screen, the desired route can be selected or the route
information can be checked.
A Displays the name or address of

checked. Restriction information can be switched by touching [

] or

[
].
I Touch to select another route.
J Touch to start route guidance. Touch and hold to start a demo of route
guidance to the destination.
K Touch to select the desired route other than the currently navigating
route.
● Select from the following three routes: recommended route, time priority route, and general road priority route. As initial setting, recommended route is selected.
INFORMATION
If the set destination is outside of the EV range, the charging stations suggestion
is displayed on the screen. Touching [Add charging points] automatically adds
charging stops to the route.
*1 : This function is not available in some countries or areas.

163

4

Navigation

the destination.
B Touch to register the destination
as a favorite.
C Displays the current weather at
the destination.*1
D Displays the distance, travel time,
and estimated time of arrival from
the starting point to the destination.
When multiple destinations are set, touch to display a list of the estimated time of arrival for each destination.
E Touch to display the route options.
F Touch to mute voice guidance.
G Touch to display detailed information about the destination.
H Touch to display driving restrictions information.
If there are driving restrictions (exhaust restrictions or ecological vehicle
sticker required segments) along a route, the restriction details can be

4-4. Destination setting

Related Links
Route settings(P. 81)
Search result list screen(P. 159)
Viewing a route guidance demo(P. 165)
Changing route options(P. 166)
Changing the route(P. 167)
Editing waypoints(P. 169)

164

4-4. Destination setting

Viewing a route guidance demo
Before route guidance is started, a demo of the route guidance can be
viewed.
● Touch and hold [Go] on the full route screen.
To end the demo, touch [

] or begin driving.

4

Navigation

165

4-4. Destination setting

Changing route options
The route search conditions can be changed, such as to avoid routes that
include tolls or expressways.
1 Touch [Route options] on the full route map screen.
2 Change the setting of the item
for the desired condition.
A Touch to change between avoiding/not avoiding specific types of
roads. Route guidance will be performed avoiding types of roads
which are set to on.
B Touch to change the order of set
waypoints.
C Touch to add, delete, or change
waypoints on the route.

Related Links
Setting points to pass through on a route(P. 168)
Editing waypoints(P. 169)

166

4-4. Destination setting

Changing the route
A desired route can be selected from several routes with different conditions.
1 Touch [Alternative route] on the full route map screen.
2 After selecting the desired route, touch [OK].
INFORMATION
● New alternative routes will be delivered sequentially.*1

● Changes the route by touching the route directly on the map screen of full

route map screens.

4

Navigation

*1 : This function is displayed only when using Connected navigation.

167

4-4. Destination setting

Setting points to pass through on a route
After setting a destination, points to pass through on a route can be set.
1 Touch [
] on the waypoint setting screen.

2 Touch the point you want to add as a waypoint on the map and
touch [Complete].
[

168

]: Delete the corresponding waypoint.

4-4. Destination setting

Editing waypoints
Waypoints can be deleted or their order set on the route can be changed.
1 Touch to display [Move up] and
[Move down] and change the order of the waypoints.
]: Delete the corresponding way[
point.

4

Navigation

2 Touch [OK].
Related Links
Searching for a destination(P. 155)

169
