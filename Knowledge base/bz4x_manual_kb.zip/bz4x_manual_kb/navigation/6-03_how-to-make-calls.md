# 6-3. How to make calls

> Source: Toyota bZ4X Touring — Navigation & Multimedia Manual, 6 Hands-free calls, pages 220–225

calls

make

to

How

6-3. How to make calls

Making calls from call history
Calls can be made to phone numbers that have been recorded in the call
history as outgoing or incoming calls.
] from the main menu.
1 Touch [
2 Touch [Recents].
3 Select the contact.
For phone numbers that are not registered in the contact, the phone number
will be displayed as it is.

4 Touch the desired phone number.

INFORMATION
● The latest 100 entries in the call history are shown. If the call history ex-

ceeds 100 entries, history items are automatically deleted starting from the
oldest.

● The outgoing call history is registered as follows, depending on conditions.
• If the call was placed to a phone number registered in contacts or to the

multimedia system, the name and image data are also registered if they
exist.

• When several calls have been made to the same phone number, the

number of calls will be displayed after the name of the contact.

● The incoming call history is registered as follows, depending on conditions.
• If the call was received from a phone number registered in contacts, the

name and image data are also registered if they exist.

• If multiple calls were received from the same phone number, all are

registered.

• Missed calls and declined calls are also registered.
• If the other party does not support caller ID, the call is registered as

"Unknown".

● Calls that were placed on hold are also registered to the call history.

● Depending on the model of cellular phone, it may not be possible to make

international calls.

220

6-3. How to make calls

Making calls from the favorites list
Make a call from your favorites list by adding your contacts to your favorites.
] from the main menu.
1 Touch [
2 Touch [Favourites].
3 Select the person you want to
call from your favorites list.
4 Touch the desired phone number.

INFORMATION

6

transferred to the multimedia system.

● Depending on the cellular phone model, favorites cannot be transferred.

● The favorites data can also be registered from the data registered in con-

tacts on the multimedia system.

Related Links
Setting Bluetooth® devices(P. 99)
Transferring contact data(P. 236)

221

Hands-free calls

● When [Sync contacts] is ON, cellular phone favorites are automatically

6-3. How to make calls

Making calls from contacts
Calls can be made from the contacts registered on the multimedia system.
1
2
3
4

] from the main menu.
Touch [
Touch [Contacts].
Select a contact.
Touch the desired phone number.

INFORMATION
● If [Sync contacts] is displayed on the screen, touching it transfers the

contact data of the cellular phone to the multimedia system.

● If no contact data has been registered, contact data must be transferred or

added to the multimedia system.

● The contact data of the hands-free phone that is connected is displayed on

the multimedia system. When the hands-free phone is switched during a
2-phone connection, the contact data also switches.*1

Related Links
Adding new contact data to contacts(P. 240)
Transferring contact data(P. 236)

*1 : This function is not available in some countries or areas.

222

6-3. How to make calls

Making calls from keypad
Enter the phone number on the keypad to make a call.
] from the main menu.
1 Touch [
2 Touch [Keypad].
3 Enter the phone number.
4 Touch [
], or press the [
switch on the steering.

]

Calls can also be made by touching a
contact displayed on the submenu.

INFORMATION
Depending on the cellular phone model, it may be necessary to perform operations on the cellular phone.

6

Hands-free calls

Related Links
Operating with the steering switches(P. 218)

223

6-3. How to make calls

Calling Toyota roadside assist service*1
Toyota roadside assist service can be called from the favorites list.The call
must be made from a country that supports the use of Toyota roadside
assist service.The country must be registered in order to use this function.
1
2
3
4

] from the main menu.
Touch [
Touch [Favourites].
Touch [Toyota assistance] on the favorites list.
Touch the phone number.

Registering the country in Toyota assistance
The country must be registered in Toyota assistance in order to use Toyota
roadside assist service.
1 Touch [

] from the main menu.
2 Touch [Favourites].
3 Touch [Toyota assistance] on
the favorites list.
4 Touch [Select a country].
5 Select the country.
6 Touch [OK].

*1 : This function is not available in some countries or areas.

224

6-3. How to make calls

Calling using a wait or pause signal
Numbers that include wait (w) or pause (p) signals can be called. The
transmission of the numbers that follow the wait (w) or pause (p) signal is
suspended or stopped for about 2 seconds.
● A wait (w) signal suspends the transmission of the number. Transmission

resumes after an operation by the user until the next wait (w) signal.
When a pause (p) signal is included partway, the transmission stops for 2
seconds before sending the following number.
● A pause (p) signal stops the transmission of the number for about 2
seconds.
] from the main menu.
Touch [
Touch [Contacts].
Select the contact.
Select the phone number that includes a wait (; or w) or pause (, or
p) signal.
5 If the phone number includes a

1
2
3
4

].

Hands-free calls

wait (w) signal, touch [

6

When [
] is touched, the number
that was suspended by the wait (w)
signal resumes transmission until the
next wait (w) signal. When a pause (p)
signal is included partway, the transmission stops for 2 seconds before
sending the following number.

INFORMATION
● Depending on the model of cellular phone, the wait signal may be displayed

as a semi colon (;) and the pause signal may be displayed as a comma (,)
on the cellular phone screen.

● This function is used to make international calls.

● Release tones can be used when automated operation of a phone based

service such as an answering machine or bank phone service is desired.
A phone number with wait(w) or pause(p) signals can be registered in the
contact list.

225
